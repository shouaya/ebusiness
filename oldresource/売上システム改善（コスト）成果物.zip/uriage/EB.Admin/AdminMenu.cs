﻿using System;
using System.Drawing;
using System.Windows.Forms;
using EB.Common;

namespace EB.Admin
{
    public partial class AdminMenu : Form
    {
        #region 初期化
        public AdminMenu()
        {
            this.Hide();
            new EB.Menu.Login(() =>
            {
                this.Show();
                InitializeComponent();
            }).ShowDialog();
        }
        #endregion

        #region 管理台帳

        private void ManagementBook_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Admin.ManagementBook.ImportExport", "EB.Admin.ManagementBook", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        #endregion
    }
}
