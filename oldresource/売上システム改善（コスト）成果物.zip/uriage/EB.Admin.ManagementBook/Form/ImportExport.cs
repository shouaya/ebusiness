﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.IO;
using EB.Common;
using EB.DBAcess;
using OfficeOpenXml.Style;
using OfficeOpenXml;

namespace EB.Admin.ManagementBook
{
    public partial class ImportExport : DialogForm
    {
        public ImportExport()
        {
            InitializeComponent();
        }

        #region インスポート
        private void import_Click(object sender, EventArgs e)
        {
            string filename = CommonHandler.fileDialog("エクセル|*.xlsx|エクセル（2003）|*.xls");
            if (!string.IsNullOrEmpty(filename))
            {
                this.input(filename);
            }
        }
        private void input(string filename)
        {
            this.Cursor = Cursors.WaitCursor;
            FileInfo newFile = new FileInfo(filename);
            ExcelPackage package = new ExcelPackage(newFile);
            // get the first worksheet in the workbook
            ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
            ThreadPoolHelper.StartThread(this,
                    () => { 
                        bool isloop = true;
                        int row = 1;
                        List<ExcelModel> model = ExportModel.getModel();
                        IList<IF_ManagementBook> entities = new List<IF_ManagementBook>();
                        while(isloop){
                            row++;
                            object val = worksheet.Cells[row, 1].Value;
                            isloop = !(val==null);
                            if (isloop)
                            {
                                IF_ManagementBook entity = new IF_ManagementBook();
                                //社員
                                string str_employee = this.getCellValue(worksheet,row,2);
                                if (string.IsNullOrEmpty(str_employee)) { continue; }
                                entity.EmployeeID = this.getEmployeeID(str_employee);

                                //営業担当1
                                entity.Salesman1ID = this.getSalesmanID(this.getCellValue(worksheet, row, 3));
                                //営業担当2
                                entity.Salesman2ID = this.getSalesmanID(this.getCellValue(worksheet, row, 4));
                                //顧客
                                entity.CustomerID = this.getCustomerID(this.getCellValue(worksheet, row, 9));
                                

                                //支払いサイト
                                string str_paysite = this.getCellValue(worksheet, row, 23);
                                int paysite = CommonHandler.ToInt(str_paysite);
                                entity.PaymentType = (paysite / 30).ToString();
                                int payday = paysite%30;
                                if (payday > 28 || payday == 0)
                                {
                                    payday = 99;
                                }
                                entity.PaymentDay = payday.ToString();

                                entity.DeptName = this.getCellValue(worksheet, row, 5);
                                entity.CustSalesman = this.getCellValue(worksheet, row, 10);
                                entity.ContractName = this.getCellValue(worksheet, row, 11);
                                entity.ProjectName = this.getCellValue(worksheet, row, 12);
                                entity.WorkAddr = this.getCellValue(worksheet, row, 13);
                                entity.WorkMonth = this.getCellValue(worksheet, row, 16);
                                entity.StartDate = this.getCellValue(worksheet, row, 14);
                                entity.EndDate = this.getCellValue(worksheet, row, 15);
                                entity.Amount = CommonHandler.ToDecimal(this.getCellValue(worksheet, row, 17));
                                entity.MinHour = CommonHandler.ToDecimal(this.getCellValue(worksheet, row, 18));
                                entity.MaxHour = CommonHandler.ToDecimal(this.getCellValue(worksheet, row, 20));
                                entity.MinusUnitPrice = CommonHandler.ToDecimal(this.getCellValue(worksheet, row, 19));
                                entity.PlusUnitPrice = CommonHandler.ToDecimal(this.getCellValue(worksheet, row, 21));
                                entity.Quantity = CommonHandler.ToDecimal(this.getCellValue(worksheet, row, 22));
                                entity.TranExpense = CommonHandler.ToDecimal(this.getCellValue(worksheet, row, 24));
                                entity.Price = CommonHandler.ToDecimal(this.getCellValue(worksheet, row, 27));
                                entity.Memo = this.getCellValue(worksheet, row, 28);
                                entity.OrderDate = this.getCellValue(worksheet, row, 32);
                                entity.OrderNo = this.getCellValue(worksheet, row, 33);
                                entity.UpdateFlg = "1";
                                entity.DeleteFlg = "0";
                                if (this.insertCheck(entity))
                                {
                                    entities.Add(entity);
                                }
                                //BL_ManagementBook.GetInstance().InsertManagementBook(entity);
                            }
                        }
                        if (entities != null && entities.Count > 0)
                        {
                            BL_ManagementBook.GetInstance().InsertManagementBook(entities);
                        }
                        return true; 
                    },
                    (obj) =>
                    {
                        Common.MessageHelper.ShowinforMessageByID("EB0012","台帳導入");
                        this.Cursor = Cursors.Default;
                    }
                    );

        }
        /// <summary>
        /// 登録していないか
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        private bool insertCheck(IF_ManagementBook entity)
        {
            IF_ManagementBook entity_search = new IF_ManagementBook();//一致する条件
            entity_search.EmployeeID = entity.EmployeeID;
            entity_search.CustomerID = entity.CustomerID;
            entity_search.ContractName = entity.ContractName;
            entity_search.WorkMonth = entity.WorkMonth;
            entity_search.WorkAddr = entity.WorkAddr;

            DataTable dt = BL_ManagementBook.GetInstance().SelectManagementBook(entity_search);
            return !(dt != null && dt.Rows.Count > 0);
        }

        private int getCustomerID(string str_customer)
        {
            int res = 0;
            DataRow dr_Customer = this.findCustomerinfo(str_customer);
            if (dr_Customer == null)
            {
                IF_Customer entity_customer = new IF_Customer { CustomerName = str_customer, DeleteFlg = "0" };
                BL_Customer.GetInstance().InsertCustomer(entity_customer);
                this._customerinfo = null;
                dr_Customer = this.findCustomerinfo(str_customer);
            }
            if (dr_Customer != null)
            {
               res = CommonHandler.ToInt(dr_Customer["CustomerID"].ToString());
            }
            return res;
        }
        private int getSalesmanID(string str_salesman)
        {
            int res = 0;
            DataRow dr_Salesman = this.findUserInfo(str_salesman);
            if (dr_Salesman != null)
            {
                res = CommonHandler.ToInt(dr_Salesman["EmployeeID"].ToString());
            }
            return res;
        }
        private int getEmployeeID(string str_employee)
        {
            //string str_employee = this.getCellValue(worksheet, row, 2);
            DataRow dr_Employee = this.findUserInfo(str_employee);
            if (dr_Employee == null)
            {
                IF_Employee entity_employee = new IF_Employee();

                entity_employee.EmployeeName = str_employee;//社員名
                entity_employee.JapaneseSpell = "";//フリカナ
                entity_employee.Birthday = "";//生年月日
                entity_employee.Experience = "";//経験年数
                entity_employee.Degree = "";//学歴
                entity_employee.Certificate = "";//資格
                entity_employee.SiirePrice = "";//仕入先単価
                entity_employee.SiireID = "";//仕入先ID
                entity_employee.SiireSales = "";//仕入先担当
                entity_employee.Skill = "0";//技術

                entity_employee.Language = "";//言語
                entity_employee.PostCode = "";//郵便番号
                entity_employee.Address1 = "";//住所１
                entity_employee.Address2 = "";//住所２
                entity_employee.Tel = "";//TEL
                entity_employee.Company = "";//勤務先
                entity_employee.Remark = "";//評価
                entity_employee.Note = "";//備考
                entity_employee.EmployeeType = "1";//社員区分
                entity_employee.DeleteFlg = "0";

                BL_Employee.GetInstance().InsertEmployee(entity_employee);
                this._userinfo = null;
                dr_Employee = this.findUserInfo(str_employee);
            }
            return CommonHandler.ToInt(dr_Employee["EmployeeID"].ToString());
        }
        private string getCellValue(ExcelWorksheet worksheet, int row, int col)
        {
            object val = worksheet.Cells[row, col].Value;
            if (val != null)
            {
                return val.ToString();
            }
            return "";
        }

        private DataTable _userinfo;
        private DataRow findUserInfo(string EmployeeName)
        {
            if (this._userinfo == null)
            {
                this._userinfo = BL_Employee.GetInstance().SelectAllEmployee(null);
                for (int i = 0; i < this._userinfo.Rows.Count; i++)
                {
                    this._userinfo.Rows[i]["EmployeeName"] = CommonHandler.replaceSpace(this._userinfo.Rows[i]["EmployeeName"].ToString());
                }
            }
            EmployeeName = CommonHandler.replaceSpace(EmployeeName);
            DataRow[] res = this._userinfo.Select("EmployeeName='" + Common.CommonHandler.StrConv(EmployeeName, false) + "' OR EmployeeName='" + Common.CommonHandler.StrConv(EmployeeName, true) + "'");
            if (res.Length>0)
            {
                return res[0];
            }
            else
            {
                return null;
            }
        }
        private DataTable _customerinfo;
        private DataRow findCustomerinfo(string CustomerName)
        {
            if (this._customerinfo == null)
            {
                this._customerinfo = BL_Customer.GetInstance().SelectAllCustomer(null); ;
                for (int i = 0; i < this._customerinfo.Rows.Count; i++)
                {
                    this._customerinfo.Rows[i]["CustomerName"] = CommonHandler.replaceSpace(this._customerinfo.Rows[i]["CustomerName"].ToString());
                }
            }
            CustomerName = CommonHandler.replaceSpace(CustomerName);
            DataRow[] res = this._customerinfo.Select("CustomerName='" + Common.CommonHandler.StrConv(CustomerName, false) + "' OR CustomerName='" + Common.CommonHandler.StrConv(CustomerName, true) + "'");
            if (res.Length > 0)
            {
                return res[0];
            }
            else
            {
                return null;
            }
        }
        #endregion



        #region エクスポート
        private void export_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            string folder = CommonHandler.folderDialog();
            if (!string.IsNullOrEmpty(folder))
            {

                IF_ManagementBook entity = new IF_ManagementBook();

                if (!string.IsNullOrEmpty(cobYear.Text) && !string.IsNullOrEmpty(cobMonth.Text))
                {
                    entity.WorkMonth = CommonHandler.ToString(cobYear.Text) + "/" + CommonHandler.ToString(cobMonth.Text);
                }
                if (!string.IsNullOrEmpty(cobYearEnd.Text) && !string.IsNullOrEmpty(cobMonthEnd.Text))
                {
                    entity.WorkMonthEnd = CommonHandler.ToString(cobYearEnd.Text) + "/" + CommonHandler.ToString(cobMonthEnd.Text);
                }
                ThreadPoolHelper.StartThread(this,
                    () => {
                        DataTable dt = BL_ManagementBook.GetInstance().SelectManagementBook(entity);
                        this.output(folder, dt);
                        return true;
                    },
                    (obj) =>
                    {
                        this.Cursor = Cursors.Default;
                    });

            }
        }
        private void output(string folder, DataTable dt)
        {
            string filename = @"\ManagementBook.xlsx";
            FileInfo newFile = new FileInfo(folder + filename);
            if (newFile.Exists)
            {
                newFile.Delete();  // ensures we create a new workbook
                newFile = new FileInfo(folder + filename);
            }
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                // add a new worksheet to the empty workbook
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Inventory");

                int i = 1, j = 0;
                IList<ExcelModel> model = ExportModel.getModel();
                foreach (ExcelModel em in model)
                {
                    j++;
                    worksheet.Cells[i, j].Value = em.key;
                }

                foreach (DataRow dr in dt.Rows)
                {
                    i++;
                    j = 0;
                    foreach (ExcelModel em in model)
                    {
                        j++;
                        if (em.key == "支払サイト")
                        {
                            int Paymentsite1 = CommonHandler.ToInt(dr["PaymentType"].ToString())*30;
                            int Paymentsite2 = CommonHandler.ToInt(dr["PaymentDay"].ToString());
                            if (Paymentsite2 == 99)
                            {
                                Paymentsite2 = 30;
                            }

                            worksheet.Cells[i, j].Value = Paymentsite1 + Paymentsite2;
                            continue;
                        }
                        if (string.IsNullOrEmpty(em.value))
                        {
                            worksheet.Cells[i, j].Value = "";
                        }
                        else
                        {
                            worksheet.Cells[i, j].Value = dr[em.value].ToString();
                        }
                    }
                }

                worksheet.Cells.AutoFitColumns(0);  //Autofit columns for all cells

                // set some document properties
                package.Workbook.Properties.Title = "Invertory";
                package.Workbook.Properties.Author = "Hikaru";
                package.Workbook.Properties.Comments = "売上システムー管理台帳";

                // set some extended property values
                package.Workbook.Properties.Company = "E-Business Inc.";

                // set some custom property values
                package.Workbook.Properties.SetCustomPropertyValue("Checked by", "Hikaru");
                package.Workbook.Properties.SetCustomPropertyValue("AssemblyName", "EB.Admin");
                // save our new workbook and we are done!
                package.Save();
            }
        }
        #endregion
    }
}
