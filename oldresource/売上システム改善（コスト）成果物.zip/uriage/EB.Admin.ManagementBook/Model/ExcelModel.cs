﻿using System;

namespace EB.Admin.ManagementBook
{
    public class ExcelModel
    {
        public string key { get; set; }
        public string value { get; set; }
    }
}
