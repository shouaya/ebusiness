﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Text;
using System.Windows.Forms;
using EB.Common;
using EB.DBAcess;

namespace EB.Report
{
    public partial class SalesListForm : DialogForm
    {
        BL_Report _bl = BL_Report.GetInstance();

        public SalesListForm()
        {
            InitializeComponent();
            bindCommbox(); 
        }
        /// <summary>
        /// 初期マスタ表示
        /// </summary>
        private void bindCommbox()
        {
            ThreadPoolHelper.StartThread(this,
                () =>
                {
                    return _bl.SelectYears();//売上年
                },
                (obj) => {
                    this.cobYear.DataSource = obj as DataTable;
                    int i = this.cobYear.Items.Count;

                    this.cobYear.SelectedIndex = i - 1;
                }
                );
            this.getCustomerList();
        }
        /// <summary>
        /// 顧客様を検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCustomer_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.getCustomerList();
            }

        }
        /// <summary>
        /// 顧客様リスト
        /// </summary>
        private void getCustomerList()
        {
            ThreadPoolHelper.StartThread(this,
                () =>
                {
                    DataTable dt = _bl.SelectCustomerName(this.txtCustomer.Text);//顧客様
                    //空白行
                    DataRow dr = dt.NewRow();
                    dr[cobCustomer.ValueMember] = 0;
                    dr[cobCustomer.DisplayMember] = "";
                    dt.Rows.InsertAt(dr, 0);
                    return dt;
                },
                (obj) =>
                {
                    cobCustomer.DataSource = obj as DataTable;
                    cobCustomer.SelectedIndex = -1;
                }
                );
            ThreadPoolHelper.StartThread(this,
                () =>
                {
                    DataTable dt = BL_Employee.GetInstance().SelectSalesEmployee();//営業
                    //空白行
                    DataRow dr = dt.NewRow();
                    dr[this.cobSalesMan.ValueMember] = 0;
                    dr[this.cobSalesMan.DisplayMember] = "";
                    dt.Rows.InsertAt(dr, 0);
                    return dt;
                },
                (obj) =>
                {
                    this.cobSalesMan.DataSource = obj as DataTable;
                    this.cobSalesMan.SelectedIndex = -1;
                }
                );
        }
        /// <summary>
        /// 検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cob_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Boolean iswithbill = this.iswithBill.Checked;
            Boolean isGroupbyCustomer = this.isGroupbyCustomer.Checked;
            String month = this.cobYear.SelectedValue.ToString() + "/" + this.cobMonth.Text;
            int customerID = CommonHandler.ToInt(this.cobCustomer.SelectedValue);
            int salesManID = CommonHandler.ToInt(this.cobSalesMan.SelectedValue);

            List<string> ids = new List<string>();
            if (this.cobSalesGroup1.Checked)
            {
                ids.Add("245");
                ids.Add("246");
                ids.Add("250");
                ids.Add("412");
                this.cobSalesMan.SelectedIndex = -1;
                this.cobSalesMan.Enabled = false;
            }
            else
            {
                this.cobSalesMan.Enabled = true;
                if (salesManID > 0)
                {
                    ids.Add(salesManID.ToString());
                }
            }

            ThreadPoolHelper.StartThread(this,
                  () =>
                  {
                     
                      return _bl.SelectAll(isGroupbyCustomer, iswithbill, month, customerID, ids);
                  },
                  (obj) =>
                  {
                      DataTable table = obj as DataTable;

                      //add by liuyuqi start
                      int totalCount = table.Rows.Count;
                      //add by liuyuqi start
                      
                      if (isGroupbyCustomer == false)
                      {
                          this. Subtotal(table);
                      }
                      else {

                          this.SalesList.DataSource = table as DataTable;
                      }

                      this.SalesList.Focus();
                      // edit by liuyuqi start
                      //salesCount.Text = "件数：" + this.SalesList.RowCount.ToString();
                      salesCount.Text = "件数：" + totalCount.ToString();
                      // edit by liuyuqi End
                  }
                  );
        }
        /// <summary>
        /// 小計
        /// </summary>
        /// <param name="table"></param>
        private void Subtotal(DataTable table)
        {
            DataTable table02 = table.Clone();
            table02.Clear();
            DataRow sumRow = table.NewRow();

            int result;
            string CustomerName = "";
            int RowCnt111 = table.Rows.Count;

            // add by liuyuqi start
            // 社員数をサマリ
            int staffSum = 0;
            // 前回社員ID
            string lastStaff = "";
            // 今回社員ID
            string currStaff = "";
            // add by liuyuqi end

            if (RowCnt111 != 0)
            {
                CustomerName = table.Rows[0]["顧客様"].ToString();

                DataRow sumRow01 = table.NewRow();
                sumRow01 = table.Rows[0];

                sumRow.ItemArray = sumRow01.ItemArray.Clone() as object[];
                //sumRow = table.Rows[0];
                sumRow["顧客様"] = sumRow["顧客様"] + "\t" + "小計";
                sumRow["窓口"] = "";
                sumRow["契約件名"] = "";
                sumRow["売上日"] = "";
                sumRow["営業１"] = "";
                sumRow["営業２"] = "";

                // add by liuyuqi start
                // 同会社1番目
                staffSum = 0;
                staffSum++;

                // 社員ID
                lastStaff = CommonHandler.ToString(table.Rows[0]["社員ID"]);
                sumRow["社員"] = staffSum;

                // add by liuyuqi end


            }

            for (int RowCnt = 0; RowCnt < RowCnt111; RowCnt++)
            {
                DataRow sourceRow = table.NewRow();
                sourceRow = table.Rows[RowCnt];

                DataRow desRow = table02.NewRow();
                desRow.ItemArray = sourceRow.ItemArray.Clone() as object[];
                table02.Rows.Add(desRow);

                result = string.Compare(CustomerName, table.Rows[RowCnt]["顧客様"].ToString());

                if (result == 0 && RowCnt != 0)
                {
                    int Sum111;
                    //契約金額
                    Sum111 = CommonHandler.ToInt(sumRow["契約金額"]) + CommonHandler.ToInt(table.Rows[RowCnt]["契約金額"]);
                    sumRow["契約金額"] = Sum111.ToString();
                    //売上
                    Sum111 = CommonHandler.ToInt(sumRow["売上"]) + CommonHandler.ToInt(table.Rows[RowCnt]["売上"]);
                    sumRow["売上"] = Sum111;
                    //仕入原価
                    Sum111 = CommonHandler.ToInt(sumRow["仕入原価"]) + CommonHandler.ToInt(table.Rows[RowCnt]["仕入原価"]);
                    sumRow["仕入原価"] = Sum111;
                    //交通費
                    Sum111 = CommonHandler.ToInt(sumRow["交通費"]) + CommonHandler.ToInt(table.Rows[RowCnt]["交通費"]);
                    sumRow["交通費"] = Sum111;
                    //粗利
                    Sum111 = CommonHandler.ToInt(sumRow["粗利"]) + CommonHandler.ToInt(table.Rows[RowCnt]["粗利"]);
                    sumRow["粗利"] = Sum111;

                    // add by liuyuqi start
                    currStaff = CommonHandler.ToString(table.Rows[RowCnt]["社員ID"]);
                    if (!lastStaff.Equals(currStaff))
                    {
                        staffSum++;
                        lastStaff = currStaff;
                        currStaff = "";
                    }
                    sumRow["社員"] = staffSum;//社員数　合計

                    // add by liuyuqi end

                }
                else
                {
                    if (RowCnt != 0)
                    {
                        CustomerName = table.Rows[RowCnt]["顧客様"].ToString();

                        DataRow desRow01 = table02.NewRow();
                        desRow01.ItemArray = sumRow.ItemArray.Clone() as object[];
                        int RowCnt02 = table02.Rows.Count;

                        table02.Rows.InsertAt(desRow01, RowCnt02 - 1);

                        sumRow = table.Rows[RowCnt];
                        sumRow["顧客様"] = sumRow["顧客様"] + "\t" + "小計";
                        sumRow["窓口"] = "";
                        sumRow["契約件名"] = "";
                        sumRow["売上日"] = "";
                        sumRow["営業１"] = "";
                        sumRow["営業２"] = "";

                        // add by liuyuqi start
                        // 同会社1番目
                        staffSum = 0;
                        staffSum++;

                        // 社員ID
                        lastStaff = CommonHandler.ToString(table.Rows[RowCnt]["社員ID"]);
                        sumRow["社員"] = staffSum;//社員数　合計
                        // add by liuyuqi end
                    }
                }

                // add by liuyuqi start
                if (RowCnt + 1 < RowCnt111)
                {
                    int resultNext = string.Compare(CustomerName, table.Rows[RowCnt + 1]["顧客様"].ToString());
                    // 最後件ではない場合
                    if (resultNext != 0)
                    {
                        // 同会社最後の件場合
                        // 粗利率集計
                        sumRow["粗利率（％）"] = Math.Round(CommonHandler.ToDecimal(sumRow["粗利"]) * 100 / CommonHandler.ToDecimal(sumRow["売上"]), 2, MidpointRounding.AwayFromZero);
                    }
                }

                // 最後行の場合
                if (RowCnt + 1 == RowCnt111)
                {
                    // 粗利率集計
                    sumRow["粗利率（％）"] = Math.Round(CommonHandler.ToDecimal(sumRow["粗利"]) * 100 / CommonHandler.ToDecimal(sumRow["売上"]), 2, MidpointRounding.AwayFromZero);
                }
                // add bu liuyuqi end


            }
            //最後のレコード

            if (RowCnt111 != 0)
            {

                DataRow desRow02 = table02.NewRow();
                desRow02.ItemArray = sumRow.ItemArray.Clone() as object[];
                int RowCnt02 = table02.Rows.Count;

                table02.Rows.InsertAt(desRow02, RowCnt02);

            }

            this.SalesList.DataSource = table02;
            for (int ColCnt = 1; ColCnt < SalesList.Columns.Count; ColCnt++)
            {
                this.SalesList.Columns[ColCnt].SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;

                // 社員IDコラムを非表示
                this.SalesList.Columns["社員ID"].Visible = false;
                this.SalesList.Columns["SaleDetailID"].Visible = false;
                this.SalesList.Columns["SaleID"].Visible = false;
            }

            for (int RowCnt = 0; RowCnt < SalesList.RowCount; RowCnt++)
            {
                string CustomerName1 = SalesList.Rows[RowCnt].Cells["顧客様"].Value.ToString();
                if (CustomerName1.Substring((CustomerName1.Length - 2), 2) == "小計")
                {
                    SalesList.Rows[RowCnt].DefaultCellStyle.BackColor = Color.Aqua;

                }
            }
                          

        }
        /// <summary>
        /// リサイズ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SalesListForm_Resize(object sender, EventArgs e)
        {
            this.btnClose.Location = new System.Drawing.Point(this.Width - 100, this.Height - 65);
            this.SalesList.Size = new System.Drawing.Size(this.Width - 30, this.Height-200);
        }
        /// <summary>
        /// 売上詳細の編集
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SalesList_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (SalesList.Rows[e.RowIndex].DefaultCellStyle.BackColor == Color.Aqua) { return; };
            DataGridViewCellCollection dgvcc = this.SalesList.Rows[e.RowIndex].Cells;

            decimal purchase_price = CommonHandler.ToDecimal( dgvcc["仕入原価"].Value);
            decimal purchase_carfare = CommonHandler.ToDecimal(dgvcc["交通費"].Value);

            Purchase f = new Purchase(
                CommonHandler.ToInt( dgvcc["SaleID"].Value),
                dgvcc["SaleDetailID"].Value.ToString(),
                (IF_SaleDetail isd)=>{
                    dgvcc["仕入原価"].Value = isd.purchase_price;
                    dgvcc["交通費"].Value = isd.purchase_carfare;
                    dgvcc["通勤区間"].Value = isd.purchase_commuting;
                    dgvcc["備考"].Value = isd.purchase_note;

                    string CustomerName = dgvcc["顧客様"].Value.ToString();
                    foreach (DataGridViewRow dgvr in this.SalesList.Rows)
                    {
                        if (dgvr.Cells["顧客様"].Value.ToString() == CustomerName + "\t" + "小計")
                        {
                            dgvr.Cells["仕入原価"].Value = CommonHandler.ToDecimal(dgvr.Cells["仕入原価"].Value) + isd.purchase_price - purchase_price;
                            dgvr.Cells["交通費"].Value = CommonHandler.ToDecimal(dgvr.Cells["交通費"].Value) + isd.purchase_carfare - purchase_carfare;
                            break;
                        }
                    }
                    
                }
            );
            f.ShowDialog();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            if (this.SalesList.RowCount < 1) { return; }
            ThreadPoolHelper.StartThread(this,
                () =>
                {
                    CommonExcelModel excelData = new CommonExcelModel();

                    for (int ColCnt = 0; ColCnt < this.SalesList.Columns.Count; ColCnt++)
                    {
                        excelData.addCell(new ExcelCellModel { row = 1, col = ColCnt + 1, value = this.SalesList.Columns[ColCnt].HeaderCell.Value.ToString() });
                    }

                    for (int RowCnt = 0; RowCnt < this.SalesList.RowCount; RowCnt++)
                    {
                        for (int ColCnt = 0; ColCnt < this.SalesList.Columns.Count; ColCnt++)
                        {
                            excelData.addCell(new ExcelCellModel { row = RowCnt + 2, col = ColCnt + 1, value = this.SalesList.Rows[RowCnt].Cells[ColCnt].Value.ToString() });
                        }
                    }
                    return excelData; 
                },
                (obj) =>
                {
                    string folder = CommonHandler.folderDialog();
                    if (!string.IsNullOrEmpty(folder))
                    {
                        OpenXML.fillExcel(folder + "\\エクスポート.xlsx", 1, obj as CommonExcelModel);

                        Common.MessageHelper.ShowinforMessageByID("EB0012", "エクスポート");
                    }
                });

            //OpenXML.fillExcel("test2.xlsx", "sss", excelData);
        }
    }
}
