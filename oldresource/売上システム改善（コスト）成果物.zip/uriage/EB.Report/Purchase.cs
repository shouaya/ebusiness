﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.Common;
using EB.DBAcess;

namespace EB.Report
{
    public partial class Purchase : DialogForm
    {
        public delegate void CallBackDelegate(IF_SaleDetail isd);
        private CallBackDelegate _cbd;
        private IF_SaleDetail _isd;
        private BL_SaleDetail _bsd;
        private IF_Employee _ie;

        public Purchase(int saleID, string saleDetailID, CallBackDelegate cbd)
        {
            InitializeComponent();
            this._isd = new IF_SaleDetail();
            this._isd.SaleID = saleID;
            this._isd.SaleDetailID = saleDetailID;
            this._cbd = cbd;
        }
        /// <summary>
        /// 初期化処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Purchase_Load(object sender, EventArgs e)
        {
            this._bsd = BL_SaleDetail.GetInstance();
            //データを取得
            this.loaddata();

        }
        /// <summary>
        /// データを取得
        /// </summary>
        public void loaddata()
        {
            ThreadPoolHelper.StartThread(this,
                () =>
                {
                    return this._bsd.SelectSaleDetailByID(false, this._isd.SaleID, this._isd.SaleDetailID);
                },
                (obj) =>
                {
                    DataRow dr = obj as DataRow;
                    this.txtEmployeeName.Text = dr["社員"].ToString();
                    this.txtContractName.Text = dr["契約件名"].ToString();
                    this.txtUndertaker.Text = dr["窓口"].ToString();
                    this.txtCustomerName.Text = dr["顧客様"].ToString();
                    this.txtSaleDate.Text = dr["売上日"].ToString();
                    this.txtSalesManName1.Text = dr["営業１"].ToString();
                    this.txtSalesManName2.Text = dr["営業２"].ToString();
                    this.txtCommuting.Text = dr["通勤区間"].ToString();
                    this.txtContractAmount.Text = dr["契約金額"].ToString();
                    this.txtSalesAmount.Text = dr["売上"].ToString();
                    this.txtSiirePrice.Text = dr["仕入原価"].ToString();
                    this.txtCarfare.Text = dr["交通費"].ToString();
                    this.txtNote.Text = dr["備考"].ToString();
                    this.txtSiireSales.Text = dr["仕入担当"].ToString();

                    this._ie = new IF_Employee();
                    this._ie.EmployeeID = CommonHandler.ToInt( dr["社員ID"]);

                });
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            this._isd.purchase_price = CommonHandler.ToDecimal(this.txtSiirePrice.Text);
            this._isd.purchase_carfare = CommonHandler.ToDecimal(this.txtCarfare.Text);
            this._isd.purchase_commuting = this.txtCommuting.Text;
            this._isd.purchase_note = this.txtNote.Text;

            this._bsd.UpdateSaleDetailForPurchase(this._isd);

            //this._ie.carfare = this._isd.purchase_carfare.ToString();
            //this._ie.SiirePrice = this._isd.purchase_price.ToString();
            //BL_Employee.GetInstance().UpdateEmployeeForPurchase(this._ie);
            this._cbd(this._isd);
            MessageHelper.ShowinforMessageByID( "EB1003" );//更新成功しました。
            this.Close();
        }
    }
}
