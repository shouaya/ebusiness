﻿namespace EB.Contract
{
    partial class ContractLedgerForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label Thread_Status = new System.Windows.Forms.Label();

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cobYear = new System.Windows.Forms.ComboBox();
            this.cobMonth = new System.Windows.Forms.ComboBox();
            this.cobCustomerID = new System.Windows.Forms.ComboBox();
            this.cobEmployeeID = new System.Windows.Forms.ComboBox();
            this.cobEmployeeType = new System.Windows.Forms.ComboBox();
            this.cobWorkAddr = new System.Windows.Forms.ComboBox();
            this.dgvContractLedger = new System.Windows.Forms.DataGridView();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.btnAutoRegister = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnInsert = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.cobMonthEnd = new System.Windows.Forms.ComboBox();
            this.cobYearEnd = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblRowsCount = new System.Windows.Forms.Label();
            this.button_panel = new System.Windows.Forms.Panel();
            this.cobMemo = new System.Windows.Forms.ComboBox();
            this.check = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ManagementID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UpdateFlg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Memo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siirePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Group1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeTypeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeptName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siireName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siireSales = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TranExpense = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CostStartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CostEndDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Salesman1Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Salesman2Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Group2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustSalesman = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WorkAddr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Group3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinHour = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxHour = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinusUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PlusUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentSet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WorkMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Group4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Salesman1ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Salesman2ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentDay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContractLedger)).BeginInit();
            this.button_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(922, 18);
            this.btnClose.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "年月を指定してください";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(234, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "年";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(320, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 74;
            this.label3.Text = "月";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 12);
            this.label4.TabIndex = 75;
            this.label4.Text = "顧客を指定してください";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(173, 12);
            this.label5.TabIndex = 76;
            this.label5.Text = "技術者氏名を入力してください";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(504, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 12);
            this.label6.TabIndex = 77;
            this.label6.Text = "現場を選択してください";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(483, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(161, 12);
            this.label7.TabIndex = 78;
            this.label7.Text = "社員区分を選択してください";
            // 
            // cobYear
            // 
            this.cobYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobYear.FormattingEnabled = true;
            this.cobYear.Items.AddRange(new object[] {
            "2020",
            "2019",
            "2018",
            "2017",
            "2016",
            "2015",
            "2014",
            "2013",
            "2012",
            "2011",
            "2010",
            "2009",
            "2008"});
            this.cobYear.Location = new System.Drawing.Point(144, 16);
            this.cobYear.Name = "cobYear";
            this.cobYear.Size = new System.Drawing.Size(84, 20);
            this.cobYear.TabIndex = 2;
            this.cobYear.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // cobMonth
            // 
            this.cobMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobMonth.FormattingEnabled = true;
            this.cobMonth.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.cobMonth.Location = new System.Drawing.Point(257, 16);
            this.cobMonth.Name = "cobMonth";
            this.cobMonth.Size = new System.Drawing.Size(57, 20);
            this.cobMonth.TabIndex = 2;
            this.cobMonth.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // cobCustomerID
            // 
            this.cobCustomerID.DisplayMember = "CustomerName";
            this.cobCustomerID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobCustomerID.FormattingEnabled = true;
            this.cobCustomerID.Location = new System.Drawing.Point(144, 43);
            this.cobCustomerID.Name = "cobCustomerID";
            this.cobCustomerID.Size = new System.Drawing.Size(158, 20);
            this.cobCustomerID.TabIndex = 5;
            this.cobCustomerID.ValueMember = "CustomerID";
            this.cobCustomerID.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // cobEmployeeID
            // 
            this.cobEmployeeID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cobEmployeeID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cobEmployeeID.DisplayMember = "EmployeeName";
            this.cobEmployeeID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobEmployeeID.FormattingEnabled = true;
            this.cobEmployeeID.Location = new System.Drawing.Point(180, 68);
            this.cobEmployeeID.Name = "cobEmployeeID";
            this.cobEmployeeID.Size = new System.Drawing.Size(122, 20);
            this.cobEmployeeID.TabIndex = 8;
            this.cobEmployeeID.ValueMember = "EmployeeID";
            this.cobEmployeeID.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // cobEmployeeType
            // 
            this.cobEmployeeType.DisplayMember = "CodeName";
            this.cobEmployeeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobEmployeeType.FormattingEnabled = true;
            this.cobEmployeeType.Location = new System.Drawing.Point(623, 68);
            this.cobEmployeeType.Name = "cobEmployeeType";
            this.cobEmployeeType.Size = new System.Drawing.Size(95, 20);
            this.cobEmployeeType.TabIndex = 10;
            this.cobEmployeeType.ValueMember = "CodeId";
            this.cobEmployeeType.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // cobWorkAddr
            // 
            this.cobWorkAddr.DisplayMember = "WorkAddr";
            this.cobWorkAddr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobWorkAddr.FormattingEnabled = true;
            this.cobWorkAddr.Location = new System.Drawing.Point(623, 42);
            this.cobWorkAddr.Name = "cobWorkAddr";
            this.cobWorkAddr.Size = new System.Drawing.Size(95, 20);
            this.cobWorkAddr.TabIndex = 7;
            this.cobWorkAddr.ValueMember = "WorkAddr";
            this.cobWorkAddr.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // dgvContractLedger
            // 
            this.dgvContractLedger.AllowDrop = true;
            this.dgvContractLedger.AllowUserToAddRows = false;
            this.dgvContractLedger.AllowUserToDeleteRows = false;
            this.dgvContractLedger.AllowUserToResizeRows = false;
            this.dgvContractLedger.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvContractLedger.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvContractLedger.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.check,
            this.ManagementID,
            this.UpdateFlg,
            this.Memo,
            this.EmployeeName,
            this.siirePrice,
            this.Group1,
            this.EmployeeTypeName,
            this.DeptName,
            this.siireName,
            this.siireSales,
            this.TranExpense,
            this.CostStartDate,
            this.CostEndDate,
            this.Salesman1Name,
            this.Salesman2Name,
            this.CustomerName,
            this.Group2,
            this.CustSalesman,
            this.ContractName,
            this.WorkAddr,
            this.StartDate,
            this.EndDate,
            this.Amount,
            this.Group3,
            this.MinHour,
            this.MaxHour,
            this.MinusUnitPrice,
            this.PlusUnitPrice,
            this.Quantity,
            this.PaymentSet,
            this.WorkMonth,
            this.OrderDate,
            this.Group4,
            this.OrderNo,
            this.ProjectName,
            this.EmployeeID,
            this.Salesman1ID,
            this.Salesman2ID,
            this.EmployeeType,
            this.CustomerID,
            this.PaymentType,
            this.PaymentDay,
            this.Price,
            this.Unit});
            this.dgvContractLedger.Location = new System.Drawing.Point(12, 94);
            this.dgvContractLedger.Name = "dgvContractLedger";
            this.dgvContractLedger.RowHeadersVisible = false;
            this.dgvContractLedger.RowTemplate.Height = 23;
            this.dgvContractLedger.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvContractLedger.Size = new System.Drawing.Size(985, 292);
            this.dgvContractLedger.TabIndex = 1;
            this.dgvContractLedger.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvContractLedger_CellMouseDoubleClick);
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Location = new System.Drawing.Point(322, 69);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(122, 21);
            this.txtEmployeeName.TabIndex = 9;
            this.txtEmployeeName.TextChanged += new System.EventHandler(this.txtBox_TextChanged);
            // 
            // btnAutoRegister
            // 
            this.btnAutoRegister.Location = new System.Drawing.Point(339, 18);
            this.btnAutoRegister.Name = "btnAutoRegister";
            this.btnAutoRegister.Size = new System.Drawing.Size(120, 23);
            this.btnAutoRegister.TabIndex = 14;
            this.btnAutoRegister.Text = "契約情報自動登録";
            this.btnAutoRegister.UseVisualStyleBackColor = true;
            this.btnAutoRegister.Click += new System.EventHandler(this.btnAutoRegister_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(37, 18);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(120, 23);
            this.btnRegister.TabIndex = 12;
            this.btnRegister.Text = "新規追加";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(186, 18);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(120, 23);
            this.btnDelete.TabIndex = 13;
            this.btnDelete.Text = "削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnInsert
            // 
            this.btnInsert.Enabled = false;
            this.btnInsert.Location = new System.Drawing.Point(483, 18);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(131, 23);
            this.btnInsert.TabIndex = 15;
            this.btnInsert.Text = "翌月台帳仮作成";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // label8
            // 
            this.label8.AccessibleRole = System.Windows.Forms.AccessibleRole.WhiteSpace;
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.Location = new System.Drawing.Point(360, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(17, 12);
            this.label8.TabIndex = 197;
            this.label8.Text = "～";
            // 
            // cobMonthEnd
            // 
            this.cobMonthEnd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobMonthEnd.FormattingEnabled = true;
            this.cobMonthEnd.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.cobMonthEnd.Location = new System.Drawing.Point(506, 16);
            this.cobMonthEnd.Name = "cobMonthEnd";
            this.cobMonthEnd.Size = new System.Drawing.Size(57, 20);
            this.cobMonthEnd.TabIndex = 4;
            this.cobMonthEnd.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // cobYearEnd
            // 
            this.cobYearEnd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobYearEnd.FormattingEnabled = true;
            this.cobYearEnd.Items.AddRange(new object[] {
            "2020",
            "2019",
            "2018",
            "2017",
            "2016",
            "2015",
            "2014",
            "2013",
            "2012",
            "2011",
            "2010",
            "2009",
            "2008"});
            this.cobYearEnd.Location = new System.Drawing.Point(393, 16);
            this.cobYearEnd.Name = "cobYearEnd";
            this.cobYearEnd.Size = new System.Drawing.Size(84, 20);
            this.cobYearEnd.TabIndex = 3;
            this.cobYearEnd.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(483, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(17, 12);
            this.label9.TabIndex = 200;
            this.label9.Text = "年";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(569, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(17, 12);
            this.label10.TabIndex = 201;
            this.label10.Text = "月";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(739, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 23);
            this.button1.TabIndex = 202;
            this.button1.Text = "台帳導入";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(322, 45);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(122, 21);
            this.txtCustomerName.TabIndex = 6;
            this.txtCustomerName.TextChanged += new System.EventHandler(this.txtBox_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(621, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 204;
            this.label11.Text = "備考";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(897, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 12);
            this.label12.TabIndex = 206;
            this.label12.Text = "件数:";
            // 
            // lblRowsCount
            // 
            this.lblRowsCount.AutoSize = true;
            this.lblRowsCount.Location = new System.Drawing.Point(940, 76);
            this.lblRowsCount.Name = "lblRowsCount";
            this.lblRowsCount.Size = new System.Drawing.Size(65, 12);
            this.lblRowsCount.TabIndex = 207;
            this.lblRowsCount.Text = "99,999,999";
            // 
            // button_panel
            // 
            this.button_panel.Controls.Add(this.btnAutoRegister);
            this.button_panel.Controls.Add(this.btnRegister);
            this.button_panel.Controls.Add(this.btnDelete);
            this.button_panel.Controls.Add(this.btnInsert);
            this.button_panel.Controls.Add(this.btnClose);
            this.button_panel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.button_panel.Location = new System.Drawing.Point(0, 392);
            this.button_panel.Name = "button_panel";
            this.button_panel.Size = new System.Drawing.Size(1039, 64);
            this.button_panel.TabIndex = 204;
            this.button_panel.Controls.SetChildIndex(this.btnClose, 0);
            this.button_panel.Controls.SetChildIndex(this.btnInsert, 0);
            this.button_panel.Controls.SetChildIndex(this.btnDelete, 0);
            this.button_panel.Controls.SetChildIndex(this.btnRegister, 0);
            this.button_panel.Controls.SetChildIndex(this.btnAutoRegister, 0);
            // 
            // cobMemo
            // 
            this.cobMemo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobMemo.FormattingEnabled = true;
            this.cobMemo.Items.AddRange(new object[] {
            "",
            "有",
            "無"});
            this.cobMemo.Location = new System.Drawing.Point(668, 16);
            this.cobMemo.Name = "cobMemo";
            this.cobMemo.Size = new System.Drawing.Size(50, 20);
            this.cobMemo.TabIndex = 208;
            this.cobMemo.SelectionChangeCommitted += new System.EventHandler(this.cobMemo_SelectionChangeCommitted);
            // 
            // check
            // 
            this.check.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.check.DataPropertyName = "check";
            this.check.FalseValue = "0";
            this.check.HeaderText = "";
            this.check.MinimumWidth = 15;
            this.check.Name = "check";
            this.check.TrueValue = "1";
            this.check.Width = 30;
            // 
            // ManagementID
            // 
            this.ManagementID.DataPropertyName = "ManagementID";
            this.ManagementID.HeaderText = "No.";
            this.ManagementID.Name = "ManagementID";
            this.ManagementID.ReadOnly = true;
            this.ManagementID.Width = 40;
            // 
            // UpdateFlg
            // 
            this.UpdateFlg.DataPropertyName = "UpdateFlg";
            this.UpdateFlg.FillWeight = 85F;
            this.UpdateFlg.HeaderText = "契約登録";
            this.UpdateFlg.Name = "UpdateFlg";
            this.UpdateFlg.ReadOnly = true;
            this.UpdateFlg.Width = 60;
            // 
            // Memo
            // 
            this.Memo.DataPropertyName = "Memo";
            this.Memo.HeaderText = "備考";
            this.Memo.Name = "Memo";
            this.Memo.ReadOnly = true;
            this.Memo.Width = 200;
            // 
            // EmployeeName
            // 
            this.EmployeeName.DataPropertyName = "EmployeeName";
            this.EmployeeName.FillWeight = 75F;
            this.EmployeeName.HeaderText = "技術者氏名";
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.ReadOnly = true;
            this.EmployeeName.Width = 75;
            // 
            // siirePrice
            // 
            this.siirePrice.DataPropertyName = "siirePrice";
            this.siirePrice.HeaderText = "仕入原価";
            this.siirePrice.Name = "siirePrice";
            this.siirePrice.ReadOnly = true;
            // 
            // Group1
            // 
            this.Group1.FillWeight = 15F;
            this.Group1.HeaderText = "+";
            this.Group1.MinimumWidth = 15;
            this.Group1.Name = "Group1";
            this.Group1.ReadOnly = true;
            this.Group1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Group1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Group1.ToolTipText = "表示";
            this.Group1.Width = 15;
            // 
            // EmployeeTypeName
            // 
            this.EmployeeTypeName.DataPropertyName = "EmployeeTypeName";
            this.EmployeeTypeName.FillWeight = 75F;
            this.EmployeeTypeName.HeaderText = "社員区分";
            this.EmployeeTypeName.Name = "EmployeeTypeName";
            this.EmployeeTypeName.ReadOnly = true;
            this.EmployeeTypeName.Visible = false;
            this.EmployeeTypeName.Width = 75;
            // 
            // DeptName
            // 
            this.DeptName.DataPropertyName = "DeptName";
            this.DeptName.FillWeight = 75F;
            this.DeptName.HeaderText = "所属部門";
            this.DeptName.Name = "DeptName";
            this.DeptName.ReadOnly = true;
            this.DeptName.Visible = false;
            this.DeptName.Width = 75;
            // 
            // siireName
            // 
            this.siireName.DataPropertyName = "siireName";
            this.siireName.FillWeight = 90F;
            this.siireName.HeaderText = "仕入先";
            this.siireName.Name = "siireName";
            this.siireName.ReadOnly = true;
            this.siireName.Visible = false;
            this.siireName.Width = 90;
            // 
            // siireSales
            // 
            this.siireSales.DataPropertyName = "siireSales";
            this.siireSales.FillWeight = 75F;
            this.siireSales.HeaderText = "仕入先担当";
            this.siireSales.Name = "siireSales";
            this.siireSales.ReadOnly = true;
            this.siireSales.Visible = false;
            this.siireSales.Width = 75;
            // 
            // TranExpense
            // 
            this.TranExpense.DataPropertyName = "TranExpense";
            this.TranExpense.HeaderText = "交通費";
            this.TranExpense.Name = "TranExpense";
            this.TranExpense.ReadOnly = true;
            this.TranExpense.Visible = false;
            // 
            // CostStartDate
            // 
            this.CostStartDate.DataPropertyName = "CostStartDate";
            this.CostStartDate.HeaderText = "原価開始日";
            this.CostStartDate.Name = "CostStartDate";
            this.CostStartDate.ReadOnly = true;
            this.CostStartDate.Visible = false;
            // 
            // CostEndDate
            // 
            this.CostEndDate.DataPropertyName = "CostEndDate";
            this.CostEndDate.HeaderText = "原価終了日";
            this.CostEndDate.Name = "CostEndDate";
            this.CostEndDate.ReadOnly = true;
            this.CostEndDate.Visible = false;
            // 
            // Salesman1Name
            // 
            this.Salesman1Name.DataPropertyName = "Salesman1Name";
            this.Salesman1Name.FillWeight = 75F;
            this.Salesman1Name.HeaderText = "営業担当１";
            this.Salesman1Name.Name = "Salesman1Name";
            this.Salesman1Name.ReadOnly = true;
            this.Salesman1Name.Width = 75;
            // 
            // Salesman2Name
            // 
            this.Salesman2Name.DataPropertyName = "Salesman2Name";
            this.Salesman2Name.FillWeight = 75F;
            this.Salesman2Name.HeaderText = "営業担当２";
            this.Salesman2Name.Name = "Salesman2Name";
            this.Salesman2Name.ReadOnly = true;
            this.Salesman2Name.Width = 75;
            // 
            // CustomerName
            // 
            this.CustomerName.DataPropertyName = "CustomerName";
            this.CustomerName.FillWeight = 75F;
            this.CustomerName.HeaderText = "顧客会社";
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.ReadOnly = true;
            this.CustomerName.Width = 250;
            // 
            // Group2
            // 
            this.Group2.FillWeight = 15F;
            this.Group2.HeaderText = "+";
            this.Group2.MinimumWidth = 15;
            this.Group2.Name = "Group2";
            this.Group2.ReadOnly = true;
            this.Group2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Group2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Group2.ToolTipText = "表示";
            this.Group2.Width = 15;
            // 
            // CustSalesman
            // 
            this.CustSalesman.DataPropertyName = "CustSalesman";
            this.CustSalesman.FillWeight = 75F;
            this.CustSalesman.HeaderText = "顧客窓口";
            this.CustSalesman.Name = "CustSalesman";
            this.CustSalesman.ReadOnly = true;
            this.CustSalesman.Visible = false;
            this.CustSalesman.Width = 75;
            // 
            // ContractName
            // 
            this.ContractName.DataPropertyName = "ContractName";
            this.ContractName.FillWeight = 90F;
            this.ContractName.HeaderText = "プロジェクト名";
            this.ContractName.Name = "ContractName";
            this.ContractName.ReadOnly = true;
            this.ContractName.Visible = false;
            this.ContractName.Width = 90;
            // 
            // WorkAddr
            // 
            this.WorkAddr.DataPropertyName = "WorkAddr";
            this.WorkAddr.HeaderText = "現場";
            this.WorkAddr.Name = "WorkAddr";
            this.WorkAddr.ReadOnly = true;
            this.WorkAddr.Visible = false;
            // 
            // StartDate
            // 
            this.StartDate.DataPropertyName = "StartDate";
            this.StartDate.HeaderText = "契約開始";
            this.StartDate.Name = "StartDate";
            this.StartDate.ReadOnly = true;
            this.StartDate.Visible = false;
            // 
            // EndDate
            // 
            this.EndDate.DataPropertyName = "EndDate";
            this.EndDate.HeaderText = "契約終了";
            this.EndDate.Name = "EndDate";
            this.EndDate.ReadOnly = true;
            this.EndDate.Visible = false;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            this.Amount.HeaderText = "売上";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            // 
            // Group3
            // 
            this.Group3.FillWeight = 15F;
            this.Group3.HeaderText = "+";
            this.Group3.MinimumWidth = 15;
            this.Group3.Name = "Group3";
            this.Group3.ReadOnly = true;
            this.Group3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Group3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Group3.ToolTipText = "表示";
            this.Group3.Width = 15;
            // 
            // MinHour
            // 
            this.MinHour.DataPropertyName = "MinHour";
            this.MinHour.HeaderText = "稼働下限";
            this.MinHour.Name = "MinHour";
            this.MinHour.ReadOnly = true;
            this.MinHour.Visible = false;
            // 
            // MaxHour
            // 
            this.MaxHour.DataPropertyName = "MaxHour";
            this.MaxHour.HeaderText = "稼働上限";
            this.MaxHour.Name = "MaxHour";
            this.MaxHour.ReadOnly = true;
            this.MaxHour.Visible = false;
            // 
            // MinusUnitPrice
            // 
            this.MinusUnitPrice.DataPropertyName = "MinusUnitPrice";
            this.MinusUnitPrice.HeaderText = "控除単価";
            this.MinusUnitPrice.Name = "MinusUnitPrice";
            this.MinusUnitPrice.ReadOnly = true;
            this.MinusUnitPrice.Visible = false;
            // 
            // PlusUnitPrice
            // 
            this.PlusUnitPrice.DataPropertyName = "PlusUnitPrice";
            this.PlusUnitPrice.HeaderText = "超過単価";
            this.PlusUnitPrice.Name = "PlusUnitPrice";
            this.PlusUnitPrice.ReadOnly = true;
            this.PlusUnitPrice.Visible = false;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "日割計算";
            this.Quantity.Name = "Quantity";
            this.Quantity.ReadOnly = true;
            this.Quantity.Visible = false;
            // 
            // PaymentSet
            // 
            this.PaymentSet.DataPropertyName = "PaymentSet";
            this.PaymentSet.HeaderText = "支払サイト";
            this.PaymentSet.Name = "PaymentSet";
            this.PaymentSet.ReadOnly = true;
            this.PaymentSet.Visible = false;
            // 
            // WorkMonth
            // 
            this.WorkMonth.DataPropertyName = "WorkMonth";
            this.WorkMonth.HeaderText = "稼働月";
            this.WorkMonth.Name = "WorkMonth";
            this.WorkMonth.ReadOnly = true;
            // 
            // OrderDate
            // 
            this.OrderDate.DataPropertyName = "OrderDate";
            this.OrderDate.HeaderText = "注文書届日";
            this.OrderDate.Name = "OrderDate";
            this.OrderDate.ReadOnly = true;
            // 
            // Group4
            // 
            this.Group4.FillWeight = 15F;
            this.Group4.HeaderText = "+";
            this.Group4.MinimumWidth = 15;
            this.Group4.Name = "Group4";
            this.Group4.ReadOnly = true;
            this.Group4.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Group4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Group4.ToolTipText = "表示";
            this.Group4.Width = 15;
            // 
            // OrderNo
            // 
            this.OrderNo.DataPropertyName = "OrderNo";
            this.OrderNo.HeaderText = "注文書番号";
            this.OrderNo.Name = "OrderNo";
            this.OrderNo.ReadOnly = true;
            this.OrderNo.Visible = false;
            // 
            // ProjectName
            // 
            this.ProjectName.DataPropertyName = "ProjectName";
            this.ProjectName.HeaderText = "作業工程";
            this.ProjectName.Name = "ProjectName";
            this.ProjectName.ReadOnly = true;
            this.ProjectName.Visible = false;
            // 
            // EmployeeID
            // 
            this.EmployeeID.DataPropertyName = "EmployeeID";
            this.EmployeeID.HeaderText = "EmployeeID";
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.Visible = false;
            // 
            // Salesman1ID
            // 
            this.Salesman1ID.HeaderText = "Salesman1ID";
            this.Salesman1ID.Name = "Salesman1ID";
            this.Salesman1ID.Visible = false;
            // 
            // Salesman2ID
            // 
            this.Salesman2ID.HeaderText = "Salesman2ID";
            this.Salesman2ID.Name = "Salesman2ID";
            this.Salesman2ID.Visible = false;
            // 
            // EmployeeType
            // 
            this.EmployeeType.HeaderText = "EmployeeType";
            this.EmployeeType.Name = "EmployeeType";
            this.EmployeeType.Visible = false;
            // 
            // CustomerID
            // 
            this.CustomerID.HeaderText = "CustomerID";
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.Visible = false;
            // 
            // PaymentType
            // 
            this.PaymentType.HeaderText = "PaymentType";
            this.PaymentType.Name = "PaymentType";
            this.PaymentType.Visible = false;
            // 
            // PaymentDay
            // 
            this.PaymentDay.HeaderText = "PaymentDay";
            this.PaymentDay.Name = "PaymentDay";
            this.PaymentDay.Visible = false;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            this.Price.HeaderText = "単価";
            this.Price.Name = "Price";
            this.Price.Visible = false;
            // 
            // Unit
            // 
            this.Unit.DataPropertyName = "Unit";
            this.Unit.HeaderText = "単位";
            this.Unit.Name = "Unit";
            this.Unit.Visible = false;
            // 
            // ContractLedgerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 456);
            this.Controls.Add(this.cobMemo);
            this.Controls.Add(this.button_panel);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblRowsCount);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cobMonthEnd);
            this.Controls.Add(this.cobYearEnd);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.dgvContractLedger);
            this.Controls.Add(this.cobWorkAddr);
            this.Controls.Add(this.cobEmployeeType);
            this.Controls.Add(this.cobEmployeeID);
            this.Controls.Add(this.cobCustomerID);
            this.Controls.Add(this.cobMonth);
            this.Controls.Add(this.cobYear);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = true;
            this.Name = "ContractLedgerForm";
            this.Text = "社内管理台帳";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ContractLedgerForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContractLedger)).EndInit();
            this.button_panel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cobYear;
        private System.Windows.Forms.ComboBox cobMonth;
        private System.Windows.Forms.ComboBox cobCustomerID;
        private System.Windows.Forms.ComboBox cobEmployeeID;
        private System.Windows.Forms.ComboBox cobEmployeeType;
        private System.Windows.Forms.ComboBox cobWorkAddr;
        private System.Windows.Forms.DataGridView dgvContractLedger;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.Button btnAutoRegister;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cobMonthEnd;
        private System.Windows.Forms.ComboBox cobYearEnd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Panel button_panel;

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblRowsCount;
        private System.Windows.Forms.ComboBox cobMemo;
        private System.Windows.Forms.DataGridViewCheckBoxColumn check;
        private System.Windows.Forms.DataGridViewTextBoxColumn ManagementID;
        private System.Windows.Forms.DataGridViewTextBoxColumn UpdateFlg;
        private System.Windows.Forms.DataGridViewTextBoxColumn Memo;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn siirePrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Group1;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeTypeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn DeptName;
        private System.Windows.Forms.DataGridViewTextBoxColumn siireName;
        private System.Windows.Forms.DataGridViewTextBoxColumn siireSales;
        private System.Windows.Forms.DataGridViewTextBoxColumn TranExpense;
        private System.Windows.Forms.DataGridViewTextBoxColumn CostStartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CostEndDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Salesman1Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Salesman2Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Group2;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustSalesman;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractName;
        private System.Windows.Forms.DataGridViewTextBoxColumn WorkAddr;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Group3;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinHour;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaxHour;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinusUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn PlusUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentSet;
        private System.Windows.Forms.DataGridViewTextBoxColumn WorkMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Group4;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectName;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Salesman1ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Salesman2ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeType;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentType;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentDay;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
    }
}