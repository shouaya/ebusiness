﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;
using System.Collections;
using System.Threading;

namespace EB.Contract
{
    public partial class ContractLedgerForm : DialogForm
    {
        #region 初期化
        public int _selectrowindex = 0;
        private int _displayrowindex = 0;
        public List<int> rowList = new List<int>();

        public ContractLedgerForm()
        {
            InitializeComponent();
            this.dgvContractLedger.AutoGenerateColumns = false;
            
        }

        private IF_ManagementBook entity = new IF_ManagementBook();//検索条件
        private void ContractLedgerForm_Load(object sender, EventArgs e)
        {
            try
            {
                //指定年を設定
                DateTime datenow = DateTime.Now;

                string datanow_year = datenow.ToString("yyyy");//年
                string datanow_month = datenow.ToString("MM");//月

                this.cobYear.SelectedItem = datanow_year;
                this.cobMonth.SelectedItem = datanow_month;
                //検索条件
                this.entity.WorkMonth = datanow_year + "/" + datanow_month;

                //面データを取得
                loadData(this.entity);

                //Reset画面項目
                resetAll();


                if (BL_User.GetLoginInfo().UserID == "wangli")
                {
                    String nextMonth = DateTime.Now.AddMonths(1).ToString("yyyy/MM");
                    BL_ManagementBook mb = BL_ManagementBook.GetInstance();
                    if (!mb.SelectFlgByNextMonth(nextMonth)){
                        this.btnInsert.Enabled = true;
                    }
                }
                
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 変更したデータを赤い色で表示する
        /// </summary>
        public void setColor()
        {
            if (rowList != null)
            {
                for (int i = 0; i < rowList.Count; i++)
                {
                    this.dgvContractLedger.Rows[rowList[i]].DefaultCellStyle.BackColor = Color.Red;
                }
            }
        }
        /// <summary>
        /// Reset画面項目
        /// </summary>
        private void resetAll()
        {
            //cobMonth.SelectedIndex = -1;//月
            cobCustomerID.SelectedIndex = -1;//顧客ID
            cobEmployeeID.SelectedIndex = -1;//技術者ID
            cobWorkAddr.SelectedIndex = -1;//現場ID
            cobEmployeeType.SelectedIndex = -1;//社員区分
        }
        /// <summary>
        /// 画面データを初期化
        /// </summary>
        public void loadData(IF_ManagementBook _entity)
        {
            if (_entity == null) { _entity = this.entity; }

            this.changeCobEnabled(false);

            //Show_Thread_Status();
            //Thread_Status.Visible = true;
            //this.Refresh();

            ThreadPoolHelper.StartThread(this, 
                () => { return BL_ManagementBook.GetInstance().SelectManagementBook(_entity); },
                (obj) => {
                    dgvContractLedger.DataSource = obj as DataTable;
                    lblRowsCount.Text = dgvContractLedger.Rows.Count.ToString(("#,0"));

                    if (dgvContractLedger.RowCount > 0)
                    {
                        dgvContractLedger.Rows[0].Selected = false;
                        dgvContractLedger.Rows[this._selectrowindex].Selected = true;
                        dgvContractLedger.FirstDisplayedScrollingRowIndex = this._displayrowindex;
                    }
                    //Commbox DataSourceを指定
                    bindCommbox();

                    this.changeCobEnabled(true);
                    this.setColor();

                });

            //dgvContractLedger.DataSource = BL_ManagementBook.GetInstance().SelectManagementBook(_entity);

            //dgvContractLedger.Columns["ManagementID"].Visible = false;//管理ID
            //dgvContractLedger.Columns["EmployeeID"].Visible = false;//社員ID
            //dgvContractLedger.Columns["Salesman1ID"].Visible = false;//営業担当１ID
            //dgvContractLedger.Columns["Salesman2ID"].Visible = false;//営業担当２ID
            //dgvContractLedger.Columns["EmployeeType"].Visible = false;//社員区分
            //dgvContractLedger.Columns["CustomerID"].Visible = false;//顧客ID
            //dgvContractLedger.Columns["PaymentType"].Visible = false;//支払方法
            //dgvContractLedger.Columns["PaymentDay"].Visible = false;//支払日

            //lblRowsCount.Text = dgvContractLedger.Rows.Count.ToString(("#,0"));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="_enabled"></param>
        private void changeCobEnabled(bool _enabled)
        {
            this.cobYear.Enabled = this.cobYearEnd.Enabled = this.cobMonth.Enabled = this.cobMonthEnd.Enabled =
                        this.cobMemo.Enabled = this.cobCustomerID.Enabled = this.cobEmployeeID.Enabled = this.cobWorkAddr.Enabled =
                        this.cobEmployeeType.Enabled = this.txtEmployeeName.Enabled = this.txtCustomerName.Enabled = _enabled;
        }
        /// <summary>
        /// 画面データをリロード
        /// </summary>
        private void reloadData(string nextMonth, BL_ManagementBook mb)
        {
            ThreadPoolHelper.StartThread(this,
                () =>
                {
                    mb.SelectByWorkMonth(DateTime.Now.ToString("yyyy/MM"), nextMonth);
                    mb.UpdateMonth(nextMonth);

                    IF_ManagementBook bl = new IF_ManagementBook();
                    bl.WorkMonth = nextMonth;
                    if (bl == null) { bl = this.entity; }
                    return BL_ManagementBook.GetInstance().SelectManagementBook(bl); },
                (obj) =>
                {
                    //DataTable dt = (DataTable)obj;
                    dgvContractLedger.DataSource = (DataTable)obj;
                    lblRowsCount.Text = dgvContractLedger.Rows.Count.ToString(("#,0"));
                    for (int i = 0; i < dgvContractLedger.Rows.Count; i++)
                    {
                        String workMonth = CommonHandler.ToString(dgvContractLedger.Rows[i].Cells["WorkMonth"].Value) + "/01";
                        String endDate = CommonHandler.ToString(dgvContractLedger.Rows[i].Cells["EndDate"].Value);
                        if (endDate.Length > 5)
                        {
                            if (Convert.ToDateTime(endDate).CompareTo(DateTime.Now) == -1)
                            {
                                this.dgvContractLedger.Rows[i].DefaultCellStyle.BackColor = Color.Red;
                            }
                        }
                    }
                }
                );
            //loadData(_entity);

            //for (int i = 0; i < dgvContractLedger.Rows.Count; i++)
            //{
            //    String workMonth=CommonHandler.ToString(dgvContractLedger.Rows[i].Cells["WorkMonth"].Value)+"/01";
            //    String endDate = CommonHandler.ToString(dgvContractLedger.Rows[i].Cells["EndDate"].Value);
            //    if (endDate.Length > 5)
            //    {
            //        if (Convert.ToDateTime(endDate).CompareTo(DateTime.Now) == -1)
            //        {
            //            this.dgvContractLedger.Rows[i].DefaultCellStyle.BackColor = Color.Red;
            //        }
            //    }
            //}

        }

        #endregion

        #region 画面動作
        /// <summary>
        /// Commbox DataSourceを指定
        /// </summary>
        private void bindCommbox()
        {
            //getRowAllValue(cobCustomerID);//顧客ID
            //getRowAllValue(cobEmployeeID);//技術者

            this.loadCobDatasouse(cobCustomerID, txtCustomerName);//顧客ID
            this.loadCobDatasouse(cobEmployeeID, txtEmployeeName);//技術者

            getRowAllValue(cobWorkAddr);//現場

            if (cobEmployeeType.Items.Count<1)
            {
                BL_CodeMaster bl = BL_CodeMaster.GetInstance();
                DataTable dt = bl.SelectCodeMaster("CD001");//社員区分
                //空白行
                DataRow dr = dt.NewRow();
                dr[cobEmployeeType.ValueMember] = null;
                dr[cobEmployeeType.DisplayMember] = "";
                dt.Rows.InsertAt(dr,0);

                cobEmployeeType.DataSource = dt;
     
               //getRowAllValue(cobEmployeeType);//社員区分
            }
        }
        /// <summary>
        /// COMBOBOX マスタ取得　顧客/技術者 
        /// </summary>
        /// <param name="cob"></param>
        /// <param name="txtBox"></param>
        private void loadCobDatasouse(ComboBox cob,TextBox txtBox)
        {
            if (cob.Items.Count < 1 && !string.IsNullOrEmpty(cob.DisplayMember) && !string.IsNullOrEmpty(cob.ValueMember))
            {
                this.txtBox_TextChanged(txtBox, null);
            }
        }
        /// <summary>
        /// 指定列内容を取得
        /// </summary>
        private void getRowAllValue(ComboBox cob)
        {
            string displayName = cob.DisplayMember;
            string valueName = cob.ValueMember;

            if (cob.Items.Count > 0 || string.IsNullOrEmpty(displayName) || string.IsNullOrEmpty(valueName))
            {
                return;
            }
            else
            {
                cob.DataSource = null;
                cob.Items.Clear();
            }

            DataTable dt = new DataTable();
            dt.Columns.Add(displayName);
            if (displayName != valueName)
            {
                dt.Columns.Add(valueName);
            }

            //空白行
            DataRow dr = dt.NewRow();
            dr[valueName] = -1;
            dr[displayName] = "";
            dt.Rows.Add(dr);

            foreach (DataGridViewRow dgvr in dgvContractLedger.Rows)
            {

                if (dgvr.Cells[displayName] != null && dgvr.Cells[valueName] != null)
                {
                    if (!string.IsNullOrEmpty(dgvr.Cells[displayName].Value.ToString()))
                    {
                        dr = dt.NewRow();
                        dr[valueName] = dgvr.Cells[valueName].Value;
                        dr[displayName] = dgvr.Cells[displayName].Value;
                        dt.Rows.Add(dr);
                    }
                }
                else
                {
                    throw new System.ArgumentException("Parameter cannot be null", "original");
                }
            }
            //重複させないように
            string[] distinctcols = new string[(dt.Columns.Count)];
            foreach (DataColumn dc in dt.Columns)
            {
                distinctcols[dc.Ordinal] = dc.ColumnName;
            }

            DataView mydataview = new DataView(dt);

            cob.DataSource = mydataview.ToTable(true, distinctcols);
        }

        bool _group1visuble = false;
        bool _group2visuble = false;
        bool _group3visuble = false;
        bool _group4visuble = false;

        #region テキストチェンジ
        /// <summary>
        /// 検索条件を取得
        /// </summary>
        private void getSearchCondition()
        {
            //既存検索条件をクリア
            this.entity.WorkMonthEnd = null;
            this.entity.CustomerName = null;
            this.entity.EmployeeName = null;

            //年月を取得
            this.entity.WorkMonth = CommonHandler.ToString(cobYear.Text) + "/" + CommonHandler.ToString(cobMonth.Text);
            //顧客
            this.entity.CustomerID = CommonHandler.ToInt(cobCustomerID.SelectedValue);
            //技術者
            this.entity.EmployeeName = CommonHandler.ToString(cobEmployeeID.Text);
            //現場
            this.entity.WorkAddr = CommonHandler.ToString(cobWorkAddr.Text);
            //社員区分
            this.entity.EmployeeType = CommonHandler.ToString(cobEmployeeType.SelectedValue);
            //備考
            this.entity.Memo = CommonHandler.ToString(cobMemo.Text);
            //検索期間ー稼働月end
            if (!string.IsNullOrEmpty(cobYearEnd.Text) && !string.IsNullOrEmpty(cobMonthEnd.Text))
            {
                this.entity.WorkMonthEnd = CommonHandler.ToString(cobYearEnd.Text) + "/" + CommonHandler.ToString(cobMonthEnd.Text);
            }
        }
        /// <summary>
        /// 技術者・顧客　検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                //検索条件を取得
                this.getSearchCondition();

                TextBox tb = (TextBox)sender;
                ComboBox cb = null;
                DataTable dt = null;

                switch (tb.Name)
                {
                    case "txtEmployeeName":
                        cb = this.cobEmployeeID;
                        this.entity.EmployeeName = this.txtEmployeeName.Text;
                        dt = BL_ManagementBook.GetInstance().SelectfuzzyEmployee(this.entity);//技術者
                        break;
                    case "txtCustomerName":
                        cb = this.cobCustomerID;
                        this.entity.CustomerName = this.txtCustomerName.Text;
                        dt = BL_ManagementBook.GetInstance().SelectfuzzyCustomer(this.entity);//顧客
                        break;
                    default:
                        break;

                }
                if (cb != null && dt != null)
                {
                    //空白行
                    DataRow dr = dt.NewRow();
                    dr[cb.ValueMember] = -1;
                    dr[cb.DisplayMember] = "";
                    dt.Rows.InsertAt(dr,0);

                    cb.DataSource = dt;
                    cb.SelectedIndex = -1;//リセット
                }
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// コンボボックスチェンジ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cob_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                this._selectrowindex = 0;
                this._displayrowindex = 0;
                //検索条件を取得
                this.getSearchCondition();

                //面データを取得
                //ThreadPoolHelper.StartThread(this,
                //() => { return BL_ManagementBook.GetInstance().SelectManagementBook(this.entity); },
                //(obj) =>
                //{
                //    //DataTable dt = (DataTable)obj;
                //    dgvContractLedger.DataSource = (DataTable)obj;
                //    lblRowsCount.Text = dgvContractLedger.Rows.Count.ToString(("#,0"));
                //    Thread_Status.Visible = false;
                //}
                //);
                loadData(this.entity);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        #endregion
        /// <summary>
        /// 契約台帳明細
        /// </summary>
        private void dgvContractLedger_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
            if (e.RowIndex == -1)
            {
                if (e.ColumnIndex == this.dgvContractLedger.Columns["Group1"].Index)
                {
                    _group1visuble = !_group1visuble;
                    this.dgvContractLedger.Columns["Group1"].HeaderText = _group1visuble ? "-" : "+";
                    this.dgvContractLedger.Columns["Group1"].HeaderCell.ToolTipText = _group1visuble ? "非表示" : "表示";
                    this.dgvContractLedger.Columns["EmployeeTypeName"].Visible = _group1visuble;
                    this.dgvContractLedger.Columns["DeptName"].Visible = _group1visuble;
                    this.dgvContractLedger.Columns["siireName"].Visible = _group1visuble;
                    this.dgvContractLedger.Columns["siireSales"].Visible = _group1visuble;
                    this.dgvContractLedger.Columns["TranExpense"].Visible = _group1visuble;
                    this.dgvContractLedger.Columns["CostStartDate"].Visible = _group1visuble;
                    this.dgvContractLedger.Columns["CostEndDate"].Visible = _group1visuble;
                }
                else if (e.ColumnIndex == this.dgvContractLedger.Columns["Group2"].Index)
                {
                    _group2visuble = !_group2visuble;
                    this.dgvContractLedger.Columns["Group2"].HeaderText = _group2visuble ? "-" : "+";
                    this.dgvContractLedger.Columns["CustSalesman"].Visible = _group2visuble;
                    this.dgvContractLedger.Columns["ContractName"].Visible = _group2visuble;
                    this.dgvContractLedger.Columns["WorkAddr"].Visible = _group2visuble;
                    this.dgvContractLedger.Columns["StartDate"].Visible = _group2visuble;
                    this.dgvContractLedger.Columns["EndDate"].Visible = _group2visuble;
                }
                else if (e.ColumnIndex == this.dgvContractLedger.Columns["Group3"].Index)
                {
                    _group3visuble = !_group3visuble;
                    this.dgvContractLedger.Columns["Group3"].HeaderText = _group3visuble ? "-" : "+";
                    this.dgvContractLedger.Columns["MinHour"].Visible = _group3visuble;
                    this.dgvContractLedger.Columns["MaxHour"].Visible = _group3visuble;
                    this.dgvContractLedger.Columns["MinusUnitPrice"].Visible = _group3visuble;
                    this.dgvContractLedger.Columns["PlusUnitPrice"].Visible = _group3visuble;
                    this.dgvContractLedger.Columns["PaymentSet"].Visible = _group3visuble;
                }
                else if (e.ColumnIndex == this.dgvContractLedger.Columns["Group4"].Index)
                {
                    _group4visuble = !_group4visuble;
                    this.dgvContractLedger.Columns["Group4"].HeaderText = _group4visuble ? "-" : "+";
                    this.dgvContractLedger.Columns["OrderNo"].Visible = _group4visuble;
                }
                return;
            }
            try
            {
                ContractLedgerAddForm form = new ContractLedgerAddForm();
                this._selectrowindex = dgvContractLedger.CurrentRow.Index;
                this._displayrowindex = dgvContractLedger.FirstDisplayedScrollingRowIndex;

                form._entity = this.GetEntityByIndex(this._selectrowindex);
                

                form._parentForm = this;
                form.Text = "社内管理台帳更新";
                form.ShowDialog();

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 台帳詳細を取得
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private IF_ManagementBook GetEntityByIndex(int row)
        {
            IF_ManagementBook entity = new IF_ManagementBook();

            entity.ManagementID = CommonHandler.ToInt(dgvContractLedger.Rows[row].Cells["ManagementID"].Value);//管理ID
            entity.EmployeeID = CommonHandler.ToInt(dgvContractLedger.Rows[row].Cells["EmployeeID"].Value);//技術者ID
            entity.EmployeeName = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["EmployeeName"].Value);//技術者氏名
            entity.Salesman1Name = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["Salesman1Name"].Value);//営業担当１氏名
            entity.Salesman2Name = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["Salesman2Name"].Value);//営業担当２氏名
            entity.CustomerName = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["CustomerName"].Value);//顧客会社
            entity.EmployeeType = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["EmployeeType"].Value);//社員区分
            entity.CustSalesman = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["CustSalesman"].Value);//顧客窓口
            entity.ContractName = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["ContractName"].Value);//プロジェクト名
            entity.ProjectName = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["ProjectName"].Value);//作業工程
            entity.WorkAddr = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["WorkAddr"].Value);//現場
            entity.WorkMonth = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["WorkMonth"].Value);//稼働月
            entity.StartDate = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["StartDate"].Value);//契約開始
            entity.EndDate = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["EndDate"].Value);//契約終了
            entity.Amount = CommonHandler.ToDecimal(dgvContractLedger.Rows[row].Cells["Amount"].Value);//売上
            entity.MinHour = CommonHandler.ToDecimal(dgvContractLedger.Rows[row].Cells["MinHour"].Value);//稼働下限
            entity.MaxHour = CommonHandler.ToDecimal(dgvContractLedger.Rows[row].Cells["MaxHour"].Value);//稼働上限
            entity.MinusUnitPrice = CommonHandler.ToDecimal(dgvContractLedger.Rows[row].Cells["MinusUnitPrice"].Value);//控除単価
            entity.PlusUnitPrice = CommonHandler.ToDecimal(dgvContractLedger.Rows[row].Cells["PlusUnitPrice"].Value);//超過単価
            entity.Quantity = CommonHandler.ToDecimal(dgvContractLedger.Rows[row].Cells["Quantity"].Value);//日割計算
            entity.PaymentType = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["PaymentType"].Value);//支払方法
            entity.PaymentDay = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["PaymentDay"].Value);//支払日
            entity.TranExpense = CommonHandler.ToDecimal(dgvContractLedger.Rows[row].Cells["TranExpense"].Value);//交通費
            entity.CostStartDate = CommonHandler.ToDecimal(dgvContractLedger.Rows[row].Cells["CostStartDate"].Value);//原価開始期間
            entity.CostEndDate = CommonHandler.ToDecimal(dgvContractLedger.Rows[row].Cells["CostEndDate"].Value);//原価終了期間
            entity.Price = CommonHandler.ToDecimal(dgvContractLedger.Rows[row].Cells["Price"].Value);//単価
            entity.Unit = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["Unit"].Value);//単位
            entity.Memo = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["Memo"].Value);//備考
            entity.OrderDate = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["OrderDate"].Value);//注文書届日
            entity.OrderNo = CommonHandler.ToString(dgvContractLedger.Rows[row].Cells["OrderNo"].Value);//注文書番号

            return entity;
        }
        #region ボタンー
        /// <summary>
        /// 新規追加
        /// </summary>
        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                ContractLedgerAddForm form = new ContractLedgerAddForm();

                form._parentForm = this;
                form.ShowDialog();
                //if (form.PARA_IsAddOK)
                //{
                //    int row = dgvContractLedger.RowCount - 1;
                //    dgvContractLedger.Rows[0].Selected = false;
                //    dgvContractLedger.Rows[row].Selected = true;
                //}
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 契約情報自動登録
        /// </summary>
        private void btnAutoRegister_Click(object sender, EventArgs e)
        {
            try
            {
                ContractAutoAddForm form = new ContractAutoAddForm();
                int listCount = 0;
                for (int i = 0; i < dgvContractLedger.Rows.Count; i++)
                {
                    if ((bool)dgvContractLedger.Rows[i].Cells["check"].EditedFormattedValue == true)
                    {
                        form.EntityList.Add(this.GetEntityByIndex(i));
                        listCount = form.EntityList.Count;
                        if (listCount > 0)
                        {
                            if (!form.EntityList[0].CustomerName.Equals(form.EntityList[listCount - 1].CustomerName))
                            {
                                MessageHelper.ShowinforMessageByID("EB3001");//顧客会社が一致しない
                                return;
                            }
                            if (!form.EntityList[0].OrderNo.Equals(form.EntityList[listCount - 1].OrderNo))
                            {
                                if (MessageHelper.ShowConfirmMessage("EB3003") == DialogResult.No)
                                {
                                    //注文書番号が一致しない
                                    return;
                                }
                            }
                        }
                    }
                }
                if (listCount > 0)
                {
                    form.ShowDialog();
                }
                else
                {
                    form.EntityList.Add(new IF_ManagementBook());
                    //MessageHelper.ShowinforMessageByID("EB0010","台帳詳細");
                }
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            List<Int32> managementIDs = new List<Int32>();
            for (int i = 0; i < dgvContractLedger.Rows.Count; i++)
            {
                if ((bool)dgvContractLedger.Rows[i].Cells["check"].EditedFormattedValue == true)
                {
                    managementIDs.Add(Convert.ToInt32(dgvContractLedger.Rows[i].Cells["ManagementID"].Value));
                }
            }
            if (managementIDs.Count > 0)
            {
                if (MessageHelper.ShowDeleteConfirmMessage() != DialogResult.Yes)
                {
                    return;
                }
                // 削除処理
                BL_ManagementBook bl = BL_ManagementBook.GetInstance();
                bl.DeleteManagementBook(managementIDs);

                //画面データを初期化
                loadData(this.entity);
                
                MessageHelper.ShowinforMessageByID("EB1005");//削除成功しました
            }
            else
            {
                MessageHelper.ShowinforMessageByID("EB0010","削除したいデータ");
            }
        }


        private void btnInsert_Click(object sender, EventArgs e)
        {
            BL_ManagementBook mb = BL_ManagementBook.GetInstance();
            String nextMonth = CommonHandler.NextMonth(DateTime.Now.ToString("yyyy/MM"));

            //仮台帳作成済チェック
            if (mb.SelectFlgByNextMonth(nextMonth))
            {
                //if (MessageHelper.ShowConfirmMessage("EB3005") == DialogResult.Yes)
                //{
                //    //面データを取得
                //    reloadData(nextMonth,mb);
                //}
            }
            else 
            {
                //mb.SelectByWorkMonth(DateTime.Now.ToString("yyyy/MM"), nextMonth);
                //mb.UpdateMonth(nextMonth);

                //IF_ManagementBook bl = new IF_ManagementBook();
                //bl.WorkMonth = nextMonth;

                //面データを取得
                this.btnInsert.Enabled = false;
                reloadData(nextMonth, mb);
                //reloadData(bl);
            }

        }
        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            BL_ManagementBook mb = BL_ManagementBook.GetInstance();
            DataTable dt=mb.SelectContactDetail00();
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("契約データが存在しません"); 
            }
            else
            {
                mb.InsertManagementBook00(dt);
                MessageBox.Show("処理成功しました");
            }
        }



        #endregion

        private void cobMemo_SelectionChangeCommitted(object sender, EventArgs e)
        {
            //検索条件を取得
            this.getSearchCondition();

            //面データを取得
            loadData(this.entity);

        }
    }
}
