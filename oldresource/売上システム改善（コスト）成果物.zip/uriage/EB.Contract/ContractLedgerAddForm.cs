﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;
using EB.Contract;

namespace EB.Contract
{
    public partial class ContractLedgerAddForm : DialogForm
    {
        #region 初期化

        public IF_ManagementBook _entity = new IF_ManagementBook();

        private List<string[]> partner = null;


        public ContractLedgerAddForm()
        {
            InitializeComponent();
            this.dtp_OrderDate.Format = DateTimePickerFormat.Custom;
            this.dtp_OrderDate.CustomFormat = "   ";
        }


        /// <summary>
        /// 初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ContractLedgerAddForm_Load(object sender, EventArgs e)
        {
            //Commbox DataSourceを指定
            bindCommbox();

            //string str_Temp = System.Configuration.ConfigurationSettings.AppSettings["partner"].ToString();
            string str_Temp = MessageHelper.GetMessagebyID("PARTNER");
            string[] str_partner = str_Temp.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            partner = new List<string[]>();
            foreach (string parm in str_partner)
            {
                string[] partner_Split = parm.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                partner.Add(partner_Split);
            }

            //面データを初期化
            loadData();
        }
        /// <summary>
        /// データ取得
        /// </summary>
        private void loadData()
        {
            DateTime dtime;

            if (this._entity.ManagementID <= 0)
            {
                btnUpdate.Visible = false;//更新btn使用不能にする

                cobEmployeeID.SelectedIndex = -1;//社員ID
                cobSalesman1.SelectedIndex = -1;//営業担当１
                cobSalesman2.SelectedIndex = -1;//営業担当２
                cobCustomerID.SelectedIndex = -1;//顧客ID
                cobPaymentType.SelectedIndex = -1;//支払方法
                cobPaymentDay.SelectedIndex = -1;//支払日

                dtime = DateTime.Now;

                DateTime dt_temp = DateTime.Parse(dtime.ToString("yyyy/MM"));
                dtp_StartDate.Value = dt_temp;
                dtp_EndDate.Value = dt_temp.AddMonths(1).AddDays(-1);

                cobMonth.Text = dtime.ToString("MM");//月
                cobYear.Text = dtime.ToString("yyyy");//年

            }
            else
            {
                //btnRegister.Visible = false;//新規追加btn使用不能にする
                dtime = DateTime.Parse(this._entity.WorkMonth);
                cobMonth.Text = dtime.ToString("MM");//月
                cobYear.Text = dtime.ToString("yyyy");//年
                cobEmployeeID.Text = this._entity.EmployeeName;//社員氏名
                cobSalesman1.Text = this._entity.Salesman1Name;//営業担当１氏名
                cobSalesman2.Text = this._entity.Salesman2Name;//営業担当２氏名
                cobCustomerID.Text = this._entity.CustomerName;//顧客会社
                getDeptNameAndEmployeeType();//所属部門と社員区分
                txtCustSalesman.Text = this._entity.CustSalesman;//顧客窓口
                txtContractName.Text = this._entity.ContractName;//プロジェクト名
                txtProjectName.Text = this._entity.ProjectName;//作業工程
                txtWorkAddr.Text = this._entity.WorkAddr;//現場
                dtp_StartDate.Text = this._entity.StartDate;//契約開始
                dtp_EndDate.Text = this._entity.EndDate;//契約終了
                txtAmount.Text = CommonHandler.ToString(this._entity.Amount);//売上
                txtPrice.Text = CommonHandler.ToString(this._entity.Price);//単価
                txtMinHour.Text = CommonHandler.ToString(this._entity.MinHour);//稼働下限
                txtMaxHour.Text = CommonHandler.ToString(this._entity.MaxHour);//稼働上限
                txtMinusUnitPrice.Text = CommonHandler.ToString(this._entity.MinusUnitPrice);//控除単価
                txtPlusUnitPrice.Text = CommonHandler.ToString(this._entity.PlusUnitPrice);//超過単価
                txtQuantity.Text = CommonHandler.ToString(this._entity.Quantity);//日割計算
                cobPaymentType.Text = this._entity.PaymentType;//支払方法
                cobPaymentDay.Text = this._entity.PaymentDay;//支払日
                txtTranExpense.Text = CommonHandler.ToString(this._entity.TranExpense);//交通費
                txtMemo.Text = this._entity.Memo;//備考
                if (!string.IsNullOrEmpty(this._entity.OrderDate))
                {
                    dtp_OrderDate.Text = this._entity.OrderDate;//注文書届日
                }
                txtOrderNo.Text = this._entity.OrderNo;//注文書番号
                if (string.IsNullOrEmpty(this._entity.Unit))
                {
                    this._entity.Unit = "1";
                }
                cobUnit.Text = CommonHandler.GetTextByValueFromCob(this.cobUnit, this._entity.Unit);//単位
            }
            //Reset画面項目
            resetAll();
        }
        #endregion
        #region 画面動作
        /// <summary>
        /// Commbox DataSourceを指定
        /// </summary>
        private void bindCommbox()
        {
            BL_CodeMaster bl = BL_CodeMaster.GetInstance();

            cobPaymentType.DataSource = bl.SelectCodeMaster("CD005");//支払方法
            cobPaymentDay.DataSource = bl.SelectCodeMaster("CD006");//支払日
            cobEmployeeType.DataSource = bl.SelectCodeMaster("CD001");//社員区分
            cobCustomerID.DataSource = BL_Customer.GetInstance().SelectAllCustomer(null);//顧客ID
            cobSalesman1.DataSource = getSalesEmployee();//営業担当１
            cobSalesman2.DataSource = getSalesEmployee();//営業担当２
            cobEmployeeID.DataSource = BL_Employee.GetInstance().SelectTechEmployee();//技術者
            cobUnit.DataSource = bl.SelectCodeMaster("CD008");//単位
        }
        /// <summary>
        /// 営業担当Combobox用のDataSourceを取得

        /// <returns></returns>
        private DataTable getSalesEmployee()
        {
            DataTable dt = BL_Employee.GetInstance().SelectSalesEmployee();
            DataRow dr = dt.NewRow();
            dr["EmployeeName"] = "";
            dr["EmployeeID"] = -1;

            dt.Rows.InsertAt(dr, 0);

            return dt;
        }


        /// <summary>
        /// 仕入先Combobox用のDataSourceを取得
        /// </summary>
        /// <returns></returns>
        private DataTable getSiire()
        {
            DataTable dt = BL_Employee.GetInstance().SelectSiire();
            DataRow dr = dt.NewRow();
            dr["SiireName"] = "";
            dr["SiireID"] = -1;

            dt.Rows.InsertAt(dr, 0);

            return dt;
        }




        /// <summary>
        /// 所属部門と社員区分を取得
        /// </summary>
        private void getDeptNameAndEmployeeType()
        {
            //string name = cobEmployeeID.Text;
            //DataTable dt = BL_Employee.GetInstance().SelectEmployeeByName(name);
            int employeeID = CommonHandler.ToInt(cobEmployeeID.SelectedValue);
            string workmonth = cobYear.Text + "/" + cobMonth.Text;
            DataTable dt = BL_Employee.GetInstance().SelectEmployeeById(employeeID, workmonth);

            if (dt.Rows.Count > 0)
            {
                getEmployeeType(dt.Rows[0]["EmployeeType"].ToString());
                txtSiireName.Text = dt.Rows[0]["CustomerName"].ToString();
                txtSiireSales.Text = dt.Rows[0]["siireSales"].ToString();


                string stxt = CommonHandler.ToString(dt.Rows[0]["siirePrice"].ToString());//仕入先単価
                if (!stxt.Equals(""))
                {
                    long longPrice = long.Parse(stxt);
                    siirePrice.Text = longPrice.ToString("#,0");
                }
                else
                {
                    siirePrice.Text = stxt;
                }

                //txtPrice.Text = dt.Rows[0]["siirePrice"].ToString();
            }
        }
        /// <summary>
        /// 社員区分を取得
        /// </summary>
        private void getEmployeeType(string employeeType)
        {
            foreach (System.Data.DataRowView dr in cobEmployeeType.Items)
            {
                if (dr["CodeID"].ToString() == employeeType)
                {
                    txtEmployeeType.Text = dr["CodeName"].ToString();
                }
            }
        }
        /// <summary>
        /// 社員氏名を指定
        /// </summary>
        private void cobEmployeeID_SelectionChangeCommitted(object sender, EventArgs e)
        {
            // 所属部門と社員区分を取得
            getDeptNameAndEmployeeType();
        }
        /// <summary>
        /// 新規追加
        /// </summary>
        private void btnRegister_Click(object sender, EventArgs e)
        {

            try
            {
                //入力チェック
                if (!isValidCheck()) return;




                //登録処理
                proceessRegister();


                //Reset画面項目
                resetAll();

                MessageHelper.ShowinforMessageByID("EB1001");//登録成功しました。

                this.Close();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheck()
        {
            if (cobEmployeeID.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "技術者氏名");
                return false;
            }
            if (cobSalesman1.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "営業担当１");
                return false;
            }
            else if (cobSalesman1.SelectedIndex == cobSalesman2.SelectedIndex)
            {
                MessageHelper.ShowinforMessageByID("EB0010", "重複していない営業担当");
                return false;
            }
            if (cobCustomerID.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "顧客会社");
                return false;
            }
            //if (string.IsNullOrEmpty(txtContractName.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "プロジェクト");
            //    return false;
            //}
            //if (string.IsNullOrEmpty(txtQuantity.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "日割計算");
            //    return false;
            //}

            if (cobPaymentType.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "支払サイト");
                return false;
            }
            if (cobPaymentDay.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "支払サイト");
                return false;
            }
            if (!CommonHandler.startEndDayCheck(dtp_StartDate.Text, dtp_EndDate.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0013");
                return false;
            }
            //稼働月 --> 契約期間
            string workMonth = cobYear.Text + "/" + cobMonth.Text;//稼働月

            DateTime workMonth_start = DateTime.Parse(workMonth);
            DateTime workMonth_end = workMonth_start.AddMonths(1).AddDays(-1);

            if (!CommonHandler.startEndDayCheck(workMonth_start.ToString(), dtp_EndDate.Text) || !CommonHandler.startEndDayCheck(dtp_StartDate.Text, workMonth_end.ToString()))
            {
                MessageHelper.ShowinforMessageByID("EB0018", "稼働月は契約期間外です");
                return false;
            }


            this.isValidCheckEmployee(false);

            return true;
        }




        /// <summary>
        /// 明細の技術者チェック　他の契約
        /// </summary>
        /// <returns></returns>
        private bool isValidCheckEmployee(bool isConfirm)
        {

            BL_ContractDetail bl = BL_ContractDetail.GetInstance();

            IF_ContractDetail entity = new IF_ContractDetail();
            entity.ContractID = -1;//契約番号
            entity.EmployeeID = CommonHandler.ToInt(cobEmployeeID.SelectedValue.ToString());//技術者番号
            entity.StartDate = dtp_StartDate.Text;//開始日
            entity.EndDate = dtp_EndDate.Text;//終了日



            DataTable dt = bl.CheckContractDetailByEmployeeID(entity);

            if (dt.Rows.Count > 0)
            {
                string CompanyName = "";

                foreach (DataRow dr in dt.Rows)
                {
                    CompanyName += dr["CustomerName"].ToString() + "[" + dr["StartDate"].ToString() + "～" + dr["EndDate"].ToString() + "]\n";
                }
                if (isConfirm)
                {
                    return MessageHelper.ShowConfirmMessage("EB0015", "技術者の契約:\n" + CompanyName + "が") == DialogResult.Yes;
                }
                else
                {
                    MessageHelper.ShowinforMessageByID("EB0015", "技術者の契約:\n" + CompanyName + "が");
                }
                return false;
            }
            return true;
        }




        /// <summary>
        /// 登録処理
        /// </summary>
        private void proceessRegister()
        {
            getEntity();

            BL_ManagementBook bl = BL_ManagementBook.GetInstance();
            bl.InsertManagementBook(this._entity);
            if (_parentForm != null)
            {
                _parentForm.loadData(null);

            }
        }
        private bool issetEvent = false;
        /// <summary>
        /// Reset画面項目
        /// </summary>
        private void resetAll()
        {
            if (!issetEvent)
            {
                issetEvent = true;
                this.cobSalesman1.SelectedIndexChanged += new System.EventHandler(this.cobSalesman_SelectedIndexChanged);
                this.cobSalesman2.SelectedIndexChanged += new System.EventHandler(this.cobSalesman_SelectedIndexChanged);
            }

        }

        public ContractLedgerForm _parentForm;
        /// <summary>
        /// 更新
        /// </summary>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            _parentForm.rowList.Add(_parentForm._selectrowindex);
            //入力チェック
            if (!isValidCheck()) return;

            //更新処理
            proceessUpdate();

            MessageHelper.ShowinforMessageByID("EB1003");//更新成功しました。


            this.Close();


            if (_parentForm != null)
            {
                _parentForm.loadData(null);
                
            }

        }
        /// <summary>
        /// 更新処理
        /// </summary>
        private void proceessUpdate()
        {
            getEntity();

            BL_ManagementBook bl = BL_ManagementBook.GetInstance();
            bl.UpdateManagementBook(this._entity);
        }
        /// <summary>
        /// エンティティを設定
        /// </summary>
        private IF_ManagementBook getEntity()
        {
            //IF_ManagementBook entity = new IF_ManagementBook();

            this._entity.EmployeeID = CommonHandler.ToInt(cobEmployeeID.SelectedValue);//社員ID
            this._entity.EmployeeName = cobEmployeeID.Text;//社員名
            this._entity.Salesman1ID = CommonHandler.ToInt(cobSalesman1.SelectedValue);//営業担当１ID
            this._entity.Salesman2ID = CommonHandler.ToInt(cobSalesman2.SelectedValue);//営業担当２ID
            this._entity.Salesman1Name = cobSalesman1.Text;//営業担当１氏名
            this._entity.Salesman2Name = cobSalesman2.Text;//営業担当２氏名
            this._entity.DeptName = txtDeptName.Text;//所属部門
            this._entity.siireName = txtSiireName.Text;//仕入
            this._entity.siireSales = txtSiireSales.Text;//仕入先担当
            this._entity.EmployeeType = CommonHandler.ToString(cobEmployeeType.SelectedValue);//社員区分
            this._entity.EmployeeTypeName = cobEmployeeType.Text;//社員区分名
            this._entity.CustomerID = CommonHandler.ToInt(cobCustomerID.SelectedValue);//顧客ID
            this._entity.CustomerName = cobCustomerID.Text;//顧客会社
            this._entity.CustSalesman = txtCustSalesman.Text;//顧客窓口
            this._entity.ContractName = txtContractName.Text;//プロジェクト名
            this._entity.ProjectName = txtProjectName.Text;//作業工程
            this._entity.WorkAddr = txtWorkAddr.Text;//現場
            this._entity.WorkMonth = cobYear.Text + "/" + cobMonth.Text;//稼働月


            this._entity.StartDate = dtp_StartDate.Text;//開始日
            this._entity.EndDate = dtp_EndDate.Text;//終了日
            this._entity.Amount = CommonHandler.ToDecimal(txtAmount.Text);//売上
            this._entity.MinHour = CommonHandler.ToDecimal(txtMinHour.Text);//稼働下限
            this._entity.MaxHour = CommonHandler.ToDecimal(txtMaxHour.Text);//稼働上限
            this._entity.MinusUnitPrice = CommonHandler.ToDecimal(txtMinusUnitPrice.Text);//控除単価
            this._entity.PlusUnitPrice = CommonHandler.ToDecimal(txtPlusUnitPrice.Text);//超過単価
            this._entity.Quantity = CommonHandler.ToDecimal(txtQuantity.Text);//日割計算
            this._entity.PaymentType = cobPaymentType.Text;//支払方法
            this._entity.PaymentDay = cobPaymentDay.Text;//支払日
            this._entity.TranExpense = CommonHandler.ToDecimal(txtTranExpense.Text);//交通費
            this._entity.Price = CommonHandler.ToDecimal(txtPrice.Text);//単価
            this._entity.Unit = CommonHandler.ToString(this.cobUnit.SelectedValue);//単位
            this._entity.Memo = txtMemo.Text;//備考
            this._entity.OrderDate = dtp_OrderDate.Text;//注文書届日
            this._entity.OrderNo = txtOrderNo.Text;//注文書番号
            this._entity.DeleteFlg = "0";//削除フラグ

            return this._entity;
        }

        /// <summary>
        /// 営業担当のチェック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobSalesman_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cobSalesman1.SelectedIndex <= 0 || cobSalesman2.SelectedIndex <= 0) { return; }

            if (cobSalesman1.SelectedIndex == cobSalesman2.SelectedIndex)
            {
                MessageHelper.ShowinforMessageByID("EB0010", "重複していない営業担当");
            }
        }
        #endregion

        /// <summary>
        /// 顧客選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobCustomerID_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cobCustomerID.SelectedIndex == -1) { return; }

            string sPaymentType = ((System.Data.DataRowView)this.cobCustomerID.SelectedItem)["PaymentType"].ToString();
            string sPaymentDay = ((System.Data.DataRowView)this.cobCustomerID.SelectedItem)["PaymentDay"].ToString();
            string sUndertaker = ((System.Data.DataRowView)this.cobCustomerID.SelectedItem)["Undertaker"].ToString();

            this.selectCobPayment(this.cobPaymentType, sPaymentType);
            this.selectCobPayment(this.cobPaymentDay, sPaymentDay);
            this.txtCustSalesman.Text = sUndertaker;

        }
        /// <summary>
        /// 支払方法・支払日のデータの反映
        /// </summary>
        /// <param name="cob"></param>
        /// <param name="itemValue"></param>
        private void selectCobPayment(ComboBox cob, string itemValue)
        {
            if (
                string.IsNullOrEmpty(itemValue) ||
                    (
                        cob.SelectedIndex != -1 &&
                        !string.IsNullOrEmpty(this._entity.PaymentType) &&
                        !string.IsNullOrEmpty(this._entity.PaymentDay)
                    )
                )
            {
                return;
            }

            for (int i = 0; i < cob.Items.Count; i++)
            {
                if (itemValue == ((System.Data.DataRowView)cob.Items[i])["CodeID"].ToString())
                {
                    cob.SelectedIndex = i;
                    break;
                }
            }
        }

        private void txtEmployeeID_TextChanged(object sender, EventArgs e)
        {
            ThreadPoolHelper.StartThread(this,
                () =>
                {
                    if (!string.IsNullOrEmpty(txtEmployeeID.Text.Trim()))
                        return BL_Employee.GetInstance().SelectTechEmployee(txtEmployeeID.Text.Trim());
                    else
                        return BL_Employee.GetInstance().SelectTechEmployee();
                },
                    (obj) =>
                    {
                        cobEmployeeID.DataSource = obj as DataTable;
                        cobEmployeeID.SelectedIndex = -1;
                    }
            );
        }

        private void cobSalesman1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (partner == null)
            {
                return;
            }

            foreach (string[] str in partner)
            {
                bool breakSign = false;
                for (int i = 0; i < str.Length; i++)
                {
                    if (str[i].Equals(cobSalesman1.Text))
                    {
                        breakSign = true;
                        if (i == 0)
                        {
                            cobSalesman2.SelectedIndex = cobSalesman2.FindString(str[i + 1]);
                        }
                        else
                        {
                            cobSalesman2.SelectedIndex = cobSalesman2.FindString(str[i - 1]);
                        }
                        break;
                    }
                }
                if (breakSign)
                {
                    break;
                }
            }
        }
        /// <summary>
        /// デフォルト空白にする
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dtp_OrderDate_ValueChanged(object sender, EventArgs e)
        {

            this.dtp_OrderDate.Format = DateTimePickerFormat.Long;
            this.dtp_OrderDate.CustomFormat = null;
        }
        /// <summary>
        /// 契約期間が変わったら、数量を自動的で計算
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ContractDatetime_ValueChanged(object sender, EventArgs e)
        {
            DateTime contract_start = this.dtp_StartDate.Value;
            DateTime contract_end = this.dtp_EndDate.Value;

            if (contract_start > contract_end)
            {
                this.txtQuantity.Text = "";
            }
            double Quantity = 0.00;
            try
            {
                string strUnit = "";
                if (this.cobUnit.SelectedItem != null)
                {
                    strUnit = ((DataRowView)this.cobUnit.SelectedItem)[this.cobUnit.DisplayMember].ToString();
                }

                if (strUnit.Equals("月"))
                {
                    Quantity = this.GetQuantityForMonth(contract_start, contract_end);
                }
                else if (strUnit.Equals("時間"))
                {
                    Quantity = this.GetQuantityForTime(contract_start, contract_end);
                }
                else//一式
                {
                    Quantity = 1.00;
                }

            }
            catch (EBException ebex)
            {

                LogHelper.Error(ebex.Message);

            }
            this.txtQuantity.Text = Quantity.ToString("#0.00");
        }
        /// <summary>
        /// 数量を取得（単位:月）
        /// </summary>
        /// <returns></returns>
        private double GetQuantityForMonth(DateTime contract_start, DateTime contract_end)
        {
            double Quantity = 0.00;
            DateTime contract_startMonth = DateTime.Parse(this.dtp_StartDate.Value.ToString("yyyy/MM"));
            DateTime contract_endMonth = DateTime.Parse(this.dtp_EndDate.Value.ToString("yyyy/MM"));

            if (contract_startMonth.Equals(contract_endMonth))
            {
                Quantity = HolidayHelper.GetQuantityBetween(contract_start, contract_end);
            }
            else
            {
                Quantity = HolidayHelper.GetQuantityBetween(contract_start, contract_startMonth.AddMonths(1).AddDays(-1));
                Quantity += HolidayHelper.GetQuantityBetween(contract_endMonth, contract_end);
                while (contract_startMonth < contract_endMonth.AddMonths(-1).AddDays(-1))
                {
                    contract_startMonth = contract_startMonth.AddMonths(1);
                    Quantity++;
                }
            }
            return Quantity;
        }
        /// <summary>
        /// 数量を取得（単位:時間）
        /// </summary>
        /// <returns></returns>
        private double GetQuantityForTime(DateTime contract_start, DateTime contract_end)
        {
            double workhours = 8;
            return HolidayHelper.GetWorkDaysByMonth(contract_start, contract_end) * workhours;
        }
        /// <summary>
        /// 売上の取得
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GettxtAmount_When_TextChanged(object sender, EventArgs e)
        {
            decimal intQuantity = CommonHandler.ToDecimal(this.txtQuantity.Text);
            decimal intPrice = CommonHandler.ToDecimal(this.txtPrice.Text);

            this.txtAmount.Text = CommonHandler.ToInt(intQuantity * intPrice).ToString();
        }

        /// <summary>
        /// 稼働年月チェンジ処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobYearMonth_SelectionChangeCommitted(object sender, EventArgs e)
        {
            int employeeID = CommonHandler.ToInt(cobEmployeeID.SelectedValue);
            string workmonth = cobYear.Text + "/" + cobMonth.Text;
            DataTable dt = BL_Employee.GetInstance().SelectEmployeeById(employeeID, workmonth);

            if (dt.Rows.Count > 0)
            {
                string stxt = CommonHandler.ToString(dt.Rows[0]["siirePrice"].ToString());//仕入先単価
                if (!stxt.Equals(""))
                {
                    long longPrice = long.Parse(stxt);
                    siirePrice.Text = longPrice.ToString("#,0");
                }
                else
                {
                    siirePrice.Text = stxt;
                }
            }
            else
            {
                siirePrice.Text = string.Empty;
            }
        }

    }
}
