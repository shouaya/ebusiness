﻿namespace EB.Contract
{
    partial class ContractLedgerAddForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.cobEmployeeID = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSiireName = new System.Windows.Forms.TextBox();
            this.txtEmployeeType = new System.Windows.Forms.TextBox();
            this.cobSalesman1 = new System.Windows.Forms.ComboBox();
            this.cobCustomerID = new System.Windows.Forms.ComboBox();
            this.txtContractName = new System.Windows.Forms.TextBox();
            this.txtWorkAddr = new System.Windows.Forms.TextBox();
            this.dtp_StartDate = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.dtp_OrderDate = new System.Windows.Forms.DateTimePicker();
            this.txtDeptName = new System.Windows.Forms.TextBox();
            this.cobPaymentType = new System.Windows.Forms.ComboBox();
            this.cobPaymentDay = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.dtp_EndDate = new System.Windows.Forms.DateTimePicker();
            this.txtProjectName = new System.Windows.Forms.TextBox();
            this.txtCustSalesman = new System.Windows.Forms.TextBox();
            this.cobSalesman2 = new System.Windows.Forms.ComboBox();
            this.txtSiireSales = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.txtOrderNo = new System.Windows.Forms.TextBox();
            this.txtMemo = new System.Windows.Forms.RichTextBox();
            this.cobMonth = new System.Windows.Forms.ComboBox();
            this.cobYear = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtAmount = new EB.Common.NumericTextox();
            this.txtMinHour = new EB.Common.NumericTextox();
            this.txtMinusUnitPrice = new EB.Common.NumericTextox();
            this.txtQuantity = new EB.Common.NumericTextox();
            this.txtTranExpense = new EB.Common.NumericTextox();
            this.txtMaxHour = new EB.Common.NumericTextox();
            this.txtPlusUnitPrice = new EB.Common.NumericTextox();
            this.cobEmployeeType = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtPrice = new EB.Common.NumericTextox();
            this.txtEmployeeID = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.siirePrice = new EB.Common.NumericTextox();
            this.label32 = new System.Windows.Forms.Label();
            this.cobUnit = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(387, 413);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 77;
            this.label5.Text = "技術者氏名";
            // 
            // cobEmployeeID
            // 
            this.cobEmployeeID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cobEmployeeID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cobEmployeeID.DisplayMember = "EmployeeName";
            this.cobEmployeeID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobEmployeeID.FormattingEnabled = true;
            this.cobEmployeeID.Location = new System.Drawing.Point(93, 15);
            this.cobEmployeeID.Name = "cobEmployeeID";
            this.cobEmployeeID.Size = new System.Drawing.Size(105, 20);
            this.cobEmployeeID.TabIndex = 78;
            this.cobEmployeeID.ValueMember = "EmployeeID";
            this.cobEmployeeID.SelectionChangeCommitted += new System.EventHandler(this.cobEmployeeID_SelectionChangeCommitted);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(286, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 79;
            this.label1.Text = "社員区分";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 12);
            this.label2.TabIndex = 80;
            this.label2.Text = "営業担当１";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 81;
            this.label3.Text = "顧客会社";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 146);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 82;
            this.label4.Text = "契約件名";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 83;
            this.label6.Text = "単価";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 171);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 84;
            this.label7.Text = "現場";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 274);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 85;
            this.label8.Text = "稼働下限";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 198);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 86;
            this.label9.Text = "契約開始";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 87;
            this.label10.Text = "控除単価";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 349);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 88;
            this.label11.Text = "交通費";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 324);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 12);
            this.label12.TabIndex = 89;
            this.label12.Text = "数量";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 44);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 90;
            this.label13.Text = "仕入先";
            // 
            // txtSiireName
            // 
            this.txtSiireName.Enabled = false;
            this.txtSiireName.Location = new System.Drawing.Point(93, 44);
            this.txtSiireName.Name = "txtSiireName";
            this.txtSiireName.Size = new System.Drawing.Size(105, 19);
            this.txtSiireName.TabIndex = 91;
            // 
            // txtEmployeeType
            // 
            this.txtEmployeeType.Enabled = false;
            this.txtEmployeeType.Location = new System.Drawing.Point(357, 69);
            this.txtEmployeeType.Name = "txtEmployeeType";
            this.txtEmployeeType.Size = new System.Drawing.Size(105, 19);
            this.txtEmployeeType.TabIndex = 92;
            // 
            // cobSalesman1
            // 
            this.cobSalesman1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cobSalesman1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cobSalesman1.DisplayMember = "EmployeeName";
            this.cobSalesman1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobSalesman1.FormattingEnabled = true;
            this.cobSalesman1.Location = new System.Drawing.Point(93, 91);
            this.cobSalesman1.Name = "cobSalesman1";
            this.cobSalesman1.Size = new System.Drawing.Size(105, 20);
            this.cobSalesman1.TabIndex = 93;
            this.cobSalesman1.ValueMember = "EmployeeID";
            this.cobSalesman1.SelectedIndexChanged += new System.EventHandler(this.cobSalesman1_SelectedIndexChanged);
            // 
            // cobCustomerID
            // 
            this.cobCustomerID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cobCustomerID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cobCustomerID.DisplayMember = "CustomerName";
            this.cobCustomerID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobCustomerID.FormattingEnabled = true;
            this.cobCustomerID.Location = new System.Drawing.Point(93, 117);
            this.cobCustomerID.Name = "cobCustomerID";
            this.cobCustomerID.Size = new System.Drawing.Size(105, 20);
            this.cobCustomerID.TabIndex = 94;
            this.cobCustomerID.ValueMember = "CustomerID";
            this.cobCustomerID.SelectedIndexChanged += new System.EventHandler(this.cobCustomerID_SelectedIndexChanged);
            // 
            // txtContractName
            // 
            this.txtContractName.Location = new System.Drawing.Point(93, 143);
            this.txtContractName.Name = "txtContractName";
            this.txtContractName.Size = new System.Drawing.Size(105, 19);
            this.txtContractName.TabIndex = 95;
            // 
            // txtWorkAddr
            // 
            this.txtWorkAddr.Location = new System.Drawing.Point(93, 168);
            this.txtWorkAddr.Name = "txtWorkAddr";
            this.txtWorkAddr.Size = new System.Drawing.Size(105, 19);
            this.txtWorkAddr.TabIndex = 96;
            // 
            // dtp_StartDate
            // 
            this.dtp_StartDate.CustomFormat = "yyyy/MM/dd";
            this.dtp_StartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_StartDate.Location = new System.Drawing.Point(93, 193);
            this.dtp_StartDate.Name = "dtp_StartDate";
            this.dtp_StartDate.Size = new System.Drawing.Size(105, 19);
            this.dtp_StartDate.TabIndex = 288;
            this.dtp_StartDate.ValueChanged += new System.EventHandler(this.ContractDatetime_ValueChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(286, 249);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 294;
            this.label14.Text = "稼働上限";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(286, 123);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 295;
            this.label15.Text = "顧客窓口";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(286, 274);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 296;
            this.label16.Text = "超過単価";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(286, 299);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 12);
            this.label17.TabIndex = 297;
            this.label17.Text = "支払サイト";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(286, 322);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 298;
            this.label18.Text = "備考";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(286, 21);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 300;
            this.label20.Text = "所属部門";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 374);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(75, 12);
            this.label22.TabIndex = 302;
            this.label22.Text = "注文書届け日";
            // 
            // dtp_OrderDate
            // 
            this.dtp_OrderDate.CustomFormat = "yyyy/MM/dd";
            this.dtp_OrderDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_OrderDate.Location = new System.Drawing.Point(93, 373);
            this.dtp_OrderDate.Name = "dtp_OrderDate";
            this.dtp_OrderDate.Size = new System.Drawing.Size(105, 19);
            this.dtp_OrderDate.TabIndex = 304;
            this.dtp_OrderDate.ValueChanged += new System.EventHandler(this.dtp_OrderDate_ValueChanged);
            // 
            // txtDeptName
            // 
            this.txtDeptName.Enabled = false;
            this.txtDeptName.Location = new System.Drawing.Point(357, 18);
            this.txtDeptName.Name = "txtDeptName";
            this.txtDeptName.Size = new System.Drawing.Size(105, 19);
            this.txtDeptName.TabIndex = 305;
            // 
            // cobPaymentType
            // 
            this.cobPaymentType.DisplayMember = "CodeName";
            this.cobPaymentType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobPaymentType.FormattingEnabled = true;
            this.cobPaymentType.Location = new System.Drawing.Point(357, 296);
            this.cobPaymentType.Name = "cobPaymentType";
            this.cobPaymentType.Size = new System.Drawing.Size(93, 20);
            this.cobPaymentType.TabIndex = 308;
            this.cobPaymentType.ValueMember = "CodeID";
            // 
            // cobPaymentDay
            // 
            this.cobPaymentDay.DisplayMember = "CodeName";
            this.cobPaymentDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobPaymentDay.FormattingEnabled = true;
            this.cobPaymentDay.Location = new System.Drawing.Point(456, 296);
            this.cobPaymentDay.Name = "cobPaymentDay";
            this.cobPaymentDay.Size = new System.Drawing.Size(93, 20);
            this.cobPaymentDay.TabIndex = 309;
            this.cobPaymentDay.ValueMember = "CodeID";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(286, 174);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 12);
            this.label23.TabIndex = 312;
            this.label23.Text = "稼働月";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(286, 72);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 12);
            this.label24.TabIndex = 313;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(286, 201);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 314;
            this.label25.Text = "契約終了";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(286, 149);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 12);
            this.label26.TabIndex = 315;
            this.label26.Text = "作業工程";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(286, 97);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(61, 12);
            this.label27.TabIndex = 316;
            this.label27.Text = "営業担当２";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(286, 47);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(65, 12);
            this.label28.TabIndex = 317;
            this.label28.Text = "仕入先担当";
            // 
            // dtp_EndDate
            // 
            this.dtp_EndDate.CustomFormat = "yyyy/MM/dd";
            this.dtp_EndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_EndDate.Location = new System.Drawing.Point(357, 196);
            this.dtp_EndDate.Name = "dtp_EndDate";
            this.dtp_EndDate.Size = new System.Drawing.Size(105, 19);
            this.dtp_EndDate.TabIndex = 318;
            this.dtp_EndDate.ValueChanged += new System.EventHandler(this.ContractDatetime_ValueChanged);
            // 
            // txtProjectName
            // 
            this.txtProjectName.Location = new System.Drawing.Point(357, 146);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(105, 19);
            this.txtProjectName.TabIndex = 320;
            // 
            // txtCustSalesman
            // 
            this.txtCustSalesman.Location = new System.Drawing.Point(357, 120);
            this.txtCustSalesman.Name = "txtCustSalesman";
            this.txtCustSalesman.Size = new System.Drawing.Size(105, 19);
            this.txtCustSalesman.TabIndex = 321;
            // 
            // cobSalesman2
            // 
            this.cobSalesman2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cobSalesman2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cobSalesman2.DisplayMember = "EmployeeName";
            this.cobSalesman2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobSalesman2.FormattingEnabled = true;
            this.cobSalesman2.Location = new System.Drawing.Point(357, 94);
            this.cobSalesman2.Name = "cobSalesman2";
            this.cobSalesman2.Size = new System.Drawing.Size(105, 20);
            this.cobSalesman2.TabIndex = 322;
            this.cobSalesman2.ValueMember = "EmployeeID";
            // 
            // txtSiireSales
            // 
            this.txtSiireSales.Enabled = false;
            this.txtSiireSales.Location = new System.Drawing.Point(357, 44);
            this.txtSiireSales.Name = "txtSiireSales";
            this.txtSiireSales.Size = new System.Drawing.Size(105, 19);
            this.txtSiireSales.TabIndex = 323;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(228, 410);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 324;
            this.btnUpdate.Text = "更新";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(93, 410);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(75, 23);
            this.btnRegister.TabIndex = 325;
            this.btnRegister.Text = "新規追加";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(284, 223);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 12);
            this.label29.TabIndex = 327;
            this.label29.Text = "注文書番号";
            // 
            // txtOrderNo
            // 
            this.txtOrderNo.Location = new System.Drawing.Point(357, 221);
            this.txtOrderNo.Name = "txtOrderNo";
            this.txtOrderNo.Size = new System.Drawing.Size(105, 19);
            this.txtOrderNo.TabIndex = 328;
            // 
            // txtMemo
            // 
            this.txtMemo.Location = new System.Drawing.Point(357, 322);
            this.txtMemo.Name = "txtMemo";
            this.txtMemo.Size = new System.Drawing.Size(192, 85);
            this.txtMemo.TabIndex = 329;
            this.txtMemo.Text = "";
            // 
            // cobMonth
            // 
            this.cobMonth.DisplayMember = "CodeName";
            this.cobMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobMonth.FormattingEnabled = true;
            this.cobMonth.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.cobMonth.Location = new System.Drawing.Point(456, 171);
            this.cobMonth.Name = "cobMonth";
            this.cobMonth.Size = new System.Drawing.Size(41, 20);
            this.cobMonth.TabIndex = 331;
            this.cobMonth.ValueMember = "CodeID";
            this.cobMonth.SelectionChangeCommitted += new System.EventHandler(this.cobYearMonth_SelectionChangeCommitted);
            // 
            // cobYear
            // 
            this.cobYear.DisplayMember = "CodeID";
            this.cobYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobYear.FormattingEnabled = true;
            this.cobYear.Items.AddRange(new object[] {
            "2020",
            "2019",
            "2018",
            "2017",
            "2016",
            "2015",
            "2014",
            "2013",
            "2012",
            "2011",
            "2010",
            "2009",
            "2008"});
            this.cobYear.Location = new System.Drawing.Point(357, 170);
            this.cobYear.Name = "cobYear";
            this.cobYear.Size = new System.Drawing.Size(72, 20);
            this.cobYear.TabIndex = 330;
            this.cobYear.ValueMember = "CodeID";
            this.cobYear.SelectionChangeCommitted += new System.EventHandler(this.cobYearMonth_SelectionChangeCommitted);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(433, 175);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(17, 12);
            this.label19.TabIndex = 332;
            this.label19.Text = "年";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(498, 175);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(17, 12);
            this.label30.TabIndex = 333;
            this.label30.Text = "月";
            // 
            // txtAmount
            // 
            this.txtAmount.Enabled = false;
            this.txtAmount.Location = new System.Drawing.Point(93, 243);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Precision = 0;
            this.txtAmount.SepratedChar = ',';
            this.txtAmount.Size = new System.Drawing.Size(105, 19);
            this.txtAmount.TabIndex = 334;
            this.txtAmount.Value = "";
            // 
            // txtMinHour
            // 
            this.txtMinHour.Location = new System.Drawing.Point(93, 268);
            this.txtMinHour.Name = "txtMinHour";
            this.txtMinHour.Precision = 2;
            this.txtMinHour.SepratedChar = ',';
            this.txtMinHour.Size = new System.Drawing.Size(105, 19);
            this.txtMinHour.TabIndex = 335;
            this.txtMinHour.Value = "";
            // 
            // txtMinusUnitPrice
            // 
            this.txtMinusUnitPrice.Location = new System.Drawing.Point(93, 296);
            this.txtMinusUnitPrice.Name = "txtMinusUnitPrice";
            this.txtMinusUnitPrice.Precision = 0;
            this.txtMinusUnitPrice.SepratedChar = ',';
            this.txtMinusUnitPrice.Size = new System.Drawing.Size(105, 19);
            this.txtMinusUnitPrice.TabIndex = 336;
            this.txtMinusUnitPrice.Value = "";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(93, 321);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Precision = 3;
            this.txtQuantity.SepratedChar = ',';
            this.txtQuantity.Size = new System.Drawing.Size(105, 19);
            this.txtQuantity.TabIndex = 337;
            this.txtQuantity.Value = "";
            this.txtQuantity.TextChanged += new System.EventHandler(this.GettxtAmount_When_TextChanged);
            // 
            // txtTranExpense
            // 
            this.txtTranExpense.Location = new System.Drawing.Point(93, 344);
            this.txtTranExpense.Name = "txtTranExpense";
            this.txtTranExpense.Precision = 0;
            this.txtTranExpense.SepratedChar = ',';
            this.txtTranExpense.Size = new System.Drawing.Size(105, 19);
            this.txtTranExpense.TabIndex = 338;
            this.txtTranExpense.Value = "";
            // 
            // txtMaxHour
            // 
            this.txtMaxHour.Location = new System.Drawing.Point(357, 246);
            this.txtMaxHour.Name = "txtMaxHour";
            this.txtMaxHour.Precision = 2;
            this.txtMaxHour.SepratedChar = ',';
            this.txtMaxHour.Size = new System.Drawing.Size(105, 19);
            this.txtMaxHour.TabIndex = 340;
            this.txtMaxHour.Value = "";
            // 
            // txtPlusUnitPrice
            // 
            this.txtPlusUnitPrice.Location = new System.Drawing.Point(357, 271);
            this.txtPlusUnitPrice.Name = "txtPlusUnitPrice";
            this.txtPlusUnitPrice.Precision = 0;
            this.txtPlusUnitPrice.SepratedChar = ',';
            this.txtPlusUnitPrice.Size = new System.Drawing.Size(105, 19);
            this.txtPlusUnitPrice.TabIndex = 341;
            this.txtPlusUnitPrice.Value = "";
            // 
            // cobEmployeeType
            // 
            this.cobEmployeeType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cobEmployeeType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cobEmployeeType.DisplayMember = "CodeName";
            this.cobEmployeeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobEmployeeType.Enabled = false;
            this.cobEmployeeType.FormattingEnabled = true;
            this.cobEmployeeType.Location = new System.Drawing.Point(468, 69);
            this.cobEmployeeType.Name = "cobEmployeeType";
            this.cobEmployeeType.Size = new System.Drawing.Size(105, 20);
            this.cobEmployeeType.TabIndex = 326;
            this.cobEmployeeType.ValueMember = "CodeID";
            this.cobEmployeeType.Visible = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(12, 69);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(53, 12);
            this.label31.TabIndex = 342;
            this.label31.Text = "仕入原価";
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(93, 218);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Precision = 0;
            this.txtPrice.SepratedChar = ',';
            this.txtPrice.Size = new System.Drawing.Size(105, 19);
            this.txtPrice.TabIndex = 344;
            this.txtPrice.Value = "";
            this.txtPrice.TextChanged += new System.EventHandler(this.GettxtAmount_When_TextChanged);
            // 
            // txtEmployeeID
            // 
            this.txtEmployeeID.Location = new System.Drawing.Point(204, 16);
            this.txtEmployeeID.Name = "txtEmployeeID";
            this.txtEmployeeID.Size = new System.Drawing.Size(64, 19);
            this.txtEmployeeID.TabIndex = 345;
            this.txtEmployeeID.TextChanged += new System.EventHandler(this.txtEmployeeID_TextChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 246);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(29, 12);
            this.label21.TabIndex = 346;
            this.label21.Text = "売上";
            // 
            // siirePrice
            // 
            this.siirePrice.Enabled = false;
            this.siirePrice.Location = new System.Drawing.Point(93, 69);
            this.siirePrice.Name = "siirePrice";
            this.siirePrice.Precision = 0;
            this.siirePrice.SepratedChar = ',';
            this.siirePrice.Size = new System.Drawing.Size(105, 19);
            this.siirePrice.TabIndex = 347;
            this.siirePrice.Value = "";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(198, 221);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(29, 12);
            this.label32.TabIndex = 348;
            this.label32.Text = "単位";
            // 
            // cobUnit
            // 
            this.cobUnit.DisplayMember = "CodeName";
            this.cobUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobUnit.FormattingEnabled = true;
            this.cobUnit.Location = new System.Drawing.Point(228, 217);
            this.cobUnit.Name = "cobUnit";
            this.cobUnit.Size = new System.Drawing.Size(50, 20);
            this.cobUnit.TabIndex = 349;
            this.cobUnit.ValueMember = "CodeID";
            this.cobUnit.SelectedIndexChanged += new System.EventHandler(this.ContractDatetime_ValueChanged);
            // 
            // ContractLedgerAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 492);
            this.Controls.Add(this.cobUnit);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.siirePrice);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.txtEmployeeID);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.txtPlusUnitPrice);
            this.Controls.Add(this.txtMaxHour);
            this.Controls.Add(this.txtTranExpense);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.txtMinusUnitPrice);
            this.Controls.Add(this.txtMinHour);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.cobMonth);
            this.Controls.Add(this.cobYear);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.txtOrderNo);
            this.Controls.Add(this.txtMemo);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtProjectName);
            this.Controls.Add(this.txtSiireSales);
            this.Controls.Add(this.cobEmployeeType);
            this.Controls.Add(this.cobSalesman2);
            this.Controls.Add(this.txtCustSalesman);
            this.Controls.Add(this.dtp_OrderDate);
            this.Controls.Add(this.dtp_EndDate);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.cobPaymentDay);
            this.Controls.Add(this.cobPaymentType);
            this.Controls.Add(this.txtDeptName);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dtp_StartDate);
            this.Controls.Add(this.txtWorkAddr);
            this.Controls.Add(this.txtContractName);
            this.Controls.Add(this.cobCustomerID);
            this.Controls.Add(this.cobSalesman1);
            this.Controls.Add(this.txtEmployeeType);
            this.Controls.Add(this.txtSiireName);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cobEmployeeID);
            this.Controls.Add(this.label5);
            this.Name = "ContractLedgerAddForm";
            this.Text = "社内管理台帳登録";
            this.Load += new System.EventHandler(this.ContractLedgerAddForm_Load);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.cobEmployeeID, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.txtSiireName, 0);
            this.Controls.SetChildIndex(this.txtEmployeeType, 0);
            this.Controls.SetChildIndex(this.cobSalesman1, 0);
            this.Controls.SetChildIndex(this.cobCustomerID, 0);
            this.Controls.SetChildIndex(this.txtContractName, 0);
            this.Controls.SetChildIndex(this.txtWorkAddr, 0);
            this.Controls.SetChildIndex(this.dtp_StartDate, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.label15, 0);
            this.Controls.SetChildIndex(this.label16, 0);
            this.Controls.SetChildIndex(this.label17, 0);
            this.Controls.SetChildIndex(this.label18, 0);
            this.Controls.SetChildIndex(this.label20, 0);
            this.Controls.SetChildIndex(this.label22, 0);
            this.Controls.SetChildIndex(this.txtDeptName, 0);
            this.Controls.SetChildIndex(this.cobPaymentType, 0);
            this.Controls.SetChildIndex(this.cobPaymentDay, 0);
            this.Controls.SetChildIndex(this.label23, 0);
            this.Controls.SetChildIndex(this.label24, 0);
            this.Controls.SetChildIndex(this.label25, 0);
            this.Controls.SetChildIndex(this.label26, 0);
            this.Controls.SetChildIndex(this.label27, 0);
            this.Controls.SetChildIndex(this.label28, 0);
            this.Controls.SetChildIndex(this.dtp_EndDate, 0);
            this.Controls.SetChildIndex(this.dtp_OrderDate, 0);
            this.Controls.SetChildIndex(this.txtCustSalesman, 0);
            this.Controls.SetChildIndex(this.cobSalesman2, 0);
            this.Controls.SetChildIndex(this.cobEmployeeType, 0);
            this.Controls.SetChildIndex(this.txtSiireSales, 0);
            this.Controls.SetChildIndex(this.txtProjectName, 0);
            this.Controls.SetChildIndex(this.btnUpdate, 0);
            this.Controls.SetChildIndex(this.txtMemo, 0);
            this.Controls.SetChildIndex(this.txtOrderNo, 0);
            this.Controls.SetChildIndex(this.label29, 0);
            this.Controls.SetChildIndex(this.btnRegister, 0);
            this.Controls.SetChildIndex(this.cobYear, 0);
            this.Controls.SetChildIndex(this.cobMonth, 0);
            this.Controls.SetChildIndex(this.label19, 0);
            this.Controls.SetChildIndex(this.label30, 0);
            this.Controls.SetChildIndex(this.txtAmount, 0);
            this.Controls.SetChildIndex(this.txtMinHour, 0);
            this.Controls.SetChildIndex(this.txtMinusUnitPrice, 0);
            this.Controls.SetChildIndex(this.txtQuantity, 0);
            this.Controls.SetChildIndex(this.txtTranExpense, 0);
            this.Controls.SetChildIndex(this.txtMaxHour, 0);
            this.Controls.SetChildIndex(this.txtPlusUnitPrice, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.label31, 0);
            this.Controls.SetChildIndex(this.txtPrice, 0);
            this.Controls.SetChildIndex(this.txtEmployeeID, 0);
            this.Controls.SetChildIndex(this.label21, 0);
            this.Controls.SetChildIndex(this.siirePrice, 0);
            this.Controls.SetChildIndex(this.label32, 0);
            this.Controls.SetChildIndex(this.cobUnit, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cobEmployeeID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSiireName;
        private System.Windows.Forms.TextBox txtEmployeeType;
        private System.Windows.Forms.ComboBox cobSalesman1;
        private System.Windows.Forms.ComboBox cobCustomerID;
        private System.Windows.Forms.TextBox txtContractName;
        private System.Windows.Forms.TextBox txtWorkAddr;
        private System.Windows.Forms.DateTimePicker dtp_StartDate;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DateTimePicker dtp_OrderDate;
        private System.Windows.Forms.TextBox txtDeptName;
        private System.Windows.Forms.ComboBox cobPaymentType;
        private System.Windows.Forms.ComboBox cobPaymentDay;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.DateTimePicker dtp_EndDate;
        private System.Windows.Forms.TextBox txtProjectName;
        private System.Windows.Forms.TextBox txtCustSalesman;
        private System.Windows.Forms.ComboBox cobSalesman2;
        private System.Windows.Forms.TextBox txtSiireSales;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtOrderNo;
        private System.Windows.Forms.RichTextBox txtMemo;
        private System.Windows.Forms.ComboBox cobMonth;
        private System.Windows.Forms.ComboBox cobYear;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label30;
        private Common.NumericTextox txtAmount;
        private Common.NumericTextox txtMinHour;
        private Common.NumericTextox txtMinusUnitPrice;
        private Common.NumericTextox txtQuantity;
        private Common.NumericTextox txtTranExpense;
        private Common.NumericTextox txtMaxHour;
        private Common.NumericTextox txtPlusUnitPrice;
        private System.Windows.Forms.ComboBox cobEmployeeType;
        private System.Windows.Forms.Label label31;
        private Common.NumericTextox txtPrice;
        private System.Windows.Forms.TextBox txtEmployeeID;
        private System.Windows.Forms.Label label21;
        private Common.NumericTextox siirePrice;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox cobUnit;
    }
}