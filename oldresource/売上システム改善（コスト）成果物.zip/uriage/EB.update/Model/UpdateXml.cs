﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace EB.Update
{
    [XmlRoot("ebspatch")]
    public class UpdateXml
    {
        [XmlElement("patch")]
        public List<UpdatePatch> patchs { get; set; }
    }
    [Serializable]
    public class UpdatePatch
    {
        [XmlAttribute("name")]
        public string name { get; set; }
        [XmlAttribute("updatetime")]
        public string updatetime { get; set; }
        [XmlAttribute("url")]
        public string url { get; set; }
        [XmlAttribute("byte")]
        public byte[] bt { get; set; }
    }
}
