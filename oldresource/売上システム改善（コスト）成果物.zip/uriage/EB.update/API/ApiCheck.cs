﻿using System;
using System.Windows.Forms;

namespace EB.Update
{
    public partial class Api
    {
        public static void check()
        {
            if (UpdateHelper.getInstance().checkUpdate())
            {
                BaseHelper.processStart(Arguments.Update);
            }
            else
            {
                BaseHelper.processStartMenu();
                //MessageBox.Show("noupdate");
            }
        }
    }
}
