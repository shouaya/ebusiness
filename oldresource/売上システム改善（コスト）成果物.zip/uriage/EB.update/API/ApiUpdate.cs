﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;

namespace EB.Update
{
    public partial class Api
    {
        public static void update(string path)
        {
            //System.Windows.Forms.MessageBox.Show("path" + path);

            if (BaseHelper.IsAdministrator())
            {
                getInstance().SetICON();

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MsgForm(path));
                
            }
            else
            {
                BaseHelper.processStart(path);
            }
        }
    }
}
