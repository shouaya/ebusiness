﻿using System;
using Microsoft.Win32;
using System.Windows.Forms;

namespace EB.Update
{
    public partial class Api
    {
        public static void setup()
        {
            getInstance().SetICON();
            check();
        }
        #region SetIcon
        private string _str_extension = "ebspatch";
        private string _str_extension_key = "eb_auto_file";
        /// <summary>
        /// set patch icon 
        /// </summary>
        private void SetICON()
        {
            try
            {
                string str = " \"%1\"";
                RegistryKey classesRoot = Registry.ClassesRoot;
                classesRoot.CreateSubKey("." + this._str_extension, RegistryKeyPermissionCheck.ReadWriteSubTree).SetValue("", this._str_extension_key);
                classesRoot.CreateSubKey(this._str_extension_key + @"\DefaultIcon", RegistryKeyPermissionCheck.ReadWriteSubTree).SetValue("", Application.ExecutablePath);
                classesRoot = Registry.ClassesRoot.CreateSubKey(this._str_extension_key + @"\shell\open\command", RegistryKeyPermissionCheck.ReadWriteSubTree);
                classesRoot.SetValue("", Application.ExecutablePath + str);
                classesRoot.Close();
                Win32.SHChangeNotify(0x8000000, 0, IntPtr.Zero, IntPtr.Zero);
            }
            catch
            {
                BaseHelper.processStart(Arguments.Setup);
            }
        }
        #endregion
    }
    /// <summary>
    /// Windows　api
    /// </summary>
    public class Win32
    {
        // Methods
        [System.Runtime.InteropServices.DllImport("shell32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto, SetLastError = true)]
        public static extern void SHChangeNotify(uint wEventId, uint uFlags, IntPtr dwItem1, IntPtr dwItem2);
    }
}
