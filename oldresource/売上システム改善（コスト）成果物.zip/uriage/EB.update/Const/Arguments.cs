﻿using System;

namespace EB.Update
{
    //enum Arguments { 
    //    Check,
    //    Setup,
    //    Start,
    //    Update
    //};

    public class Arguments
    {
        public const string Check = "check";
        public const string Setup = "setup";
        public const string Start = "start";
        public const string Update = "update";
        public const string MakePatch = "makePatch";
    }
}
