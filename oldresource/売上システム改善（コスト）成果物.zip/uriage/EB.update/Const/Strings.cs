﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EB.Update
{
    public class Strings
    {
        public const string updateExeTemp = "EB.Update.temp";
        public const string updatePatch = "EB.Update.patch";
        public const string updateExe = "EB.Update.exe";
    }
}
