﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EB.Update
{
    public delegate void InvokeDelegate(String message, Int32 value, Int32 maxnum);

    public partial class MsgForm : Form
    {
        public MsgForm(string path)
        {
            InitializeComponent();
            UpdateHelper.getInstance().update(path, SetProgress);
        }

        public void SetProgress(String message, Int32 value, Int32 maxnum)
        {
            if (this.InvokeRequired)
            {
                InvokeDelegate d = new InvokeDelegate(SetProgress);
                this.Invoke(d, new object[] { message, value, maxnum });
            }
            else
            {
                this.msgTextBox.Text = message + "\n" + this.msgTextBox.Text;
                if (maxnum > 0)
                {
                    if (value == maxnum)
                    {
                        maxnum = this.progressBar.Maximum;
                        this.progressBar.Value = maxnum;
                        value = maxnum;
                    }
                    else
                    {
                        this.progressBar.Maximum = maxnum;
                        this.progressBar.Value = value;
                    }
                    this.label1.Text = (Math.Truncate(value / 2.0)).ToString() + "/" + (maxnum / 2).ToString();
                }
            }
        }
    }
}
