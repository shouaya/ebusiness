﻿namespace EB.Update
{
    partial class MakeParchForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.path_input = new System.Windows.Forms.TextBox();
            this.btn_input = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_output = new System.Windows.Forms.Button();
            this.path_output = new System.Windows.Forms.TextBox();
            this.todo = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.SuspendLayout();
            // 
            // path_input
            // 
            this.path_input.Location = new System.Drawing.Point(73, 29);
            this.path_input.Name = "path_input";
            this.path_input.ReadOnly = true;
            this.path_input.Size = new System.Drawing.Size(338, 19);
            this.path_input.TabIndex = 0;
            // 
            // btn_input
            // 
            this.btn_input.Location = new System.Drawing.Point(412, 27);
            this.btn_input.Name = "btn_input";
            this.btn_input.Size = new System.Drawing.Size(46, 23);
            this.btn_input.TabIndex = 1;
            this.btn_input.Text = "参照";
            this.btn_input.UseVisualStyleBackColor = true;
            this.btn_input.Click += new System.EventHandler(this.btn_input_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "ファイルパス";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "出力パス";
            // 
            // btn_output
            // 
            this.btn_output.Enabled = false;
            this.btn_output.Location = new System.Drawing.Point(412, 75);
            this.btn_output.Name = "btn_output";
            this.btn_output.Size = new System.Drawing.Size(46, 23);
            this.btn_output.TabIndex = 4;
            this.btn_output.Text = "参照";
            this.btn_output.UseVisualStyleBackColor = true;
            this.btn_output.Click += new System.EventHandler(this.btn_output_Click);
            // 
            // path_output
            // 
            this.path_output.Location = new System.Drawing.Point(73, 78);
            this.path_output.Name = "path_output";
            this.path_output.ReadOnly = true;
            this.path_output.Size = new System.Drawing.Size(338, 19);
            this.path_output.TabIndex = 3;
            // 
            // todo
            // 
            this.todo.Location = new System.Drawing.Point(186, 126);
            this.todo.Name = "todo";
            this.todo.Size = new System.Drawing.Size(75, 23);
            this.todo.TabIndex = 6;
            this.todo.Text = "出力";
            this.todo.UseVisualStyleBackColor = true;
            this.todo.Click += new System.EventHandler(this.todo_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(0, 0);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(472, 2);
            this.progressBar1.TabIndex = 7;
            // 
            // MakeParchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 161);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.todo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_output);
            this.Controls.Add(this.path_output);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_input);
            this.Controls.Add(this.path_input);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MakeParchForm";
            this.Text = "MakeParchForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox path_input;
        private System.Windows.Forms.Button btn_input;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_output;
        private System.Windows.Forms.TextBox path_output;
        private System.Windows.Forms.Button todo;
        private System.Windows.Forms.ProgressBar progressBar1;
    }
}