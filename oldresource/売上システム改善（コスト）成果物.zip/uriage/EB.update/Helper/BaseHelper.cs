﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Net;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Security.Principal;

namespace EB.Update
{
    public class BaseHelper
    {
        #region common
        /// <summary>
        /// update.exeを起動する
        /// </summary>
        public static void processStart(string arguments)
        {
            processStart("EB.Update.EXE", arguments);
        }
        /// <summary>
        /// EB.Menu.EXEを起動する
        /// </summary>
        public static void processStartMenu()
        {
            processStart("EB.Menu.EXE", null);
        }
        /// <summary>
        /// 起動する
        /// </summary>
        public static void processStart(string FileName, string arguments)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            //startInfo.FileName = Application.ExecutablePath;
            startInfo.FileName = Application.StartupPath + "\\" + FileName;
            if (!File.Exists(startInfo.FileName)) { return; }

            bool isFileExists = false;
            if (File.Exists(arguments))
            {
                startInfo.Arguments = "\"" + arguments + "\"";
                isFileExists = true;
            }
            else
            {
                startInfo.Arguments = arguments;
            }
            //startInfo.UseShellExecute = false;  
            if (isFileExists || arguments == Arguments.Update || arguments == Arguments.Setup)
            {
                startInfo.Verb = "RunAs";
            }
            Process process = new Process();
            process.StartInfo = startInfo;
            if (process.Start() && Application.ExecutablePath == startInfo.FileName)
            {
                Application.Exit();
            }
        }

        /// <summary>
        /// 管理者権限のチェック
        /// </summary>
        /// <returns></returns>
        public static bool IsAdministrator()
        {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();
            WindowsPrincipal principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
        #endregion

    }
}
