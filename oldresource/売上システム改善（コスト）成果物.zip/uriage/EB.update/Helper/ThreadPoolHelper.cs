﻿using System;
using System.Windows.Forms;
using System.Threading;

namespace EB.Update
{
    public delegate void ThreadingDelegateWithoutReturn();
    public class ThreadPoolHelper
    {
        public static Thread todo(ThreadingDelegateWithoutReturn threadTodo)
        {
            Thread oThread = new Thread(delegate()
            {
                if (threadTodo != null)
                {
                    threadTodo();
                }
            });
            oThread.IsBackground = true;
            oThread.Start();
            return oThread;
        }
    }
}
