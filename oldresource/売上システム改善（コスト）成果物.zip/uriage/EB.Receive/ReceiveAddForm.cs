﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;

namespace EB.Receive
{
    public partial class ReceiveAddForm : DialogForm
    {
        #region 初期化
        public ReceiveAddForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReceiveAddForm_Load(object sender, EventArgs e)
        {
            try
            {
                cobYear.SelectedItem = System.DateTime.Now.ToString("yyyy");

                //Reset画面項目
                resetAll();


            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// Reset画面項目
        /// </summary>
        private void resetAll()
        {
            this.txtReceiptAmount.Text = "";
            this.txtDiffAmount.Text = "";
        }
        #endregion

        #region 画面動作
        /// <summary>
        /// 月選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobMonth_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(cobMonth.Text.Trim()))
                {
                    return;
                }

                if (dgvBill.Rows.Count > 0)
                {
                    DataTable dt_Temp = (dgvBill.DataSource as DataTable).Clone();
                    dgvBill.DataSource = dt_Temp;
                }

                string mm = cobMonth.Text;
                string yy_mm = cobYear.Text + "/" + cobMonth.Text;

                //Reset画面項目
                //resetAll();

                BL_Customer bl = BL_Customer.GetInstance();
                DataTable dt = bl.SelectCustomerByMonthOnBill(yy_mm,false);
                cobCustomerID.DataSource = dt;
                cobCustomerID.SelectedIndex = -1;

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 顧客選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobCustomerID_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                //Reset画面項目
                resetAll();

                ////面データを初期化
                loadDataGridViewData();

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }

        }
        /// <summary>
        /// 画面データを初期化
        /// </summary>
        private void loadDataGridViewData()
        {
            string yy_mm = cobYear.Text + "/" + cobMonth.Text;

            string customerID = CommonHandler.ToString(cobCustomerID.SelectedValue);

            BL_Bill bl = BL_Bill.GetInstance();
            DataTable dt = bl.SelectBillForReceive(customerID, yy_mm);
            dgvBill.DataSource = dt;

            string billDate = string.Empty;//予定入金日
            decimal billAmountTotal = 0;//請求総金額
            decimal receiptAmountTotal = 0;//総入金額
            decimal diffAmountTotal = 0;//総差額
            for (int row = 0; row < dgvBill.Rows.Count; row++)
            {

                IF_Bill entityDetail = new IF_Bill();
                billDate = CommonHandler.ToString(dgvBill.Rows[row].Cells["BillDate"].Value);//予定入金日
                billAmountTotal = billAmountTotal + CommonHandler.ToDecimal(dgvBill.Rows[row].Cells["BillAmountTotal"].Value);//請求総金額
                receiptAmountTotal = CommonHandler.ToDecimal(dgvBill.Rows[row].Cells["ReceiptAmountTotal"].Value);//入金額

            }
            diffAmountTotal = billAmountTotal - receiptAmountTotal;//総差額
            txtBillDate.Text = billDate;
            txtTotalBillAmount.Text = billAmountTotal.ToString();//請求総金額
            txtTotalReceiptAmount.Text = receiptAmountTotal.ToString();//総入金額
            txtTotalDiffAmount.Text = diffAmountTotal.ToString();//総差額

            txtBillAmount.Text = billAmountTotal.ToString();//請求金額

        }
        /// <summary>
        /// 日付同一
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDateSame_Click(object sender, EventArgs e)
        {
            txtReceiptDate.Text = txtBillDate.Text;
        }
        /// <summary>
        /// 金額同一
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAmountSame_Click(object sender, EventArgs e)
        {
            txtReceiptAmount.Text = txtBillAmount.Text;
            caculateDiff();
        }

        /// <summary>
        /// 登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {

                //入力チェック
                if (!isValidCheck()) return;

                //登録処理
                proceessRegister();

                loadDataGridViewData();

                MessageHelper.ShowinforMessageByID("EB1001");//登録成功しました。

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheck()
        {
            //明細行必須
            if (dgvBill.RowCount == 0)
            {
                MessageHelper.ShowinforMessageByID("EB0007");
                return false;
            }

            for (int row = 0; row < dgvBill.Rows.Count; row++)
            {
                string receiptID = CommonHandler.ToString(dgvBill.Rows[row].Cells["ReceiptID"].Value);//ReceiptID
                if (!string.IsNullOrEmpty(receiptID))
                {
                    MessageHelper.ShowinforMessageByID("EB0014");
                    return false;
                }
            }

            if (string.IsNullOrEmpty(txtReceiptAmount.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "入金額");
                txtReceiptAmount.Focus();
                return false;
            }
            if (CommonHandler.ToString(txtReceiptAmount.Text) == "0")
            {
                MessageHelper.ShowinforMessageByID("EB0001", "入金額");
                txtReceiptAmount.Focus();
                return false;
            }
            string diffAmount = CommonHandler.ToString(txtDiffAmount.Text);
            if (diffAmount != "0")
            {
                if (MessageHelper.ShowConfirmMessage("EB2005") != DialogResult.Yes)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// 登録処理
        /// </summary>
        private void proceessRegister()
        {
            IF_Receipt entity = new IF_Receipt();

            entity.CustomerID = CommonHandler.ToInt(cobCustomerID.SelectedValue);//顧客ID
            entity.ReceiptAmount = CommonHandler.ToDecimal(txtReceiptAmount.Value);//入金額
            entity.ReceiptDate = txtReceiptDate.Text;//入金日
            entity.DeleteFlg = "0";//削除フラグ

            List<IF_Bill> list = new List<IF_Bill>();

            decimal receiveAmount = entity.ReceiptAmount;//入金額
            for (int row = 0; row < dgvBill.Rows.Count; row++)
            {

                IF_Bill entityDetail = new IF_Bill();
                entityDetail.BillNo = CommonHandler.ToString(dgvBill.Rows[row].Cells["BillNo"].Value);//請求書番号
                entityDetail.BillAmountTotal = CommonHandler.ToDecimal(dgvBill.Rows[row].Cells["BillAmountTotal"].Value);//請求総金額

                if (receiveAmount >= entityDetail.BillAmountTotal)
                {
                    entityDetail.ReceiptAmount = entityDetail.BillAmountTotal;//入金額
                    receiveAmount = receiveAmount - entityDetail.BillAmountTotal;
                }
                else
                {
                    entityDetail.ReceiptAmount = receiveAmount;//入金額
                    receiveAmount = 0;
                }

                //最終行
                if (row == dgvBill.Rows.Count - 1)
                {
                    entityDetail.ReceiptAmount = entityDetail.ReceiptAmount + receiveAmount;//入金額
                }

                list.Add(entityDetail);
            }

            BL_Receipt bl = BL_Receipt.GetInstance();
            bl.RegisterAll(entity, list);

        }
        private void txtReceiptAmount_TextChanged(object sender, EventArgs e)
        {
            caculateDiff();
        }

        private void caculateDiff()
        {
            decimal billAmount = CommonHandler.ToDecimal(txtBillAmount.Text);
            decimal receiptAmount = CommonHandler.ToDecimal(txtReceiptAmount.Text);

            txtDiffAmount.Value = CommonHandler.ToString(billAmount - receiptAmount);
        }
        #endregion

        private void cobCustomerID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


    }
}
