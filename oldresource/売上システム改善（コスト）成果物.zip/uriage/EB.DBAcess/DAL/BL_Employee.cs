﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;

namespace EB.DBAcess
{
    public class BL_Employee
    {
        private static BL_Employee bl = new BL_Employee();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_Employee GetInstance()
        {
            return bl;
        }

        /// <summary>
        /// 全社員取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectAllEmployee(String keyword)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("A.EmployeeID,");//社員ID
                sb.Append("A.EmployeeName,");//社員名
                sb.Append("A.JapaneseSpell,");//フリカナ
                sb.Append("A.Birthday,");//生年月日
                sb.Append("A.Experience,");//経験年数
                sb.Append("A.Degree,");//学歴
                sb.Append("A.Certificate,");//資格
                sb.Append("A.Skill,");//技術
                sb.Append("A.Language,");//言語
                sb.Append("A.PostCode,");//郵便番号
                sb.Append("A.Address1,");//住所１
                sb.Append("A.Address2,");//住所２
                sb.Append("A.Tel,");//TEL
                sb.Append("A.Company,");//勤務先
                sb.Append("A.Remark,");//評価
                //sb.Append("A.siirePrice,");//仕入原価
                sb.Append("C.siirePrice,");//仕入原価
                sb.Append("B.CustomerName,");//仕入先
                sb.Append("A.siireSales,");//仕入先担当
                //sb.Append("A.carfare,");//交通費
                sb.Append("C.carfare,");//交通費

                sb.Append("A.Note,");//備考
                sb.Append("A.EmployeeType,");//社員区分
                sb.Append("A.DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Employee A ");
                sb.Append(" LEFT JOIN  T_Customer B  ON A.siireID=B.CustomerID ");
                sb.Append(" LEFT JOIN (SELECT * FROM (select * from t_cost t1 order by t1.serial desc) t2 group by employeeid) C ON A.employeeid = C.employeeid");

                sb.Append(" WHERE A.DeleteFlg = '0'");

                if (!string.IsNullOrEmpty(keyword))
                {
                    sb.Append(" AND (                             ");
                    sb.Append("  A.EmployeeName    LIKE @keyword  ");
                    sb.Append(" OR A.JapaneseSpell LIKE @keyword  ");
                    //sb.Append(" OR A.Address1      LIKE @keyword  ");
                    //sb.Append(" OR A.Address2      LIKE @keyword  ");
                    //sb.Append(" OR A.Tel           LIKE @keyword  ");
                    //sb.Append(" OR A.PostCode      LIKE @keyword  ");
                    //sb.Append(" OR A.Certificate   LIKE @keyword  ");
                    sb.Append(" OR B.CustomerName  LIKE @keyword  ");

                    sb.Append(" OR A.EmployeeName  LIKE @wkeyword ");
                    sb.Append(" OR A.JapaneseSpell LIKE @wkeyword ");
                    //sb.Append(" OR A.Address1      LIKE @wkeyword ");
                    //sb.Append(" OR A.Address2      LIKE @wkeyword ");
                    //sb.Append(" OR A.Tel           LIKE @wkeyword ");
                    //sb.Append(" OR A.PostCode      LIKE @wkeyword ");
                    //sb.Append(" OR A.Certificate   LIKE @wkeyword ");
                    sb.Append(" OR B.CustomerName  LIKE @wkeyword ");
                    sb.Append(" )                                 ");
                    para = new MySqlParameter("@keyword", MySqlDbType.VarChar);
                    para.Value = "%" + Common.CommonHandler.StrConv(keyword, false) + "%";
                    dbParams.Add(para);
                    para = new MySqlParameter("@wkeyword", MySqlDbType.VarChar);
                    para.Value = "%" + Common.CommonHandler.StrConv(keyword, true) + "%";
                    dbParams.Add(para);
                }
                sb.Append(" ORDER BY EmployeeID");

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        public DataTable SelectAllEmployeeWithMap()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("A.EmployeeID,");//社員ID
                sb.Append("A.EmployeeName,");//社員名
                sb.Append("C.CodeName as EmployeeType,");//社員区分
                sb.Append("B.EmployeeID2 ");//社員ID2
                sb.Append(" FROM T_Employee A ");
                sb.Append(" LEFT JOIN T_IDMap B  ON A.EmployeeID=B.EmployeeID1 ");
                sb.Append(" LEFT JOIN T_CodeMaster C ON C.CodeType='00001' AND C.CodeId = A.EmployeeType ");
                sb.Append(" WHERE A.DeleteFlg = '0'");
                sb.Append(" ORDER BY EmployeeName");

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 営業社員取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectSalesEmployee()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("EmployeeID,");//社員ID
                sb.Append("EmployeeName,");//社員名
                sb.Append("JapaneseSpell,");//フリカナ
                sb.Append("Birthday,");//生年月日
                sb.Append("Experience,");//経験年数
                sb.Append("Degree,");//学歴
                sb.Append("Certificate,");//資格
                sb.Append("Skill,");//技術
                sb.Append("Language,");//言語
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address1,");//住所１
                sb.Append("Address2,");//住所２
                sb.Append("Tel,");//TEL
                sb.Append("Company,");//勤務先
                sb.Append("Remark,");//評価
                sb.Append("Note,");//備考
                sb.Append("EmployeeType,");//社員区分
                sb.Append("DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Employee ");
                sb.Append(" WHERE DeleteFlg = '0' AND EmployeeType='5'");
                sb.Append(" ORDER BY EmployeeID");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }


        /// <summary>
        /// 仕入先取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectSiire()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT * ");
 
                sb.Append(" FROM T_Customer ");
                sb.Append(" WHERE DeleteFlg = '0' ");
                sb.Append(" ORDER BY CustomerID");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }




        /// <summary>
        /// 技術者取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectTechEmployee()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("EmployeeID,");//社員ID
                sb.Append("EmployeeName,");//社員名
                sb.Append("JapaneseSpell,");//フリカナ
                sb.Append("Birthday,");//生年月日
                sb.Append("Experience,");//経験年数
                sb.Append("Degree,");//学歴
                sb.Append("Certificate,");//資格
                sb.Append("Skill,");//技術
                sb.Append("Language,");//言語
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address1,");//住所１
                sb.Append("Address2,");//住所２
                sb.Append("Tel,");//TEL
                sb.Append("Company,");//勤務先
                sb.Append("Remark,");//評価
                sb.Append("Note,");//備考
                sb.Append("EmployeeType,");//社員区分
                sb.Append("DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Employee ");
                sb.Append(" WHERE DeleteFlg = '0' AND (EmployeeType='1' OR EmployeeType='2' OR EmployeeType='3' OR EmployeeType='4')");
                sb.Append(" ORDER BY EmployeeName");

                return DBAccess.ExecuteDataTable(sb.ToString(), null, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 技術者取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectTechEmployee(string EmployeeName)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> myparam = new List<MySqlParameter>();
                MySqlParameter param = null;
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("EmployeeID,");//社員ID
                sb.Append("EmployeeName,");//社員名
                sb.Append("JapaneseSpell,");//フリカナ
                sb.Append("Birthday,");//生年月日
                sb.Append("Experience,");//経験年数
                sb.Append("Degree,");//学歴
                sb.Append("Certificate,");//資格
                sb.Append("Skill,");//技術
                sb.Append("Language,");//言語
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address1,");//住所１
                sb.Append("Address2,");//住所２
                sb.Append("Tel,");//TEL
                sb.Append("Company,");//勤務先
                sb.Append("Remark,");//評価
                sb.Append("Note,");//備考
                sb.Append("EmployeeType,");//社員区分
                sb.Append("DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Employee ");
                sb.Append(" WHERE DeleteFlg = '0' AND (EmployeeType='1' OR EmployeeType='2' OR EmployeeType='3' OR EmployeeType='4')");
                sb.Append(" AND EmployeeName LIKE @EmployeeName");
                sb.Append(" ORDER BY EmployeeName");

                param = new MySqlParameter("@EmployeeName", MySqlDbType.VarChar, 50);
                param.Value = "%" + EmployeeName + "%";
                myparam.Add(param);

                return DBAccess.ExecuteDataTable(sb.ToString(), myparam, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 技術者取得(名重複チェック)
        /// </summary>
        /// <returns></returns>
        public bool SelectExsitsEmployee(string name)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string EmployeeName = name.Replace(" ", "").Replace("　", "");
                List<MySqlParameter> myparam = new List<MySqlParameter>();
                MySqlParameter param = null;
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT 1 ");
                sb.Append(" FROM T_Employee ");
                sb.Append(" WHERE DeleteFlg = '0' AND (REPLACE(REPLACE(EmployeeName,' ',''),'　','')=@EmployeeName");
                sb.Append(" OR REPLACE(REPLACE(EmployeeName,' ',''),'　','')=@TWEmployeeName)");
                sb.Append(" ORDER BY EmployeeID");

                param = new MySqlParameter("@EmployeeName", MySqlDbType.VarChar);
                param.Value = Common.CommonHandler.StrConv(EmployeeName,false);
                myparam.Add(param);

                param = new MySqlParameter("@TWEmployeeName", MySqlDbType.VarChar);
                param.Value = Common.CommonHandler.StrConv(EmployeeName, true);
                myparam.Add(param);

                DataTable dt = DBAccess.ExecuteDataTable(sb.ToString(),myparam, cn);

                if (dt.Rows.Count > 0) return true;

                return false;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        ///// <summary>
        ///// 社員取得
        ///// </summary>
        ///// <returns></returns>
        //public DataTable SelectEmployeeByName(string name)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    MySqlConnection cn = null;
        //    try
        //    {

        //        string connectString = DBAccess.ConnectString;
        //        cn = new MySqlConnection(connectString);
        //        cn.Open();

        //        sb.Append(" SELECT ");
        //        sb.Append("A.EmployeeID,");//社員ID
        //        sb.Append("A.EmployeeName,");//社員名
        //        sb.Append("A.JapaneseSpell,");//フリカナ
        //        sb.Append("A.Birthday,");//生年月日
        //        sb.Append("A.Experience,");//経験年数
        //        sb.Append("A.Degree,");//学歴
        //        sb.Append("A.Certificate,");//資格
        //        sb.Append("A.Skill,");//技術
        //        sb.Append("A.Language,");//言語
        //        sb.Append("A.PostCode,");//郵便番号
        //        sb.Append("A.Address1,");//住所１
        //        sb.Append("A.Address2,");//住所２
        //        sb.Append("A.Tel,");//TEL
        //        sb.Append("A.Company,");//勤務先
        //        sb.Append("A.Remark,");//評価
        //        sb.Append("A.Note,");//備考
        //        sb.Append("A.EmployeeType,");//社員区分

        //        sb.Append("B.CustomerName,");//仕入先
        //        sb.Append("A.siireSales,");//仕入先担当
        //        sb.Append("A.siirePrice,");//仕入単価

        //        sb.Append("A.DeleteFlg ");//削除フラグ
        //        sb.Append(" FROM T_Employee A ");
        //        sb.Append(" LEFT JOIN T_Customer B ON A.siireID=B.CustomerID ");


        //        sb.Append(" WHERE A.DeleteFlg = '0' AND A.EmployeeName='" + name + "' ");
        //        sb.Append(" ORDER BY A.EmployeeID");

        //        return DBAccess.Select(sb.ToString(), cn);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw (ex);
        //    }
        //    finally
        //    {
        //        cn.Close();
        //    }
        //}

        /// <summary>
        /// 社員取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectEmployeeById(int id, string workMonth)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("A.EmployeeID,");//社員ID
                sb.Append("A.EmployeeName,");//社員名
                sb.Append("A.JapaneseSpell,");//フリカナ
                sb.Append("A.Birthday,");//生年月日
                sb.Append("A.Experience,");//経験年数
                sb.Append("A.Degree,");//学歴
                sb.Append("A.Certificate,");//資格
                sb.Append("A.Skill,");//技術
                sb.Append("A.Language,");//言語
                sb.Append("A.PostCode,");//郵便番号
                sb.Append("A.Address1,");//住所１
                sb.Append("A.Address2,");//住所２
                sb.Append("A.Tel,");//TEL
                sb.Append("A.Company,");//勤務先
                sb.Append("A.Remark,");//評価
                sb.Append("A.Note,");//備考
                sb.Append("A.EmployeeType,");//社員区分
                sb.Append("B.CustomerName,");//仕入先
                sb.Append("A.siireSales,");//仕入先担当
                sb.Append("C.siirePrice,");//仕入原価
                sb.Append("A.DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Employee A ");
                sb.Append(" LEFT JOIN T_Customer B ON A.siireID=B.CustomerID ");
                sb.Append(" LEFT JOIN T_Cost C ON A.EmployeeID = C.EmployeeID and substr(C.startdate,1,7) <= '" + workMonth + "' and substr(C.enddate,1,7) >= '" + workMonth + "' ");

                sb.Append(" WHERE A.DeleteFlg = '0' AND A.EmployeeID=" + id + " ");
                sb.Append(" ORDER BY C.serial desc limit 0,1");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 社員取得
        /// </summary>
        /// <returns></returns>
        public DataRow SelectEmployeeByID(int id)
        {
            if (id < 1) { return null; }
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;
                para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);
                para.Value = id;
                dbParams.Add(para);


                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("A.EmployeeID,");//社員ID
                sb.Append("A.EmployeeName,");//社員名
                sb.Append("A.JapaneseSpell,");//フリカナ
                sb.Append("A.Birthday,");//生年月日
                sb.Append("A.Experience,");//経験年数
                sb.Append("A.Degree,");//学歴
                sb.Append("A.Certificate,");//資格
                sb.Append("A.Skill,");//技術
                sb.Append("A.Language,");//言語
                sb.Append("A.PostCode,");//郵便番号
                sb.Append("A.Address1,");//住所１
                sb.Append("A.Address2,");//住所２
                sb.Append("A.Tel,");//TEL
                sb.Append("A.Company,");//勤務先
                sb.Append("A.Remark,");//評価
                sb.Append("A.Note,");//備考
                sb.Append("A.EmployeeType,");//社員区分

                sb.Append("B.CustomerName,");//仕入先
                sb.Append("A.siireSales,");//仕入先担当
                //sb.Append("A.siirePrice,");//仕入単価
                //sb.Append("A.carfare,");//交通費

                sb.Append("A.DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Employee A ");
                sb.Append(" LEFT JOIN T_Customer B ON A.siireID=B.CustomerID ");
                sb.Append(" WHERE A.DeleteFlg = '0' AND A.EmployeeID=@EmployeeID ");


                DataTable dt = DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);

                return (dt.Rows.Count > 0) ?dt.Rows[0]:null;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int InsertEmployee(IF_Employee entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                sb.Append("INSERT INTO ");
                sb.Append("T_Employee  ");
                sb.Append("( ");
                sb.Append("EmployeeID,");//社員ID
                sb.Append("EmployeeName,");//社員名
                sb.Append("JapaneseSpell,");//フリカナ
                sb.Append("Birthday,");//生年月日
                sb.Append("Experience,");//経験年数
                sb.Append("Degree,");//学歴
                sb.Append("Certificate,");//資格
                sb.Append("Skill,");//技術
                sb.Append("Language,");//言語
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address1,");//住所１
                sb.Append("Address2,");//住所２
                sb.Append("Tel,");//TEL
                sb.Append("Company,");//勤務先
                sb.Append("Remark,");//評価
                sb.Append("Note,");//備考
                sb.Append("EmployeeType,");//社員区分
                sb.Append("siireID,");//仕入先ID
                sb.Append("siireSales,");//仕入先担当
                //sb.Append("siirePrice,");//仕入先単価
                //sb.Append("carfare,");//交通費
                sb.Append("DeleteFlg ");//削除フラグ
                sb.Append(") ");

                sb.Append("VALUES ");

                sb.Append("( ");
                sb.Append("@EmployeeID,");//社員ID
                sb.Append("@EmployeeName,");//社員名
                sb.Append("@JapaneseSpell,");//フリカナ
                sb.Append("@Birthday,");//生年月日
                sb.Append("@Experience,");//経験年数
                sb.Append("@Degree,");//学歴
                sb.Append("@Certificate,");//資格
                sb.Append("@Skill,");//技術
                sb.Append("@Language,");//言語
                sb.Append("@PostCode,");//郵便番号
                sb.Append("@Address1,");//住所１
                sb.Append("@Address2,");//住所２
                sb.Append("@Tel,");//TEL
                sb.Append("@Company,");//勤務先
                sb.Append("@Remark,");//評価
                sb.Append("@Note,");//備考
                sb.Append("@EmployeeType,");//社員区分
                sb.Append("@siireID,");//仕入先ID
                sb.Append("@siireSales,");//仕入先担当
                //sb.Append("@siirePrice,");//仕入単価
                //sb.Append("@carfare,");//仕入単価

                sb.Append("@DeleteFlg ");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//社員ID
                para.Value = entity.EmployeeID;//社員ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployeeName", MySqlDbType.VarChar);//社員名
                para.Value = Common.CommonHandler.StrConv(entity.EmployeeName, false);//社員名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@JapaneseSpell", MySqlDbType.VarChar);//フリカナ
                para.Value = Common.CommonHandler.StrConv(entity.JapaneseSpell, false);//フリカナ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Birthday", MySqlDbType.VarChar);//生年月日
                para.Value = entity.Birthday;//生年月日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Experience", MySqlDbType.VarChar);//経験年数
                para.Value = entity.Experience;//経験年数
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Degree", MySqlDbType.VarChar);//学歴
                para.Value = entity.Degree;//学歴
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Certificate", MySqlDbType.VarChar);//資格
                para.Value = entity.Certificate;//資格
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Skill", MySqlDbType.VarChar);//技術
                para.Value = entity.Skill;//技術
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Language", MySqlDbType.VarChar);//言語
                para.Value = entity.Language;//言語
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PostCode", MySqlDbType.VarChar);//郵便番号
                para.Value = entity.PostCode;//郵便番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address1", MySqlDbType.VarChar);//住所１
                para.Value = entity.Address1;//住所１
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address2", MySqlDbType.VarChar);//住所２
                para.Value = entity.Address2;//住所２
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Tel", MySqlDbType.VarChar);//TEL
                para.Value = entity.Tel;//TEL
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Company", MySqlDbType.VarChar);//勤務先
                para.Value = entity.Company;//勤務先
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Remark", MySqlDbType.VarChar);//評価
                para.Value = entity.Remark;//評価
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Note", MySqlDbType.VarChar);//備考
                para.Value = entity.Note;//備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployeeType", MySqlDbType.VarChar);//社員区分
                para.Value = entity.EmployeeType;//社員区分
                dbParams.Add(para);//追加

                para = new MySqlParameter("@siireID", MySqlDbType.Int32);//仕入先ID
                para.Value = entity.SiireID;//仕入先
                dbParams.Add(para);//追加
                para = new MySqlParameter("@siireSales", MySqlDbType.VarChar);//仕入先担当
                para.Value = entity.SiireSales;//仕入先担当
                dbParams.Add(para);//追加
                //para = new MySqlParameter("@siirePrice", MySqlDbType.VarChar);//仕入先単価
                //para.Value = entity.SiirePrice;//仕入先単価
                //dbParams.Add(para);//追加
                //para = new MySqlParameter("@carfare", MySqlDbType.VarChar);//仕入先単価
                //para.Value = entity.carfare;//仕入先単価
                //dbParams.Add(para);//追加



                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加


                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateEmployee(IF_Employee entity, DataTable dt)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                if (dt != null)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        DataRow dr = dt.Rows[i];
                        StringBuilder sbTemp = new StringBuilder();
                        List<MySqlParameter> dbParamsTemp = new List<MySqlParameter>();
                        sbTemp.Append(" update ");
                        sbTemp.Append(" T_Cost ");
                        sbTemp.Append(" set ");
                        sbTemp.Append(" SiirePrice=@SiirePrice, ");
                        sbTemp.Append(" Carfare=@Carfare ");
                        sbTemp.Append(" where ");
                        sbTemp.Append(" EmployeeID=@EmployeeID ");
                        sbTemp.Append(" and ");
                        sbTemp.Append(" Serial=@Serial ");

                        para = new MySqlParameter("@SiirePrice", MySqlDbType.Int32);//社員ID
                        para.Value = dr["SiirePrice"];//社員ID
                        dbParamsTemp.Add(para);//追加

                        para = new MySqlParameter("@Carfare", MySqlDbType.Int32);//社員ID
                        para.Value = dr["Carfare"];//社員ID
                        dbParamsTemp.Add(para);//追加

                        para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//社員ID
                        para.Value = entity.EmployeeID;//社員ID
                        dbParamsTemp.Add(para);//追加

                        para = new MySqlParameter("@Serial", MySqlDbType.Int32);//社員ID
                        para.Value = dr["Serial"];//社員ID
                        dbParamsTemp.Add(para);//追加

                        DBAccess.ExecuteSQL(sbTemp.ToString(), dbParamsTemp, cn, tx);
                    }

                }


                sb.Append("UPDATE ");
                sb.Append("T_Employee  ");
                sb.Append("SET ");

                sb.Append("EmployeeID = @EmployeeID,");//社員ID
                sb.Append("EmployeeName = @EmployeeName,");//社員名
                sb.Append("JapaneseSpell = @JapaneseSpell,");//フリカナ
                sb.Append("Birthday = @Birthday,");//生年月日
                sb.Append("Experience = @Experience,");//経験年数
                sb.Append("Degree = @Degree,");//学歴
                sb.Append("Certificate = @Certificate,");//資格
                sb.Append("Skill = @Skill,");//技術
                sb.Append("Language = @Language,");//言語
                sb.Append("PostCode = @PostCode,");//郵便番号
                sb.Append("Address1 = @Address1,");//住所１
                sb.Append("Address2 = @Address2,");//住所２
                sb.Append("Tel = @Tel,");//TEL
                sb.Append("Company = @Company,");//勤務先
                sb.Append("Remark = @Remark,");//評価
                sb.Append("Note = @Note,");//備考
                sb.Append("siireID = @SiireID,");//仕入先ID
                sb.Append("siireSales = @SireSales,");//仕入先担当
                //sb.Append("siirePrice = @SirePrice,");//仕入原価
                //sb.Append("carfare = @carfare,");//交通費
                sb.Append("EmployeeType = @EmployeeType,");//社員区分
                sb.Append("DeleteFlg = @DeleteFlg ,");//削除フラグ

                if (entity.DeleteFlg == "1")
                {
                    sb.Append("DeleteTime = @DeleteTime ");//削除時間

                    para = new MySqlParameter("@DeleteTime", MySqlDbType.DateTime);//削除時間
                    para.Value = DateTime.Now;//削除時間
                    dbParams.Add(para);//追加
                }
                else
                {
                    sb.Append("UpdateTime = @UpdateTime ");//更新時間
                    para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                    para.Value = DateTime.Now;//更新時間
                    dbParams.Add(para);//追加
                }
                sb.Append("WHERE EmployeeID = @EmployeeID");

                para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//社員ID
                para.Value = entity.EmployeeID;//社員ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployeeName", MySqlDbType.VarChar);//社員名
                para.Value = Common.CommonHandler.StrConv(entity.EmployeeName, false);//社員名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@JapaneseSpell", MySqlDbType.VarChar);//フリカナ
                para.Value = Common.CommonHandler.StrConv(entity.JapaneseSpell, false);//フリカナ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Birthday", MySqlDbType.VarChar);//生年月日
                para.Value = entity.Birthday;//生年月日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Experience", MySqlDbType.VarChar);//経験年数
                para.Value = entity.Experience;//経験年数
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Degree", MySqlDbType.VarChar);//学歴
                para.Value = entity.Degree;//学歴
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Certificate", MySqlDbType.VarChar);//資格
                para.Value = entity.Certificate;//資格
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Skill", MySqlDbType.VarChar);//技術
                para.Value = entity.Skill;//技術
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Language", MySqlDbType.VarChar);//言語
                para.Value = entity.Language;//言語
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PostCode", MySqlDbType.VarChar);//郵便番号
                para.Value = entity.PostCode;//郵便番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address1", MySqlDbType.VarChar);//住所１
                para.Value = entity.Address1;//住所１
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address2", MySqlDbType.VarChar);//住所２
                para.Value = entity.Address2;//住所２
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Tel", MySqlDbType.VarChar);//TEL
                para.Value = entity.Tel;//TEL
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Company", MySqlDbType.VarChar);//勤務先
                para.Value = entity.Company;//勤務先
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Remark", MySqlDbType.VarChar);//評価
                para.Value = entity.Remark;//評価
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Note", MySqlDbType.VarChar);//備考
                para.Value = entity.Note;//備考
                dbParams.Add(para);//追加

                para = new MySqlParameter("@SiireID", MySqlDbType.VarChar);//仕入先ID
                para.Value = entity.SiireID;//仕入先ID
                dbParams.Add(para);//追加

                para = new MySqlParameter("@SireSales", MySqlDbType.VarChar);//仕入先担当
                para.Value = entity.SiireSales;//仕入先担当
                dbParams.Add(para);//追加
                //para = new MySqlParameter("@SirePrice", MySqlDbType.VarChar);//仕入単価
                //para.Value = entity.SiirePrice;//仕入先単価
                //dbParams.Add(para);//追加
                //para = new MySqlParameter("@carfare", MySqlDbType.Int32);//仕入単価
                //para.Value = entity.carfare;//仕入先単価
                //dbParams.Add(para);//追加


                para = new MySqlParameter("@EmployeeType", MySqlDbType.VarChar);//社員区分
                para.Value = entity.EmployeeType;//社員区分
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加


                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }   
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        ///// <summary>
        ///// 更新(仕入原価・交通費)
        ///// </summary>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //public int UpdateEmployeeForPurchase(IF_Employee entity)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    MySqlConnection cn = null;
        //    MySqlTransaction tx = null;
        //    try
        //    {

        //        string connectString = DBAccess.ConnectString;
        //        cn = new MySqlConnection(connectString);
        //        cn.Open();
        //        tx = cn.BeginTransaction();

        //        List<MySqlParameter> dbParams = new List<MySqlParameter>();
        //        MySqlParameter para = null;

        //        sb.Append("UPDATE ");
        //        sb.Append("T_Employee  ");
        //        sb.Append("SET ");
        //        sb.Append("siirePrice = (CASE IFNULL(siirePrice,0) WHEN 0 THEN @SirePrice ELSE siirePrice END),");//仕入原価
        //        sb.Append("carfare = (CASE IFNULL(carfare,0) WHEN 0 THEN @carfare ELSE carfare END),");//交通費

        //        sb.Append("UpdateTime = @UpdateTime ");//更新時間

        //        para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
        //        para.Value = DateTime.Now;//更新時間
        //        dbParams.Add(para);//追加

        //        sb.Append("WHERE EmployeeID = @EmployeeID");

        //        para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//社員ID
        //        para.Value = entity.EmployeeID;//社員ID
        //        dbParams.Add(para);//追加
        //        para = new MySqlParameter("@SirePrice", MySqlDbType.VarChar);//仕入単価
        //        para.Value = entity.SiirePrice;//仕入先単価
        //        dbParams.Add(para);//追加
        //        para = new MySqlParameter("@carfare", MySqlDbType.VarChar);//交通費
        //        para.Value = entity.carfare;//交通費
        //        dbParams.Add(para);//追加


        //        int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

        //        tx.Commit();

        //        return row;
        //    }
        //    catch (Exception ex)
        //    {
        //        tx.Rollback();
        //        throw (ex);
        //    }
        //    finally
        //    {
        //        cn.Close();
        //    }
        //}
        /// <summary>
        /// 削除フラグを変更
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int DeleteEmployee(IF_Employee entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                sb.Append("UPDATE ");
                sb.Append("T_Employee  ");
                sb.Append("SET ");
                sb.Append("DeleteFlg = @DeleteFlg, ");//削除フラグ
                if (entity.DeleteFlg == "1")
                {
                    sb.Append("DeleteTime = @DeleteTime ");//削除時間

                    para = new MySqlParameter("@DeleteTime", MySqlDbType.DateTime);//削除時間
                    para.Value = DateTime.Now;//削除時間
                    dbParams.Add(para);//追加
                }
                else
                {
                    sb.Append("UpdateTime = @UpdateTime ");//更新時間
                    para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                    para.Value = DateTime.Now;//更新時間
                    dbParams.Add(para);//追加
                }
                sb.Append("WHERE EmployeeID = @EmployeeID");

                para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//社員ID
                para.Value = entity.EmployeeID;//社員ID
                dbParams.Add(para);//追加

                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
