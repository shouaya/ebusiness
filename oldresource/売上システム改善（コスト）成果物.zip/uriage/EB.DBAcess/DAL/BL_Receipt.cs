﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_Receipt
    {
        private static BL_Receipt bl = new BL_Receipt();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_Receipt GetInstance()
        {
            return bl;
        }
        /// <summary>
        /// 入金情報の取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectReceipt(string ReceiptID)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("ReceiptID,");//入金番号
                sb.Append("CustomerID,");//顧客ID
                sb.Append("ReceiptAmount,");//入金額
                sb.Append("ReceiptDate,");//入金日
                sb.Append("DeleteFlg,");//削除フラグ
                sb.Append(" FROM T_Receipt ");
                sb.Append(" WHERE DeleteFlg = '0' AND ReceiptID = " + ReceiptID);
                sb.Append(" ORDER BY ReceiptID");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 登録
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void RegisterAll(IF_Receipt entity, List<IF_Bill> list)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                long id =  InsertReceipt(entity, cn, tx);

                BL_Bill bl = BL_Bill.GetInstance();
                foreach (IF_Bill bill in list)
                {
                    bill.ReceiptID = Convert.ToInt32(id);
                    bl.UpdateBillForReceive(bill, cn, tx);
                }

                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void UpdateAll(IF_Receipt entity, List<IF_Bill> list)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                UpdateReceipt(entity, cn, tx);

                BL_Bill bl = BL_Bill.GetInstance();
                foreach (IF_Bill bill in list)
                {
                    bl.UpdateBillForReceive(bill, cn, tx);
                }

                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public long InsertReceipt(IF_Receipt entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();
            try
            {

                sb.Append("INSERT INTO ");
                sb.Append("T_Receipt  ");
                sb.Append("( ");
                sb.Append("CustomerID,");//顧客ID
                sb.Append("ReceiptAmount,");//入金額
                sb.Append("ReceiptDate,");//入金日
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(") ");
                sb.Append("VALUES ");
                sb.Append("( ");
                sb.Append("@CustomerID,");//顧客ID
                sb.Append("@ReceiptAmount,");//入金額
                sb.Append("@ReceiptDate,");//入金日
                sb.Append("@DeleteFlg");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ReceiptAmount", MySqlDbType.Decimal);//入金額
                para.Value = entity.ReceiptAmount;//入金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ReceiptDate", MySqlDbType.VarChar);//入金日
                para.Value = entity.ReceiptDate;//入金日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加


                long id = DBAccess.ExecuteSQLReturnID(sb.ToString(), dbParams, cn, tx);

                return id;
            }
            catch (Exception ex)
            {
                throw (ex);
            }

        }


        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateReceipt(IF_Receipt entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();
            try
            {

                sb.Append("UPDATE ");
                sb.Append("T_Receipt  ");
                sb.Append("SET ");
                sb.Append("CustomerID = @CustomerID,");//顧客ID
                sb.Append("ReceiptAmount = @ReceiptAmount,");//入金額
                sb.Append("ReceiptDate = @ReceiptDate,");//入金日
                sb.Append("UpdateTime = @UpdateTime ");//更新時間
                sb.Append(" WHERE ReceiptID = @ReceiptID");//会社ID


                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@ReceiptID", MySqlDbType.Int32);//入金番号
                para.Value = entity.ReceiptID;//入金番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ReceiptAmount", MySqlDbType.Decimal);//入金額
                para.Value = entity.ReceiptAmount;//入金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ReceiptDate", MySqlDbType.VarChar);//入金日
                para.Value = entity.ReceiptDate;//入金日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                para.Value = DateTime.Now;//更新時間
                dbParams.Add(para);//追加
                

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
    }
}
