﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_Company
    {
        private static BL_Company bl = new BL_Company();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_Company GetInstance()
        {
            return bl;
        }
        /// <summary>
        /// 会社情報の取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectCompany(string companyID)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("CompanyID,");//会社ID
                sb.Append("CompanyName,");//会社名称
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address,");//住所
                sb.Append("Representor,");//代表者
                sb.Append("Tel,");//電話番号
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(" FROM T_Company ");
                sb.Append(" WHERE DeleteFlg = '0' AND CompanyID = @companyID");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@companyID", MySqlDbType.Int32);
                para.Value = companyID;
                dbParams.Add(para);

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int InsertCompany(IF_Company entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                sb.Append("INSERT INTO ");
                sb.Append("T_Company  ");
                sb.Append("( ");
                //sb.Append("CompanyID,");//会社ID
                sb.Append("CompanyName,");//会社名称
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address,");//住所
                sb.Append("Representor,");//代表者
                sb.Append("Tel,");//電話番号
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(") ");

                sb.Append("VALUES ");

                sb.Append("( ");
                //sb.Append("@CompanyID,");//会社ID
                sb.Append("@CompanyName,");//会社名称
                sb.Append("@PostCode,");//郵便番号
                sb.Append("@Address,");//住所
                sb.Append("@Representor,");//代表者
                sb.Append("@Tel,");//電話番号
                sb.Append("@DeleteFlg");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                //para = new MySqlParameter("@CompanyID", MySqlDbType.VarChar);//会社ID
                //para.Value = entity.CompanyID;//会社ID
                //dbParams.Add(para);//追加
                para = new MySqlParameter("@CompanyName", MySqlDbType.VarChar);//会社名称
                para.Value = entity.CompanyName;//会社名称
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PostCode", MySqlDbType.VarChar);//郵便番号
                para.Value = entity.PostCode;//郵便番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address", MySqlDbType.VarChar);//住所
                para.Value = entity.Address;//住所
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Representor", MySqlDbType.VarChar);//代表者
                para.Value = entity.Representor;//代表者
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Tel", MySqlDbType.VarChar);//電話番号
                para.Value = entity.Tel;//電話番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加


                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }


        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateCompany(IF_Company entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;


                sb.Append("UPDATE ");
                sb.Append("T_Company  ");
                sb.Append("SET ");

                sb.Append("CompanyName = @CompanyName,");//会社名称
                sb.Append("PostCode = @PostCode,");//郵便番号
                sb.Append("Address = @Address,");//住所
                sb.Append("Representor = @Representor,");//代表者
                sb.Append("Tel = @Tel,");//電話番号
                sb.Append("DeleteFlg = @DeleteFlg ,");//削除フラグ
                if (entity.DeleteFlg == "1")
                {
                    sb.Append("DeleteTime = @DeleteTime ");//削除時間

                    para = new MySqlParameter("@DeleteTime", MySqlDbType.DateTime);//削除時間
                    para.Value = DateTime.Now;//削除時間
                    dbParams.Add(para);//追加
                }
                else
                {
                    sb.Append("UpdateTime = @UpdateTime ");//更新時間
                    para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                    para.Value = DateTime.Now;//更新時間
                    dbParams.Add(para);//追加
                }
                sb.Append(" WHERE CompanyID = @CompanyID");//会社ID



                para = new MySqlParameter("@CompanyID", MySqlDbType.Int32);//会社ID
                para.Value = entity.CompanyID;//会社ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@CompanyName", MySqlDbType.VarChar);//会社名称
                para.Value = entity.CompanyName;//会社名称
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PostCode", MySqlDbType.VarChar);//郵便番号
                para.Value = entity.PostCode;//郵便番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address", MySqlDbType.VarChar);//住所
                para.Value = entity.Address;//住所
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Representor", MySqlDbType.VarChar);//代表者
                para.Value = entity.Representor;//代表者
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Tel", MySqlDbType.VarChar);//電話番号
                para.Value = entity.Tel;//電話番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加



                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
