﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_OperateLog
    {
        private static BL_OperateLog bl = new BL_OperateLog();
        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_OperateLog GetInstance()
        {
            return bl;
        }
        /// <summary>
        /// 操作を記録(DBAccess専用)
        /// INSERT/UPDATE/DELETEの操作を記録する
        /// </summary>
        /// <returns></returns>
        public MySqlCommand GetOperateLogCommand(string SQLString, List<MySqlParameter> dbParams)
        {
            //return null;
            StringBuilder sb = new StringBuilder();
            IF_OperateLog entity = this.GetOperateBySqlAndParams(SQLString, dbParams);
            entity.UserID = BL_User.GetLoginInfo().UserID;

            if (string.IsNullOrEmpty(entity.Operate) || string.IsNullOrEmpty(entity.UserID))
            {
                return null;
            }
            try
            {
                sb.Append("  INSERT INTO `T_OperateLog`(    ");
                //sb.Append("    `OperateLogID`,              ");
                sb.Append("    `TableName`,                 ");
                sb.Append("    `UserID`,                    ");
                sb.Append("    `Operate`,                   ");
                sb.Append("    `LogTime`                    ");
                sb.Append("  ) VALUES (                     ");
                //sb.Append("    @OperateLogID,               ");
                sb.Append("    @TableName,                  ");
                sb.Append("    @UserID,                     ");
                sb.Append("    @Operate,                    ");
                sb.Append("    @LogTime                     ");
                sb.Append("  );                             ");

                MySqlCommand cmd = new MySqlCommand();

                cmd.CommandText = sb.ToString();

                MySqlParameter para = null;

                para = new MySqlParameter("@TableName", MySqlDbType.VarChar);
                para.Value = entity.TableName;
                cmd.Parameters.Add(para);

                para = new MySqlParameter("@UserID", MySqlDbType.VarChar);
                para.Value = entity.UserID;
                cmd.Parameters.Add(para);

                para = new MySqlParameter("@Operate", MySqlDbType.VarChar);
                para.Value = entity.Operate;
                cmd.Parameters.Add(para);

                para = new MySqlParameter("@LogTime", MySqlDbType.VarChar);
                para.Value = entity.LogTime;
                cmd.Parameters.Add(para);

                return cmd;
            }
            catch (Exception ex)
            {
                EB.Common.LogHelper.Error(ex.Message);
                throw (ex);
            }
            finally
            {
                sb = null;
                entity = null;
            }
        }

        private IF_OperateLog GetOperateBySqlAndParams(string SQLString, List<MySqlParameter> dbParams)
        {
            IF_OperateLog entity = new IF_OperateLog();

            IList<String[]> reglist = EB.Common.CommonHandler._GetString(SQLString, "(?=[\\t\\s]*)(INSERT(?=[\\t\\s]*INTO)|UPDATE[\\t\\s]|DELETE(?=[\\t\\s]*FROM))[^_]*(T_[^\\s\\t]*)[\\t\\s]*(?=SET.*DeleteFlg[\\t\\s]*=[\\t\\s]*([^\\t\\s]*).*(?=WHERE))?");

            if (reglist != null)
            {
                foreach (string[] strlist in reglist)
                {
                    if (strlist.Length > 3)
                    {
                        entity.Operate = GetValueInParam(strlist[2],dbParams)=="1" ? "DELETE" : strlist[0].ToUpper();
                        entity.TableName = strlist[1].ToUpper();
                    }
                }
            }
            return entity;
        }
        private string GetValueInParam(string key, List<MySqlParameter> dbParams)
        {
            string result = null;
            if (dbParams!=null&&key.IndexOf("@") != -1)
            {
                MySqlParameter param = dbParams.Find((item) => { return item.ParameterName.ToLower().Equals(key.ToLower()); });
                if (param != null)
                {
                    result = param.Value.ToString();
                }
            }
            else
            {
                result = key.Replace("'",null);
            }
            return result;
        }
        /*
        private readonly string[] KeyList = { 
                                                "BillNo",
                                                "CodeType", "CodeId",
                                                "CompanyID" ,
                                                "ContractID" ,"DetailID",
                                                "CustomerID",
                                                "DeptID",
                                                "EmployeeID",
                                                "EstimationID",
                                                "ManagementID",
                                                "OperateLogID",
                                                "PcCode",
                                                "ReceiptID",
                                                "SaleID" ,//"ContractID",
                                                "AttatchID",
                                                "SaleDetailID",
                                                "siireID",
                                                "UserID"
                                            };
        private void SetPrimarykeyBySqlString(IF_OperateLog entity, string SQLString, List<MySqlParameter> dbParams)
        {
            IList<String[]> reglist = EB.Common.CommonHandler._GetString(SQLString, "(?>WHERE[\\s]*)([^\\s=<>]*)[\\s=<>]*(?=IN)?([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*([^\\s=<>]*)[\\s=<>]*");
            IList<string> Primarykey = new List<string>();
            if (reglist != null)
            {
                foreach (string[] strlist in reglist)
                {
                    foreach (string key in KeyList)
                    {
                        for (int i = 0; i < strlist.Length; i++)
                        {
                            if (key.ToUpper() == strlist[i].ToUpper() && strlist.Length > i + 1)
                            {
                                Primarykey.Add(GetValueInParam(strlist[i + 1], dbParams));
                            }
                        }
                    }
                }
            }
        }
        private void SetPrimarykeyByClassname(IF_OperateLog entity,string tablename){
            Type t = Type.GetType("EB.DBAcess.IF_" + tablename.Replace("T_", null), false, true);
            if (t != null)
            {
                entity.TableName = t.Name;
                //MemberInfo[] members = t.GetMembers();

                //foreach (MemberInfo member in members)
                //{
                //    EB.Common.LogHelper.Debug("member:" + member);

                //    //Console.WriteLine(method); 
                //    //Console.WriteLine("返回值：" + method.ReturnParameter); 
                //}
            }
        }
         */
    }
}
