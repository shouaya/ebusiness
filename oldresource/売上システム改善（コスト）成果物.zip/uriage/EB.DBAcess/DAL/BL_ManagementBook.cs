﻿using System;
using System.Collections.Generic;

using EB.Common;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace EB.DBAcess
{
    public class BL_ManagementBook
    {
        private static BL_ManagementBook bl = new BL_ManagementBook();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_ManagementBook GetInstance()
        {
            return bl;
        }
        /// <summary>
        /// 社内管理台帳を取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectManagementBook(IF_ManagementBook entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("(case MB.UpdateFlg when '1' then '     済' else '' end) AS UpdateFlg,");//契約登録済フラッグ
                sb.Append("MB.ManagementID,");//管理ID
                sb.Append("MB.EmployeeID,");//社員ID

                sb.Append("EE.EmployeeName,");//社員名
                sb.Append("EE.EmployeeType,");//社員区分
                sb.Append("CM.CodeName AS EmployeeTypeName,");//社員区分名

                sb.Append("MB.Salesman1ID,");//営業担当１ID
                sb.Append("MB.Salesman2ID,");//営業担当２ID

                sb.Append("ES1.EmployeeName AS Salesman1Name,");//営業担当１氏名
                //sb.Append("MB.Salesman1Name,");//営業担当１氏名
                sb.Append("ES2.EmployeeName AS Salesman2Name,");//営業担当２氏名
                //sb.Append("MB.Salesman2Name,");//営業担当２氏名


                sb.Append("MB.DeptName,");//所属部門
                sb.Append("MB.siireName,");//仕入
                sb.Append("MB.siireSales,");//仕入先担当
                sb.Append("MB.CustomerID,");//顧客ID

                sb.Append("C.CustomerName,");//顧客会社

                sb.Append("MB.CustSalesman,");//顧客窓口
                sb.Append("MB.ContractName,");//契約件名
                sb.Append("MB.ProjectName,");//作業工程
                sb.Append("MB.WorkAddr,");//現場
                sb.Append("MB.StartDate,");//開始日
                sb.Append("MB.EndDate,");//終了日
                sb.Append("MB.WorkMonth,");//稼働月
                sb.Append("MB.Amount,");//売上
                sb.Append("MB.MinHour,");//稼働下限
                sb.Append("MB.MaxHour,");//稼働上限
                sb.Append("MB.MinusUnitPrice,");//控除単価
                sb.Append("MB.PlusUnitPrice,");//超過単価
                sb.Append("MB.Quantity,");//日割計算
                sb.Append("MB.PaymentType,");//支払方法
                sb.Append("MB.PaymentDay,");//支払日
                sb.Append("CONCAT(CM1.CodeName,(CASE  MB.PaymentDay  when '99'   then '月末' ELSE MB.PaymentDay END )) AS PaymentSet,");//支払サイト
                sb.Append("MB.TranExpense,");//交通費
                sb.Append("MB.Price,");//単価
                sb.Append("MB.Unit,");//単位
                sb.Append("TC.siirePrice,");//仕入原価
                sb.Append("TC.startdate as CostStartDate,");
                sb.Append("TC.enddate as CostEndDate,");
                sb.Append("MB.Memo,");//備考
                sb.Append("MB.OrderDate,");//注文書届日
                sb.Append("MB.OrderNo");//注文書番号

                sb.Append(" FROM T_ManagementBook AS MB");
                ////////////////////////////////////////////////////
                sb.Append(" LEFT JOIN T_Employee AS ES1 ON ES1.EmployeeID = MB.Salesman1ID");
                sb.Append(" LEFT JOIN T_Employee AS ES2 ON ES2.EmployeeID = MB.Salesman2ID");


                sb.Append(" LEFT JOIN T_Employee AS EE ON EE.EmployeeID = MB.EmployeeID");
                sb.Append(" LEFT JOIN T_Cost AS TC ON TC.EmployeeID = EE.EmployeeID and substr(TC.startdate,1,7) <= MB.WorkMonth and substr(TC.enddate,1,7) >= MB.WorkMonth");
                sb.Append(" LEFT JOIN T_CodeMaster AS CM ON CM.CodeId = EE.EmployeeType AND CM.CodeType='CD001' ");


                sb.Append(" LEFT JOIN T_Customer AS C ON C.CustomerID = MB.CustomerID");

                sb.Append(" LEFT JOIN T_CodeMaster AS CM1 ON CM1.CodeId = MB.PaymentType  AND CM1.CodeType ='CD005' ");
                ////////////////////////////////////////////////////

                sb.Append(" WHERE MB.DeleteFlg = '0'");

                if (entity.CustomerID > 0)
                {
                    sb.Append(" AND MB.CustomerID=@CustomerID ");

                    para = new MySqlParameter("@CustomerID", MySqlDbType.VarChar);
                    para.Value = entity.CustomerID;
                    dbParams.Add(para);
                }
                ///////////
                if (entity.EmployeeID > 0)
                {
                    sb.Append(" AND EE.EmployeeName=@EmployeeID ");

                    para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);
                    para.Value = entity.EmployeeID;
                    dbParams.Add(para);
                }
                if (!string.IsNullOrEmpty(entity.ContractName))
                {
                    sb.Append(" AND MB.ContractName=@ContractName ");

                    para = new MySqlParameter("@ContractName", MySqlDbType.VarChar);
                    para.Value = entity.ContractName;
                    dbParams.Add(para);
                }
                /////////////////
                if (!string.IsNullOrEmpty(entity.EmployeeName))
                {
                    sb.Append(" AND EE.EmployeeName=@EmployeeName ");

                    para = new MySqlParameter("@EmployeeName", MySqlDbType.VarChar);
                    para.Value = entity.EmployeeName;
                    dbParams.Add(para);
                }
                if (!string.IsNullOrEmpty(entity.Memo))
                {
                    if (entity.Memo.Equals("有"))
                    {
                        sb.Append(" AND TRIM(MB.Memo)<>'' ");
                    }
                    if (entity.Memo.Equals("無"))
                    {
                        sb.Append(" AND TRIM(MB.Memo)='' ");
                    }

                }
                if (!string.IsNullOrEmpty(entity.WorkAddr))
                {
                    sb.Append(" AND MB.WorkAddr LIKE @WorkAddr ");

                    para = new MySqlParameter("@WorkAddr", MySqlDbType.VarChar);
                    para.Value = "%" + entity.WorkAddr + "%";
                    dbParams.Add(para);
                }
                if (!string.IsNullOrEmpty(entity.EmployeeType))
                {
                    sb.Append(" AND EE.EmployeeType=@EmployeeType ");

                    para = new MySqlParameter("@EmployeeType", MySqlDbType.VarChar);
                    para.Value = entity.EmployeeType;
                    dbParams.Add(para);
                }

                if (entity.WorkMonth != null && entity.WorkMonthEnd == null)
                {
                    if (entity.WorkMonth.Length == 5)
                    {
                        sb.Append(" AND MB.WorkMonth LIKE @WorkMonth ");

                        para = new MySqlParameter("@WorkMonth", MySqlDbType.VarChar);
                        para.Value = "%" + entity.WorkMonth.Substring(0, 4) + "%";
                        dbParams.Add(para);

                    }
                    else
                    {
                        sb.Append(" AND MB.WorkMonth=@WorkMonth ");

                        para = new MySqlParameter("@WorkMonth", MySqlDbType.VarChar);
                        para.Value = entity.WorkMonth;
                        dbParams.Add(para);
                    }
                }


                if (entity.WorkMonthEnd != null)
                {

                    sb.Append(" AND MB.WorkMonth>=@WorkMonth ");

                    para = new MySqlParameter("@WorkMonth", MySqlDbType.VarChar);
                    para.Value = entity.WorkMonth;
                    dbParams.Add(para);
                    sb.Append(" AND MB.WorkMonth<=@WorkMonthEnd ");

                    para = new MySqlParameter("@WorkMonthEnd", MySqlDbType.VarChar);
                    para.Value = entity.WorkMonthEnd;
                    dbParams.Add(para);

                }

                sb.Append(" ORDER BY MB.ManagementID");


                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }





        /// <summary>
        /// 契約情報を取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectContactDetail00()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT A.* ,B.* FROM  T_ContractDetail A  left join T_Contract B on A.ContractID=B.ContractID ");

                DataTable dt = DBAccess.Select(sb.ToString(), cn);

                if (dt.Rows.Count > 0)
                {
                    return dt;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }


        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int InsertManagementBook00(DataTable dt)
        {
            //StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();
                int intCount = dt.Rows.Count;

                for (int i = 0; i <= intCount - 1; i++)
                {

                    string strStart = dt.Rows[i]["StartDate"].ToString(); //開始日
                    string strEnd = dt.Rows[i]["EndDate"].ToString(); //終了日
                    string strWorkMonth = strStart;//年月取得  

                    DateTime dtStart = DateTime.Parse(strWorkMonth);
                    DateTime dtEnd = DateTime.Parse(strEnd);


                    while (dtStart <= dtEnd)
                    {
                        StringBuilder sb = new StringBuilder();

                        sb.Append("INSERT INTO ");
                        sb.Append("T_ManagementBook  ");
                        sb.Append("( ");
                        //sb.Append("ManagementID,");//管理ID
                        sb.Append("EmployeeID,");//社員ID

                        sb.Append("Salesman1ID,");//営業担当１ID
                        sb.Append("Salesman2ID,");//営業担当２ID

                        sb.Append("DeptName,");//所属部門
                        sb.Append("siireName,");//仕入
                        sb.Append("siireSales,");//仕入先担当

                        sb.Append("CustomerID,");//顧客ID

                        sb.Append("CustSalesman,");//顧客窓口
                        sb.Append("ContractName,");//契約件名
                        sb.Append("ProjectName,");//作業工程
                        sb.Append("WorkAddr,");//現場
                        sb.Append("WorkMonth,");//稼働月
                        sb.Append("StartDate,");//開始日
                        sb.Append("EndDate,");//終了日
                        sb.Append("Amount,");//売上
                        sb.Append("MinHour,");//稼働下限
                        sb.Append("MaxHour,");//稼働上限
                        sb.Append("MinusUnitPrice,");//控除単価
                        sb.Append("PlusUnitPrice,");//超過単価
                        sb.Append("Quantity,");//日割計算
                        sb.Append("PaymentType,");//支払方法
                        sb.Append("PaymentDay,");//支払日
                        sb.Append("TranExpense,");//交通費
                        sb.Append("Price,");//単価
                        sb.Append("Memo,");//備考
                        sb.Append("OrderDate,");//注文書届日
                        sb.Append("OrderNo,");//注文書番号
                        sb.Append("UpdateFlg,");//契約登録済フラグ
                        sb.Append("ContractID,");//契約ID
                        sb.Append("DetailID,");//契約明細ID
                        sb.Append("DeleteFlg");//削除フラグ
                        sb.Append(") ");

                        sb.Append("VALUES ");

                        sb.Append("( ");
                        //sb.Append("@ManagementID,");//管理ID
                        sb.Append("@EmployeeID,");//社員ID

                        sb.Append("@Salesman1ID,");//営業担当１ID
                        sb.Append("@Salesman2ID,");//営業担当２ID

                        sb.Append("@DeptName,");//所属部門
                        sb.Append("@siireName,");//仕入
                        sb.Append("@siireSales,");//仕入先担当

                        sb.Append("@CustomerID,");//顧客ID

                        sb.Append("@CustSalesman,");//顧客窓口
                        sb.Append("@ContractName,");//契約件名
                        sb.Append("@ProjectName,");//作業工程
                        sb.Append("@WorkAddr,");//現場
                        sb.Append("@WorkMonth,");//稼働月
                        sb.Append("@StartDate,");//開始日
                        sb.Append("@EndDate,");//終了日
                        sb.Append("@Amount,");//売上
                        sb.Append("@MinHour,");//稼働下限
                        sb.Append("@MaxHour,");//稼働上限
                        sb.Append("@MinusUnitPrice,");//控除単価
                        sb.Append("@PlusUnitPrice,");//超過単価
                        sb.Append("@Quantity,");//日割計算
                        sb.Append("@PaymentType,");//支払方法
                        sb.Append("@PaymentDay,");//支払日
                        sb.Append("@TranExpense,");//交通費
                        sb.Append("@Price,");//単価
                        sb.Append("@Memo,");//備考
                        sb.Append("@OrderDate,");//注文書届日
                        sb.Append("@OrderNo,");//注文書番号

                        sb.Append("@UpdateFlg,");//契約登録済フラグ
                        sb.Append("@ContractID,");//契約ID
                        sb.Append("@DetailID,");//契約明細ID

                        sb.Append("@DeleteFlg");//削除フラグ
                        sb.Append(") ");


                        List<MySqlParameter> dbParams = new List<MySqlParameter>();
                        MySqlParameter para = null;

                        //para = new MySqlParameter("@ManagementID", MySqlDbType.Int32);//管理ID
                        //para.Value = i;//管理ID
                        //dbParams.Add(para);//追加
                        para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//社員ID
                        para.Value = dt.Rows[i]["EmployeeID"];//社員ID
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@Salesman1ID", MySqlDbType.Int32);//営業担当１ID
                        para.Value = dt.Rows[i]["Salesman1"];//営業担当１ID
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@Salesman2ID", MySqlDbType.Int32);//営業担当２ID
                        para.Value = dt.Rows[i]["Salesman2"];//営業担当２ID
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@DeptName", MySqlDbType.VarChar);//所属部門
                        para.Value = " ";//所属部門
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@siireName", MySqlDbType.VarChar);//仕入
                        para.Value = " ";//仕入
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@siireSales", MySqlDbType.VarChar);//仕入先担当
                        para.Value = " ";//仕入先担当
                        dbParams.Add(para);//追加


                        para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                        para.Value = dt.Rows[i]["CustomerID"];//顧客ID
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@CustSalesman", MySqlDbType.VarChar);//顧客窓口
                        para.Value = "";//顧客窓口
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@ContractName", MySqlDbType.VarChar);//契約件名
                        para.Value = dt.Rows[i]["ContractName"];//契約件名
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@ProjectName", MySqlDbType.VarChar);//作業工程
                        para.Value = " ";//作業工程
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@WorkAddr", MySqlDbType.VarChar);//現場
                        para.Value = " ";//現場
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@WorkMonth", MySqlDbType.VarChar);//稼働月
                        para.Value = strWorkMonth.Substring(0, 7);//稼働月
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@StartDate", MySqlDbType.VarChar);//開始日
                        para.Value = dt.Rows[i]["StartDate"];//開始日
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@EndDate", MySqlDbType.VarChar);//終了日
                        para.Value = dt.Rows[i]["EndDate"];//終了日
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@Amount", MySqlDbType.Decimal);//売上
                        para.Value = dt.Rows[i]["Amount"];//売上
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@MinHour", MySqlDbType.Decimal);//稼働下限
                        para.Value = dt.Rows[i]["MinHour"];//稼働下限
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@MaxHour", MySqlDbType.Decimal);//稼働上限
                        para.Value = dt.Rows[i]["MaxHour"];//稼働上限
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@MinusUnitPrice", MySqlDbType.Decimal);//控除単価
                        para.Value = dt.Rows[i]["MinusUnitPrice"];//控除単価
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@PlusUnitPrice", MySqlDbType.Decimal);//超過単価
                        para.Value = dt.Rows[i]["PlusUnitPrice"];//超過単価
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@Quantity", MySqlDbType.Decimal);//日割計算
                        para.Value = dt.Rows[i]["Quantity"];//日割計算
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@PaymentType", MySqlDbType.VarChar);//支払方法
                        para.Value = dt.Rows[i]["PaymentType"];//支払方法
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@PaymentDay", MySqlDbType.VarChar);//支払日
                        para.Value = dt.Rows[i]["PaymentDay"];//支払日
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@TranExpense", MySqlDbType.Decimal);//交通費
                        para.Value = 0;//交通費
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@Price", MySqlDbType.Decimal);//単価
                        para.Value = dt.Rows[i]["Price"];//単価
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@Memo", MySqlDbType.VarChar);//備考
                        para.Value = " ";//備考
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@OrderDate", MySqlDbType.VarChar);//注文書届日
                        para.Value = dt.Rows[i]["OrderDate"];//注文書届日
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@OrderNo", MySqlDbType.VarChar);//注文書番号
                        para.Value = dt.Rows[i]["OrderNo"];//注文書番号
                        dbParams.Add(para);//追加


                        para = new MySqlParameter("@UpdateFlg", MySqlDbType.VarChar);//契約登録済みフラグ
                        para.Value = "1";//契約登録済みフラグ
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@ContractID", MySqlDbType.VarChar);//契約ID
                        para.Value = dt.Rows[i]["ContractID"];//契約ID
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@DetailID", MySqlDbType.VarChar);//契約明細ID
                        para.Value = dt.Rows[i]["DetailID"];//契約明細
                        dbParams.Add(para);//追加

                        para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                        para.Value = dt.Rows[i]["DeleteFlg"];//削除フラグ
                        dbParams.Add(para);//追加

                        int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                        strWorkMonth = CommonHandler.NextMonth(strWorkMonth);//翌月取得
                        dtStart = DateTime.Parse(strWorkMonth);
                    }
                }


                tx.Commit();

                return 1;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }







        /// <summary>
        /// 稼働月で仮台帳作成フラグを取得
        /// </summary>
        /// <returns></returns>
        public bool SelectFlgByNextMonth(String nextMonth)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT * FROM T_CodeMaster Where CodeType= 'CD999' AND DeleteFlg='0'  AND CodeId ='");

                sb.Append(nextMonth.Substring(5)).Append("'");

                DataTable dt = DBAccess.Select(sb.ToString(), cn);

                if (dt.Rows.Count == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }



            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }


        /// <summary>
        /// 稼働月で社内管理台帳を取得
        /// </summary>
        /// <returns></returns>
        public void SelectByWorkMonth(String month, String nextMonth)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("* ");//管理ID


                sb.Append(" FROM T_ManagementBook ");
                sb.Append(" WHERE DeleteFlg = '0'");
                sb.Append(" AND WorkMonth LIKE'%" + month + "%'");

                sb.Append(" ORDER BY ManagementID");



                IList<IF_ManagementBook> mbs = new List<IF_ManagementBook>();
                DataTable dt = DBAccess.Select(sb.ToString(), cn);
                DateTime dt_temp = DateTime.Parse(DateTime.Now.AddMonths(1).ToString("yyyy/MM"));
                DateTime dt_temp2 = dt_temp.AddMonths(1).AddDays(-1);
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    IF_ManagementBook mb = new IF_ManagementBook();

                    if (dt.Rows[i]["EmployeeID"] != DBNull.Value)
                    {
                        mb.EmployeeID = Convert.ToInt32(dt.Rows[i]["EmployeeID"]);
                    }

                    if (dt.Rows[i]["Salesman1ID"] != DBNull.Value)
                    {
                        mb.Salesman1ID = Convert.ToInt32(dt.Rows[i]["Salesman1ID"]);
                    }
                    if (dt.Rows[i]["Salesman2ID"] != DBNull.Value)
                    {
                        mb.Salesman2ID = Convert.ToInt32(dt.Rows[i]["Salesman2ID"]);
                    }

                    if (dt.Rows[i]["DeptName"] != DBNull.Value)
                        mb.DeptName = dt.Rows[i]["DeptName"].ToString();
                    if (dt.Rows[i]["siireName"] != DBNull.Value)
                        mb.siireName = dt.Rows[i]["siireName"].ToString();
                    if (dt.Rows[i]["siireSales"] != DBNull.Value)
                        mb.siireSales = dt.Rows[i]["siireSales"].ToString();

                    if (dt.Rows[i]["CustomerID"] != DBNull.Value)
                    {
                        mb.CustomerID = Convert.ToInt32(dt.Rows[i]["CustomerID"]);
                    }

                    if (dt.Rows[i]["CustSalesman"] != DBNull.Value)
                        mb.CustSalesman = dt.Rows[i]["CustSalesman"].ToString();
                    if (dt.Rows[i]["ContractName"] != DBNull.Value)
                        mb.ContractName = dt.Rows[i]["ContractName"].ToString();
                    if (dt.Rows[i]["ProjectName"] != DBNull.Value)
                        mb.ProjectName = dt.Rows[i]["ProjectName"].ToString();
                    if (dt.Rows[i]["WorkAddr"] != DBNull.Value)
                        mb.WorkAddr = dt.Rows[i]["WorkAddr"].ToString();
                    if (dt.Rows[i]["WorkMonth"] != DBNull.Value)
                        mb.WorkMonth = nextMonth;

                    mb.StartDate = dt_temp.ToString();
                    mb.EndDate = dt_temp2.ToString();
                    //if (dt.Rows[i]["StartDate"] != DBNull.Value)
                    //    mb.StartDate = dt.Rows[i]["StartDate"].ToString();
                    //if (dt.Rows[i]["EndDate"] != DBNull.Value)
                    //    mb.EndDate = dt.Rows[i]["EndDate"].ToString();
                    if (dt.Rows[i]["Amount"] != DBNull.Value)
                    {
                        mb.Amount = Convert.ToDecimal(dt.Rows[i]["Amount"]);
                    }
                    if (dt.Rows[i]["MinHour"] != DBNull.Value)
                    {
                        mb.MinHour = Convert.ToDecimal(dt.Rows[i]["MinHour"]);
                    }
                    if (dt.Rows[i]["MaxHour"] != DBNull.Value)
                    {
                        mb.MaxHour = Convert.ToDecimal(dt.Rows[i]["MaxHour"]);
                    }
                    if (dt.Rows[i]["MinusUnitPrice"] != DBNull.Value)
                    {
                        mb.MinusUnitPrice = Convert.ToDecimal(dt.Rows[i]["MinusUnitPrice"]);
                    }
                    if (dt.Rows[i]["PlusUnitPrice"] != DBNull.Value)
                    {
                        mb.PlusUnitPrice = Convert.ToDecimal(dt.Rows[i]["PlusUnitPrice"]);
                    }
                    if (dt.Rows[i]["MinHour"] != DBNull.Value)
                    {
                        mb.MinHour = Convert.ToDecimal(dt.Rows[i]["MinHour"]);
                    }
                    if (dt.Rows[i]["Quantity"] != DBNull.Value)
                    {
                        mb.Quantity = Convert.ToDecimal(dt.Rows[i]["Quantity"]);
                    }
                    if (dt.Rows[i]["PaymentType"] != DBNull.Value)
                        mb.PaymentType = dt.Rows[i]["PaymentType"].ToString();
                    if (dt.Rows[i]["PaymentDay"] != DBNull.Value)
                        mb.PaymentDay = dt.Rows[i]["PaymentDay"].ToString();
                    if (dt.Rows[i]["TranExpense"] != DBNull.Value)
                    {
                        object c = dt.Rows[i]["TranExpense"];
                        mb.TranExpense = Convert.ToDecimal(dt.Rows[i]["TranExpense"]);
                    }
                    if (dt.Rows[i]["Price"] != DBNull.Value)
                    {
                        mb.Price = Convert.ToDecimal(dt.Rows[i]["Price"]);
                    }
                    if (dt.Rows[i]["Memo"] != DBNull.Value)
                        mb.Memo = dt.Rows[i]["Memo"].ToString();
                    if (dt.Rows[i]["OrderDate"] != DBNull.Value)
                        mb.OrderDate = dt.Rows[i]["OrderDate"].ToString();
                    if (dt.Rows[i]["OrderNo"] != DBNull.Value)
                        mb.OrderNo = dt.Rows[i]["OrderNo"].ToString();
                    mb.DeleteFlg = "0";
                    if (dt.Rows[i]["UpdateFlg"] != DBNull.Value)
                        mb.UpdateFlg = dt.Rows[i]["UpdateFlg"].ToString();

                    mbs.Add(mb);

                }

                InsertManagementBook(mbs);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// ファジーEmployee取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectfuzzyEmployee(IF_ManagementBook entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT DISTINCT");
                sb.Append(" A.EmployeeID,");//技術者ID
                sb.Append(" B.EmployeeName");//技術者
                sb.Append(" FROM T_Employee B");

                sb.Append(" LEFT JOIN T_ManagementBook A ON A.EmployeeID=B.EmployeeID");

                sb.Append(" WHERE B.DeleteFlg = '0'");

                //ユーザ名
                if (!string.IsNullOrEmpty(entity.EmployeeName))
                {
                    sb.Append(" AND ( B.EmployeeName LIKE @EmployeeName OR B.EmployeeName LIKE @WideEmployeeName ) ");

                    para = new MySqlParameter("@EmployeeName", MySqlDbType.VarChar);
                    para.Value = "%" + Common.CommonHandler.StrConv(entity.EmployeeName, false) + "%";//半角
                    dbParams.Add(para);

                    para = new MySqlParameter("@WideEmployeeName", MySqlDbType.VarChar);
                    para.Value = "%" + Common.CommonHandler.StrConv(entity.EmployeeName, true) + "%";//全角
                    dbParams.Add(para);
                }
                //社員区分
                if (!string.IsNullOrEmpty(entity.EmployeeType))
                {
                    sb.Append(" AND B.EmployeeType= @EmployeeType ");

                    para = new MySqlParameter("@EmployeeType", MySqlDbType.VarChar);
                    para.Value = entity.EmployeeType;
                    dbParams.Add(para);
                }
                //現場
                if (!string.IsNullOrEmpty(entity.WorkAddr))
                {
                    sb.Append(" AND A.WorkAddr=@WorkAddr ");

                    para = new MySqlParameter("@WorkAddr", MySqlDbType.VarChar);
                    para.Value = entity.WorkAddr;
                    dbParams.Add(para);
                }
                //顧客ID
                if (entity.CustomerID > 0)
                {
                    sb.Append(" AND A.CustomerID=@CustomerID ");

                    para = new MySqlParameter("@CustomerID", MySqlDbType.VarChar);
                    para.Value = entity.CustomerID;
                    dbParams.Add(para);
                }
                //稼動月
                if (!string.IsNullOrEmpty(entity.WorkMonth))
                {
                    if (entity.WorkMonth.Length == 5)
                    {
                        sb.Append(" AND A.WorkMonth LIKE @WorkMonth ");

                        para = new MySqlParameter("@WorkMonth", MySqlDbType.VarChar);
                        para.Value = "%" + entity.WorkMonth.Substring(0, 4) + "%";
                        dbParams.Add(para);
                    }
                    else
                    {
                        sb.Append(" AND A.WorkMonth=@WorkMonth ");

                        para = new MySqlParameter("@WorkMonth", MySqlDbType.VarChar);
                        para.Value = entity.WorkMonth;
                        dbParams.Add(para);
                    }
                }
                sb.Append(" ORDER BY A.ManagementID");

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }




        /// <summary>
        /// ファジーCustomere取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectfuzzyCustomer(IF_ManagementBook entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT DISTINCT");
                sb.Append(" CustomerID,");//顧客ID
                sb.Append(" CustomerName");//顧客名
                sb.Append(" FROM T_Customer ");

                sb.Append(" WHERE DeleteFlg = '0'");

                if (!string.IsNullOrEmpty(entity.CustomerName))
                {
                    sb.Append(" AND ( CustomerName LIKE @CustomerName OR CustomerName LIKE @WideCustomerName )");

                    para = new MySqlParameter("@CustomerName", MySqlDbType.VarChar);
                    para.Value = "%" + Common.CommonHandler.StrConv(entity.CustomerName, false) + "%";//半角
                    dbParams.Add(para);

                    para = new MySqlParameter("@WideCustomerName", MySqlDbType.VarChar);
                    para.Value = "%" + Common.CommonHandler.StrConv(entity.CustomerName, true) + "%";//全角
                    dbParams.Add(para);
                }
                sb.Append(" ORDER BY CustomerID");

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int InsertManagementBook(IF_ManagementBook entity)
        {
            return this.InsertManagementBook(new List<IF_ManagementBook>() { entity });
        }


        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int InsertManagementBook(IList<IF_ManagementBook> entities)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                sb.Append("INSERT INTO ");
                sb.Append("T_ManagementBook  ");
                sb.Append("( ");
                //sb.Append("ManagementID,");//管理ID
                sb.Append("EmployeeID,");//社員ID

                sb.Append("Salesman1ID,");//営業担当１ID
                sb.Append("Salesman2ID,");//営業担当２ID

                sb.Append("DeptName,");//所属部門
                //sb.Append("siireName,");//仕入
                //sb.Append("siireSales,");//仕入先担当

                sb.Append("CustomerID,");//顧客ID

                sb.Append("CustSalesman,");//顧客窓口
                sb.Append("ContractName,");//契約件名
                sb.Append("ProjectName,");//作業工程
                sb.Append("WorkAddr,");//現場
                sb.Append("WorkMonth,");//稼働月
                sb.Append("StartDate,");//開始日
                sb.Append("EndDate,");//終了日
                sb.Append("Amount,");//売上
                sb.Append("MinHour,");//稼働下限
                sb.Append("MaxHour,");//稼働上限
                sb.Append("MinusUnitPrice,");//控除単価
                sb.Append("PlusUnitPrice,");//超過単価
                sb.Append("Quantity,");//日割計算
                sb.Append("PaymentType,");//支払方法
                sb.Append("PaymentDay,");//支払日
                sb.Append("TranExpense,");//交通費
                sb.Append("Price,");//単価Unit
                sb.Append("Unit,");//単位
                sb.Append("Memo,");//備考
                sb.Append("OrderDate,");//注文書届日
                sb.Append("OrderNo,");//注文書番号
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(") ");

                sb.Append("VALUES ");
                //sb_backupはsbのバックアップ、繰り返して使用のため
                String sb_backup = sb.ToString();
                //Number_Oneは一回挿入するのデータ数
                //Number_Lastは最後回挿入するのデータ数
                int Number_One = 100, Number_Last = entities.Count % Number_One;
                //rowは挿入するの総データ数
                int row = 0;
                List<MySqlParameter> dbParams = null;
                IF_ManagementBook entity = null;
                for (int Num = 0; Num <= entities.Count / Number_One; Num++)
                {
                    dbParams = new List<MySqlParameter>();
                    sb = new StringBuilder();
                    sb.Append(sb_backup);
                    //最後回以外のループ
                    if (Num <= entities.Count / Number_One -1)
                    {
                        for (int i=0; i < Number_One; i++)
                        {
                            sb.Append("( ");
                            //sb.Append("@ManagementID" + i.ToString() + ",");//管理ID
                            sb.Append("@EmployeeID" + i.ToString() + ",");//社員ID

                            sb.Append("@Salesman1ID" + i.ToString() + ",");//営業担当１ID
                            sb.Append("@Salesman2ID" + i.ToString() + ",");//営業担当２ID

                            sb.Append("@DeptName" + i.ToString() + ",");//所属部門
                            //sb.Append("@siireName,");//仕入
                            //sb.Append("@siireSales,");//仕入先担当

                            sb.Append("@CustomerID" + i.ToString() + ",");//顧客ID

                            sb.Append("@CustSalesman" + i.ToString() + ",");//顧客窓口
                            sb.Append("@ContractName" + i.ToString() + ",");//契約件名
                            sb.Append("@ProjectName" + i.ToString() + ",");//作業工程
                            sb.Append("@WorkAddr" + i.ToString() + ",");//現場
                            sb.Append("@WorkMonth" + i.ToString() + ",");//稼働月
                            sb.Append("@StartDate" + i.ToString() + ",");//開始日
                            sb.Append("@EndDate" + i.ToString() + ",");//終了日
                            sb.Append("@Amount" + i.ToString() + ",");//売上
                            sb.Append("@MinHour" + i.ToString() + ",");//稼働下限
                            sb.Append("@MaxHour" + i.ToString() + ",");//稼働上限
                            sb.Append("@MinusUnitPrice" + i.ToString() + ",");//控除単価
                            sb.Append("@PlusUnitPrice" + i.ToString() + ",");//超過単価
                            sb.Append("@Quantity" + i.ToString() + ",");//日割計算
                            sb.Append("@PaymentType" + i.ToString() + ",");//支払方法
                            sb.Append("@PaymentDay" + i.ToString() + ",");//支払日
                            sb.Append("@TranExpense" + i.ToString() + ",");//交通費
                            sb.Append("@Price" + i.ToString() + ",");//単価
                            sb.Append("@Unit" + i.ToString() + ",");//単位
                            sb.Append("@Memo" + i.ToString() + ",");//備考
                            sb.Append("@OrderDate" + i.ToString() + ",");//注文書届日
                            sb.Append("@OrderNo" + i.ToString() + ",");//注文書番号
                            sb.Append("@DeleteFlg" + i.ToString());//削除フラグ
                            if (i >= Number_One -1)
                            {
                                sb.Append(")");
                            }
                            else
                            {
                                sb.Append("),");
                            }

                            MySqlParameter para = null;
                            entity = entities[row];
                            //para = new MySqlParameter("@ManagementID" + i.ToString(), MySqlDbType.Int32);//管理ID
                            //para.Value = entity.ManagementID;//管理ID
                            //dbParams.Add(para);//追加
                            para = new MySqlParameter("@EmployeeID" + i.ToString(), MySqlDbType.Int32);//社員ID
                            para.Value = entity.EmployeeID;//社員ID
                            dbParams.Add(para);//追加

                            para = new MySqlParameter("@Salesman1ID" + i.ToString(), MySqlDbType.Int32);//営業担当１ID
                            para.Value = entity.Salesman1ID;//営業担当１ID
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Salesman2ID" + i.ToString(), MySqlDbType.Int32);//営業担当２ID
                            para.Value = entity.Salesman2ID;//営業担当２ID
                            dbParams.Add(para);//追加

                            para = new MySqlParameter("@DeptName" + i.ToString(), MySqlDbType.VarChar);//所属部門
                            para.Value = entity.DeptName;//所属部門
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@siireName" + i.ToString(), MySqlDbType.VarChar);//仕入
                            para.Value = entity.siireName;//仕入
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@siireSales" + i.ToString(), MySqlDbType.VarChar);//仕入先担当
                            para.Value = entity.siireSales;//仕入先担当
                            dbParams.Add(para);//追加


                            para = new MySqlParameter("@CustomerID" + i.ToString(), MySqlDbType.Int32);//顧客ID
                            para.Value = entity.CustomerID;//顧客ID
                            dbParams.Add(para);//追加

                            para = new MySqlParameter("@CustSalesman" + i.ToString(), MySqlDbType.VarChar);//顧客窓口
                            para.Value = entity.CustSalesman;//顧客窓口
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@ContractName" + i.ToString(), MySqlDbType.VarChar);//契約件名
                            para.Value = entity.ContractName;//契約件名
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@ProjectName" + i.ToString(), MySqlDbType.VarChar);//作業工程
                            para.Value = entity.ProjectName;//作業工程
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@WorkAddr" + i.ToString(), MySqlDbType.VarChar);//現場
                            para.Value = entity.WorkAddr;//現場
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@WorkMonth" + i.ToString(), MySqlDbType.VarChar);//稼働月
                            para.Value = entity.WorkMonth;//稼働月
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@StartDate" + i.ToString(), MySqlDbType.VarChar);//開始日
                            para.Value = entity.StartDate;//開始日
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@EndDate" + i.ToString(), MySqlDbType.VarChar);//終了日
                            para.Value = entity.EndDate;//終了日
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Amount" + i.ToString(), MySqlDbType.Decimal);//売上
                            para.Value = entity.Amount;//売上
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@MinHour" + i.ToString(), MySqlDbType.Decimal);//稼働下限
                            para.Value = entity.MinHour;//稼働下限
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@MaxHour" + i.ToString(), MySqlDbType.Decimal);//稼働上限
                            para.Value = entity.MaxHour;//稼働上限
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@MinusUnitPrice" + i.ToString(), MySqlDbType.Decimal);//控除単価
                            para.Value = entity.MinusUnitPrice;//控除単価
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@PlusUnitPrice" + i.ToString(), MySqlDbType.Decimal);//超過単価
                            para.Value = entity.PlusUnitPrice;//超過単価
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Quantity" + i.ToString(), MySqlDbType.Decimal);//日割計算
                            para.Value = entity.Quantity;//日割計算
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@PaymentType" + i.ToString(), MySqlDbType.VarChar);//支払方法
                            para.Value = entity.PaymentType;//支払方法
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@PaymentDay" + i.ToString(), MySqlDbType.VarChar);//支払日
                            para.Value = entity.PaymentDay;//支払日
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@TranExpense" + i.ToString(), MySqlDbType.Decimal);//交通費
                            para.Value = entity.TranExpense;//交通費
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Price" + i.ToString(), MySqlDbType.Decimal);//単価
                            para.Value = entity.Price;//単価
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Unit" + i.ToString(), MySqlDbType.VarChar);//単位
                            para.Value = entity.Unit;//単位
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Memo" + i.ToString(), MySqlDbType.VarChar);//備考
                            para.Value = entity.Memo;//備考
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@OrderDate" + i.ToString(), MySqlDbType.VarChar);//注文書届日
                            para.Value = entity.OrderDate;//注文書届日
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@OrderNo" + i.ToString(), MySqlDbType.VarChar);//注文書番号
                            para.Value = entity.OrderNo;//注文書番号
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@DeleteFlg" + i.ToString(), MySqlDbType.VarChar);//削除フラグ
                            para.Value = entity.DeleteFlg;//削除フラグ
                            dbParams.Add(para);//追加

                            row++;
                        }
                        DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);
                    }
                    //最後回のループ
                    else
                    {
                        for (int i=0; i < Number_Last; i++)
                        {
                            sb.Append("( ");
                            //sb.Append("@ManagementID" + i.ToString() + ",");//管理ID
                            sb.Append("@EmployeeID" + i.ToString() + ",");//社員ID

                            sb.Append("@Salesman1ID" + i.ToString() + ",");//営業担当１ID
                            sb.Append("@Salesman2ID" + i.ToString() + ",");//営業担当２ID

                            sb.Append("@DeptName" + i.ToString() + ",");//所属部門
                            //sb.Append("@siireName,");//仕入
                            //sb.Append("@siireSales,");//仕入先担当

                            sb.Append("@CustomerID" + i.ToString() + ",");//顧客ID

                            sb.Append("@CustSalesman" + i.ToString() + ",");//顧客窓口
                            sb.Append("@ContractName" + i.ToString() + ",");//契約件名
                            sb.Append("@ProjectName" + i.ToString() + ",");//作業工程
                            sb.Append("@WorkAddr" + i.ToString() + ",");//現場
                            sb.Append("@WorkMonth" + i.ToString() + ",");//稼働月
                            sb.Append("@StartDate" + i.ToString() + ",");//開始日
                            sb.Append("@EndDate" + i.ToString() + ",");//終了日
                            sb.Append("@Amount" + i.ToString() + ",");//売上
                            sb.Append("@MinHour" + i.ToString() + ",");//稼働下限
                            sb.Append("@MaxHour" + i.ToString() + ",");//稼働上限
                            sb.Append("@MinusUnitPrice" + i.ToString() + ",");//控除単価
                            sb.Append("@PlusUnitPrice" + i.ToString() + ",");//超過単価
                            sb.Append("@Quantity" + i.ToString() + ",");//日割計算
                            sb.Append("@PaymentType" + i.ToString() + ",");//支払方法
                            sb.Append("@PaymentDay" + i.ToString() + ",");//支払日
                            sb.Append("@TranExpense" + i.ToString() + ",");//交通費
                            sb.Append("@Price" + i.ToString() + ",");//単価
                            sb.Append("@Unit" + i.ToString() + ",");//単位
                            sb.Append("@Memo" + i.ToString() + ",");//備考
                            sb.Append("@OrderDate" + i.ToString() + ",");//注文書届日
                            sb.Append("@OrderNo" + i.ToString() + ",");//注文書番号
                            sb.Append("@DeleteFlg" + i.ToString());//削除フラグ
                            if (i >= Number_Last -1)
                            {
                                sb.Append(")");
                            }
                            else
                            {
                                sb.Append("),");
                            }

                            MySqlParameter para = null;
                            entity = entities[row];
                            //para = new MySqlParameter("@ManagementID"+i.ToString(), MySqlDbType.Int32);//管理ID
                            //para.Value = entity.ManagementID;//管理ID
                            //dbParams.Add(para);//追加
                            para = new MySqlParameter("@EmployeeID"+i.ToString(), MySqlDbType.Int32);//社員ID
                            para.Value = entity.EmployeeID;//社員ID
                            dbParams.Add(para);//追加

                            para = new MySqlParameter("@Salesman1ID"+i.ToString(), MySqlDbType.Int32);//営業担当１ID
                            para.Value = entity.Salesman1ID;//営業担当１ID
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Salesman2ID"+i.ToString(), MySqlDbType.Int32);//営業担当２ID
                            para.Value = entity.Salesman2ID;//営業担当２ID
                            dbParams.Add(para);//追加

                            para = new MySqlParameter("@DeptName"+i.ToString(), MySqlDbType.VarChar);//所属部門
                            para.Value = entity.DeptName;//所属部門
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@siireName"+i.ToString(), MySqlDbType.VarChar);//仕入
                            para.Value = entity.siireName;//仕入
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@siireSales"+i.ToString(), MySqlDbType.VarChar);//仕入先担当
                            para.Value = entity.siireSales;//仕入先担当
                            dbParams.Add(para);//追加


                            para = new MySqlParameter("@CustomerID"+i.ToString(), MySqlDbType.Int32);//顧客ID
                            para.Value = entity.CustomerID;//顧客ID
                            dbParams.Add(para);//追加

                            para = new MySqlParameter("@CustSalesman"+i.ToString(), MySqlDbType.VarChar);//顧客窓口
                            para.Value = entity.CustSalesman;//顧客窓口
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@ContractName"+i.ToString(), MySqlDbType.VarChar);//契約件名
                            para.Value = entity.ContractName;//契約件名
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@ProjectName"+i.ToString(), MySqlDbType.VarChar);//作業工程
                            para.Value = entity.ProjectName;//作業工程
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@WorkAddr"+i.ToString(), MySqlDbType.VarChar);//現場
                            para.Value = entity.WorkAddr;//現場
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@WorkMonth"+i.ToString(), MySqlDbType.VarChar);//稼働月
                            para.Value = entity.WorkMonth;//稼働月
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@StartDate"+i.ToString(), MySqlDbType.VarChar);//開始日
                            para.Value = entity.StartDate;//開始日
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@EndDate"+i.ToString(), MySqlDbType.VarChar);//終了日
                            para.Value = entity.EndDate;//終了日
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Amount"+i.ToString(), MySqlDbType.Decimal);//売上
                            para.Value = entity.Amount;//売上
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@MinHour"+i.ToString(), MySqlDbType.Decimal);//稼働下限
                            para.Value = entity.MinHour;//稼働下限
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@MaxHour"+i.ToString(), MySqlDbType.Decimal);//稼働上限
                            para.Value = entity.MaxHour;//稼働上限
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@MinusUnitPrice"+i.ToString(), MySqlDbType.Decimal);//控除単価
                            para.Value = entity.MinusUnitPrice;//控除単価
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@PlusUnitPrice"+i.ToString(), MySqlDbType.Decimal);//超過単価
                            para.Value = entity.PlusUnitPrice;//超過単価
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Quantity"+i.ToString(), MySqlDbType.Decimal);//日割計算
                            para.Value = entity.Quantity;//日割計算
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@PaymentType"+i.ToString(), MySqlDbType.VarChar);//支払方法
                            para.Value = entity.PaymentType;//支払方法
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@PaymentDay"+i.ToString(), MySqlDbType.VarChar);//支払日
                            para.Value = entity.PaymentDay;//支払日
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@TranExpense"+i.ToString(), MySqlDbType.Decimal);//交通費
                            para.Value = entity.TranExpense;//交通費
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Price" + i.ToString(), MySqlDbType.Decimal);//単価
                            para.Value = entity.Price;//単価
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Unit" + i.ToString(), MySqlDbType.VarChar);//単位
                            para.Value = entity.Unit;//単位
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@Memo"+i.ToString(), MySqlDbType.VarChar);//備考
                            para.Value = entity.Memo;//備考
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@OrderDate"+i.ToString(), MySqlDbType.VarChar);//注文書届日
                            para.Value = entity.OrderDate;//注文書届日
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@OrderNo"+i.ToString(), MySqlDbType.VarChar);//注文書番号
                            para.Value = entity.OrderNo;//注文書番号
                            dbParams.Add(para);//追加
                            para = new MySqlParameter("@DeleteFlg"+i.ToString(), MySqlDbType.VarChar);//削除フラグ
                            para.Value = entity.DeleteFlg;//削除フラグ
                            dbParams.Add(para);//追加

                            row++;
                        }
                        DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);
                    }
                }
                tx.Commit();
                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateManagementBook(IF_ManagementBook entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                sb.Append("UPDATE ");
                sb.Append("T_ManagementBook ");
                sb.Append("SET ");

                sb.Append("ManagementID = @ManagementID,");//管理ID
                sb.Append("EmployeeID = @EmployeeID,");//社員ID

                sb.Append("Salesman1ID = @Salesman1ID,");//営業担当１ID
                sb.Append("Salesman2ID = @Salesman2ID,");//営業担当２ID

                sb.Append("DeptName = @DeptName,");//所属部門
                sb.Append("siireName = @siireName,");//仕入
                sb.Append("siireSales = @siireSales,");//仕入先担当

                sb.Append("CustomerID = @CustomerID,");//顧客ID

                sb.Append("CustSalesman = @CustSalesman,");//顧客窓口
                sb.Append("ContractName = @ContractName,");//契約件名
                sb.Append("ProjectName = @ProjectName,");//作業工程
                sb.Append("WorkAddr = @WorkAddr,");//現場
                sb.Append("WorkMonth = @WorkMonth,");//稼働月
                sb.Append("StartDate = @StartDate,");//開始日
                sb.Append("EndDate = @EndDate,");//終了日
                sb.Append("Amount = @Amount,");//売上
                sb.Append("MinHour = @MinHour,");//稼働下限
                sb.Append("MaxHour = @MaxHour,");//稼働上限
                sb.Append("MinusUnitPrice = @MinusUnitPrice,");//控除単価
                sb.Append("PlusUnitPrice = @PlusUnitPrice,");//超過単価
                sb.Append("Quantity = @Quantity,");//日割計算
                sb.Append("PaymentType = @PaymentType,");//支払方法
                sb.Append("PaymentDay = @PaymentDay,");//支払日
                sb.Append("TranExpense = @TranExpense,");//交通費
                sb.Append("Price = @Price,");//単価
                sb.Append("Unit = @Unit,");//単位
                sb.Append("Memo = @Memo,");//備考
                sb.Append("OrderDate = @OrderDate,");//注文書届日
                sb.Append("OrderNo = @OrderNo,");//注文書番号
                sb.Append("DeleteFlg = @DeleteFlg ,");//削除フラグ
                if (entity.DeleteFlg == "1")
                {
                    sb.Append("DeleteTime = @DeleteTime ");//削除時間

                    para = new MySqlParameter("@DeleteTime", MySqlDbType.DateTime);//削除時間
                    para.Value = DateTime.Now;//削除時間
                    dbParams.Add(para);//追加
                }
                else
                {
                    sb.Append("UpdateTime = @UpdateTime ");//更新時間
                    para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                    para.Value = DateTime.Now;//更新時間
                    dbParams.Add(para);//追加
                }

                sb.Append("WHERE ManagementID = @ManagementID");

                para = new MySqlParameter("@ManagementID", MySqlDbType.Int32);//管理ID
                para.Value = entity.ManagementID;//管理ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//社員ID
                para.Value = entity.EmployeeID;//社員ID
                dbParams.Add(para);//追加

                para = new MySqlParameter("@Salesman1ID", MySqlDbType.Int32);//営業担当１ID
                para.Value = entity.Salesman1ID;//営業担当１ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman2ID", MySqlDbType.Int32);//営業担当２ID
                para.Value = entity.Salesman2ID;//営業担当２ID
                dbParams.Add(para);//追加

                para = new MySqlParameter("@DeptName", MySqlDbType.VarChar);//所属部門
                para.Value = entity.DeptName;//所属部門
                dbParams.Add(para);//追加
                para = new MySqlParameter("@siireName", MySqlDbType.VarChar);//仕入
                para.Value = entity.siireName;//仕入
                dbParams.Add(para);//追加
                para = new MySqlParameter("@siireSales", MySqlDbType.VarChar);//仕入先担当
                para.Value = entity.siireSales;//仕入先担当
                dbParams.Add(para);//追加

                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加

                para = new MySqlParameter("@CustSalesman", MySqlDbType.VarChar);//顧客窓口
                para.Value = entity.CustSalesman;//顧客窓口
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractName", MySqlDbType.VarChar);//契約件名
                para.Value = entity.ContractName;//契約件名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ProjectName", MySqlDbType.VarChar);//作業工程
                para.Value = entity.ProjectName;//作業工程
                dbParams.Add(para);//追加
                para = new MySqlParameter("@WorkAddr", MySqlDbType.VarChar);//現場
                para.Value = entity.WorkAddr;//現場
                dbParams.Add(para);//追加
                para = new MySqlParameter("@WorkMonth", MySqlDbType.VarChar);//稼働月
                para.Value = entity.WorkMonth;//稼働月
                dbParams.Add(para);//追加
                para = new MySqlParameter("@StartDate", MySqlDbType.VarChar);//開始日
                para.Value = entity.StartDate;//開始日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EndDate", MySqlDbType.VarChar);//終了日
                para.Value = entity.EndDate;//終了日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Amount", MySqlDbType.Decimal);//売上
                para.Value = entity.Amount;//売上
                dbParams.Add(para);//追加
                para = new MySqlParameter("@MinHour", MySqlDbType.Decimal);//稼働下限
                para.Value = entity.MinHour;//稼働下限
                dbParams.Add(para);//追加
                para = new MySqlParameter("@MaxHour", MySqlDbType.Decimal);//稼働上限
                para.Value = entity.MaxHour;//稼働上限
                dbParams.Add(para);//追加
                para = new MySqlParameter("@MinusUnitPrice", MySqlDbType.Decimal);//控除単価
                para.Value = entity.MinusUnitPrice;//控除単価
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PlusUnitPrice", MySqlDbType.Decimal);//超過単価
                para.Value = entity.PlusUnitPrice;//超過単価
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Quantity", MySqlDbType.Decimal);//日割計算
                para.Value = entity.Quantity;//日割計算
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentType", MySqlDbType.VarChar);//支払方法
                para.Value = entity.PaymentType;//支払方法
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentDay", MySqlDbType.VarChar);//支払日
                para.Value = entity.PaymentDay;//支払日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@TranExpense", MySqlDbType.Decimal);//交通費
                para.Value = entity.TranExpense;//交通費
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Price", MySqlDbType.Decimal);//単価
                para.Value = entity.Price;//単価
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Unit", MySqlDbType.Decimal);//単位
                para.Value = entity.Unit;//単位
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Memo", MySqlDbType.VarChar);//備考
                para.Value = entity.Memo;//備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@OrderDate", MySqlDbType.VarChar);//注文書届日
                para.Value = entity.OrderDate;//注文書届日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@OrderNo", MySqlDbType.VarChar);//注文書番号
                para.Value = entity.OrderNo;//注文書番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int DeleteManagementBook(List<Int32> mIDs)
        {
            if (mIDs.Count < 1) { return 0; }
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                sb.Append("UPDATE ");
                sb.Append("T_ManagementBook  ");
                sb.Append("SET ");
                sb.Append("DeleteFlg = '1', ");//削除フラグ
                sb.Append("DeleteTime = @DeleteTime ");//削除時間
                sb.Append("WHERE ManagementID IN ( -1");

                //ManagementID IN @ManagementID
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@DeleteTime", MySqlDbType.DateTime);//削除時間
                para.Value = DateTime.Now;//削除時間
                dbParams.Add(para);//追加

                foreach (Int32 i in mIDs)
                {
                    string key = "@ManagementID" + i.ToString();
                    sb.Append(" ," + key);

                    para = new MySqlParameter(key, MySqlDbType.Int32);//IDs
                    para.Value = i;//ID
                    dbParams.Add(para);//追加
                }

                sb.Append(" )");


                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }


        /// <summary>
        /// 仮台帳作成済月登録
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateMonth(String month)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;

            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);

                cn.Open();

                tx = cn.BeginTransaction();

                sb.Append("UPDATE ");
                sb.Append("T_CodeMaster  ");
                sb.Append("SET ");
                sb.Append("CodeId = @CodeId, ");
                sb.Append("UpdateTime = @UpdateTime ");//更新時間
                sb.Append("WHERE CodeType = 'CD999'  AND DeleteFlg='0'    ");


                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@CodeId", MySqlDbType.VarChar);//ID
                para.Value = month.Substring(5);//翌月
                dbParams.Add(para);//追加
                para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                para.Value = DateTime.Now;//更新時間
                dbParams.Add(para);//追加
                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }





        /// <summary>
        /// 状態更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateStatus(IF_ContractDetail entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();
            try
            {

                string connectString = DBAccess.ConnectString;

                sb.Append("UPDATE ");
                sb.Append("T_ManagementBook  ");
                sb.Append("SET ");
                sb.Append("ContractID = @ContractID,");//契約ID
                sb.Append("DetailID = @DetailID,");//契約明細ID
                sb.Append("UpdateFlg = @UpdateFlg, ");//契約登録済フラッグ
                sb.Append("UpdateTime = @UpdateTime ");//更新時間
                sb.Append("WHERE ManagementID = @ManagementID");


                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@ManagementID", MySqlDbType.Int32);//ID
                para.Value = entity.ManagementID;//ID
                dbParams.Add(para);//追加

                para = new MySqlParameter("@ContractID", MySqlDbType.Int32);//ID
                para.Value = entity.ContractID;//ContractID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DetailID", MySqlDbType.Int32);//ID
                para.Value = entity.DetailID;//DetailID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@UpdateFlg", MySqlDbType.Int32);//ID
                para.Value = 1;//契約登録済フラッグ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                para.Value = DateTime.Now;//更新時間
                dbParams.Add(para);//追加


                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);



                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {

            }
        }



        /// <summary>
        /// 登録
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void RegisterAll(IF_Contract entity, List<IF_ContractDetail> list)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);

                cn.Open();

                tx = cn.BeginTransaction();

                long id = InsertContract(entity, cn, tx);

                BL_ContractDetail bl = BL_ContractDetail.GetInstance();
                BL_ManagementBook mb = BL_ManagementBook.GetInstance();
                foreach (IF_ContractDetail detail in list)
                {
                    detail.ContractID = Convert.ToInt32(id);
                    bl.InsertContractDetail(detail, cn, tx);
                    mb.UpdateStatus(detail, cn, tx);


                }

                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public long InsertContract(IF_Contract entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {

                sb.Append("INSERT INTO ");
                sb.Append("T_Contract  ");
                sb.Append("( ");
                sb.Append("ContractID,");//契約ID
                sb.Append("ContractNo,");//契約番号
                sb.Append("ContractDate,");//契約日
                sb.Append("CustomerID,");//顧客ID
                sb.Append("OrderNo,");//注文書番号
                sb.Append("EmployType,");//方式
                sb.Append("OrderDate,");//注文日
                sb.Append("ContractName,");//契約件名
                sb.Append("Amount,");//契約金額
                sb.Append("Content,");//内容
                sb.Append("Note,");//備考
                sb.Append("StartDate,");//開始日
                sb.Append("EndDate,");//終了日
                sb.Append("Salesman1,");//営業担当１
                sb.Append("Salesman2,");//営業担当２
                sb.Append("PaymentType,");//支払方法
                sb.Append("PaymentDay,");//支払日
                sb.Append("FinishFlag,");//処理済フラグ
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(") ");

                sb.Append("VALUES ");

                sb.Append("( ");
                sb.Append("@ContractID,");//契約ID
                sb.Append("@ContractNo,");//契約番号
                sb.Append("@ContractDate,");//契約日
                sb.Append("@CustomerID,");//顧客ID
                sb.Append("@OrderNo,");//注文書番号
                sb.Append("@EmployType,");//方式
                sb.Append("@OrderDate,");//注文日
                sb.Append("@ContractName,");//契約件名
                sb.Append("@Amount,");//契約金額
                sb.Append("@Content,");//内容
                sb.Append("@Note,");//備考
                sb.Append("@StartDate,");//開始日
                sb.Append("@EndDate,");//終了日
                sb.Append("@Salesman1,");//営業担当１
                sb.Append("@Salesman2,");//営業担当２
                sb.Append("@PaymentType,");//支払方法
                sb.Append("@PaymentDay,");//支払日
                sb.Append("@FinishFlag,");//処理済フラグ
                sb.Append("@DeleteFlg");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@ContractID", MySqlDbType.Int32);//契約ID
                para.Value = entity.ContractID;//契約ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractNo", MySqlDbType.VarChar);//契約番号
                para.Value = entity.ContractNo;//契約番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractDate", MySqlDbType.VarChar);//契約日
                para.Value = entity.ContractDate;//契約日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@OrderNo", MySqlDbType.VarChar);//注文書番号
                para.Value = entity.OrderNo;//注文書番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployType", MySqlDbType.VarChar);//方式
                para.Value = entity.EmployType;//方式
                dbParams.Add(para);//追加
                para = new MySqlParameter("@OrderDate", MySqlDbType.VarChar);//注文日
                para.Value = entity.OrderDate;//注文日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractName", MySqlDbType.VarChar);//契約件名
                para.Value = entity.ContractName;//契約件名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Amount", MySqlDbType.VarChar);//契約金額
                para.Value = entity.Amount;//契約金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Content", MySqlDbType.VarChar);//内容
                para.Value = entity.Content;//内容
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Note", MySqlDbType.VarChar);//備考
                para.Value = entity.Note;//備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@StartDate", MySqlDbType.VarChar);//開始日
                para.Value = entity.StartDate;//開始日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EndDate", MySqlDbType.VarChar);//終了日
                para.Value = entity.EndDate;//終了日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman1", MySqlDbType.Int32);//営業担当１
                para.Value = entity.Salesman1;//営業担当１
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman2", MySqlDbType.Int32);//営業担当２
                para.Value = entity.Salesman2;//営業担当２
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentType", MySqlDbType.VarChar);//支払方法
                para.Value = entity.PaymentType;//支払方法
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentDay", MySqlDbType.VarChar);//支払日
                para.Value = entity.PaymentDay;//支払日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@FinishFlag", MySqlDbType.VarChar);//処理済フラグ
                para.Value = entity.FinishFlag;//処理済フラグ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加


                long id = DBAccess.ExecuteSQLReturnID(sb.ToString(), dbParams, cn, tx);

                return id;
            }
            catch (Exception ex)
            {
                throw (ex);
            }

        }

    }
}
