﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_Sale
    {
        private static BL_Sale bl = new BL_Sale();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_Sale GetInstance()
        {
            return bl;
        }
        /// <summary>
        /// 売上番号（最大）の取得
        /// </summary>
        /// <returns></returns>
        public string SelectMaxContractNo(string yyMM)
        {
            string Sale_STR = "EB-売上-";
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("MAX(SaleNo) ");//契約番号

                sb.Append(" FROM T_Sale ");
                sb.Append(" WHERE SaleNo LIKE @SaleNo ");


                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@SaleNo", MySqlDbType.VarChar);
                para.Value = Sale_STR + yyMM + "%";
                dbParams.Add(para);

                DataTable dt = DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);

                if (dt.Rows.Count == 0) return Sale_STR + yyMM + "001";

                string SaleNo = Convert.ToString(dt.Rows[0][0]);

                if (string.IsNullOrEmpty(SaleNo)) return Sale_STR + yyMM + "001";

                int no = Convert.ToInt32(SaleNo.Substring(SaleNo.Length - 3));

                string strNo = "000" + (no + 1).ToString();
                strNo = strNo.Substring(strNo.Length - 3);

                return Sale_STR + yyMM + strNo;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 請求書指定（用）
        /// </summary>
        /// <returns></returns>
        public DataTable SelectCustomerHasSale(string yymm, string CustomerID)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("A.CustomerID,");//顧客ID
                sb.Append("A.CustomerName,");//顧客
                sb.Append("A.PostCode,");//郵便番号
                sb.Append("A.Address1,");//住所1
                sb.Append("A.Address2,");//住所2
                sb.Append("A.Tel,");//電話
                sb.Append("CASE D.BillFlag WHEN '0' THEN '0' ELSE '1' END  BillFlag");//請求書発行済フラグ
                sb.Append(" FROM T_Customer A");
                sb.Append(" LEFT JOIN (SELECT CustomerID,BillFlag,Max(SaleID) FROM T_Sale C WHERE C.BillFlag='0' AND C.SaleDate Like @SaleDate GROUP BY CustomerID,BillFlag) D");
                sb.Append(" On A.CustomerID=D.CustomerID");
                sb.Append(" WHERE DeleteFlg = '0'");
                sb.Append(" AND  EXISTS (SELECT B.SaleID FROM T_Sale B WHERE B.CustomerID = A.CustomerID AND B.SaleDate Like @SaleDate)");


                if (!string.IsNullOrEmpty(CustomerID))
                {
                    sb.Append(" AND A.CustomerID = @CustomerID ");
                    para = new MySqlParameter("@CustomerID", MySqlDbType.VarChar);
                    para.Value = CustomerID;
                    dbParams.Add(para);
                }
                sb.Append(" ORDER BY CustomerID");

                para = new MySqlParameter("@SaleDate", MySqlDbType.VarChar);
                para.Value = yymm + "%";
                dbParams.Add(para);

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 請求書指定（一覧）
        /// </summary>
        /// <returns></returns>
        public DataTable SelectSaleForBill(string customerID, string yymm)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("A.SaleID,");//売上ID
                sb.Append("A.SaleNo,");//売上番号
                sb.Append("A.SaleDate,");//売上日
                sb.Append("B.ContractNo,");//契約番号
                sb.Append("B.ContractName,");//契約件名
                sb.Append("B.OrderNo,");//注文書番号
                sb.Append("B.OrderDate,");//注文日
                sb.Append("A.CustomerID,");//顧客ID
                sb.Append("A.ContractID,");//契約ID
                sb.Append("A.StartDate,");//開始日
                sb.Append("A.EndDate,");//終了日
                sb.Append("A.SaleAmount,");//売上金額
                sb.Append("A.PaymentSite,");//支払サイト
                sb.Append("A.BillNo,");//請求書番号
                sb.Append("A.BillFlag ");//請求書発行済フラグ
                sb.Append(" FROM T_Sale A,T_Contract B");
                sb.Append(" WHERE A.DeleteFlg = '0' AND A.CustomerID=" + customerID);
                sb.Append(" AND A.ContractID=B.ContractID AND B.DeleteFlg = '0'");
                sb.Append(" AND A.SaleDate Like '" + yymm + "%'");
                sb.Append(" ORDER BY A.SaleNo ");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 請求書作成（控除一覧）
        /// </summary>
        /// <returns></returns>
        public DataTable SelectSaleAmount(string billno)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("A.DeductionItem,");//控除項目
                sb.Append("A.DeductionCost,");//控除額
                sb.Append("A.DeductionNotes,");//控除備考
                sb.Append("A.AdditionalItem,");//追加項目
                sb.Append("A.AdditionalCost,");//追加額
                sb.Append("A.AdditionalNotes,");//追加備考
                sb.Append("A.DeleteFlg ");//削除フラグ

                sb.Append(" FROM T_Bill A");
                sb.Append(" WHERE A.DeleteFlg = '0' AND A.BillNo=" + billno);

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }


        /// <summary>
        /// 請求書作成（明細一覧）
        /// </summary>
        /// <returns></returns>
        public DataTable SelectSaleForBillDetail(string customerID, string yymm, string saleID)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("B.SaleID,");//売上ID
                sb.Append("B.SaleDetailID,");//売上明細ID
                sb.Append("B.EmployeeID,");//技術者ID
                sb.Append("C.EmployeeName,");//技術者ID
                sb.Append("B.Unit,");//単位
                sb.Append("B.Price,");//単価
                sb.Append("B.WorkTime,");//作業時間
                sb.Append("B.Rate,");//率
                sb.Append("B.MinHour,");//Min勤務
                sb.Append("B.MaxHour,");//Max勤務
                sb.Append("B.MinusUnitPrice,");//減賃金
                sb.Append("B.PlusUnitPrice,");//増賃金
                sb.Append("B.Amount,");//金額
                sb.Append("B.OtherAmount,");//その他
                sb.Append("B.DeleteFlg ");//削除フラグ

                sb.Append(" FROM T_Sale A,T_SaleDetail B");
                sb.Append(" LEFT JOIN T_Employee C ON B.EmployeeID = C.EmployeeID ");
                sb.Append(" WHERE A.DeleteFlg = '0' AND A.CustomerID=" + customerID);
                sb.Append(" AND A.SaleID=B.SaleID AND B.DeleteFlg = '0'");
                sb.Append(" AND A.SaleDate Like '" + yymm + "%'");
                if (saleID.Length > 0)
                {
                    sb.Append(" AND A.SaleID =" + saleID);
                }
                sb.Append(" ORDER BY B.SaleID,B.SaleDetailID ");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 会社情報の取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectSale(string SaleID)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("SaleID,");//売上ID
                sb.Append("SaleNo,");//売上番号
                sb.Append("SaleDate,");//売上日
                sb.Append("CustomerID,");//顧客ID
                sb.Append("ContractID,");//契約ID
                sb.Append("StartDate,");//開始日
                sb.Append("EndDate,");//終了日
                sb.Append("SaleAmount,");//売上金額
                sb.Append("PaymentSite,");//支払サイト
                sb.Append("BillFlag,");//請求書発行済フラグ
                sb.Append("DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Sale ");
                sb.Append(" WHERE DeleteFlg = '0' AND SaleID = " + SaleID);
                sb.Append(" ORDER BY SaleID ");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 登録
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void RegisterAll(IF_Sale entity, List<IF_SaleDetail> list)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                long id = InsertSale(entity, cn, tx);

                BL_SaleDetail bl = BL_SaleDetail.GetInstance();
                foreach (IF_SaleDetail detail in list)
                {
                    detail.SaleID = Convert.ToInt32(id);
                    bl.InsertSaleDetail(detail, cn, tx);
                }

                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void UpdateAll(IF_Sale entity, List<IF_SaleDetail> list)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                UpdateSale(entity, cn, tx);

                DeleteSaleDetail(entity, cn, tx);

                BL_SaleDetail bl = BL_SaleDetail.GetInstance();
                foreach (IF_SaleDetail detail in list)
                {
                    detail.SaleID = entity.SaleID;
                    bl.InsertSaleDetail(detail, cn, tx);
//                    bl.UpdateSaleDetail(detail, cn, tx);  //Up 2014.10.3 By Banagaki
                }

                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void DeleteAll(IF_Sale entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                DeleteSaleDetail(entity, cn, tx);
                DeleteSale(entity, cn, tx);


                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public long InsertSale(IF_Sale entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {
                sb.Append("INSERT INTO ");
                sb.Append("T_Sale  ");
                sb.Append("( ");
                sb.Append("SaleNo,");//売上番号
                sb.Append("SaleDate,");//売上日
                sb.Append("CustomerID,");//顧客ID
                sb.Append("ContractID,");//契約ID
                sb.Append("StartDate,");//開始日
                sb.Append("EndDate,");//終了日
                sb.Append("SaleAmount,");//売上金額
                sb.Append("Content,");//内容
                sb.Append("Note,");//備考
                sb.Append("Salesman1,");//営業担当１
                sb.Append("Salesman2,");//営業担当２
                sb.Append("PaymentSite,");//支払サイト
                sb.Append("BillFlag,");//請求書発行済フラグ
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(") ");

                sb.Append("VALUES ");

                sb.Append("( ");
                sb.Append("@SaleNo,");//売上番号
                sb.Append("@SaleDate,");//売上日
                sb.Append("@CustomerID,");//顧客ID
                sb.Append("@ContractID,");//契約ID
                sb.Append("@StartDate,");//開始日
                sb.Append("@EndDate,");//終了日
                sb.Append("@SaleAmount,");//売上金額
                sb.Append("@Content,");//内容
                sb.Append("@Note,");//備考
                sb.Append("@Salesman1,");//営業担当１
                sb.Append("@Salesman2,");//営業担当２
                sb.Append("@PaymentSite,");//支払サイト
                sb.Append("@BillFlag,");//請求書発行済フラグ
                sb.Append("@DeleteFlg");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@SaleNo", MySqlDbType.VarChar);//売上番号
                para.Value = entity.SaleNo;//売上番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@SaleDate", MySqlDbType.VarChar);//売上日
                para.Value = entity.SaleDate;//売上日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractID", MySqlDbType.Int32);//契約ID
                para.Value = entity.ContractID;//契約ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@StartDate", MySqlDbType.VarChar);//開始日
                para.Value = entity.StartDate;//開始日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EndDate", MySqlDbType.VarChar);//終了日
                para.Value = entity.EndDate;//終了日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@SaleAmount", MySqlDbType.Decimal);//売上金額
                para.Value = entity.SaleAmount;//売上金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Content", MySqlDbType.VarChar);//内容
                para.Value = entity.Content;//内容
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Note", MySqlDbType.VarChar);//備考
                para.Value = entity.Note;//備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman1", MySqlDbType.Int32);//営業担当１
                para.Value = entity.Salesman1;//営業担当１
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman2", MySqlDbType.Int32);//営業担当２
                para.Value = entity.Salesman2;//営業担当２
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentSite", MySqlDbType.VarChar);//支払サイト
                para.Value = entity.PaymentSite;//支払サイト
                dbParams.Add(para);//追加
                para = new MySqlParameter("@BillFlag", MySqlDbType.VarChar);//請求書発行済フラグ
                para.Value = entity.BillFlag;//請求書発行済フラグ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加

                long id = DBAccess.ExecuteSQLReturnID(sb.ToString(), dbParams, cn, tx);

                return id;
            }
            catch (Exception ex)
            {

                throw (ex);
            }
        }


        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateSale(IF_Sale entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                sb.Append("UPDATE ");
                sb.Append("T_Sale  ");
                sb.Append("SET ");
                sb.Append("SaleNo = @SaleNo,");//売上番号
                sb.Append("SaleDate = @SaleDate,");//売上日
                sb.Append("CustomerID = @CustomerID,");//顧客ID
                sb.Append("ContractID = @ContractID,");//契約ID
                sb.Append("StartDate = @StartDate,");//開始日
                sb.Append("EndDate = @EndDate,");//終了日
                sb.Append("SaleAmount = @SaleAmount,");//売上金額
                sb.Append("Content = @Content,");//内容
                sb.Append("Note = @Note,");//備考
                sb.Append("Salesman1 = @Salesman1,");//営業担当１
                sb.Append("Salesman2 = @Salesman2,");//営業担当２
                sb.Append("PaymentSite = @PaymentSite,");//支払サイト
                sb.Append("UpdateTime = @UpdateTime ");//更新時間
                sb.Append(" WHERE SaleID = @SaleID");//会社ID

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@SaleID", MySqlDbType.Int32);//売上ID
                para.Value = entity.SaleID;//売上ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@SaleNo", MySqlDbType.VarChar);//売上番号
                para.Value = entity.SaleNo;//売上番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@SaleDate", MySqlDbType.VarChar);//売上日
                para.Value = entity.SaleDate;//売上日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractID", MySqlDbType.Int32);//契約ID
                para.Value = entity.ContractID;//契約ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@StartDate", MySqlDbType.VarChar);//開始日
                para.Value = entity.StartDate;//開始日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EndDate", MySqlDbType.VarChar);//終了日
                para.Value = entity.EndDate;//終了日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@SaleAmount", MySqlDbType.Decimal);//売上金額
                para.Value = entity.SaleAmount;//売上金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Content", MySqlDbType.VarChar);//内容
                para.Value = entity.Content;//内容
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Note", MySqlDbType.VarChar);//備考
                para.Value = entity.Note;//備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman1", MySqlDbType.Int32);//営業担当１
                para.Value = entity.Salesman1;//営業担当１
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman2", MySqlDbType.Int32);//営業担当２
                para.Value = entity.Salesman2;//営業担当２
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentSite", MySqlDbType.VarChar);//支払サイト
                para.Value = entity.PaymentSite;//支払サイト
                dbParams.Add(para);//追加
                para = new MySqlParameter("@BillFlag", MySqlDbType.VarChar);//請求書発行済フラグ
                para.Value = entity.BillFlag;//請求書発行済フラグ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                para.Value = DateTime.Now;//更新時間
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {

                throw (ex);
            }
        }
        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateSaleForBillStatus(string saleID,string billNo, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {
                sb.Append("UPDATE ");
                sb.Append("T_Sale  ");
                sb.Append("SET ");
                sb.Append("BillFlag = '1',");//売上番号
                sb.Append("BillNo = @BillNo,");//売上番号
                sb.Append("UpdateTime = @UpdateTime ");//更新時間
                sb.Append(" WHERE SaleID = @SaleID");//売上ID


                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@SaleID", MySqlDbType.Int32);//売上ID
                para.Value = Convert.ToInt32(saleID);//売上ID
                dbParams.Add(para);//追加

                para = new MySqlParameter("@BillNo", MySqlDbType.VarChar);//請求ID
                para.Value = billNo;//請求ID
                dbParams.Add(para);//追加

                para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                para.Value = DateTime.Now;//更新時間
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int DeleteSale(IF_Sale entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {
                sb.Append("UPDATE ");
                sb.Append("T_Sale  ");
                sb.Append("SET ");
                sb.Append("DeleteFlg = '1'");//削除フラグ
                sb.Append(" WHERE SaleID = @SaleID");//売上ID


                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@SaleID", MySqlDbType.Int32);//売上ID
                para.Value = entity.SaleID;//売上ID
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int DeleteSaleDetail(IF_Sale entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {

                sb.Append("UPDATE ");
                sb.Append("T_SaleDetail  ");
                sb.Append("SET ");
                sb.Append("DeleteFlg = '1'");//削除フラグ
                sb.Append(" WHERE SaleID = @SaleID");//売上ID

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@SaleID", MySqlDbType.Int32);//売上ID
                para.Value = entity.SaleID;//売上ID
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }

        }
    }
}
