﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;
using EB.Master.entity;

namespace EB.DBAcess
{
    public class BL_Cost
    {
        private static BL_Cost bl = new BL_Cost();

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_Cost GetInstance()
        {
            return bl;
        }

        public DataTable selectAllCost()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                sb.Append(" SELECT EmployeeID,siirePrice,carfare,StartDate,EndDate,StartContractDate,EndContractDate ");
                sb.Append(" FROM T_Cost ");
                sb.Append(" ORDER BY EmployeeID,serial");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        public DataTable selectCostById(int id)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT Serial,SiirePrice,Carfare,StartDate,EndDate,StartContractDate,EndContractDate ");

                sb.Append(" FROM T_Cost ");
                sb.Append(" WHERE EmployeeId = "+id);
                sb.Append(" ORDER BY serial desc");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        public void insertCost(Dictionary<int, List<IF_EmployeeCost>> insertTable)
        {
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                foreach (KeyValuePair<int, List<IF_EmployeeCost>> kvp in insertTable)
                {
                    int employeeid1 = kvp.Key;
                    List<IF_EmployeeCost> list = kvp.Value;
                    deleteCost(cn, tx, employeeid1);
                    for (int i = 0; i < list.Count; i++)
                    {
                        insertCost(cn, tx, employeeid1, i + 1, list[i]);
                    }
                }
                tx.Commit();
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        private int insertCost(MySqlConnection cn, MySqlTransaction tx, int employeeid1, int serial, IF_EmployeeCost entity)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                sb.Append("insert into ");
                sb.Append("t_cost  ");
                sb.Append("( ");
                sb.Append(" EmployeeID, ");
                sb.Append(" Serial, ");
                sb.Append(" siirePrice, ");
                sb.Append(" carfare, ");
                sb.Append(" StartDate, ");
                sb.Append(" EndDate, ");
                sb.Append(" StartContractDate, ");
                sb.Append(" EndContractDate ");
                sb.Append(" ) ");
                sb.Append(" values ");
                sb.Append(" ( ");
                sb.Append(" @EmployeeID, ");
                sb.Append(" @Serial, ");
                sb.Append(" @siirePrice, ");
                sb.Append(" @carfare, ");
                sb.Append(" @StartDate, ");
                sb.Append(" @EndDate, ");
                sb.Append(" @StartContractDate, ");
                sb.Append(" @EndContractDate ");
                sb.Append(" ) ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//社員ID
                para.Value = employeeid1;//社員ID
                dbParams.Add(para);//追加

                para = new MySqlParameter("@Serial", MySqlDbType.Int32);//シリアル
                para.Value = serial;//シリアル
                dbParams.Add(para);//追加

                para = new MySqlParameter("@siirePrice", MySqlDbType.Int32);//仕入原価
                para.Value = entity.siirePrice;//仕入原価
                dbParams.Add(para);//追加

                para = new MySqlParameter("@carfare", MySqlDbType.Int32);//交通費
                para.Value = 20000;//交通費
                dbParams.Add(para);//追加

                para = new MySqlParameter("@StartDate", MySqlDbType.VarChar);//開始日
                para.Value = entity.startDate;//開始日
                dbParams.Add(para);//追加

                para = new MySqlParameter("@EndDate", MySqlDbType.VarChar);//終了日
                para.Value = entity.endDate;//終了日
                dbParams.Add(para);//追加

                para = new MySqlParameter("@StartContractDate", MySqlDbType.VarChar);//契約開始日
                para.Value = entity.startContractDate;//契約開始日
                dbParams.Add(para);//追加

                para = new MySqlParameter("@EndContractDate", MySqlDbType.VarChar);//契約終了日
                para.Value = entity.endContractDate;//契約終了日
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        private int deleteCost(MySqlConnection cn, MySqlTransaction tx, int employeeid1)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                sb.Append("delete from ");
                sb.Append("t_cost  ");
                sb.Append("where ");
                sb.Append("EmployeeID = @EmployeeID");//売上システム社員ID

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//社員ID
                para.Value = employeeid1;//社員ID
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public void insertIDMap(Dictionary<int, string> insertItem)
        {
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                foreach (KeyValuePair<int, string> detail in insertItem)
                {
                    InsertIDMap(cn, tx, detail.Key, detail.Value);
                }
                tx.Commit();
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        private int InsertIDMap(MySqlConnection cn, MySqlTransaction tx, int employeeid1, string employeeid2)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                sb.Append("INSERT INTO ");
                sb.Append("T_IDMap  ");
                sb.Append("( ");
                sb.Append("EmployeeID1,");//売上システム社員ID
                sb.Append("EmployeeID2");//契約システム社員ID
                sb.Append(") ");
                sb.Append("VALUES ");
                sb.Append("( ");
                sb.Append("@EmployeeID1,");//売上システム社員ID
                sb.Append("@EmployeeID2");//契約システム社員ID
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@EmployeeID1", MySqlDbType.Int32);//売上システム社員ID
                para.Value = employeeid1;//売上システム社員ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployeeID2", MySqlDbType.VarChar);//契約システム社員ID
                para.Value = employeeid2;//契約システム社員ID
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        public int DeleteIDMap(int employeeid1)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                sb.Append("delete from ");
                sb.Append("t_idmap ");
                sb.Append("where ");
                sb.Append("EmployeeID1 = @EmployeeID1 ");//削除フラグ
                para = new MySqlParameter("@EmployeeID1", MySqlDbType.Int32);//社員ID
                para.Value = employeeid1;//社員ID
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
