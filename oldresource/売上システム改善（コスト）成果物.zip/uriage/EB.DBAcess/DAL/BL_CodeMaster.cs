﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_CodeMaster
    {
        private static BL_CodeMaster bl = new BL_CodeMaster();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_CodeMaster GetInstance()
        {
            return bl;
        }

        /// <summary>
        /// 全社員取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectCodeMaster(string codeType)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("CodeType ,");//コード区分
                sb.Append("CodeId ,");//コードID
                sb.Append("CodeName ");//コード名称
                sb.Append(" FROM T_CodeMaster ");
                sb.Append(" WHERE DeleteFlg = '0' AND CodeType = '" + codeType + "'");
                sb.Append(" ORDER BY CodeType,CodeId");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
