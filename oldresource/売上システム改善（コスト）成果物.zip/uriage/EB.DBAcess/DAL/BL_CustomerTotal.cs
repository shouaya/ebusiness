﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess.DAL
{
    public class BL_CustomerTotal
    {
        private static BL_CustomerTotal bl = new BL_CustomerTotal();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_CustomerTotal GetInstance()
        {
            return bl;
        }

        // 画面の年選択プルダウンの内容を取得
        public DataTable SelectYears()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append(" DISTINCT LEFT(WorkMonth,4) AS Years"); //契約年
                sb.Append(" FROM T_ManagementBook ");

                sb.Append(" ORDER BY Years");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        // 画面の顧客名選択プルダウンの内容を取得
        public DataTable SelectCustomerName(string strYear)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append(" DISTINCT C.CustomerName"); //顧客名
                sb.Append(" FROM T_ManagementBook AS MB");
                sb.Append(" LEFT JOIN T_Customer AS C ON C.CustomerID = MB.CustomerID");
                sb.Append(" WHERE LEFT(MB.WorkMonth,4) = '" + strYear + "'");
                sb.Append(" ORDER BY C.CustomerName");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 顧客集計　（売上）
        /// </summary>
        /// <param name="strYear"></param>
        /// <param name="strCustomer"></param>
        /// <returns></returns>
        public DataTable SelectForCustomerTotalForm(string strYear, string strCustomer)
        {
            StringBuilder sb_year = new StringBuilder();
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append("  SELECT * FROM (                                                           ");
                sb.Append("      SELECT                                                                ");
                sb.Append("          C.`CustomerName` ,                                                ");
                sb.Append("          TS.`CustomerID` ,                                                 ");
                //sb.Append("          MID(TB.BillDate,6,2) AS  MM,                                      ");//請求日で集計
                sb.Append("          MID(TS.`SaleDate`,6,2) AS  MM,                                    ");//売上日で集計
                sb.Append("          SUM( TSDS.ECOUNT ) AS EmployeeCount ,                             ");
                sb.Append("          SUM( TSDS.DAMOUNT ) AS Amount,                                    ");
                sb.Append("          SUM( TSDS.EPRICE )  AS Cost                                       ");
                sb.Append("      FROM T_Sale AS TS                                                     ");
                //sb.Append("      LEFT JOIN T_Bill AS TB ON TB.BillNo=TS.BillNo                         ");//請求状況
                sb.Append("      LEFT JOIN (                                                           ");
                sb.Append("              SELECT TSD.`SaleID`                                           ");
                sb.Append("                     ,COUNT( TSD.EmployeeID ) AS ECOUNT                     ");
                sb.Append("                     ,SUM( TSD.Amount ) AS DAMOUNT                          ");
                sb.Append("                     ,SUM( E.siirePrice ) AS EPRICE                         ");
                sb.Append("              FROM T_SaleDetail AS TSD                                      ");
                sb.Append("              LEFT JOIN T_Employee AS E ON TSD.`EmployeeID` = E.`EmployeeID`");
                sb.Append("              GROUP BY TSD.`SaleID`                                         ");
                sb.Append("          ) AS TSDS ON TS.`SaleID` = TSDS.`SaleID`                          ");
                sb.Append("      LEFT JOIN                                                             ");
                sb.Append("          T_Customer AS C ON C.CustomerID = TS.`CustomerID`                 ");
                sb.Append("      WHERE TS.DeleteFlg = 0                                                ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                strYear = strYear.Trim();
                if (strYear.Length == 4)
                {
                    sb.Append("        AND LEFT(TS.`SaleDate`,4) = @WorkYear ");  // 画面で年を指定により

                    para = new MySqlParameter("@WorkYear", MySqlDbType.VarChar);
                    para.Value = strYear;
                    dbParams.Add(para);
                }
                strCustomer = strCustomer.Trim();
                if (strCustomer.Length > 0)
                {
                    sb.Append("        AND C.CustomerName = @CustomerName   ");  // 画面で顧客名を指定により

                    para = new MySqlParameter("@CustomerName", MySqlDbType.VarChar);
                    para.Value = strCustomer;
                    dbParams.Add(para);
                }

                sb.Append("      GROUP BY TS.CustomerID,TS.`SaleDate`                                  ");
                sb.Append("      ) AS RES                                                              ");
                sb.Append("  GROUP BY RES.CustomerID, RES.MM                                           ");
                sb.Append("  ORDER BY RES.CustomerID                                                   ");



                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 廃棄（元の集計）
        /// 台帳で集計したデータ
        /// </summary>
        /// <returns></returns>
        // 検索された結果をDBから取得（合計以外明細データ）
        public DataTable SelectManagementBook( string strYear, string strCustomer)
        {
            StringBuilder sb_year = new StringBuilder();
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append("  SELECT ");
                sb.Append("    M.CustomerID,                      ");//顧客ID
                sb.Append("    M.CustomerName,                    ");//顧客名
                sb.Append("    COUNT(M.EmployeeID) AS EmployeeID, ");//社員ID(統計)
                sb.Append("    SUM(M.Amount) AS Amount,           ");//売上(統計)
                sb.Append("    SUM(M.siirePrice) AS Cost,         ");//仕入原価(統計)
                sb.Append("    M.MM");//稼働月
                sb.Append("  FROM (                               ");
                sb.Append("      SELECT                           ");
                sb.Append("        MB.CustomerID,                 ");//顧客ID
                sb.Append("        C.CustomerName,                ");//顧客名
                sb.Append("        E.siirePrice,                  ");//仕入原価
                sb.Append("        MB.EmployeeID,                 ");//社員ID
                sb.Append("        MB.Amount,                     ");//売上
                sb.Append("        MB.Quantity,                   ");//数量
                sb.Append("        RIGHT( MB.WorkMonth, 2 ) AS MM ");//稼働月
                sb.Append("      FROM                             ");
                sb.Append("        T_ManagementBook AS MB         ");
                sb.Append("      LEFT JOIN                        ");
                sb.Append("        T_Customer AS C                ");
                sb.Append("        ON C.CustomerID = MB.CustomerID");
                sb.Append("      LEFT JOIN                        ");
                sb.Append("        T_Employee AS E                ");
                sb.Append("        ON E.EmployeeID = MB.EmployeeID");
                sb.Append("      WHERE MB.DeleteFlg = 0           ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                strYear = strYear.Trim();
                if (strYear.Length == 4)
                {
                    sb.Append("        AND LEFT(MB.WorkMonth,4) = @WorkYear ");  // 画面で年を指定により

                    para = new MySqlParameter("@WorkYear", MySqlDbType.VarChar);
                    para.Value = strYear;
                    dbParams.Add(para);
                }
                strCustomer = strCustomer.Trim();
                if (strCustomer.Length > 0)
                {
                    sb.Append("        AND C.CustomerName = @CustomerName   ");  // 画面で顧客名を指定により

                    para = new MySqlParameter("@CustomerName", MySqlDbType.VarChar);
                    para.Value = strCustomer;
                    dbParams.Add(para);
                }

                sb.Append("  ) AS M                               ");
                sb.Append("  GROUP BY M.CustomerID, M.MM          ");

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }


        // 検索された結果をDBから取得（合計明細データ）

        public DataTable SelectManagementBook_Sum(string strYear)
        {
            StringBuilder sb_year = new StringBuilder();
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append("  SELECT ");
                sb.Append("    COUNT(M.EmployeeID) AS EmployeeID, ");//社員ID(統計)
                sb.Append("    SUM(M.Amount) AS Amount,           ");//売上(統計)
                sb.Append("    SUM(M.siirePrice) AS Cost,         ");//仕入原価(統計)
                sb.Append("    M.MM                               ");//稼働月
                sb.Append("  FROM (                               ");
                sb.Append("      SELECT                           ");
                sb.Append("        MB.CustomerID,                 ");//顧客ID
                sb.Append("        C.CustomerName,                ");//顧客名
                sb.Append("        MB.EmployeeID,                 ");//社員ID
                sb.Append("        MB.Amount,                     ");//売上
                sb.Append("        MB.Quantity,                   ");//数量
                sb.Append("        E.siirePrice,                  ");//仕入原価
                sb.Append("        RIGHT( MB.WorkMonth, 2 ) AS MM ");//稼働月
                sb.Append("      FROM                             ");
                sb.Append("        T_ManagementBook AS MB         ");
                sb.Append("      LEFT JOIN                        ");
                sb.Append("        T_Customer AS C                ");
                sb.Append("        ON C.CustomerID = MB.CustomerID");
                sb.Append("      LEFT JOIN                        ");
                sb.Append("        T_Employee AS E                ");
                sb.Append("        ON E.EmployeeID = MB.EmployeeID");
                sb.Append("      WHERE MB.DeleteFlg = 0           ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                strYear = strYear.Trim();
                if (strYear.Length == 4)
                {
                    sb.Append("        AND LEFT(MB.WorkMonth,4) = @WorkYear ");  // 画面で年を指定により

                    para = new MySqlParameter("@WorkYear", MySqlDbType.VarChar);
                    para.Value = strYear;
                    dbParams.Add(para);
                }

                sb.Append("  ) AS M                               ");
                sb.Append("  GROUP BY  M.MM          ");

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }



    }
}
