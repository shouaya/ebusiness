﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_User
    {
        private static IF_User loginInfo = new IF_User();
        /// <summary>
        /// ログイン情報
        /// </summary>
        /// <returns></returns>
        public static IF_User GetLoginInfo()
        {
            return loginInfo;
        }

        private static BL_User bl = new BL_User();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_User GetInstance()
        {
            return bl;
        }

        /// <summary>
        /// ユーザ情報
        /// </summary>
        /// <returns></returns>
        public Boolean IsHaveUser(string userid,string password)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append(" `UserID` ,");
                sb.Append(" `UserName`, ");
                sb.Append(" `RegistDate`, ");
                sb.Append(" `DeleteFlg` ");

                sb.Append(" FROM `T_User`");
                sb.Append(" WHERE `UserID`= @UserID");
                sb.Append(" AND `Passwrod`= @Passwrod");
                sb.Append(" AND `DeleteFlg`= '0'");


                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@UserID", MySqlDbType.VarChar);
                para.Value = userid;
                dbParams.Add(para);
                para = new MySqlParameter("@Passwrod", MySqlDbType.VarChar);
                para.Value = password;
                dbParams.Add(para);

                DataTable dt = DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);

                loginInfo.InitializeWithDatatable(dt);

                return dt.Rows.Count != 0;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
