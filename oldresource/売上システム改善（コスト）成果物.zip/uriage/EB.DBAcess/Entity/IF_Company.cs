﻿using System;
using System.Collections.Generic;

using System.Data;
using System.Text;

namespace EB.DBAcess
{
    public class IF_Company
    {
        /// <summary>
        /// 初期化
        /// </summary>
        public void InitializeWithDatatable(DataTable dt)
        {
            if (dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];

                this.CompanyID = Convert.ToInt32( dr["CompanyID"]);
                this.CompanyName = dr["CompanyName"].ToString();
                this.PostCode = dr["PostCode"].ToString();
                this.Address = dr["Address"].ToString();
                this.Representor = dr["Representor"].ToString();
                this.Tel = dr["Tel"].ToString();
                this.DeleteFlg = dr["DeleteFlg"].ToString();
            }
        }
        /// <summary>
        /// 会社ID
        /// </summary>
        public int CompanyID
        {
            set;
            get;
        }
        /// <summary>
        /// 会社名称
        /// </summary>
        public string CompanyName
        {
            set;
            get;
        }
        /// <summary>
        /// 郵便番号
        /// </summary>
        public string PostCode
        {
            set;
            get;
        }
        /// <summary>
        /// 住所
        /// </summary>
        public string Address
        {
            set;
            get;
        }
        /// <summary>
        /// 代表者
        /// </summary>
        public string Representor
        {
            set;
            get;
        }
        /// <summary>
        /// 電話番号
        /// </summary>
        public string Tel
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }
    }
}
