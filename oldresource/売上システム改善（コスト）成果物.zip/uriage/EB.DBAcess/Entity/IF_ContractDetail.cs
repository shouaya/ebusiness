﻿using System;
using System.Collections.Generic;

using System.Data;
using System.Text;

namespace EB.DBAcess
{
    public class IF_ContractDetail
    {
        /// <summary>
        /// 契約ID
        /// </summary>
        public int ContractID
        {
            set;
            get;
        }
        /// <summary>
        /// 契約明細ID
        /// </summary>
        public string DetailID
        {
            set;
            get;
        }
        /// <summary>
        /// 開始日
        /// </summary>
        public string StartDate
        {
            set;
            get;
        }
        /// <summary>
        /// 終了日
        /// </summary>
        public string EndDate
        {
            set;
            get;
        }
        /// <summary>
        /// 技術者ID
        /// </summary>
        public int EmployeeID
        {
            set;
            get;
        }
        /// <summary>
        /// 単位
        /// </summary>
        public string Unit
        {
            set;
            get;
        }
        /// <summary>
        /// 単価
        /// </summary>
        public decimal Price
        {
            set;
            get;
        }
        /// <summary>
        /// 数量
        /// </summary>
        public decimal Quantity
        {
            set;
            get;
        }
        /// <summary>
        /// Min勤務
        /// </summary>
        public decimal MinHour
        {
            set;
            get;
        }
        /// <summary>
        /// Max勤務
        /// </summary>
        public decimal MaxHour
        {
            set;
            get;
        }
        /// <summary>
        /// 減賃金
        /// </summary>
        public decimal MinusUnitPrice
        {
            set;
            get;
        }
        /// <summary>
        /// 増賃金
        /// </summary>
        public decimal PlusUnitPrice
        {
            set;
            get;
        }
        /// <summary>
        /// 金額
        /// </summary>
        public decimal Amount
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }
        /// <summary>
        /// 台帳ManagementID
        /// </summary>
        public int ManagementID
        {
            set;
            get;
        }

    }
}
