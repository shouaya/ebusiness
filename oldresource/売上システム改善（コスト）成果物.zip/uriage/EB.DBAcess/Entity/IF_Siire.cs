﻿using System;
using System.Collections.Generic;

using System.Text;

namespace EB.DBAcess
{
    public class IF_Siire
    {
        /// <summary>
        /// 仕入先ID
        /// </summary>
        public int SiireID
        {
            set;
            get;
        }
        /// <summary>
        /// 仕入先名
        /// </summary>
        public string SiireName
        {
            set;
            get;
        }
        /// <summary>
        /// 仕入先担当
        /// </summary>
        public string SiireSales
        {
            set;
            get;
        }
        /// <summary>
        /// 郵便番号
        /// </summary>
        public string PostCode
        {
            set;
            get;
        }
        /// <summary>
        /// 住所１
        /// </summary>
        public string Address1
        {
            set;
            get;
        }
        /// <summary>
        /// 住所２
        /// </summary>
        public string Address2
        {
            set;
            get;
        }
        /// <summary>
        /// 電話
        /// </summary>
        public string Tel
        {
            set;
            get;
        }
        /// <summary>
        /// FAX
        /// </summary>
        public string Fax
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }
    }
}
