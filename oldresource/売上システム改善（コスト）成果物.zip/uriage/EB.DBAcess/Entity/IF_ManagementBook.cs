﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace EB.DBAcess
{
    public class IF_ManagementBook
    {
        /// <summary>
        /// 管理ID
        /// </summary>
        public int ManagementID
        {
            set;
            get;
        }
        /// <summary>
        /// 社員ID
        /// </summary>
        public int EmployeeID
        {
            set;
            get;
        }
        /// <summary>
        /// 社員氏名
        /// </summary>
        public string EmployeeName
        {
            set;
            get;
        }
        /// <summary>
        /// 営業担当１ID
        /// </summary>
        public int Salesman1ID
        {
            set;
            get;
        }
        /// <summary>
        /// 営業担当２ID
        /// </summary>
        public int Salesman2ID
        {
            set;
            get;
        }
        /// <summary>
        /// 営業担当１氏名
        /// </summary>
        public string Salesman1Name
        {
            set;
            get;
        }
        /// <summary>
        /// 営業担当２氏名
        /// </summary>
        public string Salesman2Name
        {
            set;
            get;
        }
        /// <summary>
        /// 所属部門
        /// </summary>
        public string DeptName
        {
            set;
            get;
        }
        /// <summary>
        /// 仕入
        /// </summary>
        public string siireName
        {
            set;
            get;
        }
        /// <summary>
        /// 仕入先担当
        /// </summary>
        public string siireSales
        {
            set;
            get;
        }
        /// <summary>
        /// 社員区分
        /// </summary>
        public string EmployeeType
        {
            set;
            get;
        }
        /// <summary>
        /// 社員区分名
        /// </summary>
        public string EmployeeTypeName
        {
            set;
            get;
        }
        /// <summary>
        /// 顧客ID
        /// </summary>
        public int CustomerID
        {
            set;
            get;
        }
        /// <summary>
        /// 顧客名
        /// </summary>
        public string CustomerName
        {
            set;
            get;
        }
        /// <summary>
        /// 顧客窓口
        /// </summary>
        public string CustSalesman
        {
            set;
            get;
        }
        /// <summary>
        /// 契約件名
        /// </summary>
        public string ContractName
        {
            set;
            get;
        }
        /// <summary>
        /// 作業工程
        /// </summary>
        public string ProjectName
        {
            set;
            get;
        }
        /// <summary>
        /// 現場
        /// </summary>
        public string WorkAddr
        {
            set;
            get;
        }
        /// <summary>
        /// 稼働月
        /// </summary>
        public string WorkMonth
        {
            set;
            get;
        }
        /// <summary>
        /// 稼働月-end
        /// </summary>
        public string WorkMonthEnd
        {
            set;
            get;
        }
        /// <summary>
        /// 開始日
        /// </summary>
        public string StartDate
        {
            set;
            get;
        }
        /// <summary>
        /// 終了日
        /// </summary>
        public string EndDate
        {
            set;
            get;

        }
        /// <summary>
        /// 売上
        /// </summary>
        public decimal Amount
        {
            set;
            get;
        }
        /// <summary>
        /// 稼働下限
        /// </summary>
        public decimal MinHour
        {
            set;
            get;
        }
        /// <summary>
        /// 稼働上限
        /// </summary>
        public decimal MaxHour
        {
            set;
            get;
        }
        /// <summary>
        /// 控除単価
        /// </summary>
        public decimal MinusUnitPrice
        {
            set;
            get;
        }
        /// <summary>
        /// 超過単価
        /// </summary>
        public decimal PlusUnitPrice
        {
            set;
            get;
        }
        /// <summary>
        /// 日割計算
        /// </summary>
        public decimal Quantity
        {
            set;
            get;
        }
        /// <summary>
        /// 支払方法
        /// </summary>
        public string PaymentType
        {
            set;
            get;
        }
        /// <summary>
        /// 支払日
        /// </summary>
        public string PaymentDay
        {
            set;
            get;
        }
        /// <summary>
        /// 支払サイト
        /// </summary>
        public string PaymentSet
        {
            set;
            get;
        }
        /// <summary>
        /// 交通費
        /// </summary>
        public decimal TranExpense
        {
            set;
            get;
        }
        /// <summary>
        /// 原価開始期間
        /// </summary>
        public decimal CostStartDate
        {
            set;
            get;
        }
        /// <summary>
        /// 原価終了期間
        /// </summary>
        public decimal CostEndDate
        {
            set;
            get;
        }
        /// <summary>
        /// 仕入原価
        /// </summary>
        public decimal Price
        {
            set;
            get;
        }
        /// <summary>
        /// 備考
        /// </summary>
        public string Memo
        {
            set;
            get;
        }
        /// <summary>
        /// 注文書届日
        /// </summary>
        public string OrderDate
        {
            set;
            get;
        }
        /// <summary>
        /// 注文書番号
        /// </summary>
        public string OrderNo
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }
        /// <summary>
        /// 契約登録済フラッグ
        /// </summary>
        public string UpdateFlg
        {
            set;
            get;
        }
        /// <summary>
        /// 
        /// </summary>
        public int ContractID
        {
            set;
            get;
        }
        /// <summary>
        /// 
        /// </summary>
        public int DetailID
        {
            set;
            get;
        }
        /// <summary>
        /// 単位
        /// </summary>
        public string Unit
        {
            set;
            get;
        }

    }
}

