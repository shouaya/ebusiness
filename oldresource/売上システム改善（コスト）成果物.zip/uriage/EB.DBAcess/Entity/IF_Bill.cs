﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EB.DBAcess
{
    public class IF_Bill
    {
        /// <summary>
        /// 請求書番号
        /// </summary>
        public string BillNo
        {
            set;
            get;
        }
        /// <summary>
        /// 振込み口座ID
        /// </summary>
        public string BankInfoId
        {
            set;
            get;
        }
        /// <summary>
        /// 顧客ID
        /// </summary>
        public int CustomerID
        {
            set;
            get;
        }
        /// <summary>
        /// 請求総金額
        /// </summary>
        public decimal BillAmountTotal
        {
            set;
            get;
        }
        /// <summary>
        /// 請求日
        /// </summary>
        public string BillDate
        {
            set;
            get;
        }
        /// <summary>
        /// 控除項目
        /// </summary>
        public string DeductionItem
        {
            set;
            get;
        }
        /// <summary>
        /// 控除額
        /// </summary>
        public decimal DeductionCost
        {
            set;
            get;
        }
        /// <summary>
        /// 控除備考
        /// </summary>
        public string DeductionNotes
        {
            set;
            get;
        }
        /// <summary>
        /// 追加項目
        /// </summary>
        public string AdditionalItem
        {
            set;
            get;
        }
        /// <summary>
        /// 追加額
        /// </summary>
        public decimal AdditionalCost
        {
            set;
            get;
        }
        /// <summary>
        /// 追加備考
        /// </summary>
        public string AdditionalNotes
        {
            set;
            get;
        }
        /// <summary>
        /// 入金番号
        /// </summary>
        public int ReceiptID
        {
            set;
            get;
        }
        /// <summary>
        /// 入金額
        /// </summary>
        public decimal ReceiptAmount
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }

    }
}
