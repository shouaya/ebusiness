﻿using System;
using System.Collections.Generic;

using System.Text;

namespace EB.DBAcess
{
    public class IF_Sale
    {
        /// <summary>
        /// 売上ID
        /// </summary>
        public int SaleID
        {
            set;
            get;
        }
        /// <summary>
        /// 売上番号
        /// </summary>
        public string SaleNo
        {
            set;
            get;
        }
        /// <summary>
        /// 売上日
        /// </summary>
        public string SaleDate
        {
            set;
            get;
        }
        /// <summary>
        /// 顧客ID
        /// </summary>
        public int CustomerID
        {
            set;
            get;
        }
        /// <summary>
        /// 契約ID
        /// </summary>
        public int ContractID
        {
            set;
            get;
        }
        /// <summary>
        /// 開始日
        /// </summary>
        public string StartDate
        {
            set;
            get;
        }
        /// <summary>
        /// 終了日
        /// </summary>
        public string EndDate
        {
            set;
            get;
        }
        /// <summary>
        /// 売上金額
        /// </summary>
        public decimal SaleAmount
        {
            set;
            get;
        }
        /// <summary>
        /// 内容
        /// </summary>
        public string Content
        {
            set;
            get;
        }
        /// <summary>
        /// 備考
        /// </summary>
        public string Note
        {
            set;
            get;
        }
        /// <summary>
        /// 営業担当１
        /// </summary>
        public int Salesman1
        {
            set;
            get;
        }
        /// <summary>
        /// 営業担当２
        /// </summary>
        public int Salesman2
        {
            set;
            get;
        }
        /// <summary>
        /// 支払サイト
        /// </summary>
        public string PaymentSite
        {
            set;
            get;
        }
        /// <summary>
        /// 請求書発行済フラグ
        /// </summary>
        public string BillFlag
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }

    }
}
