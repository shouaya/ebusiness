﻿using System;
using System.Collections.Generic;

using System.Text;

namespace EB.DBAcess
{
    public class IF_Contract
    {
        /// <summary>
        /// 契約ID
        /// </summary>
        public int ContractID
        {
            set;
            get;
        }
        /// <summary>
        /// 契約番号
        /// </summary>
        public string ContractNo
        {
            set;
            get;
        }
        /// <summary>
        /// 契約日
        /// </summary>
        public string ContractDate
        {
            set;
            get;
        }
        /// <summary>
        /// 顧客ID
        /// </summary>
        public int CustomerID
        {
            set;
            get;
        }
        /// <summary>
        /// 注文書番号
        /// </summary>
        public string OrderNo
        {
            set;
            get;
        }
        /// <summary>
        /// 方式
        /// </summary>
        public string EmployType
        {
            set;
            get;
        }
        /// <summary>
        /// 注文日
        /// </summary>
        public string OrderDate
        {
            set;
            get;
        }
        /// <summary>
        /// 契約件名
        /// </summary>
        public string ContractName
        {
            set;
            get;
        }
        /// <summary>
        /// 契約金額
        /// </summary>
        public string Amount
        {
            set;
            get;
        }
        /// <summary>
        /// 内容
        /// </summary>
        public string Content
        {
            set;
            get;
        }
        /// <summary>
        /// 備考
        /// </summary>
        public string Note
        {
            set;
            get;
        }
        /// <summary>
        /// 開始日
        /// </summary>
        public string StartDate
        {
            set;
            get;
        }
        /// <summary>
        /// 終了日
        /// </summary>
        public string EndDate
        {
            set;
            get;
        }
        /// <summary>
        /// 営業担当１
        /// </summary>
        public int Salesman1
        {
            set;
            get;
        }
        /// <summary>
        /// 営業担当２
        /// </summary>
        public int Salesman2
        {
            set;
            get;
        }
        /// <summary>
        /// 支払方法
        /// </summary>
        public string PaymentType
        {
            set;
            get;
        }
        /// <summary>
        /// 支払日
        /// </summary>
        public string PaymentDay
        {
            set;
            get;
        }
        /// <summary>
        /// 処理済フラグ
        /// </summary>
        public string FinishFlag
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }



    }
}
