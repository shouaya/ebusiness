﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace EB.DBAcess
{
    public class IF_User
    {
        /// <summary>
        /// 初期化
        /// </summary>
        public void InitializeWithDatatable(DataTable dt)
        {
            if (dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];

                this.UserID = dr["UserID"].ToString();
                //this.Passwrod = dr["Passwrod"].ToString();
                this.UserName = dr["UserName"].ToString();
                this.RegistDate = dr["RegistDate"].ToString();
                this.DeleteFlg = dr["DeleteFlg"].ToString();
            }
        }
        /// <summary>
        /// ユーザーID
        /// </summary>
        public string UserID
        {
            set;
            get;
        }
        /// <summary>
        /// パスワード
        /// </summary>
        public string Passwrod
        {
            set;
            get;
        }
        /// <summary>
        /// ユーザー名
        /// </summary>
        public string UserName
        {
            set;
            get;
        }
        /// <summary>
        /// 登録日
        /// </summary>
        public string RegistDate
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }

    }
}

