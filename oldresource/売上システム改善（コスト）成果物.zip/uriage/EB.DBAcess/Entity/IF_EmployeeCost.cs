﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EB.Master.entity
{
    public class IF_EmployeeCost
    {
        /// <summary>
        /// 売上社員ID
        /// </summary>
        public int EmployeeID1
        {
            set;
            get;
        }
        /// <summary>
        /// 契約社員ID
        /// </summary>
        public string EmployeeID2
        {
            set;
            get;
        }
        /// <summary>
        /// 社員名
        /// </summary>
        public string EmployeeName
        {
            set;
            get;
        }
        /// <summary>
        /// 社員タイプ
        /// </summary>
        public string EmployeeType
        {
            set;
            get;
        }
        /// <summary>
        /// 社員タイプ
        /// </summary>
        public string kubun
        {
            set;
            get;
        }
        /// <summary>
        /// 仕入原価
        /// </summary>
        public string siirePrice
        {
            set;
            get;
        }
        /// <summary>
        /// 契約開始時間
        /// </summary>
        public string startContractDate
        {
            set;
            get;
        }
        /// <summary>
        /// 契約終了時間
        /// </summary>
        public string endContractDate
        {
            set;
            get;
        }
        /// <summary>
        /// 仕入原価適用開始時間
        /// </summary>
        public string startDate
        {
            set;
            get;
        }
        /// <summary>
        /// 仕入原価適用終了時間
        /// </summary>
        public string endDate
        {
            set;
            get;
        }
    }
}
