﻿using System;
using System.Collections.Generic;

using System.Text;

namespace EB.DBAcess
{
    public class IF_Receipt
    {
        /// <summary>
        /// 入金番号
        /// </summary>
        public int ReceiptID
        {
            set;
            get;
        }
        /// <summary>
        /// 顧客ID
        /// </summary>
        public int CustomerID
        {
            set;
            get;
        }
        /// <summary>
        /// 入金額
        /// </summary>
        public decimal ReceiptAmount
        {
            set;
            get;
        }
        /// <summary>
        /// 入金日
        /// </summary>
        public string ReceiptDate
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }

    }
}
