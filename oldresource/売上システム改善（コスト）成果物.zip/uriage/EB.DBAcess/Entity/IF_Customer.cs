﻿using System;
using System.Collections.Generic;

using System.Text;

namespace EB.DBAcess
{
    public class IF_Customer
    {
        /// <summary>
        /// 顧客ID
        /// </summary>
        public int CustomerID
        {
            set;
            get;
        }
        /// <summary>
        /// 顧客名
        /// </summary>
        public string CustomerName
        {
            set;
            get;
        }
        /// <summary>
        /// フリカナ
        /// </summary>
        public string JapaneseSpell
        {
            set;
            get;
        }
        /// <summary>
        /// 代表者名
        /// </summary>
        public string Representor
        {
            set;
            get;
        }
        /// <summary>
        /// 設立年月日
        /// </summary>
        public string FoundDate
        {
            set;
            get;
        }
        /// <summary>
        /// 資本金
        /// </summary>
        public string Capital
        {
            set;
            get;
        }
        /// <summary>
        /// 従業員数
        /// </summary>
        public string EmployeeCount
        {
            set;
            get;
        }
        /// <summary>
        /// 売上高
        /// </summary>
        public string SaleAmount
        {
            set;
            get;
        }
        /// <summary>
        /// 郵便番号
        /// </summary>
        public string PostCode
        {
            set;
            get;
        }
        /// <summary>
        /// 住所１
        /// </summary>
        public string Address1
        {
            set;
            get;
        }
        /// <summary>
        /// 住所２
        /// </summary>
        public string Address2
        {
            set;
            get;
        }
        /// <summary>
        /// 電話番号
        /// </summary>
        public string Tel
        {
            set;
            get;
        }
        /// <summary>
        /// ファックス
        /// </summary>
        public string Fax
        {
            set;
            get;
        }
        /// <summary>
        /// 担当者
        /// </summary>
        public string Undertaker
        {
            set;
            get;
        }
        /// <summary>
        /// 担当MAIL
        /// </summary>
        public string UndertakerMail
        {
            set;
            get;
        }
        /// <summary>
        /// 評価
        /// </summary>
        public string Remark
        {
            set;
            get;
        }
        /// <summary>
        /// 備考
        /// </summary>
        public string Note
        {
            set;
            get;
        }
        /// <summary>
        /// 支払方法
        /// </summary>
        public string PaymentType
        {
            set;
            get;
        }
        /// <summary>
        /// 支払日
        /// </summary>
        public string PaymentDay
        {
            set;
            get;
        }
        /// <summary>
        /// 並び順
        /// </summary>
        public string DataOrder
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }

    }
}
