﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EB.Common;
using EB.Master.entity;
using System.Globalization;

namespace EB.Master
{
    public partial class CostSelectForm : DialogForm
    {
        public IF_EmployeeCost pre;
        public IF_EmployeeCost employee;
        public IF_EmployeeCost next;
        public int ret = 0;

        public CostSelectForm()
        {
            InitializeComponent();
        }

        private void CostSelect_Load(object sender, EventArgs e)
        {

            this.btnClose.Visible = false;
            this.lblMsg.Text = employee.startContractDate.Substring(0, 7)
                          + "の契約を選択してください。";
            this.lblName.Text = employee.EmployeeName;
            this.preSiire.Text = pre.siirePrice;
            this.preStart.Text = pre.startContractDate;
            this.preEnd.Text = pre.endContractDate;
            this.empSiire.Text = employee.siirePrice;
            this.empStart.Text = employee.startContractDate;
            this.empEnd.Text = employee.endContractDate;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (!radioButton1.Checked && !radioButton2.Checked)
            {
                MessageBox.Show("契約を選択してください。");
                return;
            }
            if (radioButton1.Checked)
            {
                pre.endDate = DateTime.Parse(pre.endContractDate.Substring(0, 7)).AddMonths(1).AddDays(-1).ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo);
                employee.startDate = DateTime.Parse(employee.startContractDate.Substring(0, 7)).AddMonths(1).ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo);
            }
            if (radioButton2.Checked)
            {
                pre.endDate = DateTime.Parse(pre.endContractDate.Substring(0, 7)).AddDays(-1).ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo);
                employee.startDate = DateTime.Parse(employee.startContractDate.Substring(0, 7)).ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo);
            }
            this.Close();
        }

        private void btnCancle_Click(object sender, EventArgs e)
        {
            if(DialogResult.OK.Equals(MessageBox.Show("コスト更新をキャンセルします\r\nよろしいですか？", "", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)))
            {
                ret = -1;
                this.Close();
            }
        }
    }
}
