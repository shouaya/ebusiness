﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;

namespace EB.Master
{
    public partial class EmployeeModifyForm : DialogForm
    {
        public delegate void CallBackDelegate(IF_Employee ie);
        private CallBackDelegate _cbd;

        private IF_Employee _entity = new IF_Employee();
        private BL_Employee _bl = BL_Employee.GetInstance();

        #region 初期化
        public EmployeeModifyForm(int employeeID, CallBackDelegate cbd)
        {
            InitializeComponent();

            this._cbd = cbd;
            this._entity.EmployeeID = employeeID;

            bool isHaveId = this._entity.EmployeeID > 0;
            this.txtEmployeeID.Visible = isHaveId;
            this.label15.Visible = isHaveId;
            this.txtEmployeeName.ReadOnly = isHaveId;
            this.btnUpdate.Text = isHaveId ? "修正" : "登録";
            this.Text = isHaveId ? "社員修正／削除" : "登録";
            this.btnDelete.Visible = isHaveId;
        }

        /// <summary>
        /// 画面初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EmployeeModifyForm_Load(object sender, EventArgs e)
        {
            try
            {
                //Commbox DataSourceを指定
                bindCommbox();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// Commbox DataSourceを指定
        /// </summary>
        private void bindCommbox()
        {
            BL_CodeMaster bl = BL_CodeMaster.GetInstance();

            cobEmployeeType.DataSource = bl.SelectCodeMaster("CD001");//社員区分

            cobCompany.DataSource = bl.SelectCodeMaster("00002");//勤務先

            this.cobSiireName.DataSource = getSiire();//仕入先

            if (this._entity.EmployeeID > 0)
            {
                DataRow dr = this._bl.SelectEmployeeByID(this._entity.EmployeeID);
                txtEmployeeID.Text = dr["EmployeeID"].ToString();//社員ID
                txtEmployeeName.Text = dr["EmployeeName"].ToString();//社員名
                txtJapaneseSpell.Text = dr["JapaneseSpell"].ToString();//フリカナ
                txtBirthday.Text = dr["Birthday"].ToString();//生年月日
                txtExperience.Text = dr["Experience"].ToString();//経験年数
                txtDegree.Text = dr["Degree"].ToString();//学歴
                txtCertificate.Text = dr["Certificate"].ToString();//資格
                cobSiireName.Text = dr["CustomerName"].ToString();//仕入先
                txtsiireSales.Text = dr["siireSales"].ToString();//仕入先担当
                //txtCarfare.Text = dr["carfare"].ToString();//交通費
                //string stxt = dr["siirePrice"].ToString();//仕入先単価

                //if (!stxt.Equals(""))
                //{
                //    long longPrice = long.Parse(stxt);
                //    //txtPrice.Text = longPrice.ToString("#,0");
                //}
                //else
                //{
                //    //txtPrice.Text = stxt;
                //}

                string skill = dr["Skill"].ToString();//技術
                if (skill == "0") rdoSkill0.Checked = true;
                if (skill == "1") rdoSkill1.Checked = true;
                if (skill == "2") rdoSkill2.Checked = true;

                txtLanguage.Text = dr["Language"].ToString();//言語
                txtPostCode.Text = dr["PostCode"].ToString();//郵便番号
                txtAddress1.Text = dr["Address1"].ToString();//住所１
                txtAddress2.Text = dr["Address2"].ToString();//住所２
                txtTel.Text = dr["Tel"].ToString();//TEL
                cobCompany.Text = dr["Company"].ToString();//勤務先
                txtRemark.Text = dr["Remark"].ToString();//評価
                txtNote.Text = dr["Note"].ToString();//備考
                cobEmployeeType.SelectedValue = dr["EmployeeType"].ToString();//社員区分
                DataTable dt = EB.DBAcess.BL_Cost.GetInstance().selectCostById(this._entity.EmployeeID);
                dgvSiirePrice.DataSource = dt;
                if (dt.Rows.Count != 0)
                {
                    _entity.SiirePrice = dt.Rows[0]["SiirePrice"].ToString();
                    _entity.carfare = dt.Rows[0]["Carfare"].ToString();
                }
            }
       
        }


        /// <summary>
        /// 仕入先Combobox用のDataSourceを取得
        /// </summary>
        /// <returns></returns>
        private DataTable getSiire()
        {
            DataTable dt = this._bl.SelectSiire();
            DataRow dr = dt.NewRow();
            dr["CustomerName"] = "";
            dr["CustomerID"] = -1;

            dt.Rows.InsertAt(dr, 0);

            return dt;
        }


        #endregion

        #region 画面動作
        /// <summary>
        /// 修正
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (!isValidCheck()) return;

                this._entity.EmployeeName = txtEmployeeName.Text;//社員名
                this._entity.JapaneseSpell = txtJapaneseSpell.Text;//フリカナ
                this._entity.Birthday = txtBirthday.Text;//生年月日
                this._entity.Experience = txtExperience.Text;//経験年数
                this._entity.Degree = txtDegree.Text;//学歴
                this._entity.Certificate = txtCertificate.Text;//資格
                this._entity.EmployeeType = CommonHandler.ToString(cobEmployeeType.SelectedValue);//社員区分

                if (rdoSkill0.Checked) this._entity.Skill = "0";//技術
                if (rdoSkill0.Checked) this._entity.Skill = "1";//技術
                if (rdoSkill1.Checked) this._entity.Skill = "2";//技術

                this._entity.Language = txtLanguage.Text;//言語
                this._entity.PostCode = txtPostCode.Text;//郵便番号
                this._entity.Address1 = txtAddress1.Text;//住所１
                this._entity.Address2 = txtAddress2.Text;//住所２
                this._entity.Tel = txtTel.Text;//TEL
                this._entity.Company = cobCompany.Text;//勤務先
                this._entity.Remark = txtRemark.Text;//評価
                this._entity.Note = txtNote.Text;//備考
                this._entity.SiireID = CommonHandler.ToString(cobSiireName.SelectedValue);//仕入先ID
                //this._entity.SiirePrice = txtPrice.Text.ToString().Replace(",", "");//仕入原価
                this._entity.SiireSales = txtsiireSales.Text;//仕入先担当
                //this._entity.carfare = this.txtCarfare.Text.ToString().Replace(",", ""); ;
                this._entity.DeleteFlg = "0";

                //登録処理
                ThreadPoolHelper.StartThread(this,
                    () =>
                    {
                        if (this._entity.EmployeeID > 0)
                        {
                            DataTable dt = (DataTable)dgvSiirePrice.DataSource;
                            int rtn = this._bl.UpdateEmployee(this._entity,dt);
                            if (dt != null && dt.Rows.Count != 0)
                            {
                                _entity.SiirePrice = dt.Rows[0]["SiirePrice"].ToString();
                                _entity.carfare = dt.Rows[0]["Carfare"].ToString();
                            }
                            return rtn;
                        }
                        else
                        {
                            return this._bl.InsertEmployee(this._entity);
                        }
                    },
                    (obj) =>
                    {
                        this._cbd(this._entity);

                        MessageHelper.ShowinforMessageByID(this._entity.EmployeeID > 0 ? "EB1003" : "EB1001");//更新成功しました。
                        this.Close();
                    });
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheck()
        {
            if (string.IsNullOrEmpty(txtEmployeeName.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0002", "社員");
                return false;
            }
            if (cobEmployeeType.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0010", "社員区分");
                return false;
            }
            //if (string.IsNullOrEmpty(txtJapaneseSpell.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "ﾌﾘｶﾞﾅ");
            //    return false;
            //}

            ////郵便番号のチェック
            //if (!CommonHandler.CheckPostCode(this.txtPostCode.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0002", "郵便番号");
            //    return false;
            //}
            ////電話番号のチェック
            //if (!CommonHandler.CheckTel(this.txtTel.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0002", "電話番号");
            //    return false;
            //}
            if (this._entity.EmployeeID == 0)
            {
                string name = CommonHandler.ToString(txtEmployeeName.Text);
                if (BL_Employee.GetInstance().SelectExsitsEmployee(name))
                {
                    MessageHelper.ShowinforMessageByID("EB0005", "社員名");
                    return false;
                }
            }
            return true;
        }
        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (string.IsNullOrEmpty(txtEmployeeID.Text))
                {
                    return;
                }
                if (MessageHelper.ShowDeleteConfirmMessage() != DialogResult.Yes)
                {
                    return;
                }
                //削除処理
                this._entity.DeleteFlg = "1";
                ThreadPoolHelper.StartThread(this,
                    () =>
                    {
                        return this._bl.DeleteEmployee(this._entity);
                    }, (obj) =>
                    {
                        this._cbd(this._entity);
                        MessageHelper.ShowinforMessageByID("EB1005");//削除成功しました
                        this.Close();
                    }
                );
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobSiireName_SelectionChangeCommitted(object sender, EventArgs e)
        {
            DataRowView dr = (System.Data.DataRowView)cobSiireName.SelectedItem;
            txtsiireSales.Text = dr["Undertaker"].ToString();
        }

        

        #endregion

        private void dgvSiirePrice_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                EmployeeModifyCostForm frm = new EmployeeModifyCostForm();
                frm._dr = ((DataTable)dgvSiirePrice.DataSource).Rows[e.RowIndex];
                frm.ShowDialog();
            }
        }
    }
}
