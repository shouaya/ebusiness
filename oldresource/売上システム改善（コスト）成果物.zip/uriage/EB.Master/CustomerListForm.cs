﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;

namespace EB.Master
{
    public partial class CustomerListForm : DialogForm
    {
        #region 初期化
        public CustomerListForm()
        {
            InitializeComponent();
            this.menuInit();
        }
        /// <summary>
        /// メニュー
        /// </summary>
        private void menuInit()
        {
            ContextMenuStrip mnu = new ContextMenuStrip();
            ToolStripMenuItem mnuEdit = new ToolStripMenuItem("編集");
            ToolStripMenuItem mnuDelete = new ToolStripMenuItem("削除");
            //編集
            mnuEdit.Click += new EventHandler((sender, e) =>
            {
                DataGridViewCellEventArgs dgvce = new DataGridViewCellEventArgs(0,this.dgvCustomer.SelectedRows[0].Index);
                dgvEmployee_CellDoubleClick(sender, dgvce);
            });
            //削除
            mnuDelete.Click += new EventHandler((sender, e) =>
            {
                if (MessageHelper.ShowDeleteConfirmMessage() != DialogResult.Yes)
                {
                    return;
                }
                int row = this.dgvCustomer.SelectedRows[0].Index;
                IF_Customer entity = new IF_Customer();
                entity.CustomerID = CommonHandler.ToInt(this.dgvCustomer.Rows[row].Cells["CustomerID"].Value);
                entity.DeleteFlg = "1";
                ThreadPoolHelper.StartThread(this,
                    () =>
                    {
                        return BL_Customer.GetInstance().DeleteCustomer(entity);
                    }, (obj) =>
                    {
                        this.dgvCustomer.Rows.RemoveAt(row);
                        MessageHelper.ShowinforMessageByID("EB1005");//削除成功しました
                    }
                );
            });
            //Add to main context menu
            mnu.Items.AddRange(new ToolStripItem[] { mnuEdit, mnuDelete });
            //Assign to datagridview
            dgvCustomer.ContextMenuStrip = mnu;

        }

        /// <summary>
        /// 画面初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EmployeeAddForm_Load(object sender, EventArgs e)
        {
            try
            {
                ////面データを初期化
                btnsearch_Click(null,null);

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        #endregion

        #region 画面動作
        /// <summary>
        /// 新規登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCustomerRegister_Click(object sender, EventArgs e)
        {
            CustomerModifyForm cmf = new CustomerModifyForm(0, (entity) =>
            {
                this.keyword.Text = "";
                btnsearch_Click(sender, e);
            });
            cmf.Top = 0;
            cmf.ShowDialog();
        }
        /// <summary>
        /// 編集
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvEmployee_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int row = e.RowIndex;
            CustomerModifyForm cmf = new CustomerModifyForm(
                CommonHandler.ToInt(this.dgvCustomer.Rows[row].Cells["CustomerID"].Value)
            , (entity) =>
            {
                if (entity.DeleteFlg == "1")
                {
                    this.dgvCustomer.Rows.RemoveAt(row);
                }
                else
                {
                    this.setRowData(row, entity);
                }
            });
            cmf.Top = 0;
            cmf.ShowDialog();
        }
        /// <summary>
        /// 検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnsearch_Click(object sender, EventArgs e)
        {
            String keyword = this.keyword.Text;
            ThreadPoolHelper.StartThread(this,
                () =>
                {
                    BL_Customer bl = BL_Customer.GetInstance();

                    return bl.SelectAllCustomer(keyword);
                },
                (obj)=>{

                    dgvCustomer.AutoGenerateColumns = false;

                    dgvCustomer.DataSource = obj as DataTable;
                    this.resCount.Text = dgvCustomer.RowCount.ToString();
                    dgvCustomer.Focus();
                    if (null != sender)
                    {
                        Button btn = sender as Button;

                        if ("btnCustomerRegister" == btn.Name)
                        {
                            int lastRow = this.dgvCustomer.Rows.Count - 1;
                            this.dgvCustomer.FirstDisplayedScrollingRowIndex = lastRow;
                            this.dgvCustomer.Rows[lastRow].Selected = true;
                        }
                    }
                }
                );
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="row"></param>
        /// <param name="entity"></param>
        private void setRowData(int row, IF_Customer entity)
        {
            dgvCustomer.Rows[row].Cells["CustomerID"].Value = entity.CustomerID;//顧客ID
            dgvCustomer.Rows[row].Cells["CustomerName"].Value = entity.CustomerName;//顧客名
            dgvCustomer.Rows[row].Cells["JapaneseSpell"].Value = entity.JapaneseSpell;//フリカナ
            dgvCustomer.Rows[row].Cells["Representor"].Value = entity.Representor;//代表者名
            dgvCustomer.Rows[row].Cells["FoundDate"].Value = entity.FoundDate;//設立年月日
            dgvCustomer.Rows[row].Cells["Capital"].Value = entity.Capital;//資本金
            dgvCustomer.Rows[row].Cells["EmployeeCount"].Value = entity.EmployeeCount;//従業員数
            dgvCustomer.Rows[row].Cells["SaleAmount"].Value = entity.SaleAmount;//売上高
            dgvCustomer.Rows[row].Cells["PostCode"].Value = entity.PostCode;//郵便番号
            dgvCustomer.Rows[row].Cells["Address1"].Value = entity.Address1;//住所１
            dgvCustomer.Rows[row].Cells["Address2"].Value = entity.Address2;//住所２
            dgvCustomer.Rows[row].Cells["Tel"].Value = entity.Tel;//TEL
            dgvCustomer.Rows[row].Cells["Fax"].Value = entity.Fax;//FAX
            dgvCustomer.Rows[row].Cells["Undertaker"].Value = entity.Undertaker;//担当者
            dgvCustomer.Rows[row].Cells["UndertakerMail"].Value = entity.UndertakerMail;//担当者Mail
            dgvCustomer.Rows[row].Cells["Remark"].Value = entity.Remark;//評価
            dgvCustomer.Rows[row].Cells["Note"].Value = entity.Note;//備考
            dgvCustomer.Rows[row].Cells["PaymentType"].Value = entity.PaymentType;//支払方法
            dgvCustomer.Rows[row].Cells["PaymentDay"].Value = entity.PaymentDay;//支払日
        }
        /// <summary>
        /// 右クリック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void _CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex > -1 && e.ColumnIndex > -1)
            {
                dgvCustomer.CurrentRow.Selected = false;
                dgvCustomer.Rows[e.RowIndex].Selected = true;

            }
        }
        /// <summary>
        /// Enter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void _KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.btnsearch_Click(this.btnsearch, null);
            }

        }
        #endregion
    }
}
