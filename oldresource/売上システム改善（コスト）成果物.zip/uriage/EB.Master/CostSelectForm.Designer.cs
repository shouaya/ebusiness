﻿namespace EB.Master
{
    partial class CostSelectForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOK = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.preStart = new System.Windows.Forms.Label();
            this.preEnd = new System.Windows.Forms.Label();
            this.empStart = new System.Windows.Forms.Label();
            this.empEnd = new System.Windows.Forms.Label();
            this.lblMsg = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.preSiire = new System.Windows.Forms.Label();
            this.empSiire = new System.Windows.Forms.Label();
            this.btnCancle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(64, 180);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 27);
            this.btnOK.TabIndex = 1;
            this.btnOK.Text = "確認";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(78, 105);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(78, 139);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 3;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(211, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "契約開始";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(315, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "契約終了";
            // 
            // preStart
            // 
            this.preStart.AutoSize = true;
            this.preStart.Location = new System.Drawing.Point(211, 105);
            this.preStart.Name = "preStart";
            this.preStart.Size = new System.Drawing.Size(11, 12);
            this.preStart.TabIndex = 6;
            this.preStart.Text = "3";
            // 
            // preEnd
            // 
            this.preEnd.AutoSize = true;
            this.preEnd.Location = new System.Drawing.Point(315, 105);
            this.preEnd.Name = "preEnd";
            this.preEnd.Size = new System.Drawing.Size(11, 12);
            this.preEnd.TabIndex = 6;
            this.preEnd.Text = "4";
            // 
            // empStart
            // 
            this.empStart.AutoSize = true;
            this.empStart.Location = new System.Drawing.Point(211, 139);
            this.empStart.Name = "empStart";
            this.empStart.Size = new System.Drawing.Size(11, 12);
            this.empStart.TabIndex = 6;
            this.empStart.Text = "5";
            // 
            // empEnd
            // 
            this.empEnd.AutoSize = true;
            this.empEnd.Location = new System.Drawing.Point(315, 139);
            this.empEnd.Name = "empEnd";
            this.empEnd.Size = new System.Drawing.Size(11, 12);
            this.empEnd.TabIndex = 6;
            this.empEnd.Text = "6";
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Location = new System.Drawing.Point(140, 11);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(11, 12);
            this.lblMsg.TabIndex = 7;
            this.lblMsg.Text = "1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(140, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 8;
            this.label3.Tag = "";
            this.label3.Text = "契約者名：";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(220, 43);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(11, 12);
            this.lblName.TabIndex = 7;
            this.lblName.Text = "2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(119, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "仕入原価";
            // 
            // preSiire
            // 
            this.preSiire.AutoSize = true;
            this.preSiire.Location = new System.Drawing.Point(119, 105);
            this.preSiire.Name = "preSiire";
            this.preSiire.Size = new System.Drawing.Size(53, 12);
            this.preSiire.TabIndex = 9;
            this.preSiire.Text = "仕入原価";
            // 
            // empSiire
            // 
            this.empSiire.AutoSize = true;
            this.empSiire.Location = new System.Drawing.Point(119, 139);
            this.empSiire.Name = "empSiire";
            this.empSiire.Size = new System.Drawing.Size(53, 12);
            this.empSiire.TabIndex = 9;
            this.empSiire.Text = "仕入原価";
            // 
            // btnCancle
            // 
            this.btnCancle.Location = new System.Drawing.Point(405, 180);
            this.btnCancle.Name = "btnCancle";
            this.btnCancle.Size = new System.Drawing.Size(75, 27);
            this.btnCancle.TabIndex = 10;
            this.btnCancle.Text = "中断";
            this.btnCancle.UseVisualStyleBackColor = true;
            this.btnCancle.Click += new System.EventHandler(this.btnCancle_Click);
            // 
            // CostSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 243);
            this.Controls.Add(this.btnCancle);
            this.Controls.Add(this.empSiire);
            this.Controls.Add(this.preSiire);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblMsg);
            this.Controls.Add(this.preEnd);
            this.Controls.Add(this.empEnd);
            this.Controls.Add(this.empStart);
            this.Controls.Add(this.preStart);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.btnOK);
            this.Name = "CostSelect";
            this.Text = "CostSelect";
            this.Load += new System.EventHandler(this.CostSelect_Load);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.btnOK, 0);
            this.Controls.SetChildIndex(this.radioButton1, 0);
            this.Controls.SetChildIndex(this.radioButton2, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.preStart, 0);
            this.Controls.SetChildIndex(this.empStart, 0);
            this.Controls.SetChildIndex(this.empEnd, 0);
            this.Controls.SetChildIndex(this.preEnd, 0);
            this.Controls.SetChildIndex(this.lblMsg, 0);
            this.Controls.SetChildIndex(this.lblName, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.preSiire, 0);
            this.Controls.SetChildIndex(this.empSiire, 0);
            this.Controls.SetChildIndex(this.btnCancle, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label preStart;
        private System.Windows.Forms.Label preEnd;
        private System.Windows.Forms.Label empStart;
        private System.Windows.Forms.Label empEnd;
        private System.Windows.Forms.Label lblMsg;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label preSiire;
        private System.Windows.Forms.Label empSiire;
        private System.Windows.Forms.Button btnCancle;
    }
}