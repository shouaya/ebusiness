﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EB.Common;

namespace EB.Master
{
    public partial class EmployeeModifyCostForm : DialogForm
    {
        public DataRow _dr;
        public EmployeeModifyCostForm()
        {
            InitializeComponent();
        }

        private void EmployeeModifyCostForm_Load(object sender, EventArgs e)
        {
            label3.Text = _dr["StartDate"].ToString() + "～" + _dr["EndDate"].ToString();
            txtSiirePrice.Text = _dr["SiirePrice"].ToString();
            txtCarfare.Text = _dr["Carfare"].ToString();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (!isNum(txtSiirePrice.Text) || !isNum(txtCarfare.Text))
            {
                MessageBox.Show("数字を入力してください", "ERR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _dr["SiirePrice"] = txtSiirePrice.Text;
            _dr["Carfare"] = txtCarfare.Text;
            this.Close();
        }

        private bool isNum(object obj)
        {
            try
            {
                Convert.ToInt32(obj);
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }
    }
}
