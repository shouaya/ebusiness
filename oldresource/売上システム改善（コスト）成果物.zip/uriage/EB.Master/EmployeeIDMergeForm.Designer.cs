﻿namespace EB.Master
{
    partial class EmployeeIDMergeForm
    {
        /// <summary>
        /// 
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 

        /// <summary>
        /// 
        /// 
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dgvMergeList = new System.Windows.Forms.DataGridView();
            this.btnMerge = new System.Windows.Forms.Button();
            this.btnCostUpdate = new System.Windows.Forms.Button();
            this.btnKaijo = new System.Windows.Forms.Button();
            this.check = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.EmployeeId1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeID2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kubun = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMergeList)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(694, 537);
            // 
            // dtpDate
            // 
            this.dtpDate.CustomFormat = "yyyy-MM-dd";
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDate.Location = new System.Drawing.Point(25, 25);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(127, 21);
            this.dtpDate.TabIndex = 1;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(180, 25);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(68, 21);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dgvMergeList
            // 
            this.dgvMergeList.AllowDrop = true;
            this.dgvMergeList.AllowUserToAddRows = false;
            this.dgvMergeList.AllowUserToDeleteRows = false;
            this.dgvMergeList.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMergeList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvMergeList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMergeList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.check,
            this.EmployeeId1,
            this.EmployeeID2,
            this.EmployeeName,
            this.EmployeeType,
            this.kubun});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMergeList.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvMergeList.Location = new System.Drawing.Point(25, 70);
            this.dgvMergeList.MultiSelect = false;
            this.dgvMergeList.Name = "dgvMergeList";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMergeList.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvMergeList.RowHeadersVisible = false;
            this.dgvMergeList.RowTemplate.Height = 23;
            this.dgvMergeList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMergeList.Size = new System.Drawing.Size(744, 445);
            this.dgvMergeList.TabIndex = 3;
            this.dgvMergeList.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgvMergeList_CellPainting);
            this.dgvMergeList.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.dgvMergeList_RowPrePaint);
            // 
            // btnMerge
            // 
            this.btnMerge.Enabled = false;
            this.btnMerge.Location = new System.Drawing.Point(25, 537);
            this.btnMerge.Name = "btnMerge";
            this.btnMerge.Size = new System.Drawing.Size(73, 23);
            this.btnMerge.TabIndex = 4;
            this.btnMerge.Text = "統合";
            this.btnMerge.UseVisualStyleBackColor = true;
            this.btnMerge.Click += new System.EventHandler(this.btnMerge_Click);
            // 
            // btnCostUpdate
            // 
            this.btnCostUpdate.Enabled = false;
            this.btnCostUpdate.Location = new System.Drawing.Point(353, 535);
            this.btnCostUpdate.Name = "btnCostUpdate";
            this.btnCostUpdate.Size = new System.Drawing.Size(103, 25);
            this.btnCostUpdate.TabIndex = 5;
            this.btnCostUpdate.Text = "コスト更新";
            this.btnCostUpdate.UseVisualStyleBackColor = true;
            this.btnCostUpdate.Click += new System.EventHandler(this.btnCostUpdate_Click);
            // 
            // btnKaijo
            // 
            this.btnKaijo.Enabled = false;
            this.btnKaijo.Location = new System.Drawing.Point(135, 537);
            this.btnKaijo.Name = "btnKaijo";
            this.btnKaijo.Size = new System.Drawing.Size(75, 23);
            this.btnKaijo.TabIndex = 6;
            this.btnKaijo.Text = "解除";
            this.btnKaijo.UseVisualStyleBackColor = true;
            this.btnKaijo.Click += new System.EventHandler(this.btnKaijo_Click);
            // 
            // check
            // 
            this.check.DataPropertyName = "check";
            this.check.HeaderText = "";
            this.check.Name = "check";
            this.check.Width = 30;
            // 
            // EmployeeId1
            // 
            this.EmployeeId1.DataPropertyName = "EmployeeId1";
            this.EmployeeId1.HeaderText = "売上システム社員ID";
            this.EmployeeId1.Name = "EmployeeId1";
            this.EmployeeId1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // EmployeeID2
            // 
            this.EmployeeID2.DataPropertyName = "EmployeeID2";
            this.EmployeeID2.HeaderText = "契約システム社員ID";
            this.EmployeeID2.Name = "EmployeeID2";
            this.EmployeeID2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // EmployeeName
            // 
            this.EmployeeName.DataPropertyName = "EmployeeName";
            this.EmployeeName.HeaderText = "社員名";
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // EmployeeType
            // 
            this.EmployeeType.DataPropertyName = "EmployeeType";
            this.EmployeeType.HeaderText = "社員区分";
            this.EmployeeType.Name = "EmployeeType";
            this.EmployeeType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EmployeeType.Width = 80;
            // 
            // kubun
            // 
            this.kubun.DataPropertyName = "kubun";
            this.kubun.HeaderText = "統合区分";
            this.kubun.Name = "kubun";
            this.kubun.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.kubun.Width = 80;
            // 
            // EmployeeIDMergeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 574);
            this.Controls.Add(this.btnKaijo);
            this.Controls.Add(this.btnCostUpdate);
            this.Controls.Add(this.btnMerge);
            this.Controls.Add(this.dgvMergeList);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dtpDate);
            this.Name = "EmployeeIDMergeForm";
            this.Text = "技術者ID統合";
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.dtpDate, 0);
            this.Controls.SetChildIndex(this.btnSearch, 0);
            this.Controls.SetChildIndex(this.dgvMergeList, 0);
            this.Controls.SetChildIndex(this.btnMerge, 0);
            this.Controls.SetChildIndex(this.btnCostUpdate, 0);
            this.Controls.SetChildIndex(this.btnKaijo, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMergeList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dgvMergeList;
        private System.Windows.Forms.Button btnMerge;
        private System.Windows.Forms.Button btnCostUpdate;
        private System.Windows.Forms.Button btnKaijo;
        private System.Windows.Forms.DataGridViewCheckBoxColumn check;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeId1;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID2;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeType;
        private System.Windows.Forms.DataGridViewTextBoxColumn kubun;
    }
}