﻿namespace EB.Master
{
    partial class EmployeeModifyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtExperience = new EB.Common.DigitTextBox();
            this.txtBirthday = new System.Windows.Forms.DateTimePicker();
            this.rdoSkill2 = new System.Windows.Forms.RadioButton();
            this.rdoSkill1 = new System.Windows.Forms.RadioButton();
            this.rdoSkill0 = new System.Windows.Forms.RadioButton();
            this.cobCompany = new System.Windows.Forms.ComboBox();
            this.cobEmployeeType = new System.Windows.Forms.ComboBox();
            this.txtJapaneseSpell = new System.Windows.Forms.TextBox();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.txtPostCode = new System.Windows.Forms.TextBox();
            this.txtLanguage = new System.Windows.Forms.TextBox();
            this.txtCertificate = new System.Windows.Forms.TextBox();
            this.txtDegree = new System.Windows.Forms.TextBox();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtEmployeeID = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.cobSiireName = new System.Windows.Forms.ComboBox();
            this.txtsiireSales = new System.Windows.Forms.TextBox();
            this.dgvSiirePrice = new System.Windows.Forms.DataGridView();
            this.serial = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SiirePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Carfare = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartContractDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndContractDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSiirePrice)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(351, 588);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(86, 588);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 97;
            this.btnUpdate.Text = "修正";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(216, 588);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 97;
            this.btnDelete.Text = "削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtExperience
            // 
            this.txtExperience.Location = new System.Drawing.Point(86, 138);
            this.txtExperience.MaxLength = 2;
            this.txtExperience.Name = "txtExperience";
            this.txtExperience.Size = new System.Drawing.Size(95, 21);
            this.txtExperience.TabIndex = 131;
            // 
            // txtBirthday
            // 
            this.txtBirthday.CustomFormat = "yyyy/MM/dd";
            this.txtBirthday.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtBirthday.Location = new System.Drawing.Point(86, 113);
            this.txtBirthday.Name = "txtBirthday";
            this.txtBirthday.Size = new System.Drawing.Size(149, 21);
            this.txtBirthday.TabIndex = 130;
            // 
            // rdoSkill2
            // 
            this.rdoSkill2.AutoSize = true;
            this.rdoSkill2.Location = new System.Drawing.Point(244, 209);
            this.rdoSkill2.Name = "rdoSkill2";
            this.rdoSkill2.Size = new System.Drawing.Size(47, 16);
            this.rdoSkill2.TabIndex = 127;
            this.rdoSkill2.TabStop = true;
            this.rdoSkill2.Text = "製造";
            this.rdoSkill2.UseVisualStyleBackColor = true;
            // 
            // rdoSkill1
            // 
            this.rdoSkill1.AutoSize = true;
            this.rdoSkill1.Location = new System.Drawing.Point(164, 209);
            this.rdoSkill1.Name = "rdoSkill1";
            this.rdoSkill1.Size = new System.Drawing.Size(71, 16);
            this.rdoSkill1.TabIndex = 128;
            this.rdoSkill1.TabStop = true;
            this.rdoSkill1.Text = "詳細設計";
            this.rdoSkill1.UseVisualStyleBackColor = true;
            // 
            // rdoSkill0
            // 
            this.rdoSkill0.AutoSize = true;
            this.rdoSkill0.Location = new System.Drawing.Point(86, 210);
            this.rdoSkill0.Name = "rdoSkill0";
            this.rdoSkill0.Size = new System.Drawing.Size(71, 16);
            this.rdoSkill0.TabIndex = 129;
            this.rdoSkill0.TabStop = true;
            this.rdoSkill0.Text = "基本設計";
            this.rdoSkill0.UseVisualStyleBackColor = true;
            // 
            // cobCompany
            // 
            this.cobCompany.DisplayMember = "CodeName";
            this.cobCompany.FormattingEnabled = true;
            this.cobCompany.Location = new System.Drawing.Point(86, 504);
            this.cobCompany.MaxLength = 200;
            this.cobCompany.Name = "cobCompany";
            this.cobCompany.Size = new System.Drawing.Size(340, 20);
            this.cobCompany.TabIndex = 125;
            this.cobCompany.ValueMember = "CodeId";
            // 
            // cobEmployeeType
            // 
            this.cobEmployeeType.DisplayMember = "CodeName";
            this.cobEmployeeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobEmployeeType.FormattingEnabled = true;
            this.cobEmployeeType.Location = new System.Drawing.Point(86, 87);
            this.cobEmployeeType.Name = "cobEmployeeType";
            this.cobEmployeeType.Size = new System.Drawing.Size(95, 20);
            this.cobEmployeeType.TabIndex = 126;
            this.cobEmployeeType.ValueMember = "CodeId";
            // 
            // txtJapaneseSpell
            // 
            this.txtJapaneseSpell.Location = new System.Drawing.Point(86, 62);
            this.txtJapaneseSpell.MaxLength = 30;
            this.txtJapaneseSpell.Name = "txtJapaneseSpell";
            this.txtJapaneseSpell.Size = new System.Drawing.Size(150, 21);
            this.txtJapaneseSpell.TabIndex = 117;
            // 
            // txtRemark
            // 
            this.txtRemark.Location = new System.Drawing.Point(86, 530);
            this.txtRemark.MaxLength = 200;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(105, 21);
            this.txtRemark.TabIndex = 118;
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(86, 556);
            this.txtNote.MaxLength = 2000;
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(341, 21);
            this.txtNote.TabIndex = 119;
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(86, 324);
            this.txtTel.MaxLength = 20;
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(105, 21);
            this.txtTel.TabIndex = 114;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Location = new System.Drawing.Point(86, 301);
            this.txtAddress2.MaxLength = 200;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(232, 21);
            this.txtAddress2.TabIndex = 115;
            // 
            // txtAddress1
            // 
            this.txtAddress1.Location = new System.Drawing.Point(86, 278);
            this.txtAddress1.MaxLength = 200;
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(232, 21);
            this.txtAddress1.TabIndex = 116;
            // 
            // txtPostCode
            // 
            this.txtPostCode.Location = new System.Drawing.Point(86, 255);
            this.txtPostCode.MaxLength = 10;
            this.txtPostCode.Name = "txtPostCode";
            this.txtPostCode.Size = new System.Drawing.Size(105, 21);
            this.txtPostCode.TabIndex = 120;
            // 
            // txtLanguage
            // 
            this.txtLanguage.Location = new System.Drawing.Point(86, 232);
            this.txtLanguage.MaxLength = 200;
            this.txtLanguage.Name = "txtLanguage";
            this.txtLanguage.Size = new System.Drawing.Size(232, 21);
            this.txtLanguage.TabIndex = 124;
            // 
            // txtCertificate
            // 
            this.txtCertificate.Location = new System.Drawing.Point(86, 160);
            this.txtCertificate.MaxLength = 200;
            this.txtCertificate.Name = "txtCertificate";
            this.txtCertificate.Size = new System.Drawing.Size(231, 21);
            this.txtCertificate.TabIndex = 122;
            // 
            // txtDegree
            // 
            this.txtDegree.Location = new System.Drawing.Point(86, 185);
            this.txtDegree.MaxLength = 200;
            this.txtDegree.Name = "txtDegree";
            this.txtDegree.Size = new System.Drawing.Size(232, 21);
            this.txtDegree.TabIndex = 121;
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Location = new System.Drawing.Point(86, 37);
            this.txtEmployeeName.MaxLength = 30;
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.ReadOnly = true;
            this.txtEmployeeName.Size = new System.Drawing.Size(150, 21);
            this.txtEmployeeName.TabIndex = 123;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 112;
            this.label5.Text = "出生年月日";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(52, 327);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 12);
            this.label14.TabIndex = 113;
            this.label14.Text = "TEL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(24, 507);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 111;
            this.label12.Text = "会社区分";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(48, 235);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 98;
            this.label10.Text = "言語";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(48, 211);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 99;
            this.label8.Text = "経験";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(48, 559);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 100;
            this.label25.Text = "備考";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(48, 533);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 107;
            this.label11.Text = "評価";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(40, 281);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 105;
            this.label13.Text = "住所１";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(40, 304);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 106;
            this.label9.Text = "住所２";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(60, 258);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 12);
            this.label7.TabIndex = 108;
            this.label7.Text = "〒";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(24, 90);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 12);
            this.label28.TabIndex = 109;
            this.label28.Text = "社員区分";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(24, 141);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 12);
            this.label22.TabIndex = 101;
            this.label22.Text = "経験年数";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(48, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 102;
            this.label6.Text = "学歴";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 104;
            this.label4.Text = "資格";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 103;
            this.label3.Text = "ﾌﾘｶﾞﾅ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 110;
            this.label2.Text = "社員名";
            // 
            // txtEmployeeID
            // 
            this.txtEmployeeID.Location = new System.Drawing.Point(86, 12);
            this.txtEmployeeID.MaxLength = 30;
            this.txtEmployeeID.Name = "txtEmployeeID";
            this.txtEmployeeID.ReadOnly = true;
            this.txtEmployeeID.Size = new System.Drawing.Size(95, 21);
            this.txtEmployeeID.TabIndex = 123;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(37, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 109;
            this.label15.Text = "社員ID";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 381);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 352;
            this.label17.Text = "仕入先担当";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(36, 355);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 12);
            this.label19.TabIndex = 350;
            this.label19.Text = "仕入先";
            // 
            // cobSiireName
            // 
            this.cobSiireName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cobSiireName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cobSiireName.DisplayMember = "CustomerName";
            this.cobSiireName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobSiireName.FormattingEnabled = true;
            this.cobSiireName.Location = new System.Drawing.Point(86, 352);
            this.cobSiireName.Name = "cobSiireName";
            this.cobSiireName.Size = new System.Drawing.Size(231, 20);
            this.cobSiireName.TabIndex = 349;
            this.cobSiireName.ValueMember = "CustomerID";
            this.cobSiireName.SelectionChangeCommitted += new System.EventHandler(this.cobSiireName_SelectionChangeCommitted);
            // 
            // txtsiireSales
            // 
            this.txtsiireSales.Location = new System.Drawing.Point(86, 378);
            this.txtsiireSales.MaxLength = 200;
            this.txtsiireSales.Name = "txtsiireSales";
            this.txtsiireSales.Size = new System.Drawing.Size(129, 21);
            this.txtsiireSales.TabIndex = 356;
            // 
            // dgvSiirePrice
            // 
            this.dgvSiirePrice.AllowUserToAddRows = false;
            this.dgvSiirePrice.AllowUserToDeleteRows = false;
            this.dgvSiirePrice.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSiirePrice.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSiirePrice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvSiirePrice.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.serial,
            this.SiirePrice,
            this.Carfare,
            this.StartDate,
            this.EndDate,
            this.StartContractDate,
            this.EndContractDate});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSiirePrice.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvSiirePrice.Location = new System.Drawing.Point(14, 405);
            this.dgvSiirePrice.MultiSelect = false;
            this.dgvSiirePrice.Name = "dgvSiirePrice";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSiirePrice.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvSiirePrice.RowHeadersVisible = false;
            this.dgvSiirePrice.RowTemplate.Height = 23;
            this.dgvSiirePrice.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSiirePrice.Size = new System.Drawing.Size(430, 93);
            this.dgvSiirePrice.TabIndex = 357;
            this.dgvSiirePrice.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSiirePrice_CellDoubleClick);
            // 
            // serial
            // 
            this.serial.DataPropertyName = "serial";
            this.serial.HeaderText = "serial";
            this.serial.Name = "serial";
            this.serial.Visible = false;
            this.serial.Width = 50;
            // 
            // SiirePrice
            // 
            this.SiirePrice.DataPropertyName = "SiirePrice";
            this.SiirePrice.HeaderText = "仕入原価";
            this.SiirePrice.Name = "SiirePrice";
            this.SiirePrice.ReadOnly = true;
            this.SiirePrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SiirePrice.Width = 65;
            // 
            // Carfare
            // 
            this.Carfare.DataPropertyName = "Carfare";
            this.Carfare.HeaderText = "交通費";
            this.Carfare.Name = "Carfare";
            this.Carfare.ReadOnly = true;
            this.Carfare.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Carfare.Width = 50;
            // 
            // StartDate
            // 
            this.StartDate.DataPropertyName = "StartDate";
            this.StartDate.HeaderText = "開始日";
            this.StartDate.Name = "StartDate";
            this.StartDate.ReadOnly = true;
            this.StartDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StartDate.Width = 72;
            // 
            // EndDate
            // 
            this.EndDate.DataPropertyName = "EndDate";
            this.EndDate.HeaderText = "終了日";
            this.EndDate.Name = "EndDate";
            this.EndDate.ReadOnly = true;
            this.EndDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EndDate.Width = 72;
            // 
            // StartContractDate
            // 
            this.StartContractDate.DataPropertyName = "StartContractDate";
            this.StartContractDate.HeaderText = "契約開始日";
            this.StartContractDate.Name = "StartContractDate";
            this.StartContractDate.ReadOnly = true;
            this.StartContractDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StartContractDate.Width = 75;
            // 
            // EndContractDate
            // 
            this.EndContractDate.DataPropertyName = "EndContractDate";
            this.EndContractDate.HeaderText = "契約終了日";
            this.EndContractDate.Name = "EndContractDate";
            this.EndContractDate.ReadOnly = true;
            this.EndContractDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EndContractDate.Width = 75;
            // 
            // EmployeeModifyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(462, 620);
            this.Controls.Add(this.dgvSiirePrice);
            this.Controls.Add(this.txtsiireSales);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.cobSiireName);
            this.Controls.Add(this.txtBirthday);
            this.Controls.Add(this.txtExperience);
            this.Controls.Add(this.rdoSkill2);
            this.Controls.Add(this.rdoSkill1);
            this.Controls.Add(this.rdoSkill0);
            this.Controls.Add(this.cobCompany);
            this.Controls.Add(this.txtJapaneseSpell);
            this.Controls.Add(this.cobEmployeeType);
            this.Controls.Add(this.txtRemark);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.txtTel);
            this.Controls.Add(this.txtAddress2);
            this.Controls.Add(this.txtAddress1);
            this.Controls.Add(this.txtPostCode);
            this.Controls.Add(this.txtLanguage);
            this.Controls.Add(this.txtCertificate);
            this.Controls.Add(this.txtDegree);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.txtEmployeeID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Name = "EmployeeModifyForm";
            this.Text = "社員修正／削除";
            this.Load += new System.EventHandler(this.EmployeeModifyForm_Load);
            this.Controls.SetChildIndex(this.btnUpdate, 0);
            this.Controls.SetChildIndex(this.btnDelete, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label22, 0);
            this.Controls.SetChildIndex(this.label28, 0);
            this.Controls.SetChildIndex(this.label15, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.label25, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.txtEmployeeID, 0);
            this.Controls.SetChildIndex(this.txtEmployeeName, 0);
            this.Controls.SetChildIndex(this.txtDegree, 0);
            this.Controls.SetChildIndex(this.txtCertificate, 0);
            this.Controls.SetChildIndex(this.txtLanguage, 0);
            this.Controls.SetChildIndex(this.txtPostCode, 0);
            this.Controls.SetChildIndex(this.txtAddress1, 0);
            this.Controls.SetChildIndex(this.txtAddress2, 0);
            this.Controls.SetChildIndex(this.txtTel, 0);
            this.Controls.SetChildIndex(this.txtNote, 0);
            this.Controls.SetChildIndex(this.txtRemark, 0);
            this.Controls.SetChildIndex(this.cobEmployeeType, 0);
            this.Controls.SetChildIndex(this.txtJapaneseSpell, 0);
            this.Controls.SetChildIndex(this.cobCompany, 0);
            this.Controls.SetChildIndex(this.rdoSkill0, 0);
            this.Controls.SetChildIndex(this.rdoSkill1, 0);
            this.Controls.SetChildIndex(this.rdoSkill2, 0);
            this.Controls.SetChildIndex(this.txtExperience, 0);
            this.Controls.SetChildIndex(this.txtBirthday, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.cobSiireName, 0);
            this.Controls.SetChildIndex(this.label19, 0);
            this.Controls.SetChildIndex(this.label17, 0);
            this.Controls.SetChildIndex(this.txtsiireSales, 0);
            this.Controls.SetChildIndex(this.dgvSiirePrice, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSiirePrice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private Common.DigitTextBox txtExperience;
        private System.Windows.Forms.DateTimePicker txtBirthday;
        private System.Windows.Forms.RadioButton rdoSkill2;
        private System.Windows.Forms.RadioButton rdoSkill1;
        private System.Windows.Forms.RadioButton rdoSkill0;
        private System.Windows.Forms.ComboBox cobCompany;
        private System.Windows.Forms.ComboBox cobEmployeeType;
        private System.Windows.Forms.TextBox txtJapaneseSpell;
        private System.Windows.Forms.TextBox txtRemark;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.TextBox txtPostCode;
        private System.Windows.Forms.TextBox txtLanguage;
        private System.Windows.Forms.TextBox txtCertificate;
        private System.Windows.Forms.TextBox txtDegree;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtEmployeeID;
        private System.Windows.Forms.Label label15;
        //private Common.NumericTextox txtPrice;
        //private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cobSiireName;
        private System.Windows.Forms.TextBox txtsiireSales;
        private System.Windows.Forms.DataGridView dgvSiirePrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn serial;
        private System.Windows.Forms.DataGridViewTextBoxColumn SiirePrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Carfare;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartContractDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndContractDate;
        //private Common.NumericTextox txtCarfare;
        //private System.Windows.Forms.Label label1;
    }
}