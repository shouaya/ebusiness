﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;

namespace EB.Master
{
    public partial class CompanyInforForm : DialogForm
    {
        #region 初期化
        private BL_Company bl = BL_Company.GetInstance();

        private IF_Company dataCompany = new IF_Company();
        private IF_Company inputCompany = new IF_Company();

        public CompanyInforForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CompanyInforForm_Load(object sender, EventArgs e)
        {
            try
            {
                this.Load_Company();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }

        }
        /// <summary>
        /// 初期化　　会社情報
        /// </summary>
        private void Load_Company()
        {
            DataTable dt = this.bl.SelectCompany("1");
            this.dataCompany.InitializeWithDatatable(dt);

            if (this.dataCompany.CompanyID > 0)
            {
                this.txtCompanyName.Text = this.dataCompany.CompanyName;
                this.txtPostCode.Text = this.dataCompany.PostCode;
                this.txtAddress.Text = this.dataCompany.Address;
                this.txtRepresentor.Text = this.dataCompany.Representor;
                this.txtTel.Text = this.dataCompany.Tel;
            }

        }
        #endregion

        #region 画面動作
        /// <summary>
        /// 修正
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            this.inputCompany.CompanyName = this.txtCompanyName.Text;
            this.inputCompany.PostCode = this.txtPostCode.Text;
            this.inputCompany.Address = this.txtAddress.Text;
            this.inputCompany.Representor = this.txtRepresentor.Text;
            this.inputCompany.Tel = this.txtTel.Text;
            this.inputCompany.DeleteFlg = "0";
            if (this.InputCheck())
            {
                if (this.dataCompany.CompanyID > 0)
                {
                    this.inputCompany.CompanyID = this.dataCompany.CompanyID;
                    this.bl.UpdateCompany(this.inputCompany);
                    MessageHelper.ShowinforMessageByID("EB1003");//更新成功しました。
                }
                else
                {
                    this.bl.InsertCompany(this.inputCompany);
                    MessageHelper.ShowinforMessageByID("EB1001");//正常に登録しました。
                }

            }
        }
        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private Boolean InputCheck()
        {
            //郵便番号のチェック
            if (!CommonHandler.CheckPostCode(this.inputCompany.PostCode))
            {
                MessageHelper.ShowinforMessageByID("EB0002", "郵便番号");
                return false;
            }
            //電話番号のチェック
            if (!CommonHandler.CheckTel(this.inputCompany.Tel))
            {
                MessageHelper.ShowinforMessageByID("EB0002", "電話番号");
                return false;
            }

            //会社名のチェック
            if (string.IsNullOrEmpty(this.inputCompany.CompanyName))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "会社名");
                return false;
            }
            //住所のチェック
            if (string.IsNullOrEmpty(this.inputCompany.Address))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "住所");
                return false;
            }
            //代表者のチェック
            if (string.IsNullOrEmpty(this.inputCompany.Representor))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "代表者");
                return false;
            }
            return true;
        }
        #endregion
    }
}
