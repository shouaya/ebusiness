﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;

namespace EB.Master
{
    public partial class SiiresakiAddForm : DialogForm
    {
        #region 初期化
        public SiiresakiAddForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 画面初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EmployeeAddForm_Load(object sender, EventArgs e)
        {
            try
            {
                //Commbox DataSourceを指定
                bindCommbox();

                //画面データを初期化
                loadData();

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 画面データを初期化
        /// </summary>
        private void loadData()
        {
            BL_Siire bl = BL_Siire.GetInstance();

            DataTable dt = bl.SelectAllSiire();

            dgvEmployee.AutoGenerateColumns = false;

            dgvEmployee.DataSource = dt;
            
        }

        /// <summary>
        /// Reset画面項目
        /// </summary>
        private void resetAll()
        {
            txtSiireName.Text = string.Empty;//
            txtSiireSales.Text = string.Empty;//
            txtPostCode.Text = string.Empty;//
            txtAddress1.Text = string.Empty;//
            txtAddress2.Text = string.Empty;//
            txtTel.Text = string.Empty;//
            txtFax.Text = string.Empty;//
        }

        /// <summary>
        /// Commbox DataSourceを指定
        /// </summary>
        private void bindCommbox()
        {
            //BL_CodeMaster bl = BL_CodeMaster.GetInstance();

            //cobEmployeeType.DataSource = bl.SelectCodeMaster("CD001");//社員区分

            //cobCompany.DataSource = bl.SelectCodeMaster("00002");//勤務先

        }

        #endregion

        #region 画面動作
        /// <summary>
        /// 登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (!isValidCheck()) return;

                //登録処理
                proceessRegister();

                //画面データを初期化
                loadData();

                //Reset画面項目
                resetAll();

                //フォーカスを設定
                dgvEmployee.CurrentCell = dgvEmployee.Rows[dgvEmployee.Rows.Count - 1].Cells[0];

                MessageHelper.ShowinforMessageByID("EB1001");//登録成功しました。
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheck()
        {
            if (string.IsNullOrEmpty(txtSiireName.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", this.label2.Text);
                return false;
            }
            if (string.IsNullOrEmpty(this.txtSiireSales.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", this.label3.Text);
                return false;
            }
            //郵便番号のチェック
            if (!CommonHandler.CheckPostCode(this.txtPostCode.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0002", "郵便番号");
                return false;
            }
            //電話番号のチェック
            if (!CommonHandler.CheckTel(this.txtTel.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0002", "電話番号");
                return false;
            }

            string name = CommonHandler.ToString(txtSiireName.Text);
            if (BL_Siire.GetInstance().SelectExsitsEmployee(name))
            {
                MessageHelper.ShowinforMessageByID("EB0005", this.label2.Text);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 登録処理
        /// </summary>
        private void proceessRegister()
        {
            IF_Siire entity = new IF_Siire();

            entity.SiireName = txtSiireName.Text;
            entity.SiireSales = txtSiireSales.Text;
            entity.PostCode = txtPostCode.Text;
            entity.Address1 = txtAddress1.Text;
            entity.Address2 = txtAddress2.Text;
            entity.Tel = txtTel.Text;
            entity.Fax = txtFax.Text;
            entity.DeleteFlg = "0";

            BL_Siire bl = BL_Siire.GetInstance();
            bl.InsertSiire(entity);

        }
        #endregion
    }
}
