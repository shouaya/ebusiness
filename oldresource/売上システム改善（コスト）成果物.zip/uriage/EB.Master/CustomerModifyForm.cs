﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;

namespace EB.Master
{
    public partial class CustomerModifyForm : DialogForm
    {
        public delegate void CallBackDelegate(IF_Customer ie);
        private CallBackDelegate _cbd;
        private IF_Customer _entity = new IF_Customer();
        private BL_Customer _bl = BL_Customer.GetInstance();

        #region 初期化
        public CustomerModifyForm(int customerID, CallBackDelegate cbd)
        {
            InitializeComponent();

            this._cbd = cbd;
            this._entity.CustomerID = customerID;

            bool isHaveId = this._entity.CustomerID > 0;
            this.txtCustomerID.Visible = isHaveId;
            this.label16.Visible = isHaveId;
            this.btnModify.Text = isHaveId ? "修正" : "登録";
            this.Text = isHaveId ? "顧客修正／削除" : "登録";
            this.btnDelete.Visible = isHaveId;
        }

        /// <summary>
        /// 画面初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustomerModifyForm_Load(object sender, EventArgs e)
        {
            try
            {
                //Commbox DataSourceを指定
                bindCommbox();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// Commbox DataSourceを指定
        /// </summary>
        private void bindCommbox()
        {
            BL_CodeMaster bl = BL_CodeMaster.GetInstance();

            cobPaymentType.DataSource = bl.SelectCodeMaster("CD005");//支払サイト（月）
            cobPaymentDay.DataSource = bl.SelectCodeMaster("CD006");//支払サイト（日）

            if (this._entity.CustomerID > 0)
            {
                DataRow dr = this._bl.SelectCustomerByID(this._entity.CustomerID);
                if (dr != null)
                {
                    txtCustomerID.Text = dr["CustomerID"].ToString();//顧客ID
                    txtCustomerName.Text = dr["CustomerName"].ToString();//顧客名
                    txtJapaneseSpell.Text = dr["JapaneseSpell"].ToString();//フリカナ
                    txtRepresentor.Text = dr["Representor"].ToString();//代表者名
                    txtFoundDate.Text = dr["FoundDate"].ToString();//設立年月日
                    txtCapital.Text = dr["Capital"].ToString();//資本金
                    txtEmployeeCount.Text = dr["EmployeeCount"].ToString();//従業員数
                    txtSaleAmount.Text = dr["SaleAmount"].ToString();//売上高
                    txtPostCode.Text = dr["PostCode"].ToString();//郵便番号
                    txtAddress1.Text = dr["Address1"].ToString();//住所１
                    txtAddress2.Text = dr["Address2"].ToString();//住所２
                    txtTel.Text = dr["Tel"].ToString();//TEL
                    txtFax.Text = dr["Fax"].ToString();//FAX
                    txtUndertaker.Text = dr["Undertaker"].ToString();//担当者
                    txtUndertakerMail.Text = dr["UndertakerMail"].ToString();//担当者Mail
                    txtRemark.Text = dr["Remark"].ToString();//評価
                    txtNote.Text = dr["Note"].ToString();//備考
                    cobPaymentType.SelectedValue = dr["PaymentType"].ToString();//支払方法
                    cobPaymentDay.SelectedValue = dr["PaymentDay"].ToString();//支払日
                }
            }
        }

        /// <summary>
        /// 修正
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (!isValidCheck()) return;

                //登録処理
                this._entity.CustomerName = txtCustomerName.Text;//顧客名
                this._entity.JapaneseSpell = txtJapaneseSpell.Text;//フリカナ
                this._entity.Representor = txtRepresentor.Text;//代表者名
                this._entity.FoundDate = txtFoundDate.Text;//設立年月日
                this._entity.Capital = txtCapital.Text;//資本金
                this._entity.EmployeeCount = txtEmployeeCount.Text;//従業員数
                this._entity.SaleAmount = txtSaleAmount.Text;//売上高
                this._entity.PostCode = txtPostCode.Text;//郵便番号
                this._entity.Address1 = txtAddress1.Text;//住所１
                this._entity.Address2 = txtAddress2.Text;//住所２
                this._entity.Tel = txtTel.Text;//TEL
                this._entity.Fax = txtFax.Text;//FAX
                this._entity.Undertaker = txtUndertaker.Text;//担当者
                this._entity.UndertakerMail = txtUndertakerMail.Text;//担当MAIL
                this._entity.Remark = txtRemark.Text;//評価
                this._entity.Note = txtNote.Text;//備考
                this._entity.PaymentType = CommonHandler.ToString(cobPaymentType.SelectedValue);//支払方法
                this._entity.PaymentDay = CommonHandler.ToString(cobPaymentDay.SelectedValue);//支払日
                this._entity.DataOrder = "";//並び順
                this._entity.DeleteFlg = "0";//削除フラグ

                //登録処理
                ThreadPoolHelper.StartThread(this,
                    () =>
                    {
                        if (this._entity.CustomerID > 0)
                        {
                            return this._bl.UpdateCustomer(this._entity);
                        }
                        else
                        {
                            return this._bl.InsertCustomer(this._entity);
                        }
                    },
                    (obj) =>
                    {
                        this._cbd(this._entity);

                        MessageHelper.ShowinforMessageByID(this._entity.CustomerID > 0 ? "EB1003" : "EB1001");//更新成功しました。
                        this.Close();
                    });
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (string.IsNullOrEmpty(txtCustomerID.Text))
                {
                    return;
                }
                if (MessageHelper.ShowDeleteConfirmMessage() != DialogResult.Yes)
                {
                    return;
                }
                //削除処理
                this._entity.DeleteFlg = "1";

                ThreadPoolHelper.StartThread(this,
                    () =>
                    {
                        return this._bl.DeleteCustomer(this._entity);
                    }, (obj) =>
                    {
                        this._cbd(this._entity);
                        MessageHelper.ShowinforMessageByID("EB1005");//削除成功しました
                        this.Close();
                    }
                );
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheck()
        {
            if (string.IsNullOrEmpty(txtCustomerName.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "顧客名");
                return false;
            }
            //if (string.IsNullOrEmpty(txtJapaneseSpell.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "ﾌﾘｶﾞﾅ");
            //    return false;
            //}
            //if (string.IsNullOrEmpty(this.txtEmployeeCount.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "従業員数");
            //    return false;
            //}
            //if (string.IsNullOrEmpty(this.txtCapital.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "資本金");
            //    return false;
            //}
            //if (string.IsNullOrEmpty(this.txtSaleAmount.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "売上高");
            //    return false;
            //}
            if (string.IsNullOrEmpty(txtPostCode.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "〒");
                return false;
            }
            if (string.IsNullOrEmpty(txtAddress1.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "住所１");
                return false;
            }
            //if (string.IsNullOrEmpty(txtAddress2.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "住所２");
            //    return false;
            //}
            if (string.IsNullOrEmpty(txtTel.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "TEL");
                return false;
            }
            //if (string.IsNullOrEmpty(txtFax.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "FAX");
            //    return false;
            //}
            if (string.IsNullOrEmpty(cobPaymentType.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "支払サイト（月）");
                return false;
            }
            if (string.IsNullOrEmpty(cobPaymentDay.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "支払サイト（日）");
                return false;
            }

            //郵便番号チェック
            if (!CommonHandler.CheckPostCode(txtPostCode.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0002", "〒");
                return false;
            }
            //電話番号チェック
            if (!CommonHandler.CheckTel(txtTel.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0002", "TEL");
                return false;
            }
            //ファックスチェック
            //if (!CommonHandler.CheckTel(txtFax.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0002", "FAX");
            //    return false;
            //}

            return true;
        }
        #endregion
    }
}
