﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.Common;
using System.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections;
using EB.DBAcess;
using EB.Master.entity;
using System.Globalization;

namespace EB.Master
{
    public partial class EmployeeIDMergeForm : DialogForm
    {
        private string test_url = "http://localhost:8080/tsweb/newContract?after=>2015-5-1";
		private string search_url = "http://xxx.com/projectname/api/newContract?after=>";
        private string json;
        private DataTable employeeSale;
        private Dictionary<string, SortedList<string, IF_EmployeeCost>> employeeContractByID;
        private const string uriageKubun = "売上システム";
        private const string keiyakuKubun = "契約システム";
        private const string sumiKubun = "統合済み";

        public EmployeeIDMergeForm()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            

            btnCostUpdate.Enabled = false;
            btnMerge.Enabled = false;
            btnKaijo.Enabled = false;
            ThreadPoolHelper.StartThread(this,
                () => 
                {
                    employeeContractByID = new Dictionary<string, SortedList<string, IF_EmployeeCost>>();

                    WebClient wc = new WebClient();
                    wc.Encoding = System.Text.Encoding.UTF8;
                    json = wc.DownloadString(search_url + dtpDate.Text);
                    

                    // 売上社員一覧
                    employeeSale = BL_Employee.GetInstance().SelectAllEmployeeWithMap();

                    return 1;
                },
                (obj) =>
                {
                    JObject jsonObj = JObject.Parse(json);
                    JArray employees = (JArray)jsonObj["contractList"];
                    if (employees.Count == 0)
                    {
                        MessageBox.Show("契約更新情報がありません。", "E-Business", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    foreach (JObject employee in employees)
                    {
                        string id = employee["EMPLOYER_NO"].ToString();
                        SortedList<string, IF_EmployeeCost> list;
                        if (employeeContractByID.ContainsKey(id))
                        {
                            list = employeeContractByID[id];
                        }
                        else
                        {
                            list = new SortedList<string, IF_EmployeeCost>();
                            employeeContractByID.Add(id, list);
                        }
                        IF_EmployeeCost node = new IF_EmployeeCost();
                        node.EmployeeID1 = -1;
                        node.EmployeeID2 = id;
                        node.EmployeeName = employee["EMPLOYER_NAME"].ToString();
                        node.EmployeeType = employee["EMPLOYER_TYPE"].ToString();
                        node.siirePrice = employee["ALLOWANLE_COST"].ToString();
                        node.startContractDate = employee["EMPLOYMENT_PERIOD_START"].ToString().Replace("-", "/");
                        node.startDate = node.startContractDate;
                        node.endContractDate = employee["EMPLOYMENT_PERIOD_END"].ToString().Replace("-", "/");
                        node.endDate = node.endContractDate;
                        node.kubun = keiyakuKubun;

                        if (node.endContractDate.CompareTo(node.startContractDate) <= 0)
                        {
                            string mes = "契約期間不正、後続処理不能です。\r\n"
                                         + "契約データを確認した上で再実行してください。\r\n"
                                         + "契約者　：" + node.EmployeeName + "\r\n"
                                         + "契約開始：" + employee["EMPLOYMENT_PERIOD_START"] + "　"
                                         + "契約終了：" + employee["EMPLOYMENT_PERIOD_END"];
                            MessageBox.Show(mes, "E-Business", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return ;
                        }

                        foreach (IF_EmployeeCost otherNode in list.Values)
                        {
                            if (node.startContractDate.CompareTo(otherNode.endContractDate) <= 0
                                && node.endContractDate.CompareTo(otherNode.startContractDate) >= 0)
                            {
                                string mes = "契約期間に重なる部分有り、後続処理不能です。\r\n"
                                         + "契約データを確認した上で再実行してください。\r\n"
                                         + "契約者　　：" + node.EmployeeName + "\r\n"
                                         + "契約開始１：" + employee["EMPLOYMENT_PERIOD_START"] + "　"
                                         + "契約終了１：" + employee["EMPLOYMENT_PERIOD_END"] + "\r\n"
                                         + "契約開始２：" + otherNode.startContractDate.Replace("/", "-") + "　"
                                         + "契約終了２：" + otherNode.endContractDate.Replace("/", "-");
                                MessageBox.Show(mes, "E-Business", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        list.Add(node.startContractDate, node);
                    }
                    createDataForView();
                }
            );
        }

        private void createDataForView()
        {
            SortedList<string, IF_EmployeeCost> topList = new SortedList<string, IF_EmployeeCost>(new Mysort());
            Dictionary<int, string> insertItem = new Dictionary<int, string>();
            foreach (KeyValuePair<string, SortedList<string, IF_EmployeeCost>> employeeContractKVP in employeeContractByID)
            {
                IF_EmployeeCost ent = employeeContractKVP.Value.Values[0];
                bool has = false;
                int sameNameCount = 0;
                int sameNameIdx = 0;
                for(int i = 0; i < employeeSale.Rows.Count; i++)
                {
                    if (ent.EmployeeID2.Equals(employeeSale.Rows[i]["EmployeeID2"]))
                    {
                        has = true;
                        ent.EmployeeID1 = Convert.ToInt32(employeeSale.Rows[i]["EmployeeID"]);
                        break;
                    }
                    if (string.IsNullOrEmpty(employeeSale.Rows[i]["EmployeeID2"].ToString())
                        &&ent.EmployeeName.Equals(employeeSale.Rows[i]["EmployeeName"]))
                    {
                        sameNameCount++;
                        sameNameIdx = i;
                    }
                }
                if (!has)
                {
                    if (sameNameCount == 1)
                    {
                        int contractSameNameCount = 0;
                        foreach (KeyValuePair<string, SortedList<string, IF_EmployeeCost>> item2 in employeeContractByID)
                        { 
                            if(ent.EmployeeName.Equals(item2.Value.Values[0].EmployeeName)) 
                            {
                                contractSameNameCount++;
                            }
                        }
                        if (contractSameNameCount == 1)
                        {
                            employeeSale.Rows[sameNameIdx]["EmployeeID2"] = ent.EmployeeID2;
                            ent.EmployeeID1 = Convert.ToInt32(employeeSale.Rows[sameNameIdx]["EmployeeID"]);
                            insertItem.Add((int)employeeSale.Rows[sameNameIdx]["EmployeeID"], ent.EmployeeID2);
                        }
                        else
                        {
                            topList.Add(ent.EmployeeName, ent);
                        }
                    }
                    else
                    {
                        topList.Add(ent.EmployeeName, ent);
                    }
                }
            }

            try
            {
                ThreadPoolHelper.StartThread(this,
                    () => { BL_Cost.GetInstance().insertIDMap(insertItem); return 1; },
                    (obj) => 
                    {
                        createDataForView(topList);
                        btnCostUpdate.Enabled = true;
                        btnMerge.Enabled = true;
                        btnKaijo.Enabled = true;
                    }
                );
            }
            catch (Exception ex)
            {
                employeeSale = null;
                employeeContractByID = null;
                throw (ex);
            }
        }

        private void createDataForView(SortedList<string, IF_EmployeeCost> topList)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("check", System.Type.GetType("System.Boolean"));
            dt.Columns.Add("EmployeeID1", System.Type.GetType("System.String"));
            dt.Columns.Add("EmployeeID2", System.Type.GetType("System.String"));
            dt.Columns.Add("EmployeeName", System.Type.GetType("System.String"));
            dt.Columns.Add("EmployeeType", System.Type.GetType("System.String"));
            dt.Columns.Add("kubun", System.Type.GetType("System.String"));
            
            for (int i = 0; i < employeeSale.Rows.Count; i++)
            {
                if (String.IsNullOrEmpty(employeeSale.Rows[i]["EmployeeID2"].ToString()))
                {
                    IF_EmployeeCost ent = new IF_EmployeeCost();
                    ent.EmployeeID1 = (int)employeeSale.Rows[i]["EmployeeID"];
                    ent.EmployeeName = employeeSale.Rows[i]["EmployeeName"].ToString();
                    ent.EmployeeType = employeeSale.Rows[i]["EmployeeType"].ToString();
                    ent.kubun = uriageKubun;
                    topList.Add(ent.EmployeeName, ent);
                }
            }
             foreach(KeyValuePair<string, IF_EmployeeCost> item in topList)
            {
                IF_EmployeeCost value = item.Value;
                DataRow dr = dt.NewRow();
                dr["EmployeeID1"] = value.EmployeeID1 == -1 ? "" : value.EmployeeID1.ToString();
                dr["EmployeeID2"] = value.EmployeeID2;
                dr["EmployeeName"] = value.EmployeeName;
                dr["EmployeeType"] = value.EmployeeType;
                dr["kubun"] = value.kubun;
                dt.Rows.Add(dr);
            }
            for (int i = 0; i < employeeSale.Rows.Count; i++)
            {
                if (!string.IsNullOrEmpty(employeeSale.Rows[i]["EmployeeID2"].ToString()))
                {
                    DataRow dr = dt.NewRow();
                    dr["EmployeeID1"] = (int)employeeSale.Rows[i]["EmployeeID"];
                    dr["EmployeeID2"] = employeeSale.Rows[i]["EmployeeID2"].ToString();
                    dr["EmployeeName"] = employeeSale.Rows[i]["EmployeeName"].ToString();
                    dr["EmployeeType"] = employeeSale.Rows[i]["EmployeeType"].ToString();
                    dr["kubun"] = sumiKubun;
                    dt.Rows.Add(dr);
                }
            }
            dgvMergeList.DataSource = dt;
            dgvMergeList.Columns[1].ReadOnly = true;
            dgvMergeList.Columns[2].ReadOnly = true;
            dgvMergeList.Columns[3].ReadOnly = true;
            dgvMergeList.Columns[4].ReadOnly = true;
            dgvMergeList.Columns[5].ReadOnly = true;
        }

        private string checkDate(IF_EmployeeCost node, SortedList<string, IF_EmployeeCost> list)
        {
            if (node.endContractDate.CompareTo(node.startContractDate) <= 0)
            {
                return "契約期間不正。";
                
            }
            return null;
        }

        private void btnMerge_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)dgvMergeList.DataSource;
            DataRow keiyakuDR = null;
            DataRow uriageDR = null;
            DataRow dr = null ;
            for(int i = 0; i < dt.Rows.Count; i++)
            {
                dr = dt.Rows[i];
                if (toBoolean(dr["check"]))
                {
                    string kubun = dr["kubun"].ToString();
                    if (keiyakuKubun.Equals(kubun))
                    {
                        if (keiyakuDR != null)
                        {
                            MessageHelper.ShowInforMessage("売上システム社員と契約システム社員各一名選択してください。");
                            return;
                        }
                        else
                        {
                            keiyakuDR = dr;
                        }
                    }
                    else if (uriageKubun.Equals(kubun))
                    {
                        if (uriageDR != null)
                        {
                            MessageHelper.ShowInforMessage("売上システム社員と契約システム社員各一名選択してください。");
                            return;
                        }
                        else
                        {
                            uriageDR = dr;
                        }
                    }
                }
            }
            if (keiyakuDR == null || uriageDR == null)
            {
                MessageHelper.ShowInforMessage("売上システム社員と契約システム社員各一名選択してください。");
                return;
            }
            Dictionary<int, string> insertItem = new Dictionary<int, string>();
            int employeeID1 = Convert.ToInt32(uriageDR["EmployeeID1"]);
            string employeeID2 = keiyakuDR["EmployeeID2"].ToString();
            insertItem.Add(employeeID1, employeeID2);
            BL_Cost.GetInstance().insertIDMap(insertItem);

            employeeContractByID[employeeID2].Values[0].EmployeeID1 = employeeID1;

            dr = dt.NewRow();
            dr["EmployeeID1"] = uriageDR["EmployeeID1"];
            dr["EmployeeID2"] = keiyakuDR["EmployeeID2"];
            dr["EmployeeName"] = uriageDR["EmployeeName"];
            dr["EmployeeType"] = uriageDR["EmployeeType"];
            dr["kubun"] = sumiKubun;
            dt.Rows.Remove(uriageDR);
            dt.Rows.Remove(keiyakuDR);
            dt.Rows.Add(dr);
        }

        private void btnKaijo_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)dgvMergeList.DataSource;
            DataGridViewRow dgvr = dgvMergeList.SelectedRows[0];
            string kubun = dgvr.Cells["kubun"].Value.ToString();
            if (sumiKubun.Equals(kubun))
            {
                int employeeID1 = Convert.ToInt32(dgvr.Cells["EmployeeID1"].Value);
                string employeeID2 = dgvr.Cells["EmployeeID2"].Value.ToString();
                BL_Cost.GetInstance().DeleteIDMap(employeeID1);
                DataRow dr = dt.NewRow();
                dr["EmployeeID1"] = dgvr.Cells["EmployeeID1"].Value;
                dr["EmployeeName"] = dgvr.Cells["EmployeeName"].Value;
                dr["EmployeeType"] = dgvr.Cells["EmployeeType"].Value;
                dr["kubun"] = uriageKubun;
                dt.Rows.InsertAt(dr, 0);
                if (employeeContractByID.ContainsKey(employeeID2))
                {
                    IF_EmployeeCost entity = employeeContractByID[employeeID2].Values[0];
                    entity.EmployeeID1 = -1;
                    dr = dt.NewRow();
                    dr["EmployeeID2"] = entity.EmployeeID2;
                    dr["EmployeeName"] = entity.EmployeeName;
                    dr["EmployeeType"] = entity.EmployeeType;
                    dr["kubun"] = keiyakuKubun;
                    dt.Rows.InsertAt(dr, 0);
                }
                dgvMergeList.Rows.Remove(dgvr);
            }
            else
            {
                MessageHelper.ShowInforMessage("統合済みのレコードを選択してください。");
            }
        }

        private void btnCostUpdate_Click(object sender, EventArgs e)
        {
            
            btnCostUpdate.Enabled = false;
            btnMerge.Enabled = false;
            btnKaijo.Enabled = false;
            updateCost();
        }
            

        private void updateCost()
        {
            Dictionary<int, List<IF_EmployeeCost>> insertTable = new Dictionary<int, List<IF_EmployeeCost>>();
            DataTable allCost = BL_Cost.GetInstance().selectAllCost();
            Dictionary<int, List<IF_EmployeeCost>> employeeCostByID = new Dictionary<int, List<IF_EmployeeCost>>();
            int tempEmployeeId = -1;
            for (int i = 0; i < allCost.Rows.Count; i++)
            {
                DataRow dr = allCost.Rows[i];
                IF_EmployeeCost entity = new IF_EmployeeCost();
                entity.EmployeeID1 = (int)dr["EmployeeID"];
                entity.siirePrice = dr["siirePrice"].ToString();
                entity.startDate = dr["StartDate"].ToString();
                entity.endDate = dr["EndDate"].ToString();
                entity.startContractDate = dr["StartContractDate"].ToString();
                entity.endContractDate = dr["EndContractDate"].ToString();

                if (tempEmployeeId != entity.EmployeeID1)
                {
                    tempEmployeeId = entity.EmployeeID1;
                    List<IF_EmployeeCost> costList = new List<IF_EmployeeCost>();
                    employeeCostByID.Add(tempEmployeeId, costList);
                }
                employeeCostByID[tempEmployeeId].Add(entity);
            }

            foreach (KeyValuePair<string, SortedList<string, IF_EmployeeCost>> employeeContractKVP in employeeContractByID)
            {
                int employeeID1 = employeeContractKVP.Value.Values[0].EmployeeID1;

                // mapping無し
                if (employeeID1 == -1) continue;

                List<IF_EmployeeCost> insertList = new List<IF_EmployeeCost>();
                SortedList<string, IF_EmployeeCost> contractList = employeeContractKVP.Value;
                IF_EmployeeCost contractItem = contractList.Values[0];
                int startContractIdx = 0;
                List<IF_EmployeeCost> costList = employeeCostByID.ContainsKey(employeeID1) ? employeeCostByID[employeeID1] : null;
                IF_EmployeeCost costItem = null;
                int stratCostIdx = 0;
                if (costList != null && contractItem.startContractDate.CompareTo(costList[0].startContractDate) >= 0)
                {
                    for (; stratCostIdx < costList.Count; stratCostIdx++)
                    {
                        costItem = costList[stratCostIdx];
                        if (costItem.endContractDate.CompareTo(contractItem.startContractDate) < 0)
                        {
                            insertList.Add(costItem);
                        }
                        else
                        {
                            break;
                        }
                    }

                    // step
                    while (startContractIdx < contractList.Count && stratCostIdx < costList.Count)
                    {
                        contractItem = contractList.Values[startContractIdx];
                        costItem = costList[stratCostIdx];
                        if (contractItem.startContractDate.Equals(costItem.startContractDate)
                            && contractItem.endContractDate.Equals(costItem.endContractDate)
                            && contractItem.siirePrice.Equals(costItem.siirePrice))
                        {
                            insertList.Add(costItem);
                            startContractIdx++;
                            stratCostIdx++;
                        }
                        else
                        {
                            break;
                        }
                    }

                    // 変更無し
                    if (startContractIdx == contractList.Count) continue;
                    if (stratCostIdx == costList.Count) costItem = null;
                }

                if (insertList.Count == 0)
                {
                    contractItem.startDate = contractItem.startContractDate;
                    insertList.Add(contractItem);
                    startContractIdx = 1;
                }
                else
                {
                    if (costItem != null)
                    {
                        if (contractItem.startContractDate.CompareTo(costItem.startContractDate) > 0)
                        {
                            if (contractItem.siirePrice.Equals(costItem.siirePrice))
                            {
                                costItem.endContractDate = contractItem.endContractDate;
                                startContractIdx++;
                            }
                            else
                            {
                                DateTime dt = DateTime.Parse(contractItem.startContractDate);
                                costItem.endContractDate = dt.AddDays(-1).ToString("yyyy/MM/dd", DateTimeFormatInfo.InvariantInfo);
                            }
                            insertList.Add(costItem);
                        }
                    }
                }
                if (startContractIdx < contractList.Count)
                {
                    IF_EmployeeCost pre = null;
                    IF_EmployeeCost employee = null;
                    for (; startContractIdx < contractList.Count; startContractIdx++)
                    {
                        pre = insertList[insertList.Count - 1];
                        employee = contractList.Values[startContractIdx];

                        if (pre.endContractDate.Substring(0, 7).Equals(employee.startContractDate.Substring(0, 7)))
                        {
                            CostSelectForm costSelect = new CostSelectForm();
                            costSelect.pre = pre;
                            costSelect.employee = employee;
                            costSelect.ShowDialog();
                            if (costSelect.ret == -1)
                            {
                                enableBtn();
                                return;
                            }
                        }

                        if (pre.endDate.CompareTo(pre.startDate) < 0)
                        {
                            string msg = "契約期間不整合、後続処理不能です。\r\n"
                                             + "契約データを確認した上で再実行してください。\r\n"
                                             + "契約者：" + employee.EmployeeName + "\r\n"
                                             + "契約期間１：" + pre.startContractDate + "～" + pre.endContractDate + "\r\n"
                                             + "適用期間１：" + pre.startDate.Substring(0, 7) + "～" + pre.endDate.Substring(0, 7) + "\r\n"
                                             + "契約期間２：" + employee.startContractDate + "～" + employee.endContractDate + "\r\n"
                                             + "適用期間２：" + employee.startDate.Substring(0, 7) + "～" + employee.endContractDate.Substring(0, 7);
                            MessageBox.Show(msg, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            enableBtn();
                            return;
                        }

                        insertList.Add(employee);
                    }
                    employee.endDate = employee.endContractDate;
                    if (employee.endDate.CompareTo(employee.startDate) < 0)
                    {
                        string msg = "契約期間不整合、後続処理不能です。\r\n"
                                         + "契約データを確認した上で再実行してください。\r\n"
                                         + "契約者：" + employee.EmployeeName + "\r\n"
                                         + "契約期間１：" + pre.startContractDate + "～" + pre.endContractDate + "\r\n"
                                         + "適用期間１：" + pre.startDate.Substring(0, 7) + "～" + pre.endDate.Substring(0, 7) + "\r\n"
                                         + "契約期間２：" + employee.startContractDate + "～" + employee.endContractDate + "\r\n"
                                         + "適用期間２：" + employee.startDate.Substring(0, 7) + "～" + employee.endDate.Substring(0, 7);
                        MessageBox.Show(msg, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        enableBtn();
                        return;
                    }
                }
                
                insertTable.Add(employeeID1, insertList);
            }
            if (insertTable.Count == 0)
            {
                MessageBox.Show("更新可能なデータがありません。");
                enableBtn();
            }
            else
            {
                ThreadPoolHelper.StartThread(this,
                () =>
                {
                    BL_Cost.GetInstance().insertCost(insertTable);
                    return 1;
                },
                (obj) =>
                {
                    MessageBox.Show("更新終了。");
                    enableBtn();
                });
            }
        }

        private void enableBtn()
        {
            btnCostUpdate.Enabled = true;
            btnMerge.Enabled = true;
            btnKaijo.Enabled = true;
        }

        private void dgvMergeList_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            string kubun = dgvMergeList.Rows[e.RowIndex].Cells["kubun"].Value.ToString();
            if (sumiKubun.Equals(kubun))
            {
                dgvMergeList.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightGreen;
            }
            else if (keiyakuKubun.Equals(kubun))
            {
                dgvMergeList.Rows[e.RowIndex].DefaultCellStyle.BackColor = Color.LightPink;
            }
        }

        SolidBrush b1 = new SolidBrush(Color.FromArgb(255, 51, 153, 255));
        SolidBrush b2 = new SolidBrush(Color.LightGreen);
        Pen c = new Pen(Color.FromArgb(255, 160, 160, 160));
        private void dgvMergeList_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == 0)
            {
                string kubun = dgvMergeList.Rows[e.RowIndex].Cells["kubun"].Value.ToString();
                if ("統合済み".Equals(kubun))
                {
                    if (dgvMergeList.Rows[e.RowIndex].Selected)
                    {
                        e.Graphics.FillRectangle(b1, e.CellBounds);
                    }
                    else
                    {
                        e.Graphics.FillRectangle(b2, e.CellBounds);
                    }
                    Rectangle re = e.CellBounds;
                    e.Graphics.DrawRectangle(c, re.X, re.Y - 1, re.Width - 1, re.Height);
                    e.Handled = true;
                }
            }
        }

        private static Boolean toBoolean(object obj)
        {
            if(obj == null || "".Equals(obj.ToString()))
            {
                return false;
            }
            return Convert.ToBoolean(obj);
        }

        public class Mysort : IComparer<string>
        {
            public int Compare(string a, string b)
            {
                if (a.CompareTo(b) <= 0)
                {
                    return -1;
                }
                return 1;
            }
        }
    }
}
