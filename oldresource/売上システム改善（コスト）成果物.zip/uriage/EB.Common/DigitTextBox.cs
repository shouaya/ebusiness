﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Windows.Forms;

namespace EB.Common
{
    public class DigitTextBox: TextBox
    {

        protected override void OnLeave(EventArgs e)
        {

        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {

            if (Char.IsDigit(e.KeyChar))
            {
                // Digits are OK
            }
            else if (e.KeyChar == '\b')
            {
                // Backspace key is OK

            }
            else
            {
                e.Handled = true;
            }

        }
    }
}
