﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Text.RegularExpressions;
using System.Management;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.Data;
using Microsoft.VisualBasic;

namespace EB.Common
{
    public class CommonHandler
    {
        
        /// <summary>
        /// Exception処理
        /// </summary>
        /// <param name="ex"></param>
        public static void ProcessException(Exception ex)
        {
            if (ex is EBException)
            {
                MessageHelper.ShowInforMessage(ex.Message);
            }
            else
            {
                MessageHelper.ShowErrorMessage(ex.Message);
            }
            LogHelper.Error(ex.ToString());
        }

        /// <summary>
        /// 文字列に転換
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToString(object value)
        {
            if (value == null || value==DBNull.Value)
            {
                return string.Empty;
            }

            return value.ToString().Trim();
        }

        /// <summary>
        /// 文字列に転換
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static decimal ToDecimal(object value)
        {
            decimal retval = 0;
            try
            {
                retval = Convert.ToDecimal(StrConv(value.ToString().Replace(",", null),false));
            }
            catch
            {
            }
            return retval;
        }
        /// <summary>
        /// 文字列に転換
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static int ToInt(object value)
        {
            int retval = 0;
            try
            {
                retval = Convert.ToInt32(value);
            }
            catch
            {
            }
            return retval;
        }
        /// <summary>
        /// 郵便番号のチェック
        /// </summary>
        /// <param name="postCode"></param>
        /// <returns></returns>
        public static Boolean CheckPostCode(string postCode)
        {
            return IsHaveString(postCode, "^[１２３４５６７８９０\\d]{3}[-ー]?[１２３４５６７８９０\\d]{4}$");
        }
        /// <summary>
        /// 電話番号のチェック
        /// </summary>
        /// <param name="tel"></param>
        /// <returns></returns>
        public static Boolean CheckTel(string tel)
        {
            return IsHaveString(tel, "^0[1-9１２３４５６７８９][１２３４５６７８９０\\d]{0,3}[-ー]?[１２３４５６７８９０\\d]{1,4}[-ー]?[１２３４５６７８９０\\d]{4}$");
        }



        /// <summary>
        /// 指定した正規表現に一致する
        /// </summary>
        /// <param name="input"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static Boolean IsHaveString(string input, string pattern,RegexOptions o)
        {
            try
            {
                return Regex.IsMatch(input, pattern,o);
            }
            catch { return false; }
        }
        /// <summary>
        /// 指定した正規表現に一致する
        /// </summary>
        /// <param name="input"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static Boolean IsHaveString(string input, string pattern)
        {
            try
            {
                return Regex.IsMatch(input, pattern);
            }
            catch { return false; }
        }
        /// <summary>
        /// 指定した入力文字列内で、指定した正規表現に最初に一致する箇所を検索します
        /// </summary>
        /// <param name="input"></param>
        /// <param name="pattern"></param>
        /// <param name="S"></param>
        /// <returns></returns>
        public static String _GetString(string input, string pattern, int S)
        {
            return _GetString(input, pattern, S, RegexOptions.IgnoreCase);
        }
        /// <summary>
        /// 指定した入力文字列内で、指定した正規表現に最初に一致する箇所を検索します
        /// </summary>
        /// <param name="input"></param>
        /// <param name="pattern"></param>
        /// <param name="S"></param>
        /// <returns></returns>
        public static String _GetString(string input, string pattern, int S, RegexOptions o)
        {
            try
            {
                if ( IsHaveString(input, pattern,o))
                {
                    return Regex.Match(input, pattern,o).Groups[S].Value;
                }
                else
                    return null;
            }
            catch { return null; }
        }
        /// <summary>
        /// 指定した入力文字列内で、指定した正規表現に最初に一致する箇所を検索します
        /// </summary>
        /// <param name="input"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static IList<String[]> _GetString(string input, string pattern)
        {
            return _GetString(input, pattern,RegexOptions.IgnoreCase);
        }
        /// <summary>
        /// 指定した入力文字列内で、指定した正規表現に最初に一致する箇所を検索します
        /// </summary>
        /// <param name="input"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static IList<String[]> _GetString(string input, string pattern, RegexOptions o)
        {
            String[] strtemp = null;
            IList<String[]> StrList = null;
            try
            {
                if (IsHaveString(input, pattern,o))
                {
                    StrList = new List<String[]>();
                    MatchCollection RegData = Regex.Matches(input, pattern,o);
                    for (int i = 0; i < RegData.Count; i++)
                    {
                        strtemp = null;
                        strtemp = new String[RegData[i].Groups.Count];
                        for (int j = 0; j < strtemp.Length; j++)
                        {
                            strtemp[j] = RegData[i].Groups[j + 1].Value;
                            //result[i][j] = RegData[i].Groups[j + 1].Value;
                            //this.SetText(RegData[i].Groups[j + 1].Value + "\n");
                        }
                        StrList.Add(strtemp);
                    }
                }
            }
            catch { }
            return StrList;
        }
        /// <summary>
        /// 月末日を取得
        /// </summary>
        /// <param name="day">yyyy/MM/01</param>
        /// <returns></returns>
        public static string GetCurrentMonthLastDay(string day)
        {
            DateTime date = Convert.ToDateTime(day);
            date = date.AddMonths(1);
            date = date.AddDays(-1);

           return date.ToString("yyyy/MM/dd");
        }
        /// <summary>
        /// 月月日転換
        /// </summary>
        /// <param name="day">yyyy/MM/01</param>
        /// <returns></returns>
        public static string GetPrintFormat(string day)
        {
            if(string.IsNullOrEmpty(day)) return string.Empty;

            day = day.Substring(0, 4) + "年" + day.Substring(5, 2) + "月" + day.Substring(8, 2) + "日";
            
            return day;
        }

        /// <summary>
        /// 開始日＜＝終了日チェック
        /// </summary>
        /// <param name="dayStart">yyyy/MM/dd</param>
        /// <param name="dayEnd">yyyy/MM/dd</param>
        /// <returns></returns>
        public static Boolean startEndDayCheck(string dayStart, string dayEnd)
        {
            DateTime dateStart = Convert.ToDateTime(dayStart);
            DateTime dateEnd = Convert.ToDateTime(dayEnd);
            if (dateStart.CompareTo(dateEnd) <= 0)
            {
                return true;
            }
            else 
            {
                return false;
            }  
        }

        /// <summary>
        /// 端末コードを取得
        /// </summary>
        /// <returns></returns>
        public static string GetMachineCode()
        {
            string machinecode = null;
            //cpu
            string strCpu = null;
            ManagementClass myCpu = new ManagementClass("win32_Processor");
            ManagementObjectCollection myCpuConnection = myCpu.GetInstances();
            foreach (ManagementObject myObject in myCpuConnection)
            {
                strCpu = myObject.Properties["Processorid"].Value.ToString();
                break;
            }
            //disk
            string strdisk = null;
            ManagementClass mc =
                 new ManagementClass("Win32_NetworkAdapterConfiguration");
            ManagementObject disk =
                 new ManagementObject("win32_logicaldisk.deviceid=\"c:\"");
            disk.Get();
            strdisk = disk.GetPropertyValue("VolumeSerialNumber").ToString();

            machinecode = strCpu + strdisk;

            return GetMd5(machinecode);
        }
        /// <summary>
        /// MD5
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string GetMd5(object text)
        {
            string path = text.ToString();

            MD5CryptoServiceProvider MD5Pro = new MD5CryptoServiceProvider();
            Byte[] buffer = Encoding.GetEncoding("utf-8").GetBytes(text.ToString());
            Byte[] byteResult = MD5Pro.ComputeHash(buffer);

            return BitConverter.ToString(byteResult).Replace("-", "");
        }

        /// <summary>
        /// 来月計算
        /// </summary>
        /// <param name="text">当月</param>
        /// <returns></returns>
        public static string NextMonth(String month)
        {
            String date = String.Empty;
            String year = String.Empty;
            String nextmonth = String.Empty;
            String themonth = String.Empty;
            year=month.Substring(0,4);
            themonth = month.Substring(5, 2);
            int yearInt=ToInt(year);
            int theMonthInt = ToInt(themonth);
            
            if (theMonthInt < 12)
            {
                int nextMonthInt=theMonthInt + 1;
                nextmonth = ToString(nextMonthInt);
                if (nextMonthInt < 10)
                {
                    date = year + "/0" + nextmonth;
                }
                else {
                    date = year + "/" + nextmonth;
                }
            }
            else {
                year = ToString(yearInt+1);
                date = year + "/01";
            }
            return date;
        }

        /// <summary>
        /// GetTextByValueFromCob
        /// </summary>
        /// <param name="cob"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetTextByValueFromCob(ComboBox cob, string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return null;
            }
            else
            {
                try
                {
                    return ((DataTable)cob.DataSource).Select(cob.ValueMember + "=" + value)[0][cob.DisplayMember].ToString();
                }
                catch
                {
                    return null;
                }
            }
        }

        public static string StrConv(string str,bool isToWide)
        {
            if (string.IsNullOrEmpty(str)) { return str; }
            VbStrConv strconv = isToWide ? VbStrConv.Wide : VbStrConv.Narrow;

            Int32 len_spec_str = Regex.Matches(str, "\\?").Count;

            string result = Strings.StrConv(str, strconv, 0x0411);//  日本語

            Int32 len_spec_strConv = Regex.Matches(result, "\\?").Count;

            if (len_spec_strConv > len_spec_str)
            {
                result = Strings.StrConv(str, strconv, 0x0804);//  0x0804 简体 //0x0404 繁体
            }

            return result;
        }
        public static string folderDialog()
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                dialog.Description = "エクセル出力をフォルダを選択します。";
                dialog.ShowNewFolderButton = false;
                dialog.RootFolder = Environment.SpecialFolder.Desktop;
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    return dialog.SelectedPath;
                }
            }
            return null;
        }
        public static string fileDialog(string filter)
        {
            if (string.IsNullOrEmpty(filter))
            {
                filter = "ファイル|*.*";
            }
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = filter;
            openFileDialog.RestoreDirectory = true;
            openFileDialog.FilterIndex = 1;
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            { 
                return openFileDialog.FileName;
            }
            return null;
        }
        public static string replaceSpace(string str)
        {
            if (string.IsNullOrEmpty(str)) { return null; }
            return str.Replace(" ", null).Replace("　", null);
        }
       
    }
}
