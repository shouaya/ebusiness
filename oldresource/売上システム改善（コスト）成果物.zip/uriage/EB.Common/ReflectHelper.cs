﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace EB.Common
{
    /// <summary>   
    ///  ウインドウを開く   
    /// </summary>   
    /// </summary>   
    public class ReflectionHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="strName">クラス名</param>
        /// <param name="AssemblyName"></param>
        /// <param name="isform"></param>
        public static void load(string strName, string AssemblyName, bool isshow)
        {
            try
            {
                int Index = strName.LastIndexOf(".");
                string FormName = strName.Substring(Index);

                string path = AssemblyName;
                string name = strName;
                Form doc = (Form)Assembly.Load(path).CreateInstance(name);
                doc.Top = 0;
                if (isshow)
                {
                    doc.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error(ex.ToString());
                string errorMessage = "エラーが発生しました。管理員に連絡してください。";
                throw (new Exception(errorMessage));
            }
        }
        public static void run(string assemblyName, string className, string methodName, object[] param)
        {
            try
            {
                string filepath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) +"\\"+ assemblyName;
                
                Assembly ass = Assembly.LoadFile(filepath);
                Type type = ass.GetType(className);
                MethodInfo method = type.GetMethod(methodName);
                method.Invoke(null, param); 
            }
            catch (Exception ex)
            {
                LogHelper.Error(ex.ToString());
                string errorMessage = "エラーが発生しました。管理員に連絡してください。";
                throw (new Exception(errorMessage));
            }
        }
    }

}
