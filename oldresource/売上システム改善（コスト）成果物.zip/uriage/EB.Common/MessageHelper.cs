﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Xml;
using System.Windows.Forms;

namespace EB.Common
{
    public class MessageHelper
    {
        static XmlDocument doc = null;

        /// <summary>
        /// XMLを読み込む
        /// </summary>
        private static void getXMLInstance()
        {
            doc = new XmlDocument();
            doc.Load("Config.xml");
        }

        /// <summary>
        /// MessageListファイルからIDでメッセージを取得する。
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static string GetMessagebyID(string id)
        {
            string message = string.Empty;

            if (doc == null) getXMLInstance();

            XmlElement elem = doc.GetElementById(id);
            message = elem.InnerText;

            return message;
        }

        /// <summary>
        /// 情報メッセージ
        /// </summary>
        /// <param name="message"></param>
        public static void ShowInforMessage(string message)
        {
            MessageBox.Show(message,"E-Business",MessageBoxButtons.OK ,MessageBoxIcon.Information);
        }
        public static void ShowinforMessageByID(string id)
        {
            string message = GetMessagebyID(id);
            MessageBox.Show(message, "E-Business", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public static void ShowinforMessageByID(string id, string para)
        {
            string message = GetMessagebyID(id);
            message = string.Format(message, para);
            MessageBox.Show(message, "E-Business", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        /// <summary>
        /// エラーメッセージ
        /// </summary>
        /// <param name="message"></param>
        public static void ShowErrorMessage(string message)
        {
            MessageBox.Show(message, "E-Business", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        public static void ShowErrorMessageByID(string id)
        {
            string message = GetMessagebyID(id);
            MessageBox.Show(message, "E-Business", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static DialogResult ShowConfirmMessage(string id)
        {
            string message = GetMessagebyID(id);
            return MessageBox.Show(message, "E-Business", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        }
        public static DialogResult ShowConfirmMessage(string id, string para)
        {
            string message = GetMessagebyID(id);
            message = string.Format(message, para);
            return MessageBox.Show(message, "E-Business", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        }

        public static DialogResult ShowDeleteConfirmMessage()
        {
            string message = GetMessagebyID("EB2001");
            return MessageBox.Show(message, "E-Business", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        }

        public static DialogResult ShowCloseConfirmMessage()
        {
            string message = GetMessagebyID("EB2002");
            return  MessageBox.Show(message, "E-Business", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        }

    }
}
