﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using OfficeOpenXml.Style;
using OfficeOpenXml;

namespace EB.Common
{
    public class OpenXML
    {
        /// <summary>
        /// sheet内容を設定します（帳票類）
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="sheetIndex"></param>
        /// <param name="excelData"></param>
        public static void fillExcel(string filename,Int32 sheetIndex, CommonExcelModel excelData)
        {
            ExcelPackage package = getExcelPackage(filename);
            ExcelWorksheet worksheet;
            if (package.Workbook.Worksheets.Count >= sheetIndex)
            {
                worksheet = package.Workbook.Worksheets[sheetIndex];
            }
            else
            {
                worksheet = package.Workbook.Worksheets.Add(CommonHandler.GetMd5(DateTime.Now.ToString()));
            }
            fillExcel(worksheet, excelData);
            save(package);

        }
        /// <summary>
        /// sheet内容を設定します（帳票類）
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="sheetName"></param>
        /// <param name="excelData"></param>
        public static void fillExcel(string filename, string sheetName, CommonExcelModel excelData)
        {
            ExcelPackage package = getExcelPackage(filename);
            ExcelWorksheet worksheet = package.Workbook.Worksheets[sheetName];
            if (worksheet == null)
            {
                worksheet = package.Workbook.Worksheets.Add(sheetName);
            }
            fillExcel(worksheet, excelData);
            save(package);
        }

        private static ExcelPackage getExcelPackage(string filename)
        {
            FileInfo newFile = new FileInfo(filename);
            return new ExcelPackage(newFile);
        }
        /// <summary>
        /// sheet内容を設定する処理（帳票類）
        /// </summary>
        /// <param name="worksheet"></param>
        /// <param name="excelData"></param>
        private static void fillExcel(ExcelWorksheet worksheet, CommonExcelModel excelData)
        {
            excelData.cellModel.ForEach(delegate(ExcelCellModel cell){
                worksheet.Cells[cell.row, cell.col].Value = cell.value;
            });
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="package"></param>
        private static void save(ExcelPackage package)
        {
            //worksheet.Cells.AutoFitColumns(0);  //Autofit columns for all cells

            // set some document properties
            package.Workbook.Properties.Title = "売上";
            package.Workbook.Properties.Author = "Hikaru";
            package.Workbook.Properties.Comments = "売上システムー管理台帳";

            // set some extended property values
            package.Workbook.Properties.Company = "E-Business Inc.";

            // set some custom property values
            package.Workbook.Properties.SetCustomPropertyValue("Checked by", "Hikaru");
            package.Workbook.Properties.SetCustomPropertyValue("AssemblyName", "EB.Menu");
            // save our new workbook and we are done!
            package.Save();
        }
        /// <summary>
        /// cellを取得
        /// </summary>
        /// <param name="worksheet"></param>
        /// <param name="position"></param>
        /// <returns></returns>
        private string getCellValue(ExcelWorksheet worksheet, Int32 row, Int32 col)
        {
            //ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
            object val = worksheet.Cells[row, col].Value;
            if (val != null)
            {
                return val.ToString();
            }
            return "";
        }
    }
    /// <summary>
    /// ExcelModel
    /// </summary>
    public class CommonExcelModel{
        public List<ExcelCellModel> cellModel = new List<ExcelCellModel>();
        /// <summary>
        /// 追加
        /// </summary>
        /// <param name="cell"></param>
        public void addCell(ExcelCellModel cell){
            if (this.getCell(cell.row,cell.col) == null)
            {
                this.cellModel.Add(cell);
            }
        }
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="cell"></param>
        public void updateCell(ExcelCellModel cell){
            this.clearCell(cell.row, cell.col);
            this.addCell(cell);
        }
        /// <summary>
        /// cellを空白にします
        /// </summary>
        /// <param name="position"></param>
        public void clearCell(Int32 row, Int32 col)
        {
            ExcelCellModel cell = this.getCell(row, col);
            if(cell!=null){
                this.cellModel.Remove(cell);
            }
        }
        /// <summary>
        /// 指定のcellを取得
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public ExcelCellModel getCell(Int32 row, Int32 col)
        {
            return this.cellModel.Find(delegate(ExcelCellModel cell)
            {
                if (cell.row == row && cell.col == col)
                {
                    return true;
                }
                return false;
            });
        }
    }
    /// <summary>
    /// RowModel
    /// </summary>
    public class ExcelRowModel
    {
        public Int32 row;
        //List<ExcelCellModel> cell;
    }
    /// <summary>
    /// CellModel
    /// </summary>
    public class ExcelCellModel
    {
        public Int32 row;
        public Int32 col;
        public string value;
    }
}
