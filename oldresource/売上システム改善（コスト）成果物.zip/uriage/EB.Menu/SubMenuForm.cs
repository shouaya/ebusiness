﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.Common;

namespace EB.Menu
{
    public partial class SubMenuForm : DialogForm
    {
        #region 初期化
        public SubMenuForm()
        {
            InitializeComponent();
        }

        #endregion

        #region 画面動作
        /// <summary>
        /// 社員一覧
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEmployeeList_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Master.EmployeeListForm", "EB.Master", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 会社情報
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCompanyInfor_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Master.CompanyInforForm", "EB.Master", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 顧客様一覧
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCustomerList_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Master.CustomerListForm", "EB.Master", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 顧客様一覧
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEmployeeIDMerge_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Master.EmployeeIDMergeForm", "EB.Master", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 見積登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEstimationRegister_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Estimation.EstimationAddForm", "EB.Estimation", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 見積修正削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRegisterModify_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Estimation.EstimationModifyForm", "EB.Estimation", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 仕入先情報の登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSiiresakiRegister_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Master.SiiresakiAddForm", "EB.Master", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

    }
}
