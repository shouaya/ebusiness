﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.Common;
using MySql.Data.MySqlClient;
using EB.DBAcess;
namespace EB.Menu
{
    public partial class MainMenuForm : Form
    {
        #region 初期化
        public MainMenuForm()
        {
            this.checkUpdate();
            this.Icon = Properties.Resources.logo;
            this.Hide();
            new Login(() => { 
                this.Show(); 
                InitializeComponent();
            }).ShowDialog();
        }
        #endregion

        #region 画面動作
        /// <summary>
        /// 自動更新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void checkUpdate()
        {
            try
            {
                string updatePatch = "EB.Update.patch";
                string updateExe = "EB.Update.exe";
                if (System.IO.File.Exists(updatePatch))
                {
                    System.IO.File.Delete(updateExe);
                    System.IO.File.Move(updatePatch, updateExe);
                }
                ReflectionHelper.run(updateExe, "EB.Update.Api", "start", null);
            }
            catch //(Exception ex)
            {
                //CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 売上登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSalesRegister_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Sales.SalesAddForm", "EB.Sales", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);              
            }
        }
        /// <summary>
        /// 売上修正削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSalesModify_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Sales.SalesModifyForm", "EB.Sales", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 請求書作成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBillCreate_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Sales.BillSpecifyForm", "EB.Sales", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 契約書登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnContractRegister_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Contract.ContractAddForm", "EB.Contract", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 契約書修正削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnContractModify_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Contract.ContractModifyForm", "EB.Contract", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 入金登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReceiveRegister_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Receive.ReceiveAddForm", "EB.Receive", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 入金修正登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReceiveModify_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Receive.ReceiveModifyForm", "EB.Receive", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 契約一覧
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnContractList_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Report.ContractListForm", "EB.Report", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 売上一覧
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSalesList_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Report.SalesListForm", "EB.Report", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 入金一覧
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReceiveList_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Report.ReceiveListForm", "EB.Report", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// 債務債権一覧
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFinanceList_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Finance.FinanceListForm", "EB.Finance", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex); 
            }
        }
        /// <summary>
        /// サブメニュー
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSubMenu_Click(object sender, EventArgs e)
        {
            SubMenuForm sub = new SubMenuForm();
            sub.ShowDialog();
        }
        /// <summary>
        /// 閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    ReflectionHelper.CreateForm("EB.Master.EmployeeWorkCareerForm", "EB.Master", this);
        //}

        private void btnContractLedger_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Contract.ContractLedgerForm", "EB.Contract", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        private void btnWorkCareer_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Master.EmployeeWorkCareerForm", "EB.Master", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        private void btnCustomerTotal_Click(object sender, EventArgs e)
        {
            try
            {
                ReflectionHelper.load("EB.Master.CustomerTotalForm", "EB.Master", true);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        



    }
}
