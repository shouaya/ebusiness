﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.Common;
using EB.DBAcess;

namespace EB.Menu
{
    public partial class Login : Form
    {
        public delegate void CallbackDelegate();
        private CallbackDelegate _callback;

        public Login(CallbackDelegate callback)
        {
            this.Icon = Properties.Resources.logo;
            this._callback = callback;
            InitializeComponent();
        }
        /// <summary>
        /// 初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Login_Load(object sender, EventArgs e)
        {
            string machineCode = CommonHandler.GetMachineCode();

            this.login_pccode.Visible = false;
            this.login_input.Visible = false;

            this.pccode_textbox.Text = machineCode;

            ThreadPoolHelper.StartThread(this,
                () => { return BL_PcCodeMaster.GetInstance().IsHavePcCodeMaster(machineCode); },
                (obj) =>
                {
                    Boolean isAllow = (Boolean)obj;
                    this.login_pccode.Visible = !isAllow;
                    this.login_input.Visible = isAllow;
                    this.login_textbox_userid.Select();
                }
            );
        }
        /// <summary>
        /// 閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// ログイン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void login_submit_Click(object sender, EventArgs e)
        {
            string str_userid = this.login_textbox_userid.Text;
            string str_password = this.login_textbox_password.Text;
            if (string.IsNullOrEmpty(str_userid))
            {
                MessageHelper.ShowinforMessageByID("EB0002", "ユーザID");//ユーザIDを正しく入力してください。
                return;
            }
            if (string.IsNullOrEmpty(str_password))
            {
                MessageHelper.ShowinforMessageByID("EB0002", "パスワード");//パスワードを正しく入力してください。
                return;
            }
            this.login_textbox_userid.Enabled = false;
            this.login_textbox_password.Enabled = false;

            str_password = CommonHandler.GetMd5(str_password);
            //this.login_textbox_userid.Text = str_password;

            ThreadPoolHelper.StartThread(this,
                () => { return BL_User.GetInstance().IsHaveUser(str_userid, str_password); },
                (isValidate) => {
                    if ((Boolean)isValidate)
                    {
                        this._callback();
                        this.Close();
                    }
                    else
                    {
                        this.login_textbox_userid.Enabled = true;
                        this.login_textbox_password.Enabled = true;
                        MessageHelper.ShowinforMessageByID("EB0009", "ユーザID、また、パスワード");//ユーザID、また、パスワードが間違っています。
                    }
                }
                );
        }
        /// <summary>
        /// Enter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void _KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.login_submit_Click(this.login_submit, null); 
            }

        }
    }
}
