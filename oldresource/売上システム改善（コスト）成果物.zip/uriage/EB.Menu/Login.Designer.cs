﻿namespace EB.Menu
{
    partial class Login
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.login_header = new System.Windows.Forms.Panel();
            this.login_title = new System.Windows.Forms.Label();
            this.login_content = new System.Windows.Forms.Panel();
            this.login_input = new System.Windows.Forms.Panel();
            this.login_close_input = new System.Windows.Forms.Button();
            this.login_submit = new System.Windows.Forms.Button();
            this.login_textbox_password = new System.Windows.Forms.TextBox();
            this.login_label_password = new System.Windows.Forms.Label();
            this.login_textbox_userid = new System.Windows.Forms.TextBox();
            this.login_label_userid = new System.Windows.Forms.Label();
            this.login_pccode = new System.Windows.Forms.Panel();
            this.btn_close_pccode = new System.Windows.Forms.Button();
            this.pccode_textbox = new System.Windows.Forms.TextBox();
            this.pccode_label = new System.Windows.Forms.Label();
            this.pccode_message = new System.Windows.Forms.Label();
            this.login_header.SuspendLayout();
            this.login_content.SuspendLayout();
            this.login_input.SuspendLayout();
            this.login_pccode.SuspendLayout();
            this.SuspendLayout();
            // 
            // login_header
            // 
            this.login_header.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.login_header.Controls.Add(this.login_title);
            this.login_header.Dock = System.Windows.Forms.DockStyle.Top;
            this.login_header.Location = new System.Drawing.Point(0, 0);
            this.login_header.Name = "login_header";
            this.login_header.Size = new System.Drawing.Size(433, 60);
            this.login_header.TabIndex = 0;
            // 
            // login_title
            // 
            this.login_title.AutoSize = true;
            this.login_title.Font = new System.Drawing.Font("MS UI Gothic", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.login_title.Location = new System.Drawing.Point(88, 13);
            this.login_title.Name = "login_title";
            this.login_title.Size = new System.Drawing.Size(259, 34);
            this.login_title.TabIndex = 0;
            this.login_title.Text = "売上管理システム";
            // 
            // login_content
            // 
            this.login_content.BackColor = System.Drawing.Color.White;
            this.login_content.Controls.Add(this.login_input);
            this.login_content.Controls.Add(this.login_pccode);
            this.login_content.Dock = System.Windows.Forms.DockStyle.Fill;
            this.login_content.Location = new System.Drawing.Point(0, 60);
            this.login_content.Name = "login_content";
            this.login_content.Size = new System.Drawing.Size(433, 206);
            this.login_content.TabIndex = 1;
            // 
            // login_input
            // 
            this.login_input.Controls.Add(this.login_close_input);
            this.login_input.Controls.Add(this.login_submit);
            this.login_input.Controls.Add(this.login_textbox_password);
            this.login_input.Controls.Add(this.login_label_password);
            this.login_input.Controls.Add(this.login_textbox_userid);
            this.login_input.Controls.Add(this.login_label_userid);
            this.login_input.Location = new System.Drawing.Point(30, 27);
            this.login_input.Name = "login_input";
            this.login_input.Size = new System.Drawing.Size(375, 150);
            this.login_input.TabIndex = 1;
            this.login_input.Visible = false;
            // 
            // login_close_input
            // 
            this.login_close_input.Location = new System.Drawing.Point(213, 111);
            this.login_close_input.Name = "login_close_input";
            this.login_close_input.Size = new System.Drawing.Size(75, 23);
            this.login_close_input.TabIndex = 5;
            this.login_close_input.Text = "閉じる";
            this.login_close_input.UseVisualStyleBackColor = true;
            this.login_close_input.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // login_submit
            // 
            this.login_submit.Location = new System.Drawing.Point(50, 111);
            this.login_submit.Name = "login_submit";
            this.login_submit.Size = new System.Drawing.Size(75, 23);
            this.login_submit.TabIndex = 4;
            this.login_submit.Text = "ログイン";
            this.login_submit.UseVisualStyleBackColor = true;
            this.login_submit.Click += new System.EventHandler(this.login_submit_Click);
            // 
            // login_textbox_password
            // 
            this.login_textbox_password.Location = new System.Drawing.Point(134, 63);
            this.login_textbox_password.Name = "login_textbox_password";
            this.login_textbox_password.PasswordChar = '*';
            this.login_textbox_password.Size = new System.Drawing.Size(154, 19);
            this.login_textbox_password.TabIndex = 3;
            this.login_textbox_password.KeyDown += new System.Windows.Forms.KeyEventHandler(this._KeyDown);
            // 
            // login_label_password
            // 
            this.login_label_password.AutoSize = true;
            this.login_label_password.Location = new System.Drawing.Point(50, 71);
            this.login_label_password.Name = "login_label_password";
            this.login_label_password.Size = new System.Drawing.Size(52, 12);
            this.login_label_password.TabIndex = 2;
            this.login_label_password.Text = "パスワード";
            // 
            // login_textbox_userid
            // 
            this.login_textbox_userid.Location = new System.Drawing.Point(134, 21);
            this.login_textbox_userid.Name = "login_textbox_userid";
            this.login_textbox_userid.Size = new System.Drawing.Size(154, 19);
            this.login_textbox_userid.TabIndex = 1;
            this.login_textbox_userid.KeyDown += new System.Windows.Forms.KeyEventHandler(this._KeyDown);
            // 
            // login_label_userid
            // 
            this.login_label_userid.AutoSize = true;
            this.login_label_userid.Location = new System.Drawing.Point(50, 29);
            this.login_label_userid.Name = "login_label_userid";
            this.login_label_userid.Size = new System.Drawing.Size(46, 12);
            this.login_label_userid.TabIndex = 0;
            this.login_label_userid.Text = "ユーザID";
            // 
            // login_pccode
            // 
            this.login_pccode.Controls.Add(this.btn_close_pccode);
            this.login_pccode.Controls.Add(this.pccode_textbox);
            this.login_pccode.Controls.Add(this.pccode_label);
            this.login_pccode.Controls.Add(this.pccode_message);
            this.login_pccode.Location = new System.Drawing.Point(30, 27);
            this.login_pccode.Name = "login_pccode";
            this.login_pccode.Size = new System.Drawing.Size(375, 150);
            this.login_pccode.TabIndex = 0;
            // 
            // btn_close_pccode
            // 
            this.btn_close_pccode.Location = new System.Drawing.Point(161, 111);
            this.btn_close_pccode.Name = "btn_close_pccode";
            this.btn_close_pccode.Size = new System.Drawing.Size(75, 23);
            this.btn_close_pccode.TabIndex = 3;
            this.btn_close_pccode.Text = "閉じる";
            this.btn_close_pccode.UseVisualStyleBackColor = true;
            this.btn_close_pccode.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // pccode_textbox
            // 
            this.pccode_textbox.Location = new System.Drawing.Point(75, 67);
            this.pccode_textbox.Name = "pccode_textbox";
            this.pccode_textbox.ReadOnly = true;
            this.pccode_textbox.Size = new System.Drawing.Size(273, 19);
            this.pccode_textbox.TabIndex = 2;
            // 
            // pccode_label
            // 
            this.pccode_label.AutoSize = true;
            this.pccode_label.Location = new System.Drawing.Point(13, 70);
            this.pccode_label.Name = "pccode_label";
            this.pccode_label.Size = new System.Drawing.Size(56, 12);
            this.pccode_label.TabIndex = 1;
            this.pccode_label.Text = "端末コード";
            // 
            // pccode_message
            // 
            this.pccode_message.AutoSize = true;
            this.pccode_message.Location = new System.Drawing.Point(48, 13);
            this.pccode_message.Name = "pccode_message";
            this.pccode_message.Size = new System.Drawing.Size(287, 12);
            this.pccode_message.TabIndex = 0;
            this.pccode_message.Text = "セキュリティ保護のため、このコンピュータでは利用できません。";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 266);
            this.ControlBox = false;
            this.Controls.Add(this.login_content);
            this.Controls.Add(this.login_header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Login";
            this.Text = "ログイン";
            this.Load += new System.EventHandler(this.Login_Load);
            this.login_header.ResumeLayout(false);
            this.login_header.PerformLayout();
            this.login_content.ResumeLayout(false);
            this.login_input.ResumeLayout(false);
            this.login_input.PerformLayout();
            this.login_pccode.ResumeLayout(false);
            this.login_pccode.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel login_header;
        private System.Windows.Forms.Label login_title;
        private System.Windows.Forms.Panel login_content;
        private System.Windows.Forms.Panel login_input;
        private System.Windows.Forms.Panel login_pccode;
        private System.Windows.Forms.Label pccode_message;
        private System.Windows.Forms.Button btn_close_pccode;
        private System.Windows.Forms.TextBox pccode_textbox;
        private System.Windows.Forms.Label pccode_label;
        private System.Windows.Forms.Button login_close_input;
        private System.Windows.Forms.Button login_submit;
        private System.Windows.Forms.TextBox login_textbox_password;
        private System.Windows.Forms.Label login_label_password;
        private System.Windows.Forms.TextBox login_textbox_userid;
        private System.Windows.Forms.Label login_label_userid;
    }
}