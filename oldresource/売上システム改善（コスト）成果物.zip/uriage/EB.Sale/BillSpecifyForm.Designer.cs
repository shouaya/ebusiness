﻿namespace EB.Sales
{
    partial class BillSpecifyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreateBill = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.txtPostCode = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.Label();
            this.txtCompanyName = new System.Windows.Forms.Label();
            this.txtTel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cobRoundMothod = new System.Windows.Forms.ComboBox();
            this.rdoPrintAll = new System.Windows.Forms.RadioButton();
            this.rdoPrintOne = new System.Windows.Forms.RadioButton();
            this.cobMonth = new System.Windows.Forms.ComboBox();
            this.cobYear = new System.Windows.Forms.ComboBox();
            this.dgvCustomer = new System.Windows.Forms.DataGridView();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillFlag = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dgvSale = new System.Windows.Forms.DataGridView();
            this.ContractID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaleNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaleID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinishBillFlag = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.OrderNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentSite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.cobTaxRate = new System.Windows.Forms.ComboBox();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.cobCustomerID = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSale)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(636, 459);
            // 
            // btnCreateBill
            // 
            this.btnCreateBill.Location = new System.Drawing.Point(457, 459);
            this.btnCreateBill.Name = "btnCreateBill";
            this.btnCreateBill.Size = new System.Drawing.Size(135, 23);
            this.btnCreateBill.TabIndex = 190;
            this.btnCreateBill.Text = "請求書作成";
            this.btnCreateBill.UseVisualStyleBackColor = true;
            this.btnCreateBill.Click += new System.EventHandler(this.btnCreateBill_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(229, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 174;
            this.label2.Text = "月";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(145, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 12);
            this.label1.TabIndex = 175;
            this.label1.Text = "年";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(19, 8);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(234, 12);
            this.label36.TabIndex = 176;
            this.label36.Text = "請求書を発行します。年と日を指定してください。";
            // 
            // txtPostCode
            // 
            this.txtPostCode.AutoSize = true;
            this.txtPostCode.Location = new System.Drawing.Point(374, 5);
            this.txtPostCode.Name = "txtPostCode";
            this.txtPostCode.Size = new System.Drawing.Size(54, 12);
            this.txtPostCode.TabIndex = 192;
            this.txtPostCode.Text = "PostCode";
            // 
            // txtAddress
            // 
            this.txtAddress.AutoSize = true;
            this.txtAddress.Location = new System.Drawing.Point(374, 22);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(47, 12);
            this.txtAddress.TabIndex = 192;
            this.txtAddress.Text = "Address";
            // 
            // txtCompanyName
            // 
            this.txtCompanyName.AutoSize = true;
            this.txtCompanyName.Location = new System.Drawing.Point(374, 38);
            this.txtCompanyName.Name = "txtCompanyName";
            this.txtCompanyName.Size = new System.Drawing.Size(81, 12);
            this.txtCompanyName.TabIndex = 192;
            this.txtCompanyName.Text = "CompanyName";
            // 
            // txtTel
            // 
            this.txtTel.AutoSize = true;
            this.txtTel.Location = new System.Drawing.Point(374, 56);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(21, 12);
            this.txtTel.TabIndex = 192;
            this.txtTel.Text = "Tel";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(183, 12);
            this.label9.TabIndex = 192;
            this.label9.Text = "消費税の計算方法を選択してください";
            this.label9.UseMnemonic = false;
            // 
            // cobRoundMothod
            // 
            this.cobRoundMothod.DisplayMember = "CodeName";
            this.cobRoundMothod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobRoundMothod.FormattingEnabled = true;
            this.cobRoundMothod.Location = new System.Drawing.Point(247, 82);
            this.cobRoundMothod.Name = "cobRoundMothod";
            this.cobRoundMothod.Size = new System.Drawing.Size(97, 20);
            this.cobRoundMothod.TabIndex = 178;
            this.cobRoundMothod.ValueMember = "CodeID";
            // 
            // rdoPrintAll
            // 
            this.rdoPrintAll.AutoSize = true;
            this.rdoPrintAll.Location = new System.Drawing.Point(46, 463);
            this.rdoPrintAll.Name = "rdoPrintAll";
            this.rdoPrintAll.Size = new System.Drawing.Size(71, 16);
            this.rdoPrintAll.TabIndex = 405;
            this.rdoPrintAll.Text = "一括請求";
            this.rdoPrintAll.UseVisualStyleBackColor = true;
            // 
            // rdoPrintOne
            // 
            this.rdoPrintOne.AutoSize = true;
            this.rdoPrintOne.Checked = true;
            this.rdoPrintOne.Location = new System.Drawing.Point(131, 463);
            this.rdoPrintOne.Name = "rdoPrintOne";
            this.rdoPrintOne.Size = new System.Drawing.Size(71, 16);
            this.rdoPrintOne.TabIndex = 405;
            this.rdoPrintOne.TabStop = true;
            this.rdoPrintOne.Text = "注文書別";
            this.rdoPrintOne.UseVisualStyleBackColor = true;
            // 
            // cobMonth
            // 
            this.cobMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobMonth.FormattingEnabled = true;
            this.cobMonth.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.cobMonth.Location = new System.Drawing.Point(166, 29);
            this.cobMonth.Name = "cobMonth";
            this.cobMonth.Size = new System.Drawing.Size(57, 20);
            this.cobMonth.TabIndex = 407;
            this.cobMonth.SelectionChangeCommitted += new System.EventHandler(this.cobMonth_SelectionChangeCommitted);
            // 
            // cobYear
            // 
            this.cobYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobYear.FormattingEnabled = true;
            this.cobYear.Items.AddRange(new object[] {
            "2020",
            "2019",
            "2018",
            "2017",
            "2016",
            "2015",
            "2014",
            "2013",
            "2012",
            "2011",
            "2010",
            "2009",
            "2008"});
            this.cobYear.Location = new System.Drawing.Point(55, 29);
            this.cobYear.Name = "cobYear";
            this.cobYear.Size = new System.Drawing.Size(84, 20);
            this.cobYear.TabIndex = 406;
            this.cobYear.SelectionChangeCommitted += new System.EventHandler(this.cobMonth_SelectionChangeCommitted);
            // 
            // dgvCustomer
            // 
            this.dgvCustomer.AllowUserToAddRows = false;
            this.dgvCustomer.AllowUserToDeleteRows = false;
            this.dgvCustomer.AllowUserToOrderColumns = true;
            this.dgvCustomer.AllowUserToResizeRows = false;
            this.dgvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CustomerID,
            this.CustomerName,
            this.BillFlag});
            this.dgvCustomer.Location = new System.Drawing.Point(18, 112);
            this.dgvCustomer.MultiSelect = false;
            this.dgvCustomer.Name = "dgvCustomer";
            this.dgvCustomer.ReadOnly = true;
            this.dgvCustomer.RowHeadersVisible = false;
            this.dgvCustomer.RowTemplate.Height = 23;
            this.dgvCustomer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCustomer.Size = new System.Drawing.Size(693, 131);
            this.dgvCustomer.TabIndex = 408;
            this.dgvCustomer.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCustomer_RowEnter);
            // 
            // CustomerID
            // 
            this.CustomerID.DataPropertyName = "CustomerID";
            this.CustomerID.HeaderText = "顧客ID";
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.ReadOnly = true;
            this.CustomerID.Visible = false;
            // 
            // CustomerName
            // 
            this.CustomerName.DataPropertyName = "CustomerName";
            this.CustomerName.HeaderText = "顧客";
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.ReadOnly = true;
            this.CustomerName.Width = 300;
            // 
            // BillFlag
            // 
            this.BillFlag.DataPropertyName = "BillFlag";
            this.BillFlag.FalseValue = "0";
            this.BillFlag.HeaderText = "請求書発行状態";
            this.BillFlag.Name = "BillFlag";
            this.BillFlag.ReadOnly = true;
            this.BillFlag.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.BillFlag.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.BillFlag.TrueValue = "1";
            this.BillFlag.Width = 300;
            // 
            // dgvSale
            // 
            this.dgvSale.AllowUserToAddRows = false;
            this.dgvSale.AllowUserToDeleteRows = false;
            this.dgvSale.AllowUserToOrderColumns = true;
            this.dgvSale.AllowUserToResizeRows = false;
            this.dgvSale.AutoGenerateColumns = false;
            this.dgvSale.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSale.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ContractID,
            this.SaleNo,
            this.ContractNo,
            this.ContractName,
            this.StartDate,
            this.EndDate,
            this.SaleID,
            this.BillNo,
            this.FinishBillFlag,
            this.OrderNo,
            this.OrderDate,
            this.PaymentSite});
            this.dgvSale.Location = new System.Drawing.Point(18, 256);
            this.dgvSale.MultiSelect = false;
            this.dgvSale.Name = "dgvSale";
            this.dgvSale.ReadOnly = true;
            this.dgvSale.RowHeadersVisible = false;
            this.dgvSale.RowTemplate.Height = 23;
            this.dgvSale.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSale.Size = new System.Drawing.Size(693, 183);
            this.dgvSale.TabIndex = 409;
            // 
            // ContractID
            // 
            this.ContractID.DataPropertyName = "ContractID";
            this.ContractID.HeaderText = "契約ID";
            this.ContractID.Name = "ContractID";
            this.ContractID.ReadOnly = true;
            this.ContractID.Visible = false;
            // 
            // SaleNo
            // 
            this.SaleNo.DataPropertyName = "SaleNo";
            this.SaleNo.HeaderText = "売上番号";
            this.SaleNo.Name = "SaleNo";
            this.SaleNo.ReadOnly = true;
            // 
            // ContractNo
            // 
            this.ContractNo.DataPropertyName = "ContractNo";
            this.ContractNo.HeaderText = "契約番号";
            this.ContractNo.Name = "ContractNo";
            this.ContractNo.ReadOnly = true;
            // 
            // ContractName
            // 
            this.ContractName.DataPropertyName = "ContractName";
            this.ContractName.HeaderText = "件名";
            this.ContractName.Name = "ContractName";
            this.ContractName.ReadOnly = true;
            // 
            // StartDate
            // 
            this.StartDate.DataPropertyName = "StartDate";
            this.StartDate.HeaderText = "開始日";
            this.StartDate.Name = "StartDate";
            this.StartDate.ReadOnly = true;
            // 
            // EndDate
            // 
            this.EndDate.DataPropertyName = "EndDate";
            this.EndDate.HeaderText = "終了日";
            this.EndDate.Name = "EndDate";
            this.EndDate.ReadOnly = true;
            // 
            // SaleID
            // 
            this.SaleID.DataPropertyName = "SaleID";
            this.SaleID.HeaderText = "売上ID";
            this.SaleID.Name = "SaleID";
            this.SaleID.ReadOnly = true;
            // 
            // BillNo
            // 
            this.BillNo.DataPropertyName = "BillNo";
            this.BillNo.HeaderText = "請求書番号";
            this.BillNo.Name = "BillNo";
            this.BillNo.ReadOnly = true;
            // 
            // FinishBillFlag
            // 
            this.FinishBillFlag.DataPropertyName = "BillFlag";
            this.FinishBillFlag.FalseValue = "0";
            this.FinishBillFlag.HeaderText = "発行状態";
            this.FinishBillFlag.Name = "FinishBillFlag";
            this.FinishBillFlag.ReadOnly = true;
            this.FinishBillFlag.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.FinishBillFlag.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.FinishBillFlag.TrueValue = "1";
            // 
            // OrderNo
            // 
            this.OrderNo.DataPropertyName = "OrderNo";
            this.OrderNo.HeaderText = "注文番号";
            this.OrderNo.Name = "OrderNo";
            this.OrderNo.ReadOnly = true;
            this.OrderNo.Visible = false;
            // 
            // OrderDate
            // 
            this.OrderDate.DataPropertyName = "OrderDate";
            this.OrderDate.HeaderText = "注文日";
            this.OrderDate.Name = "OrderDate";
            this.OrderDate.ReadOnly = true;
            this.OrderDate.Visible = false;
            // 
            // PaymentSite
            // 
            this.PaymentSite.DataPropertyName = "PaymentSite";
            this.PaymentSite.HeaderText = "支払サイト";
            this.PaymentSite.Name = "PaymentSite";
            this.PaymentSite.ReadOnly = true;
            this.PaymentSite.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(374, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 410;
            this.label3.Text = "税率";
            this.label3.UseMnemonic = false;
            // 
            // cobTaxRate
            // 
            this.cobTaxRate.DisplayMember = "CodeName";
            this.cobTaxRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobTaxRate.FormattingEnabled = true;
            this.cobTaxRate.Items.AddRange(new object[] {
            "5%",
            "8%"});
            this.cobTaxRate.Location = new System.Drawing.Point(457, 82);
            this.cobTaxRate.Name = "cobTaxRate";
            this.cobTaxRate.Size = new System.Drawing.Size(97, 20);
            this.cobTaxRate.TabIndex = 411;
            this.cobTaxRate.ValueMember = "CodeID";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(247, 58);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(97, 19);
            this.txtCustomerName.TabIndex = 414;
            this.txtCustomerName.KeyDown += new System.Windows.Forms.KeyEventHandler(this._KeyDown);
            // 
            // cobCustomerID
            // 
            this.cobCustomerID.DisplayMember = "CustomerName";
            this.cobCustomerID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobCustomerID.Location = new System.Drawing.Point(55, 57);
            this.cobCustomerID.Name = "cobCustomerID";
            this.cobCustomerID.Size = new System.Drawing.Size(186, 20);
            this.cobCustomerID.TabIndex = 413;
            this.cobCustomerID.ValueMember = "CustomerID";
            this.cobCustomerID.SelectionChangeCommitted += new System.EventHandler(this.cobMonth_SelectionChangeCommitted);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 412;
            this.label4.Text = "顧客";
            // 
            // BillSpecifyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(726, 496);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.cobCustomerID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cobTaxRate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgvSale);
            this.Controls.Add(this.dgvCustomer);
            this.Controls.Add(this.cobMonth);
            this.Controls.Add(this.cobYear);
            this.Controls.Add(this.rdoPrintOne);
            this.Controls.Add(this.rdoPrintAll);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtTel);
            this.Controls.Add(this.txtCompanyName);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtPostCode);
            this.Controls.Add(this.btnCreateBill);
            this.Controls.Add(this.cobRoundMothod);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label36);
            this.Name = "BillSpecifyForm";
            this.Text = "請求書の指定";
            this.Load += new System.EventHandler(this.BillSpecifyForm_Load);
            this.Controls.SetChildIndex(this.label36, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.cobRoundMothod, 0);
            this.Controls.SetChildIndex(this.btnCreateBill, 0);
            this.Controls.SetChildIndex(this.txtPostCode, 0);
            this.Controls.SetChildIndex(this.txtAddress, 0);
            this.Controls.SetChildIndex(this.txtCompanyName, 0);
            this.Controls.SetChildIndex(this.txtTel, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.rdoPrintAll, 0);
            this.Controls.SetChildIndex(this.rdoPrintOne, 0);
            this.Controls.SetChildIndex(this.cobYear, 0);
            this.Controls.SetChildIndex(this.cobMonth, 0);
            this.Controls.SetChildIndex(this.dgvCustomer, 0);
            this.Controls.SetChildIndex(this.dgvSale, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.cobTaxRate, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.cobCustomerID, 0);
            this.Controls.SetChildIndex(this.txtCustomerName, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSale)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCreateBill;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label txtPostCode;
        private System.Windows.Forms.Label txtAddress;
        private System.Windows.Forms.Label txtCompanyName;
        private System.Windows.Forms.Label txtTel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cobRoundMothod;
        private System.Windows.Forms.RadioButton rdoPrintAll;
        private System.Windows.Forms.RadioButton rdoPrintOne;
        private System.Windows.Forms.ComboBox cobMonth;
        private System.Windows.Forms.ComboBox cobYear;
        private System.Windows.Forms.DataGridView dgvCustomer;
        private System.Windows.Forms.DataGridView dgvSale;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewCheckBoxColumn BillFlag;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractID;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaleNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractName;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaleID;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillNo;
        private System.Windows.Forms.DataGridViewCheckBoxColumn FinishBillFlag;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentSite;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cobTaxRate;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.ComboBox cobCustomerID;
        private System.Windows.Forms.Label label4;
    }
}