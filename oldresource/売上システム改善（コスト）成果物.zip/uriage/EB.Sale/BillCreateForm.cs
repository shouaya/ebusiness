﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;

namespace EB.Sales
{
    public partial class BillCreateForm : DialogForm
    {
        public class Parameters
        {
            public IF_Company _Company = new IF_Company();
            public IF_Customer _Customer = new IF_Customer();
            //public int _selectRow=-1;//整理中
            //public DataTable _dgvSale;//整理中
        }

        public Parameters _para = new Parameters();
        public decimal PARA_TaxRate = 0.08m;//税率
        public string PARA_Method = string.Empty;//消費税計算方法

        #region 初期化
        public string PARA_BillType = string.Empty;//請求書区分

        public string PARA_SaleID = string.Empty;//売上ID
        public string PARA_SaleDate = string.Empty;//売上年月
        public string PARA_BillNo = string.Empty;//請求書番号

        public string PARA_StartDate = string.Empty;//開始日
        public string PARA_EndDate = string.Empty;//終了日
        public string PARA_OrderNo = string.Empty;//注文番号
        public string PARA_OrderDate = string.Empty;//注文日
        public string PARA_ContractName = string.Empty;//契約名
        public string PARA_PaymentSite = string.Empty;//支払日

        public BillCreateForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BillCreateForm_Load(object sender, EventArgs e)
        {
            try
            {
                ThreadPoolHelper.StartThread(this,
                    () =>
                    {
                        BL_BankInfo bl = BL_BankInfo.GetInstance();
                        return bl.SelectAll();
                    },
                    (obj) =>
                    {
                        this.cobBankInfo.DataSource = obj;
                        //Reset画面項目
                        resetAll();
                        //データ取得
                        loadData();
                    }

                    );


            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// Reset画面項目
        /// </summary>
        private void resetAll()
        {
            BL_Bill blBill = BL_Bill.GetInstance();
            if (!string.IsNullOrEmpty(PARA_BillNo))
            {
                DataTable dt = blBill.SelectBill(PARA_BillNo);
                this.cobBankInfo.SelectedValue = dt.Rows[0]["BankInfoId"].ToString();
            }
        }

        /// <summary>
        /// データ取得
        /// </summary>
        private void loadData()
        {
            BL_Bill blBill = BL_Bill.GetInstance();
            string yymm = PARA_SaleDate.Substring(2).Replace("/", string.Empty);
            txtBillDate.Value = DateTime.Parse(DateTime.Now.ToString("yyyy/MM")).AddDays(-1);
            if (string.IsNullOrEmpty(PARA_BillNo))
            {
                txtBillNo.Text = blBill.SelectMaxBillNo(yymm);//請求書番号
            }
            else
            {
                txtBillNo.Text = PARA_BillNo;
                DataTable dt_Sale = BL_Sale.GetInstance().SelectSaleAmount(PARA_BillNo);//控除一覧データを取得
                if( dt_Sale.Rows.Count > 0 )
                {
                    string item_Deduction = dt_Sale.Rows[0]["DeductionItem"].ToString(); //DBから控除項目を画面にセット
                    string cost_Deduction = dt_Sale.Rows[0]["DeductionCost"].ToString(); //DBから控除額を画面にセット
                    txtDeductionItem.Text = item_Deduction;
                    txtDeductionCost.Text = string.IsNullOrEmpty(item_Deduction)&&(string.IsNullOrEmpty(cost_Deduction)||cost_Deduction.Trim()=="0")?"":cost_Deduction;
                    txtDeductionNotes.Text = dt_Sale.Rows[0]["DeductionNotes"].ToString(); //DBから控除備考を画面にセット

                    string item_Additional = dt_Sale.Rows[0]["AdditionalItem"].ToString(); //DBから追加項目を画面にセット
                    string cost_Additional = dt_Sale.Rows[0]["AdditionalCost"].ToString(); //DBから追加額を画面にセット
                    txtAdditionalItem.Text = item_Additional;
                    txtAdditionalCost.Text = string.IsNullOrEmpty(item_Additional) && (string.IsNullOrEmpty(cost_Additional) || cost_Additional.Trim() == "0") ? "" : cost_Additional;
                    txtAdditionalNotes.Text = dt_Sale.Rows[0]["AdditionalNotes"].ToString(); //DBから追加備考を画面にセット
                }
            }

            //Header情報設定
            PARA_StartDate = CommonHandler.GetPrintFormat(PARA_StartDate);
            PARA_EndDate = CommonHandler.GetPrintFormat(PARA_EndDate);
            PARA_PaymentSite = CommonHandler.GetPrintFormat(PARA_PaymentSite);
            PARA_OrderDate = CommonHandler.GetPrintFormat(PARA_OrderDate);

            txtCustomerName.Text = this._para._Customer.CustomerName + "   御中";
            txtStartDate.Text = PARA_StartDate;//開始日
            txtEndDate.Text = PARA_EndDate;//終了日    
            txtOrderNo.Text = PARA_OrderNo;//注文番号
            txtOrderDate.Text = PARA_OrderDate;//注文日
            txtContractName.Text = PARA_ContractName;//契約名
            txtPaymentSite.Text = PARA_PaymentSite;//支払日
            txtPostCode.Text = this._para._Customer.PostCode;
            txtTel.Text = this._para._Customer.Tel;
            txtAddress.Text = this._para._Customer.Address1 + this._para._Customer.Address2;
            txtCompanyName.Text = this._para._Customer.CustomerName;



            //企業情報を設定

            if (this._para._Company.CompanyID > 0)
            {
                txtCompanyName.Text = this._para._Company.CompanyName;
                txtPostCode.Text = this._para._Company.PostCode;
                txtAddress.Text = this._para._Company.Address;
                txtTel.Text = this._para._Company.Tel;
            }
            //明細情報をセットする
            BL_Sale blSale = BL_Sale.GetInstance();
            DataTable dt = null ;

            //一括請求
            if (PARA_BillType == "1")
            {
                dt = blSale.SelectSaleForBillDetail(this._para._Customer.CustomerID.ToString(), PARA_SaleDate, string.Empty);
            }

            //別請求
            if (PARA_BillType == "2")
            {
                dt = blSale.SelectSaleForBillDetail(this._para._Customer.CustomerID.ToString(), PARA_SaleDate, PARA_SaleID);
            }

            dgvDetail.AutoGenerateColumns = false;
            dgvDetail.DataSource = dt;

            //総請求金額計算
            caculateTotalAmount();
        }

        private void caculateTotalAmount()
        {
            decimal totalAmount = 0;//総請求金額
            decimal deductionCost = CommonHandler.ToDecimal(txtDeductionCost.Text);//控除額
            decimal additionalCost = CommonHandler.ToDecimal(txtAdditionalCost.Text);//追加額
            for (int i = 0; i < dgvDetail.Rows.Count; i++)
            {
                totalAmount = totalAmount + CommonHandler.ToDecimal(dgvDetail.Rows[i].Cells["Amount"].Value);//金額
            }

            decimal taxRate = CommonHandler.ToDecimal(PARA_TaxRate+1.00m);
            //なし
            if (PARA_Method == "1")
            {
                totalAmount = totalAmount + additionalCost - deductionCost;
            }
            //四捨五入
            if (PARA_Method == "2")
            {
                totalAmount = (totalAmount * taxRate) + additionalCost - deductionCost;
                totalAmount = Math.Round(totalAmount, 0, MidpointRounding.AwayFromZero);
            }
            //小数点以下切り捨て
            if (PARA_Method == "3")
            {
                totalAmount = Math.Floor((totalAmount * taxRate) + additionalCost - deductionCost);
            }

            txtBillAmountTotal.Text = totalAmount.ToString("C");
        }
        #endregion

        #region 画面動作
        /// <summary>
        /// 印刷
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (!isValidCheck()) return;

                if (MessageHelper.ShowConfirmMessage("EB0019", "この請求書を作成・更新します") == DialogResult.Yes)
                {
                    //登録処理
                    proceessRegister();
                    //Print印刷
                    printBillDoc(PARA_Method);

                    MessageHelper.ShowinforMessageByID("EB0012", "プレビュー");

                    this.Close();
                }
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheck()
        {
            //if (cobCustomerID.SelectedIndex == -1)
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "顧客");
            //    return false;
            //}
            //if (string.IsNullOrEmpty(txtOrderNo.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "注文番号");
            //    return false;
            //}
            return true;
        }

        /// <summary>
        /// 登録処理
        /// </summary>
        private void proceessRegister()
        {
            IF_Bill entity = new IF_Bill();

            entity.BillNo = txtBillNo.Text;//請求書番号
            entity.CustomerID = this._para._Customer.CustomerID;//顧客ID
            entity.BillAmountTotal = CommonHandler.ToDecimal(txtBillAmountTotal.Text);//請求総金額
            entity.BillDate = txtBillDate.Text;//請求日
            entity.DeductionItem = txtDeductionItem.Text;//控除項目
            entity.DeductionCost = CommonHandler.ToDecimal(txtDeductionCost.Text);//控除額
            entity.DeductionNotes = txtDeductionNotes.Text;//控除備考
            entity.AdditionalItem = txtAdditionalItem.Text;//追加項目
            entity.AdditionalCost = CommonHandler.ToDecimal(txtAdditionalCost.Text);//追加額
            entity.AdditionalNotes = txtAdditionalNotes.Text;//追加備考
            entity.DeleteFlg = "0";//削除フラグ
            entity.BankInfoId = this.cobBankInfo.SelectedValue.ToString();

            BL_Bill bl = BL_Bill.GetInstance();

            if (string.IsNullOrEmpty(PARA_BillNo))
            {
                bl.RegisterAll(entity, PARA_SaleID);
            }
            else
            {
                bl.UpdateAll(entity);
            }

        }
        /// <summary>
        /// 印刷
        /// </summary>
        private void printBillDoc(string PARA_Method)
        {
            ExcelProvider excel = new ExcelProvider();
            try
            {

                string filePath = Application.StartupPath;
                decimal decSum = 0;
                decimal decTax = 0;

                excel.OpenExcelFile(filePath + "\\Template");

                this.dgvDetail.Sort(this.EmployeeID, ListSortDirection.Ascending);

                //一括請求
                if (PARA_BillType == "1")
                {
                    excel.SetCurrentSheet(1);

                    excel.setValue(3, 2, "〒" + this._para._Customer.PostCode);//郵便番号
                    excel.setValue(4, 2, this._para._Customer.Address1);//住所1
                    excel.setValue(5, 2, this._para._Customer.Address2);//住所2
                    excel.setValue(6, 2, "Tel: " + this._para._Customer.Tel);//Tel


                    excel.setValue(14, 5, PARA_StartDate + "～" + PARA_EndDate);//作業期間
                    excel.setValue(16, 5, PARA_PaymentSite);//支払日;
                    excel.setValue(8, 2, this._para._Customer.CustomerName + "御中");//顧客名
                    excel.setValue(16, 5, PARA_PaymentSite);//お支払い期限
                    excel.setValue(3, 15, txtBillNo.Text);//請求書番号

                    
                    string billdate = txtBillDate.Text;//発行日

                    billdate = billdate.Substring(0, 4) + "年" + billdate.Substring(5, 2) + "月" + billdate.Substring(8, 2) + "日";
                    excel.setValue(4, 15, billdate);//発行日

                    string billAmountTotal = txtBillAmountTotal.Text;
                    billAmountTotal = billAmountTotal + "円";
                    excel.setValue(12, 5, billAmountTotal);//御請求額

                    int startRow = 19;

                    for (int i = 0; i < dgvDetail.Rows.Count; i++)
                    {
                        string EmployeeName = CommonHandler.ToString(dgvDetail.Rows[i].Cells["EmployeeName"].Value);//項目
                        string Price = CommonHandler.ToString(dgvDetail.Rows[i].Cells["Price"].Value);//単価
                        string WorkTime = CommonHandler.ToString(dgvDetail.Rows[i].Cells["WorkTime"].Value);//時間
                        string Rate = CommonHandler.ToString(dgvDetail.Rows[i].Cells["Rate"].Value);//率
                        string MinHour = CommonHandler.ToString(dgvDetail.Rows[i].Cells["MinHour"].Value);//Min勤務
                        string MaxHour = CommonHandler.ToString(dgvDetail.Rows[i].Cells["MaxHour"].Value);//Max勤務
                        string OtherAmount = CommonHandler.ToString(dgvDetail.Rows[i].Cells["OtherAmount"].Value);//その他
                        string MinusUnitPrice = CommonHandler.ToString(dgvDetail.Rows[i].Cells["MinusUnitPrice"].Value);//減賃金
                        string PlusUnitPrice = CommonHandler.ToString(dgvDetail.Rows[i].Cells["PlusUnitPrice"].Value);//増賃金
                        string Amount = CommonHandler.ToString(dgvDetail.Rows[i].Cells["Amount"].Value);//金額

                        excel.setValue(startRow + i, 2, (i + 1).ToString());////番号
                        excel.setValue(startRow + i, 3, EmployeeName);////項目
                        excel.setValue(startRow + i, 8, Price);//単価
                        excel.setValue(startRow + i, 9, WorkTime);////時間
                        excel.setValue(startRow + i, 10, Rate);//率
                        excel.setValue(startRow + i, 11, MinHour + "/" + MaxHour);//Min勤務　Max勤務
                        excel.setValue(startRow + i, 14, OtherAmount);//その他
                        excel.setValue(startRow + i, 12, MinusUnitPrice);//減賃金
                        excel.setValue(startRow + i, 13, PlusUnitPrice);//増賃金
                        excel.setValue(startRow + i, 15, Amount);//金額

                        decSum = decSum + decimal.Parse(Amount); //小計

                    }

                }

                //別請求
                if (PARA_BillType == "2")
                {
                    excel.SetCurrentSheet(2);
                    excel.setValue(3, 2, "〒" + this._para._Customer.PostCode);//郵便番号
                    excel.setValue(4, 2, this._para._Customer.Address1);//住所1
                    excel.setValue(5, 2, this._para._Customer.Address2);//住所2
                    excel.setValue(6, 2, "Tel: " + this._para._Customer.Tel);//Tel

                    excel.setValue(14, 5, PARA_StartDate + "～" + PARA_EndDate);//作業期間
                    excel.setValue(8, 2, this._para._Customer.CustomerName + "御中");//顧客名
                    excel.setValue(16, 5, PARA_OrderNo);//注文番号
                    excel.setValue(18, 5, PARA_OrderDate);//注文日
                    excel.setValue(20, 5, PARA_ContractName);//契約件名
                    excel.setValue(22, 5, PARA_PaymentSite);//お支払い期限
                    excel.setValue(3, 15, txtBillNo.Text);//請求書番号
                    string billdate = txtBillDate.Text;//発行日
                    billdate = billdate.Substring(0, 4) + "年" + billdate.Substring(5, 2) + "月" + billdate.Substring(8, 2) + "日";
                    excel.setValue(4, 15, billdate);//発行日
                    excel.setValue(12, 5, txtBillAmountTotal.Text + "円");//御請求額

                    int startRow = 25;
                    
                    for (int i = 0; i < dgvDetail.Rows.Count; i++)
                    {
                        string EmployeeName = CommonHandler.ToString(dgvDetail.Rows[i].Cells["EmployeeName"].Value);//項目
                        string Price = CommonHandler.ToString(dgvDetail.Rows[i].Cells["Price"].Value);//単価
                        string WorkTime = CommonHandler.ToString(dgvDetail.Rows[i].Cells["WorkTime"].Value);//時間
                        string Rate = CommonHandler.ToString(dgvDetail.Rows[i].Cells["Rate"].Value);//率
                        string MinHour = CommonHandler.ToString(dgvDetail.Rows[i].Cells["MinHour"].Value);//Min勤務
                        string MaxHour = CommonHandler.ToString(dgvDetail.Rows[i].Cells["MaxHour"].Value);//Max勤務
                        string OtherAmount = CommonHandler.ToString(dgvDetail.Rows[i].Cells["OtherAmount"].Value);//その他
                        string MinusUnitPrice = CommonHandler.ToString(dgvDetail.Rows[i].Cells["MinusUnitPrice"].Value);//減賃金
                        string PlusUnitPrice = CommonHandler.ToString(dgvDetail.Rows[i].Cells["PlusUnitPrice"].Value);//増賃金
                        string Amount = CommonHandler.ToString(dgvDetail.Rows[i].Cells["Amount"].Value);//金額

                        excel.setValue(startRow + i, 2, (i + 1).ToString());////番号
                        excel.setValue(startRow + i, 3, EmployeeName);////項目
                        excel.setValue(startRow + i, 8, Price);//単価
                        excel.setValue(startRow + i, 9, WorkTime);////時間
                        excel.setValue(startRow + i, 10, Rate);//率
                        excel.setValue(startRow + i, 11, MinHour + "/" + MaxHour);//Min勤務　Max勤務
                        excel.setValue(startRow + i, 14, OtherAmount);//その他
                        excel.setValue(startRow + i, 12, MinusUnitPrice);//減賃金
                        excel.setValue(startRow + i, 13, PlusUnitPrice);//増賃金
                        excel.setValue(startRow + i, 15, Amount);//金額
                        decSum = decSum + decimal.Parse(Amount); //小計

                    }
                }

                //小計、消費税設定
                if (PARA_Method.Equals("2"))
                {
                    decTax = Math.Round(decSum * PARA_TaxRate);
                }
                if (PARA_Method.Equals("3"))
                {
                    decTax = Math.Truncate(decSum * PARA_TaxRate);
                }

                if (this._para._Company.CompanyID > 0)
                {
                    int startrow_Company = 10;
                    if (PARA_BillType == "1")
                    {
                        startrow_Company = 7;
                    }
                    else if (PARA_BillType == "2")
                    {
                        startrow_Company = 10;
                    }
                    excel.setValue(startrow_Company, 13, "〒" + this._para._Company.PostCode);
                    excel.setValue(startrow_Company + 1, 13, this._para._Company.Address);
                    excel.setValue(startrow_Company + 2, 13, this._para._Company.CompanyName);
                    excel.setValue(startrow_Company + 3, 13, "代表取締役　　" + this._para._Company.Representor);
                    excel.setValue(startrow_Company + 4, 13, "TEL：" + this._para._Company.Tel);
                }

                excel.setValue(45, 15, decSum.ToString());
                excel.setValue(46, 15, decTax.ToString());
                excel.setValue(47, 15, (decSum+decTax).ToString());

                //控除額追加額

                excel.setValue(49, 4, this.txtDeductionItem.Text.ToString());
                excel.setValue(50, 4, this.txtAdditionalItem.Text.ToString());
                //控除額追加額設定

                excel.setValue(49, 15, this.txtDeductionCost.Text.ToString());
                excel.setValue(50, 15, this.txtAdditionalCost.Text.ToString());
                //お振込銀行口座
                DataRowView ibi = (DataRowView)this.cobBankInfo.SelectedItem;
                excel.setValue(53, 3, ibi["BankName"].ToString());
                excel.setValue(54, 3, ibi["BankBranch"].ToString() + "（" + CommonHandler.StrConv( ibi["BankBranchCode"].ToString(),true)+"）");
                excel.setValue(55, 3, ibi["BankAccountType"].ToString() + "口座　" + CommonHandler.StrConv(ibi["BankAccountCode"].ToString(), true));
                excel.setValue(56, 3, "名義　　　　" + ibi["BankAccountHolderName"].ToString());


                excel.SaveAs(txtBillNo.Text);
                excel.SaveAsPdf(txtBillNo.Text);
                //excel.Print();
            }
            catch(Exception ex)
            {
                LogHelper.Error(ex.Message);
                throw (new EBException("印刷エラー"));
            }
            finally
            {
                excel.ReleaseExcel();
                excel.KillAllExcelApp();
            }
        }

        private void txtDeductionCost_TextAlignChanged(object sender, EventArgs e)
        {
            try
            {
                //総請求金額計算
                caculateTotalAmount();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        private void txtDeductionCost_TextChanged(object sender, EventArgs e)
        {
            try
            {
                //総請求金額計算
                caculateTotalAmount();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        private void txtAdditionalCost_TextChanged(object sender, EventArgs e)
        {
            try
            {
                //総請求金額計算
                caculateTotalAmount();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        #endregion





    }
}
