﻿namespace EB.Sales
{
    partial class BillCreateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPrint = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtStartDate = new System.Windows.Forms.Label();
            this.txtOrderNo = new System.Windows.Forms.Label();
            this.txtOrderDate = new System.Windows.Forms.Label();
            this.txtContractName = new System.Windows.Forms.Label();
            this.txtPaymentSite = new System.Windows.Forms.Label();
            this.txtBillNo = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtDeductionItem = new System.Windows.Forms.TextBox();
            this.txtAdditionalItem = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtAdditionalNotes = new System.Windows.Forms.TextBox();
            this.txtDeductionNotes = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.Label();
            this.txtCompanyName = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.Label();
            this.txtPostCode = new System.Windows.Forms.Label();
            this.txtBillDate = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dgvDetail = new System.Windows.Forms.DataGridView();
            this.txtEndDate = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtAdditionalCost = new EB.Common.NumericTextox();
            this.txtBillAmountTotal = new EB.Common.NumericTextox();
            this.txtDeductionCost = new EB.Common.NumericTextox();
            this.cobBankInfo = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WorkTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinHour = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxHour = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinusUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PlusUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetail)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(654, 479);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(517, 479);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(101, 23);
            this.btnPrint.TabIndex = 190;
            this.btnPrint.Text = "プレビュー";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 174;
            this.label2.Text = "御請求額";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 12);
            this.label1.TabIndex = 175;
            this.label1.Text = "下記の通りご請求申し上げます";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.AutoSize = true;
            this.txtCustomerName.Font = new System.Drawing.Font("MS UI Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtCustomerName.Location = new System.Drawing.Point(20, 14);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(88, 14);
            this.txtCustomerName.TabIndex = 176;
            this.txtCustomerName.Text = "顧客１　御中";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 12);
            this.label3.TabIndex = 192;
            this.label3.Text = "ご請求期間";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 192;
            this.label4.Text = "注文番号";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 192;
            this.label5.Text = "注文日";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 192;
            this.label6.Text = "契約件名";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 197);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 12);
            this.label7.TabIndex = 192;
            this.label7.Text = "お支払日";
            // 
            // txtStartDate
            // 
            this.txtStartDate.AutoSize = true;
            this.txtStartDate.Location = new System.Drawing.Point(106, 117);
            this.txtStartDate.Name = "txtStartDate";
            this.txtStartDate.Size = new System.Drawing.Size(29, 12);
            this.txtStartDate.TabIndex = 192;
            this.txtStartDate.Text = "toDo";
            // 
            // txtOrderNo
            // 
            this.txtOrderNo.AutoSize = true;
            this.txtOrderNo.Location = new System.Drawing.Point(106, 137);
            this.txtOrderNo.Name = "txtOrderNo";
            this.txtOrderNo.Size = new System.Drawing.Size(29, 12);
            this.txtOrderNo.TabIndex = 192;
            this.txtOrderNo.Text = "toDo";
            // 
            // txtOrderDate
            // 
            this.txtOrderDate.AutoSize = true;
            this.txtOrderDate.Location = new System.Drawing.Point(106, 157);
            this.txtOrderDate.Name = "txtOrderDate";
            this.txtOrderDate.Size = new System.Drawing.Size(29, 12);
            this.txtOrderDate.TabIndex = 192;
            this.txtOrderDate.Text = "toDo";
            // 
            // txtContractName
            // 
            this.txtContractName.AutoSize = true;
            this.txtContractName.Location = new System.Drawing.Point(106, 177);
            this.txtContractName.Name = "txtContractName";
            this.txtContractName.Size = new System.Drawing.Size(29, 12);
            this.txtContractName.TabIndex = 192;
            this.txtContractName.Text = "toDo";
            // 
            // txtPaymentSite
            // 
            this.txtPaymentSite.AutoSize = true;
            this.txtPaymentSite.Location = new System.Drawing.Point(106, 197);
            this.txtPaymentSite.Name = "txtPaymentSite";
            this.txtPaymentSite.Size = new System.Drawing.Size(29, 12);
            this.txtPaymentSite.TabIndex = 192;
            this.txtPaymentSite.Text = "toDo";
            // 
            // txtBillNo
            // 
            this.txtBillNo.Location = new System.Drawing.Point(619, 15);
            this.txtBillNo.Name = "txtBillNo";
            this.txtBillNo.ReadOnly = true;
            this.txtBillNo.Size = new System.Drawing.Size(110, 19);
            this.txtBillNo.TabIndex = 406;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(560, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 192;
            this.label19.Text = "請求番号";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(572, 47);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 12);
            this.label20.TabIndex = 192;
            this.label20.Text = "発行日";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(16, 427);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 192;
            this.label21.Text = "控除項目";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(14, 454);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 12);
            this.label22.TabIndex = 192;
            this.label22.Text = "追加項目";
            // 
            // txtDeductionItem
            // 
            this.txtDeductionItem.Location = new System.Drawing.Point(71, 424);
            this.txtDeductionItem.Name = "txtDeductionItem";
            this.txtDeductionItem.Size = new System.Drawing.Size(241, 19);
            this.txtDeductionItem.TabIndex = 406;
            // 
            // txtAdditionalItem
            // 
            this.txtAdditionalItem.Location = new System.Drawing.Point(71, 451);
            this.txtAdditionalItem.Name = "txtAdditionalItem";
            this.txtAdditionalItem.Size = new System.Drawing.Size(241, 19);
            this.txtAdditionalItem.TabIndex = 406;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(335, 429);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 12);
            this.label23.TabIndex = 192;
            this.label23.Text = "控除額";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(335, 454);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(41, 12);
            this.label24.TabIndex = 192;
            this.label24.Text = "追加額";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(515, 439);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 192;
            this.label25.Text = "備考";
            // 
            // txtAdditionalNotes
            // 
            this.txtAdditionalNotes.Location = new System.Drawing.Point(574, 451);
            this.txtAdditionalNotes.Name = "txtAdditionalNotes";
            this.txtAdditionalNotes.Size = new System.Drawing.Size(155, 19);
            this.txtAdditionalNotes.TabIndex = 406;
            // 
            // txtDeductionNotes
            // 
            this.txtDeductionNotes.Location = new System.Drawing.Point(574, 424);
            this.txtDeductionNotes.Name = "txtDeductionNotes";
            this.txtDeductionNotes.Size = new System.Drawing.Size(155, 19);
            this.txtDeductionNotes.TabIndex = 406;
            // 
            // txtTel
            // 
            this.txtTel.AutoSize = true;
            this.txtTel.Location = new System.Drawing.Point(429, 140);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(21, 12);
            this.txtTel.TabIndex = 409;
            this.txtTel.Text = "Tel";
            // 
            // txtCompanyName
            // 
            this.txtCompanyName.AutoSize = true;
            this.txtCompanyName.Location = new System.Drawing.Point(429, 122);
            this.txtCompanyName.Name = "txtCompanyName";
            this.txtCompanyName.Size = new System.Drawing.Size(81, 12);
            this.txtCompanyName.TabIndex = 410;
            this.txtCompanyName.Text = "CompanyName";
            // 
            // txtAddress
            // 
            this.txtAddress.AutoSize = true;
            this.txtAddress.Location = new System.Drawing.Point(429, 104);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(47, 12);
            this.txtAddress.TabIndex = 407;
            this.txtAddress.Text = "Address";
            // 
            // txtPostCode
            // 
            this.txtPostCode.AutoSize = true;
            this.txtPostCode.Location = new System.Drawing.Point(429, 86);
            this.txtPostCode.Name = "txtPostCode";
            this.txtPostCode.Size = new System.Drawing.Size(54, 12);
            this.txtPostCode.TabIndex = 408;
            this.txtPostCode.Text = "PostCode";
            // 
            // txtBillDate
            // 
            this.txtBillDate.CustomFormat = "yyyy/MM/dd";
            this.txtBillDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtBillDate.Location = new System.Drawing.Point(619, 42);
            this.txtBillDate.Name = "txtBillDate";
            this.txtBillDate.Size = new System.Drawing.Size(110, 19);
            this.txtBillDate.TabIndex = 411;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(197, 12);
            this.label9.TabIndex = 174;
            this.label9.Text = "――――――――――――――――";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(19, 32);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(245, 12);
            this.label16.TabIndex = 174;
            this.label16.Text = "――――――――――――――――――――";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 86);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(245, 12);
            this.label8.TabIndex = 174;
            this.label8.Text = "――――――――――――――――――――";
            // 
            // dgvDetail
            // 
            this.dgvDetail.AllowUserToAddRows = false;
            this.dgvDetail.AllowUserToDeleteRows = false;
            this.dgvDetail.AllowUserToOrderColumns = true;
            this.dgvDetail.AllowUserToResizeRows = false;
            this.dgvDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeID,
            this.EmployeeName,
            this.UnitName,
            this.Unit,
            this.Price,
            this.WorkTime,
            this.Rate,
            this.Quantity,
            this.MinHour,
            this.MaxHour,
            this.OtherAmount,
            this.MinusUnitPrice,
            this.PlusUnitPrice,
            this.Amount});
            this.dgvDetail.Location = new System.Drawing.Point(14, 224);
            this.dgvDetail.MultiSelect = false;
            this.dgvDetail.Name = "dgvDetail";
            this.dgvDetail.ReadOnly = true;
            this.dgvDetail.RowHeadersVisible = false;
            this.dgvDetail.RowTemplate.Height = 23;
            this.dgvDetail.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetail.Size = new System.Drawing.Size(717, 160);
            this.dgvDetail.TabIndex = 412;
            // 
            // txtEndDate
            // 
            this.txtEndDate.AutoSize = true;
            this.txtEndDate.Location = new System.Drawing.Point(248, 117);
            this.txtEndDate.Name = "txtEndDate";
            this.txtEndDate.Size = new System.Drawing.Size(29, 12);
            this.txtEndDate.TabIndex = 192;
            this.txtEndDate.Text = "toDo";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(208, 117);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 12);
            this.label12.TabIndex = 192;
            this.label12.Text = "～";
            // 
            // txtAdditionalCost
            // 
            this.txtAdditionalCost.AcceptsTab = true;
            this.txtAdditionalCost.Location = new System.Drawing.Point(382, 451);
            this.txtAdditionalCost.Name = "txtAdditionalCost";
            this.txtAdditionalCost.Precision = 0;
            this.txtAdditionalCost.SepratedChar = ',';
            this.txtAdditionalCost.Size = new System.Drawing.Size(83, 19);
            this.txtAdditionalCost.TabIndex = 413;
            this.txtAdditionalCost.Value = "";
            this.txtAdditionalCost.TextChanged += new System.EventHandler(this.txtAdditionalCost_TextChanged);
            // 
            // txtBillAmountTotal
            // 
            this.txtBillAmountTotal.AcceptsTab = true;
            this.txtBillAmountTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBillAmountTotal.Location = new System.Drawing.Point(95, 64);
            this.txtBillAmountTotal.Name = "txtBillAmountTotal";
            this.txtBillAmountTotal.Precision = 0;
            this.txtBillAmountTotal.ReadOnly = true;
            this.txtBillAmountTotal.SepratedChar = ',';
            this.txtBillAmountTotal.Size = new System.Drawing.Size(157, 19);
            this.txtBillAmountTotal.TabIndex = 413;
            this.txtBillAmountTotal.Value = "";
            // 
            // txtDeductionCost
            // 
            this.txtDeductionCost.AcceptsTab = true;
            this.txtDeductionCost.Location = new System.Drawing.Point(382, 426);
            this.txtDeductionCost.Name = "txtDeductionCost";
            this.txtDeductionCost.Precision = 0;
            this.txtDeductionCost.SepratedChar = ',';
            this.txtDeductionCost.Size = new System.Drawing.Size(83, 19);
            this.txtDeductionCost.TabIndex = 413;
            this.txtDeductionCost.Value = "";
            this.txtDeductionCost.TextChanged += new System.EventHandler(this.txtDeductionCost_TextChanged);
            // 
            // cobBankInfo
            // 
            this.cobBankInfo.DisplayMember = "BankName";
            this.cobBankInfo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobBankInfo.FormattingEnabled = true;
            this.cobBankInfo.Location = new System.Drawing.Point(97, 482);
            this.cobBankInfo.Name = "cobBankInfo";
            this.cobBankInfo.Size = new System.Drawing.Size(205, 20);
            this.cobBankInfo.TabIndex = 414;
            this.cobBankInfo.ValueMember = "BankInfoId";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 485);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 12);
            this.label10.TabIndex = 415;
            this.label10.Text = "振込銀行口座";
            // 
            // EmployeeID
            // 
            this.EmployeeID.DataPropertyName = "EmployeeID";
            this.EmployeeID.HeaderText = "技術者ID";
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.ReadOnly = true;
            this.EmployeeID.Visible = false;
            // 
            // EmployeeName
            // 
            this.EmployeeName.DataPropertyName = "EmployeeName";
            this.EmployeeName.HeaderText = "技術者";
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.ReadOnly = true;
            // 
            // UnitName
            // 
            this.UnitName.DataPropertyName = "UnitName";
            this.UnitName.HeaderText = "単位";
            this.UnitName.Name = "UnitName";
            this.UnitName.ReadOnly = true;
            this.UnitName.Visible = false;
            this.UnitName.Width = 60;
            // 
            // Unit
            // 
            this.Unit.DataPropertyName = "Unit";
            this.Unit.HeaderText = "単位ID";
            this.Unit.Name = "Unit";
            this.Unit.ReadOnly = true;
            this.Unit.Visible = false;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            this.Price.HeaderText = "単価";
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 80;
            // 
            // WorkTime
            // 
            this.WorkTime.DataPropertyName = "WorkTime";
            this.WorkTime.HeaderText = "作業時間";
            this.WorkTime.Name = "WorkTime";
            this.WorkTime.ReadOnly = true;
            // 
            // Rate
            // 
            this.Rate.DataPropertyName = "Rate";
            this.Rate.HeaderText = "率";
            this.Rate.Name = "Rate";
            this.Rate.ReadOnly = true;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "数量(廃棄)";
            this.Quantity.Name = "Quantity";
            this.Quantity.ReadOnly = true;
            this.Quantity.Visible = false;
            this.Quantity.Width = 80;
            // 
            // MinHour
            // 
            this.MinHour.DataPropertyName = "MinHour";
            this.MinHour.HeaderText = "MinH";
            this.MinHour.Name = "MinHour";
            this.MinHour.ReadOnly = true;
            this.MinHour.Width = 80;
            // 
            // MaxHour
            // 
            this.MaxHour.DataPropertyName = "MaxHour";
            this.MaxHour.HeaderText = "MaxH";
            this.MaxHour.Name = "MaxHour";
            this.MaxHour.ReadOnly = true;
            this.MaxHour.Width = 80;
            // 
            // OtherAmount
            // 
            this.OtherAmount.DataPropertyName = "OtherAmount";
            this.OtherAmount.HeaderText = "その他";
            this.OtherAmount.Name = "OtherAmount";
            this.OtherAmount.ReadOnly = true;
            // 
            // MinusUnitPrice
            // 
            this.MinusUnitPrice.DataPropertyName = "MinusUnitPrice";
            this.MinusUnitPrice.HeaderText = "減賃金";
            this.MinusUnitPrice.Name = "MinusUnitPrice";
            this.MinusUnitPrice.ReadOnly = true;
            this.MinusUnitPrice.Width = 80;
            // 
            // PlusUnitPrice
            // 
            this.PlusUnitPrice.DataPropertyName = "PlusUnitPrice";
            this.PlusUnitPrice.HeaderText = "増賃金";
            this.PlusUnitPrice.Name = "PlusUnitPrice";
            this.PlusUnitPrice.ReadOnly = true;
            this.PlusUnitPrice.Width = 80;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            this.Amount.HeaderText = "金額";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            // 
            // BillCreateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(748, 514);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cobBankInfo);
            this.Controls.Add(this.txtAdditionalCost);
            this.Controls.Add(this.txtBillAmountTotal);
            this.Controls.Add(this.txtDeductionCost);
            this.Controls.Add(this.dgvDetail);
            this.Controls.Add(this.txtBillDate);
            this.Controls.Add(this.txtTel);
            this.Controls.Add(this.txtCompanyName);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtPostCode);
            this.Controls.Add(this.txtAdditionalItem);
            this.Controls.Add(this.txtDeductionNotes);
            this.Controls.Add(this.txtAdditionalNotes);
            this.Controls.Add(this.txtDeductionItem);
            this.Controls.Add(this.txtBillNo);
            this.Controls.Add(this.txtPaymentSite);
            this.Controls.Add(this.txtContractName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.txtOrderDate);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtOrderNo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtEndDate);
            this.Controls.Add(this.txtStartDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCustomerName);
            this.Name = "BillCreateForm";
            this.Text = "請求書";
            this.Load += new System.EventHandler(this.BillCreateForm_Load);
            this.Controls.SetChildIndex(this.txtCustomerName, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label16, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.btnPrint, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.txtStartDate, 0);
            this.Controls.SetChildIndex(this.txtEndDate, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.txtOrderNo, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.label19, 0);
            this.Controls.SetChildIndex(this.label21, 0);
            this.Controls.SetChildIndex(this.label23, 0);
            this.Controls.SetChildIndex(this.label20, 0);
            this.Controls.SetChildIndex(this.label25, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label22, 0);
            this.Controls.SetChildIndex(this.txtOrderDate, 0);
            this.Controls.SetChildIndex(this.label24, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.txtContractName, 0);
            this.Controls.SetChildIndex(this.txtPaymentSite, 0);
            this.Controls.SetChildIndex(this.txtBillNo, 0);
            this.Controls.SetChildIndex(this.txtDeductionItem, 0);
            this.Controls.SetChildIndex(this.txtAdditionalNotes, 0);
            this.Controls.SetChildIndex(this.txtDeductionNotes, 0);
            this.Controls.SetChildIndex(this.txtAdditionalItem, 0);
            this.Controls.SetChildIndex(this.txtPostCode, 0);
            this.Controls.SetChildIndex(this.txtAddress, 0);
            this.Controls.SetChildIndex(this.txtCompanyName, 0);
            this.Controls.SetChildIndex(this.txtTel, 0);
            this.Controls.SetChildIndex(this.txtBillDate, 0);
            this.Controls.SetChildIndex(this.dgvDetail, 0);
            this.Controls.SetChildIndex(this.txtDeductionCost, 0);
            this.Controls.SetChildIndex(this.txtBillAmountTotal, 0);
            this.Controls.SetChildIndex(this.txtAdditionalCost, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.cobBankInfo, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetail)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label txtCustomerName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label txtStartDate;
        private System.Windows.Forms.Label txtOrderNo;
        private System.Windows.Forms.Label txtOrderDate;
        private System.Windows.Forms.Label txtContractName;
        private System.Windows.Forms.Label txtPaymentSite;
        private System.Windows.Forms.TextBox txtBillNo;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtDeductionItem;
        private System.Windows.Forms.TextBox txtAdditionalItem;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtAdditionalNotes;
        private System.Windows.Forms.TextBox txtDeductionNotes;
        private System.Windows.Forms.Label txtTel;
        private System.Windows.Forms.Label txtCompanyName;
        private System.Windows.Forms.Label txtAddress;
        private System.Windows.Forms.Label txtPostCode;
        private System.Windows.Forms.DateTimePicker txtBillDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dgvDetail;
        private Common.NumericTextox txtDeductionCost;
        private Common.NumericTextox txtAdditionalCost;
        private Common.NumericTextox txtBillAmountTotal;
        private System.Windows.Forms.Label txtEndDate;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cobBankInfo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn WorkTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinHour;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaxHour;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinusUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn PlusUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
    }
}