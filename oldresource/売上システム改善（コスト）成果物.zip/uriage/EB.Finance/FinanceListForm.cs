﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.Common;

namespace EB.Finance
{
    public partial class FinanceListForm : DialogForm
    {
        public FinanceListForm()
        {
            InitializeComponent();
        }
    }
}
