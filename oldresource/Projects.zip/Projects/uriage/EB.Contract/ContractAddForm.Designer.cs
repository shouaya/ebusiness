﻿namespace EB.Contract
{
    partial class ContractAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cobEmployType = new System.Windows.Forms.ComboBox();
            this.txtStartDate = new System.Windows.Forms.DateTimePicker();
            this.txtEndDate = new System.Windows.Forms.DateTimePicker();
            this.txtOrderDate = new System.Windows.Forms.DateTimePicker();
            this.cobCustomerID = new System.Windows.Forms.ComboBox();
            this.btnDetailAdd = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnDetailRegister = new System.Windows.Forms.Button();
            this.btnDetailDelete = new System.Windows.Forms.Button();
            this.btnDetailUpdate = new System.Windows.Forms.Button();
            this.dgvContract = new System.Windows.Forms.DataGridView();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinHour = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxHour = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinusUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PlusUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cobUnit = new System.Windows.Forms.ComboBox();
            this.cobEmployeeID = new System.Windows.Forms.ComboBox();
            this.cobSalesman2 = new System.Windows.Forms.ComboBox();
            this.cobSalesman1 = new System.Windows.Forms.ComboBox();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.txtContent = new System.Windows.Forms.TextBox();
            this.txtFilter = new System.Windows.Forms.TextBox();
            this.txtContractName = new System.Windows.Forms.TextBox();
            this.txtOrderNo = new System.Windows.Forms.TextBox();
            this.txtContractNo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtContractDate = new System.Windows.Forms.DateTimePicker();
            this.cobPaymentType = new System.Windows.Forms.ComboBox();
            this.cobPaymentDay = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtMinHour = new EB.Common.NumericTextox();
            this.txtDetailAmount = new EB.Common.NumericTextox();
            this.txtPlusUnitPrice = new EB.Common.NumericTextox();
            this.txtMinusUnitPrice = new EB.Common.NumericTextox();
            this.txtMaxHour = new EB.Common.NumericTextox();
            this.txtQuantity = new EB.Common.NumericTextox();
            this.txtAmount = new EB.Common.NumericTextox();
            this.txtPrice = new EB.Common.NumericTextox();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.chk_isnotregist = new System.Windows.Forms.CheckBox();
            this.dtp_notregist = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txtContractCount = new EB.Common.NumericTextox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContract)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(631, 499);
            this.btnClose.TabIndex = 104;
            // 
            // cobEmployType
            // 
            this.cobEmployType.DisplayMember = "CodeName";
            this.cobEmployType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobEmployType.FormattingEnabled = true;
            this.cobEmployType.Location = new System.Drawing.Point(76, 125);
            this.cobEmployType.Name = "cobEmployType";
            this.cobEmployType.Size = new System.Drawing.Size(247, 20);
            this.cobEmployType.TabIndex = 10;
            this.cobEmployType.ValueMember = "CodeID";
            // 
            // txtStartDate
            // 
            this.txtStartDate.CustomFormat = "yyyy/MM/dd";
            this.txtStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtStartDate.Location = new System.Drawing.Point(77, 101);
            this.txtStartDate.Name = "txtStartDate";
            this.txtStartDate.Size = new System.Drawing.Size(112, 19);
            this.txtStartDate.TabIndex = 8;
            // 
            // txtEndDate
            // 
            this.txtEndDate.CustomFormat = "yyyy/MM/dd";
            this.txtEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtEndDate.Location = new System.Drawing.Point(303, 99);
            this.txtEndDate.Name = "txtEndDate";
            this.txtEndDate.Size = new System.Drawing.Size(112, 19);
            this.txtEndDate.TabIndex = 9;
            // 
            // txtOrderDate
            // 
            this.txtOrderDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtOrderDate.Location = new System.Drawing.Point(391, 55);
            this.txtOrderDate.Name = "txtOrderDate";
            this.txtOrderDate.Size = new System.Drawing.Size(112, 19);
            this.txtOrderDate.TabIndex = 6;
            this.txtOrderDate.Value = new System.DateTime(1999, 9, 9, 16, 16, 0, 0);
            this.txtOrderDate.ValueChanged += new System.EventHandler(this.txtOrderDate_ValueChanged);
            // 
            // cobCustomerID
            // 
            this.cobCustomerID.DisplayMember = "CustomerName";
            this.cobCustomerID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobCustomerID.FormattingEnabled = true;
            this.cobCustomerID.Location = new System.Drawing.Point(76, 34);
            this.cobCustomerID.Name = "cobCustomerID";
            this.cobCustomerID.Size = new System.Drawing.Size(247, 20);
            this.cobCustomerID.TabIndex = 3;
            this.cobCustomerID.ValueMember = "CustomerID";
            this.cobCustomerID.SelectedIndexChanged += new System.EventHandler(this.cobCustomerID_SelectedIndexChanged);
            // 
            // btnDetailAdd
            // 
            this.btnDetailAdd.Location = new System.Drawing.Point(679, 214);
            this.btnDetailAdd.Name = "btnDetailAdd";
            this.btnDetailAdd.Size = new System.Drawing.Size(75, 23);
            this.btnDetailAdd.TabIndex = 27;
            this.btnDetailAdd.Text = "明細行追加";
            this.btnDetailAdd.UseVisualStyleBackColor = true;
            this.btnDetailAdd.Click += new System.EventHandler(this.btnDetailAdd_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(416, 499);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(75, 23);
            this.btnRegister.TabIndex = 32;
            this.btnRegister.Text = "登録";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnDetailRegister
            // 
            this.btnDetailRegister.Location = new System.Drawing.Point(130, 499);
            this.btnDetailRegister.Name = "btnDetailRegister";
            this.btnDetailRegister.Size = new System.Drawing.Size(115, 23);
            this.btnDetailRegister.TabIndex = 31;
            this.btnDetailRegister.Text = "明細行の修正登録";
            this.btnDetailRegister.UseVisualStyleBackColor = true;
            this.btnDetailRegister.Click += new System.EventHandler(this.btnDetailRegister_Click);
            // 
            // btnDetailDelete
            // 
            this.btnDetailDelete.Location = new System.Drawing.Point(204, 470);
            this.btnDetailDelete.Name = "btnDetailDelete";
            this.btnDetailDelete.Size = new System.Drawing.Size(144, 23);
            this.btnDetailDelete.TabIndex = 30;
            this.btnDetailDelete.Text = "明細行の削除";
            this.btnDetailDelete.UseVisualStyleBackColor = true;
            this.btnDetailDelete.Click += new System.EventHandler(this.btnDetailDelete_Click);
            // 
            // btnDetailUpdate
            // 
            this.btnDetailUpdate.Location = new System.Drawing.Point(40, 470);
            this.btnDetailUpdate.Name = "btnDetailUpdate";
            this.btnDetailUpdate.Size = new System.Drawing.Size(130, 23);
            this.btnDetailUpdate.TabIndex = 29;
            this.btnDetailUpdate.Text = "明細行の修正";
            this.btnDetailUpdate.UseVisualStyleBackColor = true;
            this.btnDetailUpdate.Click += new System.EventHandler(this.btnDetailUpdate_Click);
            // 
            // dgvContract
            // 
            this.dgvContract.AllowUserToAddRows = false;
            this.dgvContract.AllowUserToDeleteRows = false;
            this.dgvContract.AllowUserToOrderColumns = true;
            this.dgvContract.AllowUserToResizeRows = false;
            this.dgvContract.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContract.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeID,
            this.EmployeeName,
            this.UnitName,
            this.Unit,
            this.Price,
            this.Quantity,
            this.MinHour,
            this.MaxHour,
            this.MinusUnitPrice,
            this.PlusUnitPrice,
            this.Amount});
            this.dgvContract.Location = new System.Drawing.Point(26, 287);
            this.dgvContract.MultiSelect = false;
            this.dgvContract.Name = "dgvContract";
            this.dgvContract.ReadOnly = true;
            this.dgvContract.RowHeadersVisible = false;
            this.dgvContract.RowTemplate.Height = 23;
            this.dgvContract.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvContract.Size = new System.Drawing.Size(736, 179);
            this.dgvContract.TabIndex = 28;
            // 
            // EmployeeID
            // 
            this.EmployeeID.DataPropertyName = "EmployeeID";
            this.EmployeeID.HeaderText = "技術者ID";
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.ReadOnly = true;
            this.EmployeeID.Visible = false;
            // 
            // EmployeeName
            // 
            this.EmployeeName.DataPropertyName = "EmployeeName";
            this.EmployeeName.HeaderText = "技術者";
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.ReadOnly = true;
            // 
            // UnitName
            // 
            this.UnitName.DataPropertyName = "UnitName";
            this.UnitName.HeaderText = "単位";
            this.UnitName.Name = "UnitName";
            this.UnitName.ReadOnly = true;
            this.UnitName.Width = 60;
            // 
            // Unit
            // 
            this.Unit.DataPropertyName = "Unit";
            this.Unit.HeaderText = "単位ID";
            this.Unit.Name = "Unit";
            this.Unit.ReadOnly = true;
            this.Unit.Visible = false;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            this.Price.HeaderText = "単価";
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 80;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "数量";
            this.Quantity.Name = "Quantity";
            this.Quantity.ReadOnly = true;
            this.Quantity.Width = 80;
            // 
            // MinHour
            // 
            this.MinHour.DataPropertyName = "MinHour";
            this.MinHour.HeaderText = "Min勤務";
            this.MinHour.Name = "MinHour";
            this.MinHour.ReadOnly = true;
            this.MinHour.Width = 80;
            // 
            // MaxHour
            // 
            this.MaxHour.DataPropertyName = "MaxHour";
            this.MaxHour.HeaderText = "Max勤務";
            this.MaxHour.Name = "MaxHour";
            this.MaxHour.ReadOnly = true;
            this.MaxHour.Width = 80;
            // 
            // MinusUnitPrice
            // 
            this.MinusUnitPrice.DataPropertyName = "MinusUnitPrice";
            this.MinusUnitPrice.HeaderText = "減賃金";
            this.MinusUnitPrice.Name = "MinusUnitPrice";
            this.MinusUnitPrice.ReadOnly = true;
            this.MinusUnitPrice.Width = 80;
            // 
            // PlusUnitPrice
            // 
            this.PlusUnitPrice.DataPropertyName = "PlusUnitPrice";
            this.PlusUnitPrice.HeaderText = "増賃金";
            this.PlusUnitPrice.Name = "PlusUnitPrice";
            this.PlusUnitPrice.ReadOnly = true;
            this.PlusUnitPrice.Width = 80;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            this.Amount.HeaderText = "金額";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(703, 247);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 100;
            this.label14.Text = "金額";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(623, 247);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 99;
            this.label12.Text = "増賃金";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(557, 247);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 102;
            this.label11.Text = "減賃金";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(500, 247);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(34, 12);
            this.label21.TabIndex = 101;
            this.label21.Text = "MaxH";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(456, 247);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 12);
            this.label20.TabIndex = 98;
            this.label20.Text = "MinH";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(385, 247);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 94;
            this.label19.Text = "数量";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(295, 247);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 93;
            this.label18.Text = "単価";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(216, 247);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 96;
            this.label17.Text = "単位";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(36, 247);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 12);
            this.label26.TabIndex = 97;
            this.label26.Text = "技術者";
            // 
            // cobUnit
            // 
            this.cobUnit.DisplayMember = "CodeName";
            this.cobUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobUnit.FormattingEnabled = true;
            this.cobUnit.Location = new System.Drawing.Point(203, 264);
            this.cobUnit.Name = "cobUnit";
            this.cobUnit.Size = new System.Drawing.Size(61, 20);
            this.cobUnit.TabIndex = 20;
            this.cobUnit.ValueMember = "CodeID";
            // 
            // cobEmployeeID
            // 
            this.cobEmployeeID.DisplayMember = "EmployeeName";
            this.cobEmployeeID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobEmployeeID.FormattingEnabled = true;
            this.cobEmployeeID.Location = new System.Drawing.Point(76, 264);
            this.cobEmployeeID.Name = "cobEmployeeID";
            this.cobEmployeeID.Size = new System.Drawing.Size(122, 20);
            this.cobEmployeeID.TabIndex = 19;
            this.cobEmployeeID.ValueMember = "EmployeeID";
            this.cobEmployeeID.SelectionChangeCommitted += new System.EventHandler(this.cobEmployeeID_SelectionChangeCommitted);
            // 
            // cobSalesman2
            // 
            this.cobSalesman2.DisplayMember = "EmployeeName";
            this.cobSalesman2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobSalesman2.FormattingEnabled = true;
            this.cobSalesman2.Location = new System.Drawing.Point(170, 218);
            this.cobSalesman2.Name = "cobSalesman2";
            this.cobSalesman2.Size = new System.Drawing.Size(93, 20);
            this.cobSalesman2.TabIndex = 15;
            this.cobSalesman2.ValueMember = "EmployeeID";
            // 
            // cobSalesman1
            // 
            this.cobSalesman1.DisplayMember = "EmployeeName";
            this.cobSalesman1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobSalesman1.FormattingEnabled = true;
            this.cobSalesman1.Location = new System.Drawing.Point(76, 218);
            this.cobSalesman1.Name = "cobSalesman1";
            this.cobSalesman1.Size = new System.Drawing.Size(93, 20);
            this.cobSalesman1.TabIndex = 14;
            this.cobSalesman1.ValueMember = "EmployeeID";
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(76, 194);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(415, 19);
            this.txtNote.TabIndex = 13;
            // 
            // txtContent
            // 
            this.txtContent.Location = new System.Drawing.Point(76, 148);
            this.txtContent.Name = "txtContent";
            this.txtContent.Size = new System.Drawing.Size(415, 19);
            this.txtContent.TabIndex = 11;
            // 
            // txtFilter
            // 
            this.txtFilter.Location = new System.Drawing.Point(26, 265);
            this.txtFilter.Name = "txtFilter";
            this.txtFilter.Size = new System.Drawing.Size(44, 19);
            this.txtFilter.TabIndex = 18;
            this.txtFilter.TextChanged += new System.EventHandler(this.txtFilter_TextChanged);
            // 
            // txtContractName
            // 
            this.txtContractName.Location = new System.Drawing.Point(76, 78);
            this.txtContractName.Name = "txtContractName";
            this.txtContractName.Size = new System.Drawing.Size(415, 19);
            this.txtContractName.TabIndex = 7;
            // 
            // txtOrderNo
            // 
            this.txtOrderNo.Location = new System.Drawing.Point(76, 56);
            this.txtOrderNo.Name = "txtOrderNo";
            this.txtOrderNo.Size = new System.Drawing.Size(247, 19);
            this.txtOrderNo.TabIndex = 5;
            // 
            // txtContractNo
            // 
            this.txtContractNo.Location = new System.Drawing.Point(76, 10);
            this.txtContractNo.Name = "txtContractNo";
            this.txtContractNo.ReadOnly = true;
            this.txtContractNo.Size = new System.Drawing.Size(247, 19);
            this.txtContractNo.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 71;
            this.label5.Text = "注文番号";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 177);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 59;
            this.label10.Text = "契約金額";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 222);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 56;
            this.label13.Text = "営業担当";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(36, 130);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 54;
            this.label8.Text = "方式";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(258, 177);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 12);
            this.label24.TabIndex = 70;
            this.label24.Text = "円（税抜）";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 199);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 55;
            this.label9.Text = "備考";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(36, 154);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 68;
            this.label7.Text = "内容";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(456, 13);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(89, 12);
            this.label15.TabIndex = 65;
            this.label15.Text = "契約日（請負日）";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 64;
            this.label4.Text = "開始日";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(219, 104);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(17, 12);
            this.label22.TabIndex = 66;
            this.label22.Text = "～";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(258, 104);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(41, 12);
            this.label30.TabIndex = 63;
            this.label30.Text = "終了日";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(338, 60);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(41, 12);
            this.label29.TabIndex = 61;
            this.label29.Text = "契約日";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 60;
            this.label6.Text = "契約件名";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 67;
            this.label3.Text = "顧客";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 58;
            this.label2.Text = "契約番号";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(0, 22);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 12);
            this.label25.TabIndex = 58;
            this.label25.Text = "（請負番号）";
            // 
            // txtContractDate
            // 
            this.txtContractDate.CustomFormat = "yyyy/MM/dd";
            this.txtContractDate.Enabled = false;
            this.txtContractDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtContractDate.Location = new System.Drawing.Point(559, 9);
            this.txtContractDate.Name = "txtContractDate";
            this.txtContractDate.Size = new System.Drawing.Size(112, 19);
            this.txtContractDate.TabIndex = 2;
            // 
            // cobPaymentType
            // 
            this.cobPaymentType.DisplayMember = "CodeName";
            this.cobPaymentType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobPaymentType.FormattingEnabled = true;
            this.cobPaymentType.Location = new System.Drawing.Point(366, 219);
            this.cobPaymentType.Name = "cobPaymentType";
            this.cobPaymentType.Size = new System.Drawing.Size(93, 20);
            this.cobPaymentType.TabIndex = 16;
            this.cobPaymentType.ValueMember = "CodeID";
            // 
            // cobPaymentDay
            // 
            this.cobPaymentDay.DisplayMember = "CodeName";
            this.cobPaymentDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobPaymentDay.FormattingEnabled = true;
            this.cobPaymentDay.Location = new System.Drawing.Point(465, 219);
            this.cobPaymentDay.Name = "cobPaymentDay";
            this.cobPaymentDay.Size = new System.Drawing.Size(93, 20);
            this.cobPaymentDay.TabIndex = 17;
            this.cobPaymentDay.ValueMember = "CodeID";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(301, 229);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 12);
            this.label16.TabIndex = 282;
            this.label16.Text = "（末締）";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(301, 219);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 12);
            this.label23.TabIndex = 281;
            this.label23.Text = "支払サイト";
            // 
            // txtMinHour
            // 
            this.txtMinHour.AcceptsTab = true;
            this.txtMinHour.Location = new System.Drawing.Point(445, 263);
            this.txtMinHour.Name = "txtMinHour";
            this.txtMinHour.Precision = 2;
            this.txtMinHour.SepratedChar = ',';
            this.txtMinHour.Size = new System.Drawing.Size(44, 19);
            this.txtMinHour.TabIndex = 23;
            this.txtMinHour.Value = "";
            // 
            // txtDetailAmount
            // 
            this.txtDetailAmount.AcceptsTab = true;
            this.txtDetailAmount.Location = new System.Drawing.Point(679, 263);
            this.txtDetailAmount.Name = "txtDetailAmount";
            this.txtDetailAmount.Precision = 0;
            this.txtDetailAmount.ReadOnly = true;
            this.txtDetailAmount.SepratedChar = ',';
            this.txtDetailAmount.Size = new System.Drawing.Size(79, 19);
            this.txtDetailAmount.TabIndex = 283;
            this.txtDetailAmount.Value = "";
            // 
            // txtPlusUnitPrice
            // 
            this.txtPlusUnitPrice.AcceptsTab = true;
            this.txtPlusUnitPrice.Location = new System.Drawing.Point(613, 263);
            this.txtPlusUnitPrice.Name = "txtPlusUnitPrice";
            this.txtPlusUnitPrice.Precision = 0;
            this.txtPlusUnitPrice.SepratedChar = ',';
            this.txtPlusUnitPrice.Size = new System.Drawing.Size(61, 19);
            this.txtPlusUnitPrice.TabIndex = 26;
            this.txtPlusUnitPrice.Value = "";
            // 
            // txtMinusUnitPrice
            // 
            this.txtMinusUnitPrice.AcceptsTab = true;
            this.txtMinusUnitPrice.Location = new System.Drawing.Point(543, 263);
            this.txtMinusUnitPrice.Name = "txtMinusUnitPrice";
            this.txtMinusUnitPrice.Precision = 0;
            this.txtMinusUnitPrice.SepratedChar = ',';
            this.txtMinusUnitPrice.Size = new System.Drawing.Size(65, 19);
            this.txtMinusUnitPrice.TabIndex = 25;
            this.txtMinusUnitPrice.Value = "";
            // 
            // txtMaxHour
            // 
            this.txtMaxHour.AcceptsTab = true;
            this.txtMaxHour.Location = new System.Drawing.Point(494, 263);
            this.txtMaxHour.Name = "txtMaxHour";
            this.txtMaxHour.Precision = 2;
            this.txtMaxHour.SepratedChar = ',';
            this.txtMaxHour.Size = new System.Drawing.Size(44, 19);
            this.txtMaxHour.TabIndex = 24;
            this.txtMaxHour.Value = "";
            // 
            // txtQuantity
            // 
            this.txtQuantity.AcceptsTab = true;
            this.txtQuantity.Location = new System.Drawing.Point(357, 263);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Precision = 3;
            this.txtQuantity.SepratedChar = ',';
            this.txtQuantity.Size = new System.Drawing.Size(83, 19);
            this.txtQuantity.TabIndex = 22;
            this.txtQuantity.Value = "";
            this.txtQuantity.TextChanged += new System.EventHandler(this.txtQuantity_TextChanged);
            // 
            // txtAmount
            // 
            this.txtAmount.AcceptsTab = true;
            this.txtAmount.Location = new System.Drawing.Point(76, 171);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Precision = 0;
            this.txtAmount.ReadOnly = true;
            this.txtAmount.SepratedChar = ',';
            this.txtAmount.Size = new System.Drawing.Size(169, 19);
            this.txtAmount.TabIndex = 12;
            this.txtAmount.Value = "";
            // 
            // txtPrice
            // 
            this.txtPrice.AcceptsTab = true;
            this.txtPrice.Location = new System.Drawing.Point(269, 263);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Precision = 0;
            this.txtPrice.SepratedChar = ',';
            this.txtPrice.Size = new System.Drawing.Size(83, 19);
            this.txtPrice.TabIndex = 21;
            this.txtPrice.Value = "";
            this.txtPrice.TextChanged += new System.EventHandler(this.txtPrice_TextChanged);
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(340, 34);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(163, 19);
            this.txtCustomerName.TabIndex = 4;
            this.txtCustomerName.TextChanged += new System.EventHandler(this.txtCustomerName_TextChanged);
            // 
            // chk_isnotregist
            // 
            this.chk_isnotregist.AutoSize = true;
            this.chk_isnotregist.Location = new System.Drawing.Point(512, 38);
            this.chk_isnotregist.Name = "chk_isnotregist";
            this.chk_isnotregist.Size = new System.Drawing.Size(60, 16);
            this.chk_isnotregist.TabIndex = 286;
            this.chk_isnotregist.Text = "未登録";
            this.chk_isnotregist.UseVisualStyleBackColor = true;
            this.chk_isnotregist.CheckedChanged += new System.EventHandler(this.txtCustomerName_TextChanged);
            // 
            // dtp_notregist
            // 
            this.dtp_notregist.CustomFormat = "yyyy/MM/dd";
            this.dtp_notregist.Enabled = false;
            this.dtp_notregist.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_notregist.Location = new System.Drawing.Point(576, 34);
            this.dtp_notregist.Name = "dtp_notregist";
            this.dtp_notregist.Size = new System.Drawing.Size(112, 19);
            this.dtp_notregist.TabIndex = 287;
            this.dtp_notregist.ValueChanged += new System.EventHandler(this.txtCustomerName_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(677, 475);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 288;
            this.label1.Text = "合計";
            // 
            // txtContractCount
            // 
            this.txtContractCount.AcceptsTab = true;
            this.txtContractCount.Location = new System.Drawing.Point(705, 472);
            this.txtContractCount.Name = "txtContractCount";
            this.txtContractCount.Precision = 0;
            this.txtContractCount.ReadOnly = true;
            this.txtContractCount.SepratedChar = ',';
            this.txtContractCount.Size = new System.Drawing.Size(57, 19);
            this.txtContractCount.TabIndex = 289;
            this.txtContractCount.Value = "";
            // 
            // ContractAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(780, 532);
            this.Controls.Add(this.txtContractCount);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtp_notregist);
            this.Controls.Add(this.chk_isnotregist);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.txtMinHour);
            this.Controls.Add(this.txtDetailAmount);
            this.Controls.Add(this.txtPlusUnitPrice);
            this.Controls.Add(this.txtMinusUnitPrice);
            this.Controls.Add(this.txtMaxHour);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.cobEmployType);
            this.Controls.Add(this.txtStartDate);
            this.Controls.Add(this.txtEndDate);
            this.Controls.Add(this.txtContractDate);
            this.Controls.Add(this.txtOrderDate);
            this.Controls.Add(this.cobCustomerID);
            this.Controls.Add(this.btnDetailAdd);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.btnDetailRegister);
            this.Controls.Add(this.btnDetailDelete);
            this.Controls.Add(this.btnDetailUpdate);
            this.Controls.Add(this.dgvContract);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.cobUnit);
            this.Controls.Add(this.cobEmployeeID);
            this.Controls.Add(this.cobPaymentType);
            this.Controls.Add(this.cobPaymentDay);
            this.Controls.Add(this.cobSalesman2);
            this.Controls.Add(this.cobSalesman1);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.txtContent);
            this.Controls.Add(this.txtContractName);
            this.Controls.Add(this.txtFilter);
            this.Controls.Add(this.txtOrderNo);
            this.Controls.Add(this.txtContractNo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label2);
            this.Name = "ContractAddForm";
            this.Text = "契約書情報の登録";
            this.Load += new System.EventHandler(this.ContractAddForm_Load);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label25, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label29, 0);
            this.Controls.SetChildIndex(this.label30, 0);
            this.Controls.SetChildIndex(this.label22, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label15, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label24, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.txtContractNo, 0);
            this.Controls.SetChildIndex(this.txtOrderNo, 0);
            this.Controls.SetChildIndex(this.txtFilter, 0);
            this.Controls.SetChildIndex(this.txtContractName, 0);
            this.Controls.SetChildIndex(this.txtContent, 0);
            this.Controls.SetChildIndex(this.txtNote, 0);
            this.Controls.SetChildIndex(this.cobSalesman1, 0);
            this.Controls.SetChildIndex(this.cobSalesman2, 0);
            this.Controls.SetChildIndex(this.cobPaymentDay, 0);
            this.Controls.SetChildIndex(this.cobPaymentType, 0);
            this.Controls.SetChildIndex(this.cobEmployeeID, 0);
            this.Controls.SetChildIndex(this.cobUnit, 0);
            this.Controls.SetChildIndex(this.label26, 0);
            this.Controls.SetChildIndex(this.label17, 0);
            this.Controls.SetChildIndex(this.label18, 0);
            this.Controls.SetChildIndex(this.label19, 0);
            this.Controls.SetChildIndex(this.label20, 0);
            this.Controls.SetChildIndex(this.label21, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.dgvContract, 0);
            this.Controls.SetChildIndex(this.btnDetailUpdate, 0);
            this.Controls.SetChildIndex(this.btnDetailDelete, 0);
            this.Controls.SetChildIndex(this.btnDetailRegister, 0);
            this.Controls.SetChildIndex(this.btnRegister, 0);
            this.Controls.SetChildIndex(this.btnDetailAdd, 0);
            this.Controls.SetChildIndex(this.cobCustomerID, 0);
            this.Controls.SetChildIndex(this.txtOrderDate, 0);
            this.Controls.SetChildIndex(this.txtContractDate, 0);
            this.Controls.SetChildIndex(this.txtEndDate, 0);
            this.Controls.SetChildIndex(this.txtStartDate, 0);
            this.Controls.SetChildIndex(this.cobEmployType, 0);
            this.Controls.SetChildIndex(this.label23, 0);
            this.Controls.SetChildIndex(this.label16, 0);
            this.Controls.SetChildIndex(this.txtPrice, 0);
            this.Controls.SetChildIndex(this.txtAmount, 0);
            this.Controls.SetChildIndex(this.txtQuantity, 0);
            this.Controls.SetChildIndex(this.txtMaxHour, 0);
            this.Controls.SetChildIndex(this.txtMinusUnitPrice, 0);
            this.Controls.SetChildIndex(this.txtPlusUnitPrice, 0);
            this.Controls.SetChildIndex(this.txtDetailAmount, 0);
            this.Controls.SetChildIndex(this.txtMinHour, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.txtCustomerName, 0);
            this.Controls.SetChildIndex(this.chk_isnotregist, 0);
            this.Controls.SetChildIndex(this.dtp_notregist, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.txtContractCount, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContract)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cobEmployType;
        private System.Windows.Forms.DateTimePicker txtStartDate;
        private System.Windows.Forms.DateTimePicker txtEndDate;
        private System.Windows.Forms.DateTimePicker txtOrderDate;
        private System.Windows.Forms.ComboBox cobCustomerID;
        private System.Windows.Forms.Button btnDetailAdd;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnDetailRegister;
        private System.Windows.Forms.Button btnDetailDelete;
        private System.Windows.Forms.Button btnDetailUpdate;
        private System.Windows.Forms.DataGridView dgvContract;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cobUnit;
        private System.Windows.Forms.ComboBox cobEmployeeID;
        private System.Windows.Forms.ComboBox cobSalesman2;
        private System.Windows.Forms.ComboBox cobSalesman1;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.TextBox txtContent;
        private System.Windows.Forms.TextBox txtFilter;
        private System.Windows.Forms.TextBox txtContractName;
        private System.Windows.Forms.TextBox txtOrderNo;
        private System.Windows.Forms.TextBox txtContractNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.DateTimePicker txtContractDate;
        private System.Windows.Forms.ComboBox cobPaymentType;
        private System.Windows.Forms.ComboBox cobPaymentDay;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label23;
        private Common.NumericTextox txtPrice;
        private Common.NumericTextox txtQuantity;
        private Common.NumericTextox txtMaxHour;
        private Common.NumericTextox txtMinHour;
        private Common.NumericTextox txtMinusUnitPrice;
        private Common.NumericTextox txtPlusUnitPrice;
        private Common.NumericTextox txtDetailAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinHour;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaxHour;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinusUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn PlusUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private Common.NumericTextox txtAmount;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.CheckBox chk_isnotregist;
        private System.Windows.Forms.DateTimePicker dtp_notregist;
        private System.Windows.Forms.Label label1;
        private Common.NumericTextox txtContractCount;
    }
}