﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;

namespace EB.Contract
{
    public partial class ContractAddForm : DialogForm
    {
        #region 初期化
        public ContractAddForm()
        {
            InitializeComponent();
            this.txtOrderDate.CustomFormat = "   ";
        }
        /// <summary>
        /// 初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ContractAddForm_Load(object sender, EventArgs e)
        {
            try
            {
                //Commbox DataSourceを指定
                bindCommbox();

                ////面データを初期化
                loadData();

                //Reset画面項目
                resetAll();

                //Reset明細画面項目
                resetAllDetail();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }

        }

        /// <summary>
        /// 画面データを初期化
        /// </summary>
        private void loadData()
        {

        }
        private bool issetEvent = false;
        /// <summary>
        /// Reset画面項目
        /// </summary>
        private void resetAll()
        {
            txtFilter.Text = string.Empty;//契約ID
            txtContractNo.Text = string.Empty;//契約番号
            txtContractDate.Text = string.Empty;//契約日
            cobCustomerID.SelectedIndex = -1;//顧客ID
            txtOrderNo.Text = string.Empty;//注文書番号
            cobEmployType.SelectedIndex = -1;//方式
            txtOrderDate.Text = string.Empty;//注文日
            txtContractName.Text = string.Empty;//契約件名
            txtAmount.Text = string.Empty;//契約金額
            txtContent.Text = string.Empty;//内容
            txtNote.Text = string.Empty;//備考
            txtStartDate.Text = string.Empty;//開始日
            txtEndDate.Text = string.Empty;//終了日
            cobSalesman1.SelectedIndex = -1;//営業担当１
            cobSalesman2.SelectedIndex = -1;//営業担当２
            cobPaymentType.SelectedIndex = -1;//支払方法
            cobPaymentDay.SelectedIndex = -1;//支払日
            txtContractCount.Text = string.Empty;//合計

            this.dgvContract.Rows.Clear();//明細
            if (!issetEvent)
            {
                issetEvent = true;
                this.cobSalesman1.SelectedIndexChanged += new System.EventHandler(this.cobSalesman_SelectedIndexChanged);
                this.cobSalesman2.SelectedIndexChanged += new System.EventHandler(this.cobSalesman_SelectedIndexChanged);
            }
        }

        /// <summary>
        /// Reset明細画面項目
        /// </summary>
        private void resetAllDetail()
        {
            cobEmployeeID.SelectedIndex = -1;//技術者ID
            cobUnit.SelectedIndex = -1;//単位
            txtPrice.Text = string.Empty;//単価
            txtQuantity.Text = string.Empty;//数量
            txtMinHour.Text = string.Empty;//Min勤務
            txtMaxHour.Text = string.Empty;//Max勤務
            txtMinusUnitPrice.Text = string.Empty;//減賃金
            txtPlusUnitPrice.Text = string.Empty;//増賃金
            txtDetailAmount.Text = string.Empty;//金額
        }
        #endregion

        #region 画面動作
        /// <summary>
        /// Commbox DataSourceを指定
        /// </summary>
        private void bindCommbox()
        {
            BL_CodeMaster bl = BL_CodeMaster.GetInstance();

            cobEmployType.DataSource = bl.SelectCodeMaster("CD007");//方式
            cobPaymentType.DataSource = bl.SelectCodeMaster("CD005");//支払方法
            cobPaymentDay.DataSource = bl.SelectCodeMaster("CD006");//支払日
            cobUnit.DataSource = bl.SelectCodeMaster("CD008");//単位
            cobCustomerID.DataSource = BL_Customer.GetInstance().SelectAllCustomer(null);//顧客ID
            cobSalesman1.DataSource = getSalesEmployee();//営業担当１
            cobSalesman2.DataSource = getSalesEmployee();//営業担当２
            cobEmployeeID.DataSource = BL_Employee.GetInstance().SelectTechEmployee();//技術者


        }
        /// <summary>
        /// 営業担当Combobox用のDataSourceを所得
        /// </summary>
        /// <returns></returns>
        private DataTable getSalesEmployee()
        {
            DataTable dt = BL_Employee.GetInstance().SelectSalesEmployee();
            DataRow dr = dt.NewRow();
            dr["EmployeeName"] = "";
            dr["EmployeeID"] = -1;

            dt.Rows.InsertAt(dr, 0);

            return dt;
        }
        /// <summary>
        /// 明細の追加
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDetailAdd_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (!isValidCheckDetail(false)) return;

                //登録処理
                processDetailAdd();

                //金額自動計算
                caculateAmount();

                //合計自動計算
                caculateCount();

                //Reset画面項目
                resetAllDetail();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        private void processDetailAdd()
        {
            int row = dgvContract.Rows.Add();
            dgvContract.Rows[row].Cells["EmployeeID"].Value = cobEmployeeID.SelectedValue;//技術者ID
            dgvContract.Rows[row].Cells["Unit"].Value = cobUnit.SelectedValue;//単位ID
            dgvContract.Rows[row].Cells["EmployeeName"].Value = cobEmployeeID.Text;//技術者
            dgvContract.Rows[row].Cells["UnitName"].Value = cobUnit.Text;//単位
            dgvContract.Rows[row].Cells["Price"].Value = txtPrice.Text;//単価
            dgvContract.Rows[row].Cells["Quantity"].Value = txtQuantity.Text;//数量
            dgvContract.Rows[row].Cells["MinHour"].Value = txtMinHour.Text;//Min勤務
            dgvContract.Rows[row].Cells["MaxHour"].Value = txtMaxHour.Text;//Max勤務
            dgvContract.Rows[row].Cells["MinusUnitPrice"].Value = txtMinusUnitPrice.Text;//減賃金
            dgvContract.Rows[row].Cells["PlusUnitPrice"].Value = txtPlusUnitPrice.Text;//増賃金
            dgvContract.Rows[row].Cells["Amount"].Value = txtDetailAmount.Text;//金額

        }
        private void caculateAmount()
        {
            decimal totalAmout = 0;

            for (int row = 0; row < dgvContract.Rows.Count; row++)
            {
                totalAmout = totalAmout + CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["Amount"].Value);//金額
            }

            txtAmount.Text = totalAmout.ToString();
        }
        private void caculateCount()
        {
            decimal totalCount = dgvContract.Rows.Count;

            txtContractCount.Text = totalCount.ToString();
        }
        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheckDetail(bool isEdit)
        {
            if (cobEmployeeID.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "技術者");
                return false;
            }
            if (cobUnit.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "単位");
                return false;
            }
            if (string.IsNullOrEmpty(txtPrice.Value))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "単価");
                return false;
            }
            if (string.IsNullOrEmpty(txtQuantity.Value))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "数量");
                return false;
            }
            if (string.IsNullOrEmpty(txtDetailAmount.Value))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "金額");
                return false;
            }

            if(isEdit){
                return true;
            }
            return isRepeatCheckEmployee();
        }
        /// <summary>
        /// 明細の技術者チェック　重複
        /// </summary>
        /// <returns></returns>
        private bool isRepeatCheckEmployee()
        {
            if (dgvContract.Rows.Count < 1) { return true; }

            foreach (DataGridViewRow dgvr in dgvContract.Rows)
            {
                if (cobEmployeeID.SelectedValue.ToString() == dgvr.Cells["EmployeeID"].Value.ToString())
                {
                    return MessageHelper.ShowConfirmMessage("EB0016", "技術者") == DialogResult.Yes;
                }
            }
            return this.isValidCheckEmployee(true);
        }
        /// <summary>
        /// 明細の技術者チェック　他の契約
        /// </summary>
        /// <returns></returns>
        private bool isValidCheckEmployee(bool isConfirm)
        {

            BL_ContractDetail bl = BL_ContractDetail.GetInstance();

            IF_ContractDetail entity = new IF_ContractDetail();
            entity.ContractID = -1;//契約番号
            entity.EmployeeID = CommonHandler.ToInt(cobEmployeeID.SelectedValue.ToString());//技術者番号
            entity.StartDate = txtStartDate.Text;//開始日
            entity.EndDate = txtEndDate.Text;//終了日



            DataTable dt = bl.CheckContractDetailByEmployeeID(entity);

            if (dt.Rows.Count > 0)
            {
                string CompanyName = "";
                
                foreach(DataRow dr in dt.Rows){
                    CompanyName += dr["CustomerName"].ToString() + "[" + dr["StartDate"].ToString() + "～" + dr["EndDate"].ToString() + "]\n";
                }
                if (isConfirm)
                {
                    return MessageHelper.ShowConfirmMessage("EB0015", "技術者の契約:\n" + CompanyName + "が") == DialogResult.Yes;
                }
                else
                {
                    MessageHelper.ShowinforMessageByID("EB0015", "技術者の契約:\n" + CompanyName + "が");
                }
                return false;
            }
            return true;
        }


        /// <summary>
        /// 明細の修正
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDetailUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvContract.SelectedRows.Count == 0) return;

                int row = dgvContract.SelectedRows[0].Index;

                cobEmployeeID.SelectedValue = CommonHandler.ToString(dgvContract.Rows[row].Cells["EmployeeID"].Value);//技術者ID
                cobUnit.SelectedValue = CommonHandler.ToString(dgvContract.Rows[row].Cells["Unit"].Value);//単位
                txtPrice.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["Price"].Value);//単価
                txtQuantity.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["Quantity"].Value);//数量
                txtMinHour.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["MinHour"].Value);//Min勤務
                txtMaxHour.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["MaxHour"].Value);//Max勤務
                txtMinusUnitPrice.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["MinusUnitPrice"].Value);//減賃金
                txtPlusUnitPrice.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["PlusUnitPrice"].Value);//増賃金
                txtDetailAmount.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["Amount"].Value);//金額

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 明細の削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDetailDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvContract.SelectedRows.Count == 0) return;

                int row = dgvContract.SelectedRows[0].Index;

                dgvContract.Rows.RemoveAt(row);

                //金額自動計算
                caculateAmount();

                //合計自動計算
                caculateCount();

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 明細の修正登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDetailRegister_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (!isValidCheckDetail(true)) return;

                //登録処理
                processDetailUpdate();

                //Reset画面項目
                resetAllDetail();

                //金額自動計算
                caculateAmount();

                //合計自動計算
                caculateCount();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        private void processDetailUpdate()
        {
            if (dgvContract.SelectedRows.Count == 0) return;

            int row = dgvContract.SelectedRows[0].Index;

            dgvContract.Rows[row].Cells["EmployeeID"].Value = cobEmployeeID.SelectedValue;//技術者ID
            dgvContract.Rows[row].Cells["Unit"].Value = cobUnit.SelectedValue;//単位ID
            dgvContract.Rows[row].Cells["EmployeeName"].Value = cobEmployeeID.Text;//技術者
            dgvContract.Rows[row].Cells["UnitName"].Value = cobUnit.Text;//単位
            dgvContract.Rows[row].Cells["Price"].Value = txtPrice.Text;//単価
            dgvContract.Rows[row].Cells["Quantity"].Value = txtQuantity.Text;//数量
            dgvContract.Rows[row].Cells["MinHour"].Value = txtMinHour.Text;//Min勤務
            dgvContract.Rows[row].Cells["MaxHour"].Value = txtMaxHour.Text;//Max勤務
            dgvContract.Rows[row].Cells["MinusUnitPrice"].Value = txtMinusUnitPrice.Text;//減賃金
            dgvContract.Rows[row].Cells["PlusUnitPrice"].Value = txtPlusUnitPrice.Text;//増賃金
            dgvContract.Rows[row].Cells["Amount"].Value = txtDetailAmount.Text;//金額

        }
        /// <summary>
        /// 登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (!isValidCheck()) return;

                //登録処理
                proceessRegister();

                //画面データを初期化
                loadData();

                //Reset画面項目
                resetAll();

                MessageHelper.ShowinforMessageByID("EB1001");//登録成功しました。
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheck()
        {
            if (cobCustomerID.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "顧客");
                return false;
            }
            if (string.IsNullOrEmpty(txtOrderDate.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "注文日");
                return false;
            }
            if (string.IsNullOrEmpty(txtContractName.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "契約件名");
                return false;
            }
            if (string.IsNullOrEmpty(txtStartDate.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "開始日");
                return false;
            }
            if (string.IsNullOrEmpty(txtEndDate.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "終了日");
                return false;
            }
            if (!CommonHandler.startEndDayCheck(txtStartDate.Text, txtEndDate.Text))
            {
                MessageHelper.ShowinforMessageByID("EB0013");
                return false;
            }
            if (cobSalesman1.SelectedIndex <=0 )
            {
                MessageHelper.ShowinforMessageByID("EB0001", "営業担当１");
                return false;
            }
            if (cobSalesman1.SelectedIndex == cobSalesman2.SelectedIndex)
            {
                MessageHelper.ShowinforMessageByID("EB0010", "重複していない営業担当");
                return false;
            }
            if (cobPaymentType.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "支払サイト（末締）（月）");
                return false;
            }
            if (cobPaymentDay.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "支払サイト（末締）（日）");
                return false;
            }
            //明細行必須
            if (dgvContract.RowCount==0)
            {
                MessageHelper.ShowinforMessageByID("EB0006");
                return false;
            }
            if (string.IsNullOrEmpty(txtOrderNo.Text))
            {
                return MessageHelper.ShowConfirmMessage("EB0017", "注文番号") == DialogResult.Yes;
            }
            return true;
        }

        /// <summary>
        /// 登録処理
        /// </summary>
        private void proceessRegister()
        {
            IF_Contract entity = new IF_Contract();

            entity.ContractNo = txtContractNo.Text;//契約番号
            entity.ContractDate = txtContractDate.Text;//契約日
            entity.CustomerID = CommonHandler.ToInt(cobCustomerID.SelectedValue);//顧客ID
            entity.OrderNo = txtOrderNo.Text;//注文書番号
            entity.EmployType = CommonHandler.ToString(cobEmployType.SelectedValue);//方式
            entity.OrderDate = txtOrderDate.Text;//注文日
            entity.ContractName = txtContractName.Text;//契約件名
            entity.Amount = txtAmount.Text;//契約金額
            entity.Content = txtContent.Text;//内容
            entity.Note = txtNote.Text;//備考
            entity.StartDate = txtStartDate.Text;//開始日
            entity.EndDate = txtEndDate.Text;//終了日

            entity.Salesman1 = CommonHandler.ToInt(cobSalesman1.SelectedValue);//営業担当１
            entity.Salesman2 = CommonHandler.ToInt(cobSalesman2.SelectedValue);//営業担当２

            entity.PaymentType = CommonHandler.ToString(cobPaymentType.SelectedValue);//支払方法
            entity.PaymentDay = CommonHandler.ToString(cobPaymentDay.SelectedValue);//支払日
            entity.FinishFlag = "0";//処理済フラグ
            entity.DeleteFlg = "0";//削除フラグ


            List<IF_ContractDetail> list = new List<IF_ContractDetail>();

            for (int row = 0; row < dgvContract.Rows.Count; row++)
            {
                IF_ContractDetail entityDetail = new IF_ContractDetail();

                entityDetail.DetailID = (row + 1).ToString();
                entityDetail.EmployeeID = CommonHandler.ToInt(dgvContract.Rows[row].Cells["EmployeeID"].Value);//技術者ID
                entityDetail.Unit = CommonHandler.ToString(dgvContract.Rows[row].Cells["Unit"].Value);//単位
                entityDetail.Price = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["Price"].Value);//単価
                entityDetail.Quantity = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["Quantity"].Value);//数量
                entityDetail.MinHour = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["MinHour"].Value);//Min勤務
                entityDetail.MaxHour = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["MaxHour"].Value);//Max勤務
                entityDetail.MinusUnitPrice = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["MinusUnitPrice"].Value);//減賃金
                entityDetail.PlusUnitPrice = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["PlusUnitPrice"].Value);//増賃金
                entityDetail.Amount = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["Amount"].Value);//金額
                entityDetail.DeleteFlg = "0";//削除フラグ

                list.Add(entityDetail);
            }

            BL_Contract bl = BL_Contract.GetInstance();
            bl.RegisterAll(entity, list);

        }
        /// <summary>
        /// 金額自動計算
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtPrice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                decimal price = CommonHandler.ToDecimal(txtPrice.Value);
                decimal quantity = CommonHandler.ToDecimal(txtQuantity.Value);
                txtDetailAmount.Value = CommonHandler.ToString(price * quantity);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 金額自動計算
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            try
            {
                decimal price = CommonHandler.ToDecimal(txtPrice.Value);
                decimal quantity = CommonHandler.ToDecimal(txtQuantity.Value);
                txtDetailAmount.Value = CommonHandler.ToString(price * quantity);
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 注文日ユーザ編集処理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtOrderDate_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                if (DateTime.Now.ToString("yyyy/MM/dd") != txtOrderDate.Value.ToString("yyyy/MM/dd") && this.txtOrderDate.CustomFormat != "yyyy/MM/dd")
                {
                    this.txtOrderDate.CustomFormat = "yyyy/MM/dd";
                }
                string yyMM = txtOrderDate.Value.ToString("yyMM");

                BL_Contract bl = BL_Contract.GetInstance();
                string newContractNo = bl.SelectMaxContractNo(yyMM);

                txtContractNo.Text = newContractNo;
                txtContractDate.Value = txtOrderDate.Value;
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 顧客選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobCustomerID_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cobCustomerID.SelectedIndex == -1) { return; }
            
            string sPaymentType = ((System.Data.DataRowView)this.cobCustomerID.SelectedItem)["PaymentType"].ToString();
            string sPaymentDay = ((System.Data.DataRowView)this.cobCustomerID.SelectedItem)["PaymentDay"].ToString();

            this.selectCobPayment(this.cobPaymentType, sPaymentType);
            this.selectCobPayment(this.cobPaymentDay, sPaymentDay);
        }
        /// <summary>
        /// 支払方法・支払日のデータの反映
        /// </summary>
        /// <param name="cob"></param>
        /// <param name="itemValue"></param>
        private void selectCobPayment(ComboBox cob, string itemValue)
        {
            cob.SelectedIndex = -1;
            if (string.IsNullOrEmpty(itemValue)) { return; }

            for (int i = 0; i < cob.Items.Count; i++)
            {
                if (itemValue == ((System.Data.DataRowView)cob.Items[i])["CodeID"].ToString())
                {
                    cob.SelectedIndex = i;
                    break;
                }
            }
        }

        #endregion
        /// <summary>
        /// 営業担当のチェック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobSalesman_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cobSalesman1.SelectedIndex <=0 || cobSalesman2.SelectedIndex <= 0) { return; }

            if ( cobSalesman1.SelectedIndex == cobSalesman2.SelectedIndex )
            {
                MessageHelper.ShowinforMessageByID("EB0010", "重複していない営業担当");
            }
        }

        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            findEmployeeItem();//先頭文字検索
        }
        /// <summary>
        /// 先頭文字検索
        /// </summary>
        private void findEmployeeItem()
        {
            string text = CommonHandler.ToString(txtFilter.Text);
            if (text == string.Empty)
            {
                return;
            }

            for (int i = 0; i < cobEmployeeID.Items.Count; i++)
            {
                DataRowView row = (DataRowView)cobEmployeeID.Items[i];
                string value = CommonHandler.ToString(row["EmployeeName"]);

                if (value.StartsWith(text))
                {
                    cobEmployeeID.SelectedIndex = i;
                    return;
                }
            }
        }

        /// <summary>
        /// 技術者の契約をチェック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobEmployeeID_SelectionChangeCommitted(object sender, EventArgs e)
        {
            this.isValidCheckEmployee(false);
        }
        /// <summary>
        /// 顧客検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCustomerName_TextChanged(object sender, EventArgs e)
        {
            this.dtp_notregist.Enabled = this.chk_isnotregist.Checked;
            IF_Customer entity = new IF_Customer();
            entity.CustomerName = this.txtCustomerName.Text;
            ThreadPoolHelper.StartThread(this, () =>
                {
                    return BL_Customer.GetInstance().SelectCustomer(entity, !this.chk_isnotregist.Checked, this.dtp_notregist.Text);//顧客ID
                },
                (obj) =>
                {
                    cobCustomerID.DataSource = obj as DataTable;
                    cobCustomerID.SelectedIndex = -1;
                });
        }
    }
}