﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;

namespace EB.Master
{
    public partial class EmployeeListForm : DialogForm
    {
        #region 初期化
        public EmployeeListForm()
        {
            InitializeComponent();
            this.menuInit();
        }
        /// <summary>
        /// メニュー
        /// </summary>
        private void menuInit()
        {
            ContextMenuStrip mnu = new ContextMenuStrip();
            ToolStripMenuItem mnuEdit = new ToolStripMenuItem("編集");
            ToolStripMenuItem mnuDelete = new ToolStripMenuItem("削除");
            //編集
            mnuEdit.Click += new EventHandler((sender, e) =>
            {
                DataGridViewCellEventArgs dgvce = new DataGridViewCellEventArgs(0,this.dgvEmployee.SelectedRows[0].Index);
                dgvEmployee_CellDoubleClick(sender, dgvce);
            });
            //削除
            mnuDelete.Click += new EventHandler((sender, e) =>
            {
                if (MessageHelper.ShowDeleteConfirmMessage() != DialogResult.Yes)
                {
                    return;
                }
                int row = this.dgvEmployee.SelectedRows[0].Index;
                IF_Employee entity = new IF_Employee();
                entity.EmployeeID = CommonHandler.ToInt(this.dgvEmployee.Rows[row].Cells["EmployeeID"].Value);
                entity.DeleteFlg = "1";
                ThreadPoolHelper.StartThread(this,
                    () =>
                    {
                        return BL_Employee.GetInstance().DeleteEmployee(entity);
                    }, (obj) =>
                    {
                        this.dgvEmployee.Rows.RemoveAt(row);
                        MessageHelper.ShowinforMessageByID("EB1005");//削除成功しました
                    }
                );
            });
            //Add to main context menu
            mnu.Items.AddRange(new ToolStripItem[] { mnuEdit, mnuDelete });
            //Assign to datagridview
            dgvEmployee.ContextMenuStrip = mnu;

        }

        /// <summary>
        /// 画面初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EmployeeAddForm_Load(object sender, EventArgs e)
        {
            try
            {
                ////面データを初期化
                btnsearch_Click(null,null);

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        #endregion

        #region 画面動作
        /// <summary>
        /// 新規登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEmployeeRegister_Click(object sender, EventArgs e)
        {
            EmployeeModifyForm emf = new EmployeeModifyForm(0, (entity) =>
            {
                this.keyword.Text = "";
                btnsearch_Click(sender, e);
            });
            emf.Top = 0;
            emf.ShowDialog();
        }
        /// <summary>
        /// 編集
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvEmployee_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int row = e.RowIndex;
            EmployeeModifyForm emf = new EmployeeModifyForm(
                CommonHandler.ToInt(this.dgvEmployee.Rows[row].Cells["EmployeeID"].Value)//社員ID
            , (entity) =>
            {
                if (entity.DeleteFlg == "1")
                {
                    this.dgvEmployee.Rows.RemoveAt(row);
                }
                else
                {
                    this.setRowData(row, entity);
                }
            });
            emf.Top = 0;
            emf.ShowDialog();
        }
        /// <summary>
        /// 検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnsearch_Click(object sender, EventArgs e)
        {
            String keyword = this.keyword.Text;
            ThreadPoolHelper.StartThread(this,
                () =>
                {
                    BL_Employee bl = BL_Employee.GetInstance();
                    return bl.SelectAllEmployee(keyword);
                },
                (obj)=>{

                    dgvEmployee.AutoGenerateColumns = false;

                    dgvEmployee.DataSource = obj as DataTable;
                    this.resCount.Text = dgvEmployee.RowCount.ToString();
                    dgvEmployee.Focus();
                    if (null != sender)
                    {
                        Button btn = sender as Button;

                        if ("btnEmployeeRegister" == btn.Name)
                        {
                            int lastRow = this.dgvEmployee.Rows.Count - 1;
                            this.dgvEmployee.FirstDisplayedScrollingRowIndex = lastRow;
                            this.dgvEmployee.Rows[lastRow].Selected = true;
                        }
                    }
                }
                );
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="row"></param>
        /// <param name="entity"></param>
        private void setRowData(int row,IF_Employee entity)
        {
            //社員ID
            this.dgvEmployee.Rows[row].Cells["EmployeeID"].Value = entity.EmployeeID;
            //社員名
            dgvEmployee.Rows[row].Cells["EmployeeName"].Value = entity.EmployeeName;
            //経験年数
            dgvEmployee.Rows[row].Cells["Experience"].Value = CommonHandler.ToInt(entity.Experience);
            //学歴
            dgvEmployee.Rows[row].Cells["Degree"].Value = entity.Degree;
            //言語
            dgvEmployee.Rows[row].Cells["Language"].Value = entity.Language;
            //勤務先
            dgvEmployee.Rows[row].Cells["Company"].Value = entity.Company;
            //評価
            dgvEmployee.Rows[row].Cells["Remark"].Value = entity.Remark;
            //仕入原価
            dgvEmployee.Rows[row].Cells["SiirePrice"].Value = CommonHandler.ToInt(entity.SiirePrice);
            //仕入先担当
            dgvEmployee.Rows[row].Cells["siireSales"].Value = entity.SiireSales;
            //交通費
            dgvEmployee.Rows[row].Cells["carfare"].Value = entity.carfare;
        }
        /// <summary>
        /// 右クリック
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void _CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex > -1 && e.ColumnIndex > -1)
            {
                dgvEmployee.CurrentRow.Selected = false;
                dgvEmployee.Rows[e.RowIndex].Selected = true;

            }
        }
        /// <summary>
        /// Enter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void _KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.btnsearch_Click(this.btnsearch, null);
            }

        }
        #endregion
    }
}
