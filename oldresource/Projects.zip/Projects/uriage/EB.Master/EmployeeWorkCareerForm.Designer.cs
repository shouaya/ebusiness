﻿namespace EB.Master
{
    partial class EmployeeWorkCareerForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cobYear = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dgvEmployeeWork = new System.Windows.Forms.DataGridView();
            this.EmployeeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSearch = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployeeWork)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(681, 376);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "年を指定してください";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "社員名を入力してください";
            // 
            // cobYear
            // 
            this.cobYear.DisplayMember = "Years";
            this.cobYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobYear.FormattingEnabled = true;
            this.cobYear.Location = new System.Drawing.Point(187, 24);
            this.cobYear.Name = "cobYear";
            this.cobYear.Size = new System.Drawing.Size(134, 20);
            this.cobYear.TabIndex = 2;
            this.cobYear.ValueMember = "Years";
            this.cobYear.SelectedIndexChanged += new System.EventHandler(this.cobYear_SelectedIndexChanged);
            this.cobYear.SelectionChangeCommitted += new System.EventHandler(this.cobYear_SelectionChangeCommitted);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(187, 62);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(134, 19);
            this.textBox1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(337, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "年";
            // 
            // dgvEmployeeWork
            // 
            this.dgvEmployeeWork.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmployeeWork.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeName,
            this.CustomerName,
            this.Month1,
            this.Month2,
            this.Month3,
            this.Month4,
            this.Month5,
            this.Month6,
            this.Month7,
            this.Month8,
            this.Month9,
            this.Month10,
            this.Month11,
            this.Month12});
            this.dgvEmployeeWork.Location = new System.Drawing.Point(44, 94);
            this.dgvEmployeeWork.Name = "dgvEmployeeWork";
            this.dgvEmployeeWork.RowTemplate.Height = 21;
            this.dgvEmployeeWork.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEmployeeWork.Size = new System.Drawing.Size(759, 258);
            this.dgvEmployeeWork.TabIndex = 5;
            // 
            // EmployeeName
            // 
            this.EmployeeName.DataPropertyName = "EmployeeName";
            this.EmployeeName.HeaderText = "技術者氏名";
            this.EmployeeName.Name = "EmployeeName";
            // 
            // CustomerName
            // 
            this.CustomerName.DataPropertyName = "CustomerName";
            this.CustomerName.HeaderText = "顧客会社名";
            this.CustomerName.Name = "CustomerName";
            // 
            // Month1
            // 
            this.Month1.HeaderText = "1月";
            this.Month1.Name = "Month1";
            this.Month1.Width = 40;
            // 
            // Month2
            // 
            this.Month2.HeaderText = "2月";
            this.Month2.Name = "Month2";
            this.Month2.Width = 40;
            // 
            // Month3
            // 
            this.Month3.HeaderText = "3月";
            this.Month3.Name = "Month3";
            this.Month3.Width = 40;
            // 
            // Month4
            // 
            this.Month4.HeaderText = "4月";
            this.Month4.Name = "Month4";
            this.Month4.Width = 40;
            // 
            // Month5
            // 
            this.Month5.HeaderText = "5月";
            this.Month5.Name = "Month5";
            this.Month5.Width = 40;
            // 
            // Month6
            // 
            this.Month6.HeaderText = "6月";
            this.Month6.Name = "Month6";
            this.Month6.Width = 40;
            // 
            // Month7
            // 
            this.Month7.HeaderText = "7月";
            this.Month7.Name = "Month7";
            this.Month7.Width = 40;
            // 
            // Month8
            // 
            this.Month8.HeaderText = "8月";
            this.Month8.Name = "Month8";
            this.Month8.Width = 40;
            // 
            // Month9
            // 
            this.Month9.HeaderText = "9月";
            this.Month9.Name = "Month9";
            this.Month9.Width = 40;
            // 
            // Month10
            // 
            this.Month10.HeaderText = "10月";
            this.Month10.Name = "Month10";
            this.Month10.Width = 55;
            // 
            // Month11
            // 
            this.Month11.HeaderText = "11月";
            this.Month11.Name = "Month11";
            this.Month11.Width = 55;
            // 
            // Month12
            // 
            this.Month12.HeaderText = "12月";
            this.Month12.Name = "Month12";
            this.Month12.Width = 55;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(376, 58);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 6;
            this.btnSearch.Text = "検索";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // EmployeeWorkCareerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(850, 411);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dgvEmployeeWork);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.cobYear);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "EmployeeWorkCareerForm";
            this.Text = "社員稼働履歴";
            this.Load += new System.EventHandler(this.EmployeeWorkCareerForm_Load);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.cobYear, 0);
            this.Controls.SetChildIndex(this.textBox1, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.dgvEmployeeWork, 0);
            this.Controls.SetChildIndex(this.btnSearch, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployeeWork)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cobYear;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgvEmployeeWork;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month12;
        private System.Windows.Forms.Button btnSearch;
    }
}