﻿namespace EB.Master
{
    partial class EmployeeListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvEmployee = new System.Windows.Forms.DataGridView();
            this.btnEmployeeRegister = new System.Windows.Forms.Button();
            this.searcharea = new System.Windows.Forms.Panel();
            this.resCount = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.keyword = new System.Windows.Forms.TextBox();
            this.btnarea = new System.Windows.Forms.Panel();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Experience = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Degree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Language = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Company = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siireName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siireSales = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.siirePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.carfare = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remark = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployee)).BeginInit();
            this.searcharea.SuspendLayout();
            this.btnarea.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(808, 14);
            // 
            // dgvEmployee
            // 
            this.dgvEmployee.AllowDrop = true;
            this.dgvEmployee.AllowUserToAddRows = false;
            this.dgvEmployee.AllowUserToDeleteRows = false;
            this.dgvEmployee.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmployee.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvEmployee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvEmployee.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeID,
            this.EmployeeName,
            this.Experience,
            this.Degree,
            this.Language,
            this.Company,
            this.siireName,
            this.siireSales,
            this.siirePrice,
            this.carfare,
            this.Remark});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEmployee.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvEmployee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEmployee.Location = new System.Drawing.Point(0, 49);
            this.dgvEmployee.MultiSelect = false;
            this.dgvEmployee.Name = "dgvEmployee";
            this.dgvEmployee.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmployee.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvEmployee.RowHeadersVisible = false;
            this.dgvEmployee.RowTemplate.Height = 23;
            this.dgvEmployee.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEmployee.Size = new System.Drawing.Size(904, 469);
            this.dgvEmployee.TabIndex = 49;
            this.dgvEmployee.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmployee_CellDoubleClick);
            this.dgvEmployee.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this._CellMouseDown);
            // 
            // btnEmployeeRegister
            // 
            this.btnEmployeeRegister.Location = new System.Drawing.Point(17, 14);
            this.btnEmployeeRegister.Name = "btnEmployeeRegister";
            this.btnEmployeeRegister.Size = new System.Drawing.Size(187, 23);
            this.btnEmployeeRegister.TabIndex = 50;
            this.btnEmployeeRegister.Text = "新規登録";
            this.btnEmployeeRegister.UseVisualStyleBackColor = true;
            this.btnEmployeeRegister.Click += new System.EventHandler(this.btnEmployeeRegister_Click);
            // 
            // searcharea
            // 
            this.searcharea.Controls.Add(this.resCount);
            this.searcharea.Controls.Add(this.btnsearch);
            this.searcharea.Controls.Add(this.keyword);
            this.searcharea.Dock = System.Windows.Forms.DockStyle.Top;
            this.searcharea.Location = new System.Drawing.Point(0, 0);
            this.searcharea.Name = "searcharea";
            this.searcharea.Size = new System.Drawing.Size(904, 49);
            this.searcharea.TabIndex = 51;
            // 
            // resCount
            // 
            this.resCount.AutoSize = true;
            this.resCount.Location = new System.Drawing.Point(490, 21);
            this.resCount.Name = "resCount";
            this.resCount.Size = new System.Drawing.Size(11, 12);
            this.resCount.TabIndex = 55;
            this.resCount.Text = "1";
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(358, 12);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(84, 26);
            this.btnsearch.TabIndex = 54;
            this.btnsearch.Text = "検索";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // keyword
            // 
            this.keyword.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.keyword.Location = new System.Drawing.Point(17, 12);
            this.keyword.Name = "keyword";
            this.keyword.Size = new System.Drawing.Size(334, 26);
            this.keyword.TabIndex = 53;
            this.keyword.KeyDown += new System.Windows.Forms.KeyEventHandler(this._KeyDown);
            // 
            // btnarea
            // 
            this.btnarea.Controls.Add(this.btnEmployeeRegister);
            this.btnarea.Controls.Add(this.btnClose);
            this.btnarea.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnarea.Location = new System.Drawing.Point(0, 518);
            this.btnarea.Name = "btnarea";
            this.btnarea.Size = new System.Drawing.Size(904, 49);
            this.btnarea.TabIndex = 52;
            this.btnarea.Controls.SetChildIndex(this.btnClose, 0);
            this.btnarea.Controls.SetChildIndex(this.btnEmployeeRegister, 0);
            // 
            // EmployeeID
            // 
            this.EmployeeID.DataPropertyName = "EmployeeID";
            this.EmployeeID.HeaderText = "社員ID";
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.ReadOnly = true;
            // 
            // EmployeeName
            // 
            this.EmployeeName.DataPropertyName = "EmployeeName";
            this.EmployeeName.HeaderText = "社員名";
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.ReadOnly = true;
            // 
            // Experience
            // 
            this.Experience.DataPropertyName = "Experience";
            this.Experience.HeaderText = "年数";
            this.Experience.Name = "Experience";
            this.Experience.ReadOnly = true;
            // 
            // Degree
            // 
            this.Degree.DataPropertyName = "Degree";
            this.Degree.HeaderText = "学歴";
            this.Degree.Name = "Degree";
            this.Degree.ReadOnly = true;
            // 
            // Language
            // 
            this.Language.DataPropertyName = "Language";
            this.Language.HeaderText = "言語";
            this.Language.Name = "Language";
            this.Language.ReadOnly = true;
            // 
            // Company
            // 
            this.Company.DataPropertyName = "Company";
            this.Company.FillWeight = 150F;
            this.Company.HeaderText = "勤務先";
            this.Company.Name = "Company";
            this.Company.ReadOnly = true;
            this.Company.Width = 150;
            // 
            // siireName
            // 
            this.siireName.DataPropertyName = "CustomerName";
            this.siireName.HeaderText = "仕入先";
            this.siireName.Name = "siireName";
            this.siireName.ReadOnly = true;
            // 
            // siireSales
            // 
            this.siireSales.DataPropertyName = "siireSales";
            this.siireSales.HeaderText = "仕入先担当";
            this.siireSales.Name = "siireSales";
            this.siireSales.ReadOnly = true;
            // 
            // siirePrice
            // 
            this.siirePrice.DataPropertyName = "siirePrice";
            this.siirePrice.HeaderText = "仕入先単価";
            this.siirePrice.Name = "siirePrice";
            this.siirePrice.ReadOnly = true;
            // 
            // carfare
            // 
            this.carfare.DataPropertyName = "carfare";
            this.carfare.HeaderText = "交通費";
            this.carfare.Name = "carfare";
            this.carfare.ReadOnly = true;
            // 
            // Remark
            // 
            this.Remark.DataPropertyName = "Remark";
            this.Remark.HeaderText = "評価";
            this.Remark.Name = "Remark";
            this.Remark.ReadOnly = true;
            // 
            // EmployeeListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(904, 567);
            this.Controls.Add(this.dgvEmployee);
            this.Controls.Add(this.searcharea);
            this.Controls.Add(this.btnarea);
            this.MaximizeBox = true;
            this.Name = "EmployeeListForm";
            this.Text = "社員一覧";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.EmployeeAddForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmployee)).EndInit();
            this.searcharea.ResumeLayout(false);
            this.searcharea.PerformLayout();
            this.btnarea.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvEmployee;
        private System.Windows.Forms.Button btnEmployeeRegister;
        private System.Windows.Forms.Panel searcharea;
        private System.Windows.Forms.Label resCount;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.TextBox keyword;
        private System.Windows.Forms.Panel btnarea;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Experience;
        private System.Windows.Forms.DataGridViewTextBoxColumn Degree;
        private System.Windows.Forms.DataGridViewTextBoxColumn Language;
        private System.Windows.Forms.DataGridViewTextBoxColumn Company;
        private System.Windows.Forms.DataGridViewTextBoxColumn siireName;
        private System.Windows.Forms.DataGridViewTextBoxColumn siireSales;
        private System.Windows.Forms.DataGridViewTextBoxColumn siirePrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn carfare;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remark;
    }
}