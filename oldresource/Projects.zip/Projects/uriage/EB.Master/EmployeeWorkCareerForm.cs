﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.Common;
using EB.DBAcess.DAL;
using EB.DBAcess;

namespace EB.Master
{
    public partial class EmployeeWorkCareerForm : DialogForm
    {
        #region 初期化
        public EmployeeWorkCareerForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 画面初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EmployeeWorkCareerForm_Load(object sender, EventArgs e)
        {
            //Commbox DataSourceを指定
            bindCommbox();

            //画面データを初期化
            loadData();
        }

        /// <summary>
        /// Commbox DataSourceを指定
        /// </summary>
        private void bindCommbox()
        {
            BL_EmployeeWorkCareer bl = BL_EmployeeWorkCareer.GetInstance();

            cobYear.DataSource = bl.SelectYears();//契約年

            int i = cobYear.Items.Count;

            cobYear.SelectedIndex = i-1;

        }

        /// <summary>
        /// 画面データを初期化
        /// </summary>
        private void loadData()
        {
            string strYear = cobYear.Text;
            string strEmployee = textBox1.Text;
            bindDataGridView(strYear, strEmployee);
        }

        #endregion

        #region 画面動作
        /// <summary>
        /// 
        /// </summary>
        /// <param name="strYear"></param>
        private void bindDataGridView(string strYear, string strEmployee)
        {
            BL_EmployeeWorkCareer bl = BL_EmployeeWorkCareer.GetInstance();

            DataTable dt = bl.SelectEmployeeWorkCareer(strYear, strEmployee);
            string temp = string.Empty;
            string temp1 = string.Empty;
            int index = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string strEmployeeID = dt.Rows[i]["EmployeeID"].ToString();
                string strEmployeeName = dt.Rows[i]["EmployeeName"].ToString();
                string strCustomerName = dt.Rows[i]["CustomerName"].ToString();
                string strCustomerID = dt.Rows[i]["CustomerID"].ToString();
                string strStartDate = dt.Rows[i]["StartDate"].ToString();

                DateTime dtStartDate = DateTime.Parse(strStartDate);
                DateTime dtEndDate = DateTime.Parse(dt.Rows[i]["EndDate"].ToString());

                string sStartDate = strStartDate.Substring(8, 2);//開始日
                string sEndDate = dtEndDate.AddDays(1).ToString().Substring(8, 2);//終了日

                string strQuantity = dt.Rows[i]["Quantity"].ToString();

                int intStartDate = 0;
                int intEndDate = 0;

                double quantity = 0;
                int intCell = 0;

                if (!string.IsNullOrEmpty(strEmployeeName) && !string.IsNullOrEmpty(strCustomerName))  // 社員IDと顧客IDがある場合
                {
                    dgvEmployeeWork.Rows[index].Cells[0].Value = strEmployeeName;
                    dgvEmployeeWork.Rows[index].Cells[1].Value = strCustomerName;

                    if (sStartDate == "01" && sEndDate == "01") //開始日が月初、終了日が月末の場合
                    {
                        intStartDate = int.Parse(strStartDate.Substring(5, 2));
                        intEndDate = int.Parse(dtEndDate.ToString().Substring(5, 2));

                        for (int j = intStartDate; j <= intEndDate; j++)
                        {
                            dgvEmployeeWork.Rows[index].Cells[j + 1].Style.BackColor = Color.Aqua;
                            dgvEmployeeWork.Rows[index].Cells[j + 1].Value = "1";
                        }
                    }
                    else if (sStartDate != "01" && sEndDate == "01") //開始日が月初ではない、終了日が月末
                    {
                        DateTime start_month = DateTime.Parse(dtStartDate.ToString("yyyy/MM"));
                        DateTime end_month = DateTime.Parse(dtEndDate.ToString("yyyy/MM"));

                        if (DateTime.Compare(start_month, end_month) == 0)
                        {
                            quantity = HolidayHelper.GetQuantityBetween(dtStartDate, dtEndDate);

                            intCell = int.Parse(strStartDate.Substring(5, 2));
                            dgvEmployeeWork.Rows[index].Cells[intCell + 1].Style.BackColor = Color.Aqua;
                            dgvEmployeeWork.Rows[index].Cells[intCell + 1].Value = quantity.ToString();
                        }
                        else if (DateTime.Compare(start_month, end_month) < 0)
                        {
                            //開始月
                            DateTime dtEndDate1 = dtStartDate.AddMonths(1).AddDays(-1);
                            quantity = HolidayHelper.GetQuantityBetween(dtStartDate, dtEndDate1);
                            
                            intCell = int.Parse(strStartDate.Substring(5, 2));
                            dgvEmployeeWork.Rows[index].Cells[intCell + 1].Style.BackColor = Color.Aqua;
                            dgvEmployeeWork.Rows[index].Cells[intCell + 1].Value = quantity.ToString();

                            //次月から終了月まで
                            intStartDate = int.Parse(dtStartDate.AddMonths(1).ToString().Substring(5, 2));
                            intEndDate = int.Parse(dtEndDate.ToString().Substring(5, 2));

                            for (int j = intStartDate; j <= intEndDate; j++)
                            {
                                dgvEmployeeWork.Rows[index].Cells[j + 1].Style.BackColor = Color.Aqua;
                                dgvEmployeeWork.Rows[index].Cells[j + 1].Value = "1";
                            }
                        }
                    }
                    else if (sStartDate == "01" && sEndDate != "01")//開始日が月初である、終了日が月末ではない
                    {
                        DateTime start_month = DateTime.Parse(dtStartDate.ToString("yyyy/MM"));
                        DateTime end_month = DateTime.Parse(dtEndDate.ToString("yyyy/MM"));

                        if (DateTime.Compare(start_month, end_month) == 0)
                        {
                            quantity = HolidayHelper.GetQuantityBetween(dtStartDate, dtEndDate);

                            intCell = int.Parse(strStartDate.Substring(5, 2));
                            dgvEmployeeWork.Rows[index].Cells[intCell + 1].Style.BackColor = Color.Aqua;
                            dgvEmployeeWork.Rows[index].Cells[intCell + 1].Value = quantity.ToString();
                        }
                        else if (DateTime.Compare(start_month, end_month) < 0)
                        {
                            //開始月から終了月の先月まで DateTime dtEndDate1 = DateTime.Parse(dtEndDate.ToString("yyyy/MM")).AddDays(-1);
                            intStartDate = int.Parse(dtStartDate.ToString().Substring(5,2));
                            intEndDate = int.Parse(dtEndDate.AddMonths(-1).ToString().Substring(5,2));

                            for (int j = intStartDate; j <= intEndDate; j++)
                            {
                                dgvEmployeeWork.Rows[index].Cells[j + 1].Style.BackColor = Color.Aqua;
                                dgvEmployeeWork.Rows[index].Cells[j + 1].Value = "1";
                            }

                            //終了月
                            quantity = HolidayHelper.GetQuantityBetween(end_month, dtEndDate);

                            intCell = int.Parse(dtEndDate.ToString().Substring(5, 2));
                            dgvEmployeeWork.Rows[index].Cells[intCell + 1].Style.BackColor = Color.Aqua;
                            dgvEmployeeWork.Rows[index].Cells[intCell + 1].Value = quantity.ToString();
                        }

                    }
                    else if (sStartDate != "01" && sEndDate != "01")//開始日が月初ではない、終了日が月末ではないの場合
                    {
                        intCell = int.Parse(strStartDate.Substring(5, 2));
                        int intCell1 = int.Parse(dtEndDate.ToString().Substring(5, 2));

                        dgvEmployeeWork.Rows[index].Cells[intCell + 1].Style.BackColor = Color.Red;
                        dgvEmployeeWork.Rows[index].Cells[intCell + 1].Value = "?";

                        dgvEmployeeWork.Rows[index].Cells[intCell1 + 1].Style.BackColor = Color.Red;
                        dgvEmployeeWork.Rows[index].Cells[intCell1 + 1].Value = "?";

                        intStartDate = int.Parse(strStartDate.Substring(5, 2)) + 1;
                        intEndDate = int.Parse(dtEndDate.ToString().Substring(5, 2)) - 1;
                        for (int j = intStartDate; j <= intEndDate; j++)
                        {
                            dgvEmployeeWork.Rows[index].Cells[j + 1].Style.BackColor = Color.Aqua;
                            dgvEmployeeWork.Rows[index].Cells[j + 1].Value = "1";
                        }

                    }

                    if (i < dt.Rows.Count-1)
                        index = this.dgvEmployeeWork.Rows.Add();
                }
                
            }

            checkOverRate();
        }
        
        private void checkOverRate() 
        {

            //行、列初期化；社員名初期化
            int intRow = dgvEmployeeWork.RowCount;
            int intCol = dgvEmployeeWork.ColumnCount;
            string strEmployee = "";
            
            decimal decCount = 0;
 
            strEmployee = dgvEmployeeWork.Rows[0].Cells[0].Value.ToString();
            
                     
            //列毎に
            for (int j = 2; j < intCol-1; j++ )
            {
                int startRow = 0;
                int endRow = 0;
                decCount = 0;
               
                //行毎に
                for (int i = 0; i < intRow-1; i++)
                {


                    if (strEmployee == dgvEmployeeWork.Rows[i].Cells[0].Value.ToString())    //同一社員の場合
                    {
                        if (dgvEmployeeWork.Rows[i].Cells[j].Value != null && dgvEmployeeWork.Rows[i].Cells[j].Value.ToString() != "?")
                        {
                            decCount = decCount + Decimal.Parse(dgvEmployeeWork.Rows[i].Cells[j].Value.ToString());  //稼働率合計
                        }
                    }
                    else 　　　　　　　　　　　　　　　　　　　　　　　　　　　　//社員毎に
                    {
                        strEmployee = dgvEmployeeWork.Rows[i].Cells[0].Value.ToString();    //社員名を取得
                        if (decCount > 1)
                        {
                            
                            endRow=i-1;

                            for (int k=startRow; k<=endRow; k++)
                            {
                                if (!string.IsNullOrEmpty((string)dgvEmployeeWork.Rows[k].Cells[j].Value))
                                    dgvEmployeeWork.Rows[k].Cells[j].Style.BackColor = Color.Red;　　　　//合計値が1を超えたら、背景色赤に設定
                            }
                        }

                        startRow = i;
                        endRow = i;

                        if (dgvEmployeeWork.Rows[i].Cells[j].Value != null && dgvEmployeeWork.Rows[i].Cells[j].Value.ToString() != "?" && dgvEmployeeWork.Rows[i].Cells[j].Value.ToString().Length >0)
                        {
                            decCount = Decimal.Parse(dgvEmployeeWork.Rows[i].Cells[j].Value.ToString());  //稼働率取得
                        }
                        else 
                        {
                            decCount = 0;
                        }

                    }
                 }

                }
            }
        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobYear_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cobYear.SelectedValue != null && cobYear.SelectedValue.ToString().Trim().Length != 0)
            {
                while (dgvEmployeeWork.Rows.Count - 1 > 0)
                {
                    dgvEmployeeWork.Rows.Remove(dgvEmployeeWork.Rows[0]);
                }

                string strYear = "";

                strYear = cobYear.SelectedValue.ToString();

                string strEmployee = textBox1.Text;
                bindDataGridView(strYear, strEmployee);

            }
        }

        private void sumEmployeeWork()
        {
            int rows = dgvEmployeeWork.RowCount;
            string temp = string.Empty;
            double sum = 0;

            for (int i = 0; i < rows; i++)
            {
                string employeeName = dgvEmployeeWork.Rows[i].Cells[0].Value.ToString();
                double quantity = double.Parse( dgvEmployeeWork.Rows[i].Cells[2].Value.ToString());

                if (temp == employeeName)
                {
                    sum = sum + quantity;
                }
                else
                {
                    sum = quantity;
                }


            }
        }

        



        #endregion

        private void btnSearch_Click(object sender, EventArgs e)
        {
            while (dgvEmployeeWork.Rows.Count - 1 > 0)
            {
                dgvEmployeeWork.Rows.Remove(dgvEmployeeWork.Rows[0]);
            }

            loadData();
        }

        private void cobYear_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        //private void dgvEmployeeWork_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        //{
        //    // 对第1列相同单元格进行合并 
        //    if (e.ColumnIndex == 0 && e.RowIndex != -1)
        //    {
        //        using
        //        (
        //        Brush gridBrush = new SolidBrush(this.dgvEmployeeWork.GridColor),
        //        backColorBrush = new SolidBrush(e.CellStyle.BackColor)
        //        )
        //        {
        //            using (Pen gridLinePen = new Pen(gridBrush))
        //            {
        //                // 清除单元格 
        //                e.Graphics.FillRectangle(backColorBrush, e.CellBounds);
        //                // 画 Grid 边线（仅画单元格的底边线和右边线） 
        //                // 如果下一行和当前行的数据不同，则在当前的单元格画一条底边线 
        //                if (e.RowIndex < dgvEmployeeWork.Rows.Count - 1 &&
        //                dgvEmployeeWork.Rows[e.RowIndex + 1].Cells[e.ColumnIndex].Value.ToString() !=
        //                e.Value.ToString())
        //                    e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left + 2,
        //                    e.CellBounds.Bottom - 1, e.CellBounds.Right - 1,
        //                    e.CellBounds.Bottom - 1);
        //                //画最后一条记录的底线 
        //                if (e.RowIndex == dgvEmployeeWork.Rows.Count - 1)
        //                    e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left + 2,
        //                    e.CellBounds.Bottom - 1, e.CellBounds.Right - 1,
        //                    e.CellBounds.Bottom - 1);
        //                // 画右边线 
        //                e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1,
        //                e.CellBounds.Top, e.CellBounds.Right - 1,
        //                e.CellBounds.Bottom);
        //                // 画左边线 
        //                e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left + 2,
        //                e.CellBounds.Top, e.CellBounds.Left + 2,
        //                e.CellBounds.Bottom);
        //                // 画（填写）单元格内容，相同的内容的单元格只填写第一个 
        //                if (e.Value != null)
        //                {
        //                    if (e.RowIndex > 0 &&
        //                    dgvEmployeeWork.Rows[e.RowIndex - 1].Cells[e.ColumnIndex].Value.ToString() ==
        //                    e.Value.ToString())
        //                    {
        //                    }
        //                    else
        //                    {
        //                        e.Graphics.DrawString((String)e.Value, e.CellStyle.Font,
        //                        Brushes.Black, e.CellBounds.X + 2,
        //                        e.CellBounds.Y + 5, StringFormat.GenericDefault);
        //                    }
        //                }
        //                e.Handled = true;
        //            }
        //        }
        //    } 
        //}

    }
}
