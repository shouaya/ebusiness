﻿namespace EB.Master
{
    partial class CustomerModifyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cobPaymentDay = new System.Windows.Forms.ComboBox();
            this.cobPaymentType = new System.Windows.Forms.ComboBox();
            this.txtJapaneseSpell = new System.Windows.Forms.TextBox();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.txtUndertakerMail = new System.Windows.Forms.TextBox();
            this.txtUndertaker = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.txtPostCode = new System.Windows.Forms.TextBox();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.txtRepresentor = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnModify = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtFoundDate = new System.Windows.Forms.DateTimePicker();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtCapital = new EB.Common.DigitTextBox();
            this.txtEmployeeCount = new EB.Common.DigitTextBox();
            this.txtSaleAmount = new EB.Common.DigitTextBox();
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(437, 396);
            // 
            // cobPaymentDay
            // 
            this.cobPaymentDay.DisplayMember = "CodeName";
            this.cobPaymentDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobPaymentDay.FormattingEnabled = true;
            this.cobPaymentDay.Location = new System.Drawing.Point(200, 313);
            this.cobPaymentDay.Name = "cobPaymentDay";
            this.cobPaymentDay.Size = new System.Drawing.Size(61, 20);
            this.cobPaymentDay.TabIndex = 18;
            this.cobPaymentDay.ValueMember = "CodeId";
            // 
            // cobPaymentType
            // 
            this.cobPaymentType.DisplayMember = "CodeName";
            this.cobPaymentType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobPaymentType.FormattingEnabled = true;
            this.cobPaymentType.Location = new System.Drawing.Point(91, 313);
            this.cobPaymentType.Name = "cobPaymentType";
            this.cobPaymentType.Size = new System.Drawing.Size(93, 20);
            this.cobPaymentType.TabIndex = 17;
            this.cobPaymentType.ValueMember = "CodeId";
            // 
            // txtJapaneseSpell
            // 
            this.txtJapaneseSpell.Location = new System.Drawing.Point(91, 57);
            this.txtJapaneseSpell.MaxLength = 100;
            this.txtJapaneseSpell.Name = "txtJapaneseSpell";
            this.txtJapaneseSpell.Size = new System.Drawing.Size(117, 19);
            this.txtJapaneseSpell.TabIndex = 2;
            // 
            // txtRemark
            // 
            this.txtRemark.Location = new System.Drawing.Point(91, 339);
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.Size = new System.Drawing.Size(100, 19);
            this.txtRemark.TabIndex = 15;
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(91, 361);
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(323, 19);
            this.txtNote.TabIndex = 16;
            // 
            // txtUndertakerMail
            // 
            this.txtUndertakerMail.Location = new System.Drawing.Point(91, 287);
            this.txtUndertakerMail.Name = "txtUndertakerMail";
            this.txtUndertakerMail.Size = new System.Drawing.Size(247, 19);
            this.txtUndertakerMail.TabIndex = 14;
            // 
            // txtUndertaker
            // 
            this.txtUndertaker.Location = new System.Drawing.Point(91, 264);
            this.txtUndertaker.Name = "txtUndertaker";
            this.txtUndertaker.Size = new System.Drawing.Size(100, 19);
            this.txtUndertaker.TabIndex = 13;
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(91, 241);
            this.txtTel.MaxLength = 13;
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(100, 19);
            this.txtTel.TabIndex = 11;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Location = new System.Drawing.Point(91, 218);
            this.txtAddress2.MaxLength = 100;
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(247, 19);
            this.txtAddress2.TabIndex = 10;
            // 
            // txtAddress1
            // 
            this.txtAddress1.Location = new System.Drawing.Point(91, 195);
            this.txtAddress1.MaxLength = 100;
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(247, 19);
            this.txtAddress1.TabIndex = 9;
            // 
            // txtPostCode
            // 
            this.txtPostCode.Location = new System.Drawing.Point(91, 172);
            this.txtPostCode.MaxLength = 8;
            this.txtPostCode.Name = "txtPostCode";
            this.txtPostCode.Size = new System.Drawing.Size(100, 19);
            this.txtPostCode.TabIndex = 8;
            // 
            // txtFax
            // 
            this.txtFax.Location = new System.Drawing.Point(314, 241);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(100, 19);
            this.txtFax.TabIndex = 12;
            // 
            // txtRepresentor
            // 
            this.txtRepresentor.Location = new System.Drawing.Point(91, 80);
            this.txtRepresentor.MaxLength = 100;
            this.txtRepresentor.Name = "txtRepresentor";
            this.txtRepresentor.Size = new System.Drawing.Size(247, 19);
            this.txtRepresentor.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 27;
            this.label5.Text = "代表者名";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(55, 246);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(25, 12);
            this.label14.TabIndex = 29;
            this.label14.Text = "TEL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 292);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 12);
            this.label12.TabIndex = 31;
            this.label12.Text = "担当者MAIL";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(43, 200);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 12);
            this.label10.TabIndex = 30;
            this.label10.Text = "住所１";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(27, 269);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 28;
            this.label13.Text = "担当者名";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 10;
            this.label8.Text = "売上高";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(51, 364);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 7;
            this.label25.Text = "備考";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(51, 342);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 15;
            this.label11.Text = "評価";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(43, 223);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 12);
            this.label9.TabIndex = 23;
            this.label9.Text = "住所２";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(63, 178);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 12);
            this.label7.TabIndex = 22;
            this.label7.Text = "〒";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(197, 150);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 12);
            this.label24.TabIndex = 24;
            this.label24.Text = "万円";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(24, 316);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(56, 12);
            this.label28.TabIndex = 26;
            this.label28.Text = "支払サイト";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(282, 246);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(27, 12);
            this.label27.TabIndex = 25;
            this.label27.Text = "FAX";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(198, 129);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(29, 12);
            this.label23.TabIndex = 21;
            this.label23.Text = "万円";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(255, 131);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 12);
            this.label22.TabIndex = 17;
            this.label22.Text = "従業員数";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 109);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 16;
            this.label6.Text = "設立年月日";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 18;
            this.label4.Text = "資本金";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 12);
            this.label3.TabIndex = 20;
            this.label3.Text = "ﾌﾘｶﾞﾅ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 19;
            this.label2.Text = "顧客名";
            // 
            // btnModify
            // 
            this.btnModify.Location = new System.Drawing.Point(201, 396);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(75, 23);
            this.btnModify.TabIndex = 20;
            this.btnModify.Text = "修正";
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(314, 396);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 21;
            this.btnDelete.Text = "削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtFoundDate
            // 
            this.txtFoundDate.CustomFormat = "yyyy/MM/dd";
            this.txtFoundDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtFoundDate.Location = new System.Drawing.Point(91, 103);
            this.txtFoundDate.Name = "txtFoundDate";
            this.txtFoundDate.Size = new System.Drawing.Size(100, 19);
            this.txtFoundDate.TabIndex = 4;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(91, 34);
            this.txtCustomerName.MaxLength = 100;
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(247, 19);
            this.txtCustomerName.TabIndex = 1;
            // 
            // txtCapital
            // 
            this.txtCapital.Location = new System.Drawing.Point(91, 126);
            this.txtCapital.MaxLength = 15;
            this.txtCapital.Name = "txtCapital";
            this.txtCapital.Size = new System.Drawing.Size(100, 19);
            this.txtCapital.TabIndex = 5;
            // 
            // txtEmployeeCount
            // 
            this.txtEmployeeCount.Location = new System.Drawing.Point(314, 126);
            this.txtEmployeeCount.MaxLength = 15;
            this.txtEmployeeCount.Name = "txtEmployeeCount";
            this.txtEmployeeCount.Size = new System.Drawing.Size(100, 19);
            this.txtEmployeeCount.TabIndex = 6;
            // 
            // txtSaleAmount
            // 
            this.txtSaleAmount.Location = new System.Drawing.Point(91, 149);
            this.txtSaleAmount.MaxLength = 15;
            this.txtSaleAmount.Name = "txtSaleAmount";
            this.txtSaleAmount.Size = new System.Drawing.Size(100, 19);
            this.txtSaleAmount.TabIndex = 7;
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.Location = new System.Drawing.Point(91, 10);
            this.txtCustomerID.MaxLength = 30;
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.ReadOnly = true;
            this.txtCustomerID.Size = new System.Drawing.Size(95, 19);
            this.txtCustomerID.TabIndex = 124;
            this.txtCustomerID.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(40, 13);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 12);
            this.label16.TabIndex = 125;
            this.label16.Text = "顧客ID";
            // 
            // CustomerModifyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(528, 435);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtCustomerID);
            this.Controls.Add(this.txtSaleAmount);
            this.Controls.Add(this.txtEmployeeCount);
            this.Controls.Add(this.txtCapital);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.txtFoundDate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnModify);
            this.Controls.Add(this.cobPaymentDay);
            this.Controls.Add(this.cobPaymentType);
            this.Controls.Add(this.txtJapaneseSpell);
            this.Controls.Add(this.txtRemark);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.txtUndertakerMail);
            this.Controls.Add(this.txtTel);
            this.Controls.Add(this.txtAddress2);
            this.Controls.Add(this.txtAddress1);
            this.Controls.Add(this.txtPostCode);
            this.Controls.Add(this.txtFax);
            this.Controls.Add(this.txtRepresentor);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtUndertaker);
            this.Name = "CustomerModifyForm";
            this.Text = "顧客修正／削除";
            this.Load += new System.EventHandler(this.CustomerModifyForm_Load);
            this.Controls.SetChildIndex(this.txtUndertaker, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label6, 0);
            this.Controls.SetChildIndex(this.label22, 0);
            this.Controls.SetChildIndex(this.label23, 0);
            this.Controls.SetChildIndex(this.label27, 0);
            this.Controls.SetChildIndex(this.label28, 0);
            this.Controls.SetChildIndex(this.label24, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.label25, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.txtRepresentor, 0);
            this.Controls.SetChildIndex(this.txtFax, 0);
            this.Controls.SetChildIndex(this.txtPostCode, 0);
            this.Controls.SetChildIndex(this.txtAddress1, 0);
            this.Controls.SetChildIndex(this.txtAddress2, 0);
            this.Controls.SetChildIndex(this.txtTel, 0);
            this.Controls.SetChildIndex(this.txtUndertakerMail, 0);
            this.Controls.SetChildIndex(this.txtNote, 0);
            this.Controls.SetChildIndex(this.txtRemark, 0);
            this.Controls.SetChildIndex(this.txtJapaneseSpell, 0);
            this.Controls.SetChildIndex(this.cobPaymentType, 0);
            this.Controls.SetChildIndex(this.cobPaymentDay, 0);
            this.Controls.SetChildIndex(this.btnModify, 0);
            this.Controls.SetChildIndex(this.btnDelete, 0);
            this.Controls.SetChildIndex(this.txtFoundDate, 0);
            this.Controls.SetChildIndex(this.txtCustomerName, 0);
            this.Controls.SetChildIndex(this.txtCapital, 0);
            this.Controls.SetChildIndex(this.txtEmployeeCount, 0);
            this.Controls.SetChildIndex(this.txtSaleAmount, 0);
            this.Controls.SetChildIndex(this.txtCustomerID, 0);
            this.Controls.SetChildIndex(this.label16, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cobPaymentDay;
        private System.Windows.Forms.ComboBox cobPaymentType;
        private System.Windows.Forms.TextBox txtJapaneseSpell;
        private System.Windows.Forms.TextBox txtRemark;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.TextBox txtUndertakerMail;
        private System.Windows.Forms.TextBox txtUndertaker;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.TextBox txtPostCode;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.TextBox txtRepresentor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DateTimePicker txtFoundDate;
        private System.Windows.Forms.TextBox txtCustomerName;
        private Common.DigitTextBox txtCapital;
        private Common.DigitTextBox txtEmployeeCount;
        private Common.DigitTextBox txtSaleAmount;
        private System.Windows.Forms.TextBox txtCustomerID;
        private System.Windows.Forms.Label label16;
    }
}