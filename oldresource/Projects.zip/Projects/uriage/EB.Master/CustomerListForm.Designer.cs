﻿namespace EB.Master
{
    partial class CustomerListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCustomerRegister = new System.Windows.Forms.Button();
            this.searcharea = new System.Windows.Forms.Panel();
            this.resCount = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.keyword = new System.Windows.Forms.TextBox();
            this.btnarea = new System.Windows.Forms.Panel();
            this.dgvCustomer = new System.Windows.Forms.DataGridView();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Representor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Undertaker = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UndertakerMail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remark = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JapaneseSpell = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FoundDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Capital = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaleAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PostCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentDay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.searcharea.SuspendLayout();
            this.btnarea.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(808, 14);
            // 
            // btnCustomerRegister
            // 
            this.btnCustomerRegister.Location = new System.Drawing.Point(17, 14);
            this.btnCustomerRegister.Name = "btnCustomerRegister";
            this.btnCustomerRegister.Size = new System.Drawing.Size(187, 23);
            this.btnCustomerRegister.TabIndex = 50;
            this.btnCustomerRegister.Text = "新規登録";
            this.btnCustomerRegister.UseVisualStyleBackColor = true;
            this.btnCustomerRegister.Click += new System.EventHandler(this.btnCustomerRegister_Click);
            // 
            // searcharea
            // 
            this.searcharea.Controls.Add(this.resCount);
            this.searcharea.Controls.Add(this.btnsearch);
            this.searcharea.Controls.Add(this.keyword);
            this.searcharea.Dock = System.Windows.Forms.DockStyle.Top;
            this.searcharea.Location = new System.Drawing.Point(0, 0);
            this.searcharea.Name = "searcharea";
            this.searcharea.Size = new System.Drawing.Size(904, 49);
            this.searcharea.TabIndex = 51;
            // 
            // resCount
            // 
            this.resCount.AutoSize = true;
            this.resCount.Location = new System.Drawing.Point(490, 21);
            this.resCount.Name = "resCount";
            this.resCount.Size = new System.Drawing.Size(11, 12);
            this.resCount.TabIndex = 55;
            this.resCount.Text = "1";
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(358, 12);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(84, 26);
            this.btnsearch.TabIndex = 54;
            this.btnsearch.Text = "検索";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // keyword
            // 
            this.keyword.Font = new System.Drawing.Font("MS UI Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.keyword.Location = new System.Drawing.Point(17, 12);
            this.keyword.Name = "keyword";
            this.keyword.Size = new System.Drawing.Size(334, 26);
            this.keyword.TabIndex = 53;
            this.keyword.KeyDown += new System.Windows.Forms.KeyEventHandler(this._KeyDown);
            // 
            // btnarea
            // 
            this.btnarea.Controls.Add(this.btnCustomerRegister);
            this.btnarea.Controls.Add(this.btnClose);
            this.btnarea.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnarea.Location = new System.Drawing.Point(0, 518);
            this.btnarea.Name = "btnarea";
            this.btnarea.Size = new System.Drawing.Size(904, 49);
            this.btnarea.TabIndex = 52;
            this.btnarea.Controls.SetChildIndex(this.btnClose, 0);
            this.btnarea.Controls.SetChildIndex(this.btnCustomerRegister, 0);
            // 
            // dgvCustomer
            // 
            this.dgvCustomer.AllowDrop = true;
            this.dgvCustomer.AllowUserToAddRows = false;
            this.dgvCustomer.AllowUserToDeleteRows = false;
            this.dgvCustomer.AllowUserToResizeRows = false;
            this.dgvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CustomerID,
            this.CustomerName,
            this.Representor,
            this.Tel,
            this.Undertaker,
            this.UndertakerMail,
            this.Remark,
            this.JapaneseSpell,
            this.FoundDate,
            this.Capital,
            this.EmployeeCount,
            this.SaleAmount,
            this.PostCode,
            this.Address1,
            this.Address2,
            this.Fax,
            this.Note,
            this.PaymentType,
            this.PaymentDay});
            this.dgvCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCustomer.Location = new System.Drawing.Point(0, 49);
            this.dgvCustomer.MultiSelect = false;
            this.dgvCustomer.Name = "dgvCustomer";
            this.dgvCustomer.ReadOnly = true;
            this.dgvCustomer.RowHeadersVisible = false;
            this.dgvCustomer.RowTemplate.Height = 23;
            this.dgvCustomer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCustomer.Size = new System.Drawing.Size(904, 469);
            this.dgvCustomer.TabIndex = 53;
            this.dgvCustomer.TabStop = false;
            this.dgvCustomer.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmployee_CellDoubleClick);
            this.dgvCustomer.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this._CellMouseDown);
            // 
            // CustomerID
            // 
            this.CustomerID.DataPropertyName = "CustomerID";
            this.CustomerID.Frozen = true;
            this.CustomerID.HeaderText = "顧客ID";
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.ReadOnly = true;
            this.CustomerID.Width = 65;
            // 
            // CustomerName
            // 
            this.CustomerName.DataPropertyName = "CustomerName";
            this.CustomerName.Frozen = true;
            this.CustomerName.HeaderText = "顧客名";
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.ReadOnly = true;
            this.CustomerName.Width = 130;
            // 
            // Representor
            // 
            this.Representor.DataPropertyName = "Representor";
            this.Representor.Frozen = true;
            this.Representor.HeaderText = "代表者名";
            this.Representor.Name = "Representor";
            this.Representor.ReadOnly = true;
            // 
            // Tel
            // 
            this.Tel.DataPropertyName = "Tel";
            this.Tel.Frozen = true;
            this.Tel.HeaderText = "電話番号";
            this.Tel.Name = "Tel";
            this.Tel.ReadOnly = true;
            this.Tel.Width = 90;
            // 
            // Undertaker
            // 
            this.Undertaker.DataPropertyName = "Undertaker";
            this.Undertaker.Frozen = true;
            this.Undertaker.HeaderText = "担当者";
            this.Undertaker.Name = "Undertaker";
            this.Undertaker.ReadOnly = true;
            // 
            // UndertakerMail
            // 
            this.UndertakerMail.DataPropertyName = "UndertakerMail";
            this.UndertakerMail.Frozen = true;
            this.UndertakerMail.HeaderText = "担当者MAIL";
            this.UndertakerMail.Name = "UndertakerMail";
            this.UndertakerMail.ReadOnly = true;
            this.UndertakerMail.Width = 110;
            // 
            // Remark
            // 
            this.Remark.DataPropertyName = "Remark";
            this.Remark.Frozen = true;
            this.Remark.HeaderText = "評価";
            this.Remark.Name = "Remark";
            this.Remark.ReadOnly = true;
            // 
            // JapaneseSpell
            // 
            this.JapaneseSpell.DataPropertyName = "JapaneseSpell";
            this.JapaneseSpell.Frozen = true;
            this.JapaneseSpell.HeaderText = "フリカナ";
            this.JapaneseSpell.Name = "JapaneseSpell";
            this.JapaneseSpell.ReadOnly = true;
            // 
            // FoundDate
            // 
            this.FoundDate.DataPropertyName = "FoundDate";
            this.FoundDate.Frozen = true;
            this.FoundDate.HeaderText = "設立年月日";
            this.FoundDate.Name = "FoundDate";
            this.FoundDate.ReadOnly = true;
            // 
            // Capital
            // 
            this.Capital.DataPropertyName = "Capital";
            this.Capital.Frozen = true;
            this.Capital.HeaderText = "資本金";
            this.Capital.Name = "Capital";
            this.Capital.ReadOnly = true;
            // 
            // EmployeeCount
            // 
            this.EmployeeCount.DataPropertyName = "EmployeeCount";
            this.EmployeeCount.Frozen = true;
            this.EmployeeCount.HeaderText = "従業員数";
            this.EmployeeCount.Name = "EmployeeCount";
            this.EmployeeCount.ReadOnly = true;
            // 
            // SaleAmount
            // 
            this.SaleAmount.DataPropertyName = "SaleAmount";
            this.SaleAmount.Frozen = true;
            this.SaleAmount.HeaderText = "売上高";
            this.SaleAmount.Name = "SaleAmount";
            this.SaleAmount.ReadOnly = true;
            // 
            // PostCode
            // 
            this.PostCode.DataPropertyName = "PostCode";
            this.PostCode.Frozen = true;
            this.PostCode.HeaderText = "郵便番号";
            this.PostCode.Name = "PostCode";
            this.PostCode.ReadOnly = true;
            // 
            // Address1
            // 
            this.Address1.DataPropertyName = "Address1";
            this.Address1.Frozen = true;
            this.Address1.HeaderText = "住所１";
            this.Address1.Name = "Address1";
            this.Address1.ReadOnly = true;
            // 
            // Address2
            // 
            this.Address2.DataPropertyName = "Address2";
            this.Address2.Frozen = true;
            this.Address2.HeaderText = "住所２";
            this.Address2.Name = "Address2";
            this.Address2.ReadOnly = true;
            // 
            // Fax
            // 
            this.Fax.DataPropertyName = "Fax";
            this.Fax.Frozen = true;
            this.Fax.HeaderText = "ファックス";
            this.Fax.Name = "Fax";
            this.Fax.ReadOnly = true;
            // 
            // Note
            // 
            this.Note.DataPropertyName = "Note";
            this.Note.Frozen = true;
            this.Note.HeaderText = "備考";
            this.Note.Name = "Note";
            this.Note.ReadOnly = true;
            // 
            // PaymentType
            // 
            this.PaymentType.DataPropertyName = "PaymentType";
            this.PaymentType.Frozen = true;
            this.PaymentType.HeaderText = "支払方法";
            this.PaymentType.Name = "PaymentType";
            this.PaymentType.ReadOnly = true;
            // 
            // PaymentDay
            // 
            this.PaymentDay.DataPropertyName = "PaymentDay";
            this.PaymentDay.Frozen = true;
            this.PaymentDay.HeaderText = "支払日";
            this.PaymentDay.Name = "PaymentDay";
            this.PaymentDay.ReadOnly = true;
            // 
            // CustomerListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(904, 567);
            this.Controls.Add(this.dgvCustomer);
            this.Controls.Add(this.searcharea);
            this.Controls.Add(this.btnarea);
            this.MaximizeBox = true;
            this.Name = "CustomerListForm";
            this.Text = "顧客様一覧";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.EmployeeAddForm_Load);
            this.searcharea.ResumeLayout(false);
            this.searcharea.PerformLayout();
            this.btnarea.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCustomerRegister;
        private System.Windows.Forms.Panel searcharea;
        private System.Windows.Forms.Label resCount;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.TextBox keyword;
        private System.Windows.Forms.Panel btnarea;
        private System.Windows.Forms.DataGridView dgvCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Representor;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel;
        private System.Windows.Forms.DataGridViewTextBoxColumn Undertaker;
        private System.Windows.Forms.DataGridViewTextBoxColumn UndertakerMail;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remark;
        private System.Windows.Forms.DataGridViewTextBoxColumn JapaneseSpell;
        private System.Windows.Forms.DataGridViewTextBoxColumn FoundDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Capital;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaleAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn PostCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fax;
        private System.Windows.Forms.DataGridViewTextBoxColumn Note;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentType;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentDay;
    }
}