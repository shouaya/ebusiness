﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EB.Common;
using EB.DBAcess.DAL;

namespace EB.Master
{
    public partial class CustomerTotalForm : DialogForm
    {
        public CustomerTotalForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 画面初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustomerTotalForm_Load(object sender, EventArgs e)
        {
            bindCommbox();                                               // Commbox DataSourceを指定

            loadData();                                                  // 画面データを初期化
        }

        /// <summary>
        /// Commbox DataSourceを指定
        /// </summary>
        private void bindCommbox()
        {
            BL_CustomerTotal bl = BL_CustomerTotal.GetInstance();

            cobYear.DataSource = bl.SelectYears();                        // 契約年

            int i = cobYear.Items.Count;

            cobYear.SelectedIndex = i - 1;

            cobCustomer.DataSource = bl.SelectCustomerName(cobYear.Text); // 顧客名

            cobCustomer.SelectedIndex = -1;                               // 顧客名デフォルト値＝空
        }

        /// <summary>
        /// 画面データを初期化
        /// </summary>
        private void loadData()
        {
            string strYear = cobYear.Text;           // 年を指定

            string strCustomer = cobCustomer.Text;   // 顧客名を指定

            bindDataGridView( strYear, strCustomer); // 年と顧客名により明細部にデータをセット
        }

        // 明細部にデータをセット
        private void bindDataGridView( string strYear, string strCustomer)
        {
            BL_CustomerTotal bl = BL_CustomerTotal.GetInstance();

            DataTable dt = bl.SelectForCustomerTotalForm(strYear, strCustomer); // 画面の検索条件（年、顧客名）でDBからデータを取得
            string temp = string.Empty;
            string temp_strCustomer = string.Empty;
            int index = 0;

            // 明細部にデータをセット（一番したの合計以外の部分）
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string strCustomerID = dt.Rows[i]["CustomerID"].ToString();
                string strCustomerName = dt.Rows[i]["CustomerName"].ToString();
                string strEmployeeID = String.Format("{0:#,0}", dt.Rows[i]["EmployeeCount"]);
                string strAmount = String.Format("{0:C}", dt.Rows[i]["Amount"]);
                string strCost = String.Format("{0:C}",dt.Rows[i]["Cost"]);
                int intMM = int.Parse( dt.Rows[i]["MM"].ToString());
                string strTest = String.Format("{0:C}円の商品を{1:000}個買う", "1000", 12);
                string strAmount1 = String.Format("{0:C}", dt.Rows[i]["Amount"]);
                strAmount = String.Format("{0:C}", strAmount);

                if (temp != strCustomerID)
                {
                    temp = strCustomerID;

                    index = this.dgvCustomerTotal.Rows.Add();                            // 次の行に移動

                    dgvCustomerTotal.Rows[index].Cells[0].Value = strCustomerName;       // 顧客社名をセット
                    dgvCustomerTotal.Rows[index].Cells[1].Value = "技術者人数";          // 「技術者人数」タイトルセット
                    dgvCustomerTotal.Rows[index].Cells[intMM + 1].Value = strEmployeeID; // 顧客社名ごとの技術者数セット

                    index = this.dgvCustomerTotal.Rows.Add();                            // 次の行に移動

                    dgvCustomerTotal.Rows[index].Cells[1].Value = "仕入原価合計";        // 「仕入原価合計」タイトルセット
                    dgvCustomerTotal.Rows[index].Cells[intMM + 1].Value = strCost;       // 顧客社名ごとの仕入原価合計セット

                    index = this.dgvCustomerTotal.Rows.Add();                            // 次の行に移動 

                    dgvCustomerTotal.Rows[index].Cells[1].Value = "売上合計";            //「売上合計」タイトルセット
                    dgvCustomerTotal.Rows[index].Cells[intMM + 1].Value =  strAmount;    // 顧客社名ごとの売上合計セット
                }
                else
                {
                    dgvCustomerTotal.Rows[index - 2].Cells[intMM + 1].Value =  strEmployeeID;
               
                    dgvCustomerTotal.Rows[index - 1].Cells[intMM + 1].Value =  strCost;
                
                    dgvCustomerTotal.Rows[index].Cells[intMM + 1].Value =  strAmount;
                }
            }


            // 明細部にデータをセット（一番したの合計の部分）
            if ( temp_strCustomer == strCustomer )                                        // 画面で顧客名を指定されていない
            {
                index = this.dgvCustomerTotal.Rows.Add();                                 // 次の行に移動
                int index1 = this.dgvCustomerTotal.Rows.Add();                           
                int index2 = this.dgvCustomerTotal.Rows.Add();

                for (int i = 1; i < 13; i++)
                {
                    String num = i < 10 ? "0" + i.ToString() : i.ToString();

                    string strEmployeeCount = String.Format("{0:#,0}", dt.Compute("Sum(EmployeeCount)", "MM='" + num + "'"));
                    string strAmount = String.Format("{0:C}", dt.Compute("Sum(Amount)", "MM='" + num + "'"));
                    string strCost = String.Format("{0:C}", dt.Compute("Sum(Cost)", "MM='" + num + "'"));

                    dgvCustomerTotal.Rows[index].Cells[0].Value = "合計";                 // 「合計」タイトルセット
                    dgvCustomerTotal.Rows[index].Cells[1].Value = "技術者人数";           // 「技術者人数」タイトルセット
                    dgvCustomerTotal.Rows[index].Cells[i + 1].Value =
                                                                          strEmployeeCount;  // 合計の技術者数セット

                    dgvCustomerTotal.Rows[index1].Cells[1].Value = "仕入原価合計";        // 「仕入原価合計」タイトルセット
                    dgvCustomerTotal.Rows[index1].Cells[i + 1].Value = strCost;   // 合計の仕入原価セット

                    dgvCustomerTotal.Rows[index2].Cells[1].Value = "売上合計";            // 「売上合計」タイトルセット
                    dgvCustomerTotal.Rows[index2].Cells[i + 1].Value = strAmount; // 合計の売上合計セット
                }
            }
        }

        // 年を指定し、画面を再検索
        private void cobYear_SelectionChangeCommitted(object sender, EventArgs e)
        {
            BL_CustomerTotal b2 = BL_CustomerTotal.GetInstance();

            while (dgvCustomerTotal.Rows.Count - 1 > 0)
            {
                dgvCustomerTotal.Rows.Remove(dgvCustomerTotal.Rows[0]);
            }

            string strYear = cobYear.SelectedValue.ToString();                            // 指定した画面の年を取得

            cobCustomer.DataSource = b2.SelectCustomerName(cobYear.Text);                 // 指定した年により、顧客名をDBから取得

            string strCustomer = "";                                                      // 顧客名を空にする

            bindDataGridView(strYear, strCustomer);                                       // 年を指定、顧客名を指定しない状態で、集計の明細部を表示
            cobCustomer.SelectedIndex = -1;                                               // 顧客名のプルダウンをからにする
        }

        // 顧客名を指定し、画面を再検索
        private void cobCustomer_SelectionChangeCommitted(object sender, EventArgs e)
        {
            while (dgvCustomerTotal.Rows.Count - 1 > 0)
            {
                dgvCustomerTotal.Rows.Remove(dgvCustomerTotal.Rows[0]);
            }

            string strYear = cobYear.SelectedValue.ToString();                            // 指定した画面の年を取得
            string strCustomer = cobCustomer.SelectedValue.ToString();                    // 指定した画面の顧客名を取得
            bindDataGridView(strYear, strCustomer);                                       // 年と顧客名を指定した状態で、集計の明細部を表示
        }

        private void cobYear_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
