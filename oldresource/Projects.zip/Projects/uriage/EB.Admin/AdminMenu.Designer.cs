﻿namespace EB.Admin
{
    partial class AdminMenu
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.group_importexport = new System.Windows.Forms.GroupBox();
            this.ManagementBook = new System.Windows.Forms.Button();
            this.group_importexport.SuspendLayout();
            this.SuspendLayout();
            // 
            // group_importexport
            // 
            this.group_importexport.Controls.Add(this.ManagementBook);
            this.group_importexport.Location = new System.Drawing.Point(26, 13);
            this.group_importexport.Name = "group_importexport";
            this.group_importexport.Size = new System.Drawing.Size(204, 121);
            this.group_importexport.TabIndex = 0;
            this.group_importexport.TabStop = false;
            this.group_importexport.Text = "インポート・エクスポート";
            // 
            // ManagementBook
            // 
            this.ManagementBook.Location = new System.Drawing.Point(7, 38);
            this.ManagementBook.Name = "ManagementBook";
            this.ManagementBook.Size = new System.Drawing.Size(187, 23);
            this.ManagementBook.TabIndex = 0;
            this.ManagementBook.Text = "管理台帳";
            this.ManagementBook.UseVisualStyleBackColor = true;
            this.ManagementBook.Click += new System.EventHandler(this.ManagementBook_Click);
            // 
            // AdminMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(254, 174);
            this.Controls.Add(this.group_importexport);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AdminMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "売上システムー管理";
            this.group_importexport.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox group_importexport;
        private System.Windows.Forms.Button ManagementBook;

    }
}

