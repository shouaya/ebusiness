﻿namespace EB.Menu
{
    partial class SubMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpd1 = new System.Windows.Forms.GroupBox();
            this.btnEmployeeList = new System.Windows.Forms.Button();
            this.btnCustomerRegister = new System.Windows.Forms.Button();
            this.btnCompanyInfor = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnRegisterModify = new System.Windows.Forms.Button();
            this.btnEstimationRegister = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnSiiresakiModify = new System.Windows.Forms.Button();
            this.btnSiiresakiRegister = new System.Windows.Forms.Button();
            this.gpd1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Visible = false;
            // 
            // gpd1
            // 
            this.gpd1.Controls.Add(this.btnEmployeeList);
            this.gpd1.Controls.Add(this.btnCustomerRegister);
            this.gpd1.Location = new System.Drawing.Point(26, 21);
            this.gpd1.Name = "gpd1";
            this.gpd1.Size = new System.Drawing.Size(268, 126);
            this.gpd1.TabIndex = 2;
            this.gpd1.TabStop = false;
            this.gpd1.Text = "マスタ";
            // 
            // btnEmployeeList
            // 
            this.btnEmployeeList.Location = new System.Drawing.Point(43, 33);
            this.btnEmployeeList.Name = "btnEmployeeList";
            this.btnEmployeeList.Size = new System.Drawing.Size(187, 23);
            this.btnEmployeeList.TabIndex = 1;
            this.btnEmployeeList.Text = "社員一覧";
            this.btnEmployeeList.UseVisualStyleBackColor = true;
            this.btnEmployeeList.Click += new System.EventHandler(this.btnEmployeeList_Click);
            // 
            // btnCustomerRegister
            // 
            this.btnCustomerRegister.Location = new System.Drawing.Point(43, 62);
            this.btnCustomerRegister.Name = "btnCustomerRegister";
            this.btnCustomerRegister.Size = new System.Drawing.Size(187, 23);
            this.btnCustomerRegister.TabIndex = 0;
            this.btnCustomerRegister.Text = "顧客様一覧";
            this.btnCustomerRegister.UseVisualStyleBackColor = true;
            this.btnCustomerRegister.Click += new System.EventHandler(this.btnCustomerList_Click);
            // 
            // btnCompanyInfor
            // 
            this.btnCompanyInfor.Location = new System.Drawing.Point(43, 33);
            this.btnCompanyInfor.Name = "btnCompanyInfor";
            this.btnCompanyInfor.Size = new System.Drawing.Size(187, 23);
            this.btnCompanyInfor.TabIndex = 0;
            this.btnCompanyInfor.Text = "会社情報";
            this.btnCompanyInfor.UseVisualStyleBackColor = true;
            this.btnCompanyInfor.Click += new System.EventHandler(this.btnCompanyInfor_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnCompanyInfor);
            this.groupBox3.Location = new System.Drawing.Point(26, 161);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(268, 126);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "会社情報";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnRegisterModify);
            this.groupBox4.Controls.Add(this.btnEstimationRegister);
            this.groupBox4.Location = new System.Drawing.Point(313, 21);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(268, 126);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "見積情報";
            // 
            // btnRegisterModify
            // 
            this.btnRegisterModify.Enabled = false;
            this.btnRegisterModify.Location = new System.Drawing.Point(43, 62);
            this.btnRegisterModify.Name = "btnRegisterModify";
            this.btnRegisterModify.Size = new System.Drawing.Size(187, 23);
            this.btnRegisterModify.TabIndex = 0;
            this.btnRegisterModify.Text = "見積情報の修正／削除";
            this.btnRegisterModify.UseVisualStyleBackColor = true;
            this.btnRegisterModify.Click += new System.EventHandler(this.btnRegisterModify_Click);
            // 
            // btnEstimationRegister
            // 
            this.btnEstimationRegister.Enabled = false;
            this.btnEstimationRegister.Location = new System.Drawing.Point(43, 33);
            this.btnEstimationRegister.Name = "btnEstimationRegister";
            this.btnEstimationRegister.Size = new System.Drawing.Size(187, 23);
            this.btnEstimationRegister.TabIndex = 0;
            this.btnEstimationRegister.Text = "見積情報の登録";
            this.btnEstimationRegister.UseVisualStyleBackColor = true;
            this.btnEstimationRegister.Click += new System.EventHandler(this.btnEstimationRegister_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(472, 314);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(109, 23);
            this.btnReturn.TabIndex = 0;
            this.btnReturn.Text = "戻る";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnSiiresakiModify);
            this.groupBox5.Controls.Add(this.btnSiiresakiRegister);
            this.groupBox5.Enabled = false;
            this.groupBox5.Location = new System.Drawing.Point(313, 161);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(268, 126);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "仕入先情報";
            // 
            // btnSiiresakiModify
            // 
            this.btnSiiresakiModify.Location = new System.Drawing.Point(43, 62);
            this.btnSiiresakiModify.Name = "btnSiiresakiModify";
            this.btnSiiresakiModify.Size = new System.Drawing.Size(187, 23);
            this.btnSiiresakiModify.TabIndex = 0;
            this.btnSiiresakiModify.Text = "仕入先情報の修正／削除";
            this.btnSiiresakiModify.UseVisualStyleBackColor = true;
            // 
            // btnSiiresakiRegister
            // 
            this.btnSiiresakiRegister.Location = new System.Drawing.Point(43, 33);
            this.btnSiiresakiRegister.Name = "btnSiiresakiRegister";
            this.btnSiiresakiRegister.Size = new System.Drawing.Size(187, 23);
            this.btnSiiresakiRegister.TabIndex = 0;
            this.btnSiiresakiRegister.Text = "仕入先情報の登録";
            this.btnSiiresakiRegister.UseVisualStyleBackColor = true;
            this.btnSiiresakiRegister.Click += new System.EventHandler(this.btnSiiresakiRegister_Click);
            // 
            // SubMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 348);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.gpd1);
            this.Name = "SubMenuForm";
            this.Text = "サブメニュー";
            this.Controls.SetChildIndex(this.gpd1, 0);
            this.Controls.SetChildIndex(this.btnReturn, 0);
            this.Controls.SetChildIndex(this.groupBox3, 0);
            this.Controls.SetChildIndex(this.groupBox4, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.groupBox5, 0);
            this.gpd1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gpd1;
        private System.Windows.Forms.Button btnCompanyInfor;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnCustomerRegister;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnRegisterModify;
        private System.Windows.Forms.Button btnEstimationRegister;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnSiiresakiModify;
        private System.Windows.Forms.Button btnSiiresakiRegister;
        private System.Windows.Forms.Button btnEmployeeList;
    }
}