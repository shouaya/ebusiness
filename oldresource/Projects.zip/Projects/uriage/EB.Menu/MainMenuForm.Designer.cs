﻿namespace EB.Menu
{
    partial class MainMenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSalesRegister = new System.Windows.Forms.Button();
            this.btnContractRegister = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnFinanceList = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnContractList = new System.Windows.Forms.Button();
            this.btnSalesList = new System.Windows.Forms.Button();
            this.btnReceiveList = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnContractModify = new System.Windows.Forms.Button();
            this.gpd1 = new System.Windows.Forms.GroupBox();
            this.btnSalesModify = new System.Windows.Forms.Button();
            this.btnBillCreate = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnReceiveModify = new System.Windows.Forms.Button();
            this.btnReceiveRegister = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.btnSubMenu = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.c = new System.Windows.Forms.Button();
            this.btnContractLedger = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnCustomerTotal = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.gpd1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSalesRegister
            // 
            this.btnSalesRegister.Location = new System.Drawing.Point(49, 20);
            this.btnSalesRegister.Name = "btnSalesRegister";
            this.btnSalesRegister.Size = new System.Drawing.Size(187, 23);
            this.btnSalesRegister.TabIndex = 0;
            this.btnSalesRegister.Text = "売上情報の登録";
            this.btnSalesRegister.UseVisualStyleBackColor = true;
            this.btnSalesRegister.Click += new System.EventHandler(this.btnSalesRegister_Click);
            // 
            // btnContractRegister
            // 
            this.btnContractRegister.Location = new System.Drawing.Point(49, 32);
            this.btnContractRegister.Name = "btnContractRegister";
            this.btnContractRegister.Size = new System.Drawing.Size(187, 23);
            this.btnContractRegister.TabIndex = 0;
            this.btnContractRegister.Text = "契約情報の登録";
            this.btnContractRegister.UseVisualStyleBackColor = true;
            this.btnContractRegister.Click += new System.EventHandler(this.btnContractRegister_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnFinanceList);
            this.groupBox1.Location = new System.Drawing.Point(321, 162);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(268, 126);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "財務管理";
            // 
            // btnFinanceList
            // 
            this.btnFinanceList.Enabled = false;
            this.btnFinanceList.Location = new System.Drawing.Point(41, 48);
            this.btnFinanceList.Name = "btnFinanceList";
            this.btnFinanceList.Size = new System.Drawing.Size(187, 23);
            this.btnFinanceList.TabIndex = 0;
            this.btnFinanceList.Text = "売上債権一覧";
            this.btnFinanceList.UseVisualStyleBackColor = true;
            this.btnFinanceList.Click += new System.EventHandler(this.btnFinanceList_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnContractList);
            this.groupBox2.Controls.Add(this.btnSalesList);
            this.groupBox2.Controls.Add(this.btnReceiveList);
            this.groupBox2.Location = new System.Drawing.Point(321, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(268, 126);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "帳票";
            // 
            // btnContractList
            // 
            this.btnContractList.Enabled = false;
            this.btnContractList.Location = new System.Drawing.Point(41, 20);
            this.btnContractList.Name = "btnContractList";
            this.btnContractList.Size = new System.Drawing.Size(187, 23);
            this.btnContractList.TabIndex = 0;
            this.btnContractList.Text = "契約一覧";
            this.btnContractList.UseVisualStyleBackColor = true;
            this.btnContractList.Click += new System.EventHandler(this.btnContractList_Click);
            // 
            // btnSalesList
            // 
            this.btnSalesList.Location = new System.Drawing.Point(41, 53);
            this.btnSalesList.Name = "btnSalesList";
            this.btnSalesList.Size = new System.Drawing.Size(187, 23);
            this.btnSalesList.TabIndex = 0;
            this.btnSalesList.Text = "売上一覧";
            this.btnSalesList.UseVisualStyleBackColor = true;
            this.btnSalesList.Click += new System.EventHandler(this.btnSalesList_Click);
            // 
            // btnReceiveList
            // 
            this.btnReceiveList.Enabled = false;
            this.btnReceiveList.Location = new System.Drawing.Point(41, 86);
            this.btnReceiveList.Name = "btnReceiveList";
            this.btnReceiveList.Size = new System.Drawing.Size(187, 23);
            this.btnReceiveList.TabIndex = 0;
            this.btnReceiveList.Text = "入金一覧";
            this.btnReceiveList.UseVisualStyleBackColor = true;
            this.btnReceiveList.Click += new System.EventHandler(this.btnReceiveList_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnContractRegister);
            this.groupBox3.Controls.Add(this.btnContractModify);
            this.groupBox3.Location = new System.Drawing.Point(19, 162);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(268, 126);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "契約情報";
            // 
            // btnContractModify
            // 
            this.btnContractModify.Location = new System.Drawing.Point(49, 66);
            this.btnContractModify.Name = "btnContractModify";
            this.btnContractModify.Size = new System.Drawing.Size(187, 23);
            this.btnContractModify.TabIndex = 0;
            this.btnContractModify.Text = "契約修正／削除";
            this.btnContractModify.UseVisualStyleBackColor = true;
            this.btnContractModify.Click += new System.EventHandler(this.btnContractModify_Click);
            // 
            // gpd1
            // 
            this.gpd1.Controls.Add(this.btnSalesModify);
            this.gpd1.Controls.Add(this.btnBillCreate);
            this.gpd1.Controls.Add(this.btnSalesRegister);
            this.gpd1.Location = new System.Drawing.Point(19, 12);
            this.gpd1.Name = "gpd1";
            this.gpd1.Size = new System.Drawing.Size(268, 126);
            this.gpd1.TabIndex = 1;
            this.gpd1.TabStop = false;
            this.gpd1.Text = "売上情報";
            // 
            // btnSalesModify
            // 
            this.btnSalesModify.Location = new System.Drawing.Point(49, 53);
            this.btnSalesModify.Name = "btnSalesModify";
            this.btnSalesModify.Size = new System.Drawing.Size(187, 23);
            this.btnSalesModify.TabIndex = 0;
            this.btnSalesModify.Text = "売上情報の修正／削除";
            this.btnSalesModify.UseVisualStyleBackColor = true;
            this.btnSalesModify.Click += new System.EventHandler(this.btnSalesModify_Click);
            // 
            // btnBillCreate
            // 
            this.btnBillCreate.Location = new System.Drawing.Point(49, 86);
            this.btnBillCreate.Name = "btnBillCreate";
            this.btnBillCreate.Size = new System.Drawing.Size(187, 23);
            this.btnBillCreate.TabIndex = 0;
            this.btnBillCreate.Text = "請求書作成";
            this.btnBillCreate.UseVisualStyleBackColor = true;
            this.btnBillCreate.Click += new System.EventHandler(this.btnBillCreate_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnReceiveModify);
            this.groupBox5.Controls.Add(this.btnReceiveRegister);
            this.groupBox5.Controls.Add(this.button10);
            this.groupBox5.Location = new System.Drawing.Point(321, 315);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(268, 126);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "入金情報";
            // 
            // btnReceiveModify
            // 
            this.btnReceiveModify.Location = new System.Drawing.Point(41, 58);
            this.btnReceiveModify.Name = "btnReceiveModify";
            this.btnReceiveModify.Size = new System.Drawing.Size(187, 23);
            this.btnReceiveModify.TabIndex = 0;
            this.btnReceiveModify.Text = "入金修正";
            this.btnReceiveModify.UseVisualStyleBackColor = true;
            this.btnReceiveModify.Click += new System.EventHandler(this.btnReceiveModify_Click);
            // 
            // btnReceiveRegister
            // 
            this.btnReceiveRegister.Location = new System.Drawing.Point(41, 25);
            this.btnReceiveRegister.Name = "btnReceiveRegister";
            this.btnReceiveRegister.Size = new System.Drawing.Size(187, 23);
            this.btnReceiveRegister.TabIndex = 0;
            this.btnReceiveRegister.Text = "入金登録";
            this.btnReceiveRegister.UseVisualStyleBackColor = true;
            this.btnReceiveRegister.Click += new System.EventHandler(this.btnReceiveRegister_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(366, 50);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 0;
            this.button10.Text = "button1";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // btnSubMenu
            // 
            this.btnSubMenu.Location = new System.Drawing.Point(321, 456);
            this.btnSubMenu.Name = "btnSubMenu";
            this.btnSubMenu.Size = new System.Drawing.Size(126, 23);
            this.btnSubMenu.TabIndex = 0;
            this.btnSubMenu.Text = "サブメニュー表示";
            this.btnSubMenu.UseVisualStyleBackColor = true;
            this.btnSubMenu.Click += new System.EventHandler(this.btnSubMenu_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(470, 456);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(119, 23);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "終了";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // c
            // 
            this.c.Location = new System.Drawing.Point(49, 58);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(187, 23);
            this.c.TabIndex = 2;
            this.c.Text = "社員稼働履歴";
            this.c.UseVisualStyleBackColor = true;
            this.c.Click += new System.EventHandler(this.btnWorkCareer_Click);
            // 
            // btnContractLedger
            // 
            this.btnContractLedger.Location = new System.Drawing.Point(49, 25);
            this.btnContractLedger.Name = "btnContractLedger";
            this.btnContractLedger.Size = new System.Drawing.Size(187, 23);
            this.btnContractLedger.TabIndex = 1;
            this.btnContractLedger.Text = "社内管理台帳";
            this.btnContractLedger.UseVisualStyleBackColor = true;
            this.btnContractLedger.Click += new System.EventHandler(this.btnContractLedger_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnCustomerTotal);
            this.groupBox4.Controls.Add(this.c);
            this.groupBox4.Controls.Add(this.btnContractLedger);
            this.groupBox4.Location = new System.Drawing.Point(19, 315);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(268, 126);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "管理台帳";
            // 
            // btnCustomerTotal
            // 
            this.btnCustomerTotal.Location = new System.Drawing.Point(49, 90);
            this.btnCustomerTotal.Name = "btnCustomerTotal";
            this.btnCustomerTotal.Size = new System.Drawing.Size(187, 23);
            this.btnCustomerTotal.TabIndex = 2;
            this.btnCustomerTotal.Text = "顧客集計";
            this.btnCustomerTotal.UseVisualStyleBackColor = true;
            this.btnCustomerTotal.Click += new System.EventHandler(this.btnCustomerTotal_Click);
            // 
            // MainMenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 500);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.btnSubMenu);
            this.Controls.Add(this.gpd1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainMenuForm";
            this.Text = "売上管理システム";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.gpd1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSalesRegister;
        private System.Windows.Forms.Button btnContractRegister;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox gpd1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnFinanceList;
        private System.Windows.Forms.Button btnContractList;
        private System.Windows.Forms.Button btnSalesList;
        private System.Windows.Forms.Button btnReceiveList;
        private System.Windows.Forms.Button btnContractModify;
        private System.Windows.Forms.Button btnSalesModify;
        private System.Windows.Forms.Button btnBillCreate;
        private System.Windows.Forms.Button btnReceiveModify;
        private System.Windows.Forms.Button btnReceiveRegister;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button btnSubMenu;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button c;
        private System.Windows.Forms.Button btnContractLedger;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnCustomerTotal;
    }
}

