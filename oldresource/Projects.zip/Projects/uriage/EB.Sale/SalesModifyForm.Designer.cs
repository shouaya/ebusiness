﻿namespace EB.Sales
{
    partial class SalesModifyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtAmount = new EB.Common.NumericTextox();
            this.txtMinHour = new EB.Common.NumericTextox();
            this.txtDetailAmount = new EB.Common.NumericTextox();
            this.txtPlusUnitPrice = new EB.Common.NumericTextox();
            this.txtMinusUnitPrice = new EB.Common.NumericTextox();
            this.txtOtherAmount = new EB.Common.NumericTextox();
            this.txtMaxHour = new EB.Common.NumericTextox();
            this.txtRate = new EB.Common.NumericTextox();
            this.txtWorkTime = new EB.Common.NumericTextox();
            this.txtPrice = new EB.Common.NumericTextox();
            this.dgvContract = new System.Windows.Forms.DataGridView();
            this.EmployeeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployeeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WorkTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinHour = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxHour = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinusUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PlusUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cobUnit = new System.Windows.Forms.ComboBox();
            this.cobEmployeeID = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cobEmployType = new System.Windows.Forms.ComboBox();
            this.txtStartDate = new System.Windows.Forms.DateTimePicker();
            this.txtPaymentSite = new System.Windows.Forms.DateTimePicker();
            this.txtEndDate = new System.Windows.Forms.DateTimePicker();
            this.cobSalesman2 = new System.Windows.Forms.ComboBox();
            this.cobSalesman1 = new System.Windows.Forms.ComboBox();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.txtContent = new System.Windows.Forms.TextBox();
            this.txtContractID = new System.Windows.Forms.TextBox();
            this.txtContractName = new System.Windows.Forms.TextBox();
            this.txtOrderNo = new System.Windows.Forms.TextBox();
            this.txtContractNo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.cobCustomerID = new System.Windows.Forms.ComboBox();
            this.dgvContractByCustomer = new System.Windows.Forms.DataGridView();
            this.SaleNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaleID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentSite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmployType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Content = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Note = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Salesman1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Salesman2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentDay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinishFlag = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.DeleteFlg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaleDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtSaleNo = new System.Windows.Forms.TextBox();
            this.txtFinishFlag = new System.Windows.Forms.TextBox();
            this.txtContractDate = new System.Windows.Forms.TextBox();
            this.txtSaleDate = new System.Windows.Forms.TextBox();
            this.cobMonth = new System.Windows.Forms.ComboBox();
            this.cobYear = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btnDetailDelete = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.txtSaleID = new System.Windows.Forms.TextBox();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.Btn_Bill = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContract)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContractByCustomer)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(689, 651);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(237, 651);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(110, 23);
            this.btnUpdate.TabIndex = 331;
            this.btnUpdate.Text = "売上情報の更新";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(415, 651);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(110, 23);
            this.btnDelete.TabIndex = 331;
            this.btnDelete.Text = "売上情報削除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtAmount
            // 
            this.txtAmount.AcceptsTab = true;
            this.txtAmount.Location = new System.Drawing.Point(94, 330);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Precision = 0;
            this.txtAmount.SepratedChar = ',';
            this.txtAmount.Size = new System.Drawing.Size(169, 19);
            this.txtAmount.TabIndex = 471;
            this.txtAmount.Value = "";
            // 
            // txtMinHour
            // 
            this.txtMinHour.AcceptsTab = true;
            this.txtMinHour.Location = new System.Drawing.Point(427, 426);
            this.txtMinHour.Name = "txtMinHour";
            this.txtMinHour.Precision = 2;
            this.txtMinHour.ReadOnly = true;
            this.txtMinHour.SepratedChar = ',';
            this.txtMinHour.Size = new System.Drawing.Size(44, 19);
            this.txtMinHour.TabIndex = 464;
            this.txtMinHour.Value = "";
            // 
            // txtDetailAmount
            // 
            this.txtDetailAmount.AcceptsTab = true;
            this.txtDetailAmount.Location = new System.Drawing.Point(714, 426);
            this.txtDetailAmount.Name = "txtDetailAmount";
            this.txtDetailAmount.Precision = 0;
            this.txtDetailAmount.ReadOnly = true;
            this.txtDetailAmount.SepratedChar = ',';
            this.txtDetailAmount.Size = new System.Drawing.Size(79, 19);
            this.txtDetailAmount.TabIndex = 465;
            this.txtDetailAmount.Value = "";
            // 
            // txtPlusUnitPrice
            // 
            this.txtPlusUnitPrice.AcceptsTab = true;
            this.txtPlusUnitPrice.Location = new System.Drawing.Point(647, 426);
            this.txtPlusUnitPrice.Name = "txtPlusUnitPrice";
            this.txtPlusUnitPrice.Precision = 0;
            this.txtPlusUnitPrice.ReadOnly = true;
            this.txtPlusUnitPrice.SepratedChar = ',';
            this.txtPlusUnitPrice.Size = new System.Drawing.Size(61, 19);
            this.txtPlusUnitPrice.TabIndex = 462;
            this.txtPlusUnitPrice.Value = "";
            // 
            // txtMinusUnitPrice
            // 
            this.txtMinusUnitPrice.AcceptsTab = true;
            this.txtMinusUnitPrice.Location = new System.Drawing.Point(576, 426);
            this.txtMinusUnitPrice.Name = "txtMinusUnitPrice";
            this.txtMinusUnitPrice.Precision = 0;
            this.txtMinusUnitPrice.ReadOnly = true;
            this.txtMinusUnitPrice.SepratedChar = ',';
            this.txtMinusUnitPrice.Size = new System.Drawing.Size(65, 19);
            this.txtMinusUnitPrice.TabIndex = 463;
            this.txtMinusUnitPrice.Value = "";
            // 
            // txtOtherAmount
            // 
            this.txtOtherAmount.AcceptsTab = true;
            this.txtOtherAmount.Location = new System.Drawing.Point(525, 426);
            this.txtOtherAmount.MaxLength = 12;
            this.txtOtherAmount.Name = "txtOtherAmount";
            this.txtOtherAmount.Precision = 0;
            this.txtOtherAmount.SepratedChar = ',';
            this.txtOtherAmount.Size = new System.Drawing.Size(44, 19);
            this.txtOtherAmount.TabIndex = 468;
            this.txtOtherAmount.Value = "";
            // 
            // txtMaxHour
            // 
            this.txtMaxHour.AcceptsTab = true;
            this.txtMaxHour.Location = new System.Drawing.Point(477, 426);
            this.txtMaxHour.Name = "txtMaxHour";
            this.txtMaxHour.Precision = 2;
            this.txtMaxHour.ReadOnly = true;
            this.txtMaxHour.SepratedChar = ',';
            this.txtMaxHour.Size = new System.Drawing.Size(44, 19);
            this.txtMaxHour.TabIndex = 467;
            this.txtMaxHour.Value = "";
            // 
            // txtRate
            // 
            this.txtRate.AcceptsTab = true;
            this.txtRate.Location = new System.Drawing.Point(379, 426);
            this.txtRate.MaxLength = 7;
            this.txtRate.Name = "txtRate";
            this.txtRate.Precision = 3;
            this.txtRate.SepratedChar = ',';
            this.txtRate.Size = new System.Drawing.Size(42, 19);
            this.txtRate.TabIndex = 470;
            this.txtRate.Value = "";
            // 
            // txtWorkTime
            // 
            this.txtWorkTime.AcceptsTab = true;
            this.txtWorkTime.Location = new System.Drawing.Point(290, 426);
            this.txtWorkTime.Name = "txtWorkTime";
            this.txtWorkTime.Precision = 2;
            this.txtWorkTime.SepratedChar = ',';
            this.txtWorkTime.Size = new System.Drawing.Size(83, 19);
            this.txtWorkTime.TabIndex = 469;
            this.txtWorkTime.Value = "";
            this.txtWorkTime.TextChanged += new System.EventHandler(this.txtWorkTime_TextChanged);
            // 
            // txtPrice
            // 
            this.txtPrice.AcceptsTab = true;
            this.txtPrice.Location = new System.Drawing.Point(201, 426);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Precision = 0;
            this.txtPrice.SepratedChar = ',';
            this.txtPrice.Size = new System.Drawing.Size(83, 19);
            this.txtPrice.TabIndex = 466;
            this.txtPrice.Value = "";
            this.txtPrice.TextChanged += new System.EventHandler(this.txtPrice_TextChanged);
            // 
            // dgvContract
            // 
            this.dgvContract.AllowUserToAddRows = false;
            this.dgvContract.AllowUserToDeleteRows = false;
            this.dgvContract.AllowUserToOrderColumns = true;
            this.dgvContract.AllowUserToResizeRows = false;
            this.dgvContract.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContract.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EmployeeID,
            this.EmployeeName,
            this.UnitName,
            this.Unit,
            this.Price,
            this.WorkTime,
            this.Rate,
            this.Quantity,
            this.MinHour,
            this.MaxHour,
            this.OtherAmount,
            this.MinusUnitPrice,
            this.PlusUnitPrice,
            this.Amount});
            this.dgvContract.Location = new System.Drawing.Point(19, 453);
            this.dgvContract.MultiSelect = false;
            this.dgvContract.Name = "dgvContract";
            this.dgvContract.RowHeadersVisible = false;
            this.dgvContract.RowTemplate.Height = 23;
            this.dgvContract.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvContract.Size = new System.Drawing.Size(778, 192);
            this.dgvContract.TabIndex = 461;
            this.dgvContract.CellValidated += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContract_CellValidated);
            this.dgvContract.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContract_CellValueChanged);
            this.dgvContract.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvContract_EditingControlShowing);
            // 
            // EmployeeID
            // 
            this.EmployeeID.DataPropertyName = "EmployeeID";
            this.EmployeeID.HeaderText = "技術者ID";
            this.EmployeeID.Name = "EmployeeID";
            this.EmployeeID.Visible = false;
            // 
            // EmployeeName
            // 
            this.EmployeeName.DataPropertyName = "EmployeeName";
            this.EmployeeName.HeaderText = "技術者";
            this.EmployeeName.Name = "EmployeeName";
            this.EmployeeName.ReadOnly = true;
            this.EmployeeName.Width = 70;
            // 
            // UnitName
            // 
            this.UnitName.DataPropertyName = "UnitName";
            this.UnitName.HeaderText = "単位";
            this.UnitName.Name = "UnitName";
            this.UnitName.ReadOnly = true;
            this.UnitName.Width = 40;
            // 
            // Unit
            // 
            this.Unit.DataPropertyName = "Unit";
            this.Unit.HeaderText = "単位ID";
            this.Unit.Name = "Unit";
            this.Unit.ReadOnly = true;
            this.Unit.Visible = false;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = "0";
            this.Price.DefaultCellStyle = dataGridViewCellStyle4;
            this.Price.HeaderText = "単価";
            this.Price.Name = "Price";
            this.Price.Width = 80;
            // 
            // WorkTime
            // 
            this.WorkTime.HeaderText = "作業時間";
            this.WorkTime.Name = "WorkTime";
            this.WorkTime.Width = 60;
            // 
            // Rate
            // 
            dataGridViewCellStyle5.Format = "N3";
            dataGridViewCellStyle5.NullValue = "0";
            this.Rate.DefaultCellStyle = dataGridViewCellStyle5;
            this.Rate.HeaderText = "数量";
            this.Rate.Name = "Rate";
            this.Rate.Width = 80;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "数量";
            this.Quantity.Name = "Quantity";
            this.Quantity.ReadOnly = true;
            this.Quantity.Visible = false;
            this.Quantity.Width = 80;
            // 
            // MinHour
            // 
            this.MinHour.DataPropertyName = "MinHour";
            this.MinHour.HeaderText = "MinH";
            this.MinHour.Name = "MinHour";
            this.MinHour.ReadOnly = true;
            this.MinHour.Width = 80;
            // 
            // MaxHour
            // 
            this.MaxHour.DataPropertyName = "MaxHour";
            this.MaxHour.HeaderText = "MaxH";
            this.MaxHour.Name = "MaxHour";
            this.MaxHour.ReadOnly = true;
            this.MaxHour.Width = 80;
            // 
            // OtherAmount
            // 
            this.OtherAmount.HeaderText = "その他";
            this.OtherAmount.Name = "OtherAmount";
            this.OtherAmount.Width = 70;
            // 
            // MinusUnitPrice
            // 
            this.MinusUnitPrice.DataPropertyName = "MinusUnitPrice";
            this.MinusUnitPrice.HeaderText = "減賃金";
            this.MinusUnitPrice.Name = "MinusUnitPrice";
            this.MinusUnitPrice.ReadOnly = true;
            this.MinusUnitPrice.Width = 80;
            // 
            // PlusUnitPrice
            // 
            this.PlusUnitPrice.DataPropertyName = "PlusUnitPrice";
            this.PlusUnitPrice.HeaderText = "増賃金";
            this.PlusUnitPrice.Name = "PlusUnitPrice";
            this.PlusUnitPrice.ReadOnly = true;
            this.PlusUnitPrice.Width = 80;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = "0";
            this.Amount.DefaultCellStyle = dataGridViewCellStyle6;
            this.Amount.HeaderText = "金額";
            this.Amount.Name = "Amount";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(735, 410);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 458;
            this.label14.Text = "金額";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(659, 410);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 457;
            this.label12.Text = "増賃金";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(591, 410);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 460;
            this.label11.Text = "減賃金";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(484, 410);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(34, 12);
            this.label21.TabIndex = 459;
            this.label21.Text = "MaxH";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(435, 410);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 12);
            this.label20.TabIndex = 456;
            this.label20.Text = "MinH";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(228, 410);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 453;
            this.label18.Text = "単価";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(147, 410);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 454;
            this.label17.Text = "単位";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(18, 410);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 12);
            this.label26.TabIndex = 455;
            this.label26.Text = "技術者";
            // 
            // cobUnit
            // 
            this.cobUnit.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cobUnit.DisplayMember = "CodeName";
            this.cobUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobUnit.Enabled = false;
            this.cobUnit.FormattingEnabled = true;
            this.cobUnit.Location = new System.Drawing.Point(141, 427);
            this.cobUnit.Name = "cobUnit";
            this.cobUnit.Size = new System.Drawing.Size(54, 20);
            this.cobUnit.TabIndex = 452;
            this.cobUnit.ValueMember = "CodeID";
            // 
            // cobEmployeeID
            // 
            this.cobEmployeeID.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cobEmployeeID.DisplayMember = "EmployeeName";
            this.cobEmployeeID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobEmployeeID.Enabled = false;
            this.cobEmployeeID.FormattingEnabled = true;
            this.cobEmployeeID.Location = new System.Drawing.Point(19, 427);
            this.cobEmployeeID.Name = "cobEmployeeID";
            this.cobEmployeeID.Size = new System.Drawing.Size(116, 20);
            this.cobEmployeeID.TabIndex = 451;
            this.cobEmployeeID.ValueMember = "EmployeeID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(348, 388);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 450;
            this.label1.Text = "（末締）";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(348, 377);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 12);
            this.label2.TabIndex = 449;
            this.label2.Text = "支払サイト";
            // 
            // cobEmployType
            // 
            this.cobEmployType.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cobEmployType.DisplayMember = "CodeName";
            this.cobEmployType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobEmployType.Enabled = false;
            this.cobEmployType.FormattingEnabled = true;
            this.cobEmployType.Location = new System.Drawing.Point(93, 284);
            this.cobEmployType.Name = "cobEmployType";
            this.cobEmployType.Size = new System.Drawing.Size(247, 20);
            this.cobEmployType.TabIndex = 448;
            this.cobEmployType.ValueMember = "CodeID";
            // 
            // txtStartDate
            // 
            this.txtStartDate.CustomFormat = "yyyy/MM/dd";
            this.txtStartDate.Enabled = false;
            this.txtStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtStartDate.Location = new System.Drawing.Point(93, 261);
            this.txtStartDate.Name = "txtStartDate";
            this.txtStartDate.Size = new System.Drawing.Size(116, 19);
            this.txtStartDate.TabIndex = 445;
            // 
            // txtPaymentSite
            // 
            this.txtPaymentSite.CustomFormat = "yyyy/MM/dd";
            this.txtPaymentSite.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtPaymentSite.Location = new System.Drawing.Point(413, 380);
            this.txtPaymentSite.Name = "txtPaymentSite";
            this.txtPaymentSite.Size = new System.Drawing.Size(112, 19);
            this.txtPaymentSite.TabIndex = 446;
            // 
            // txtEndDate
            // 
            this.txtEndDate.CustomFormat = "yyyy/MM/dd";
            this.txtEndDate.Enabled = false;
            this.txtEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtEndDate.Location = new System.Drawing.Point(319, 261);
            this.txtEndDate.Name = "txtEndDate";
            this.txtEndDate.Size = new System.Drawing.Size(112, 19);
            this.txtEndDate.TabIndex = 447;
            // 
            // cobSalesman2
            // 
            this.cobSalesman2.DisplayMember = "EmployeeName";
            this.cobSalesman2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobSalesman2.Enabled = false;
            this.cobSalesman2.FormattingEnabled = true;
            this.cobSalesman2.Location = new System.Drawing.Point(187, 377);
            this.cobSalesman2.Name = "cobSalesman2";
            this.cobSalesman2.Size = new System.Drawing.Size(93, 20);
            this.cobSalesman2.TabIndex = 444;
            this.cobSalesman2.ValueMember = "EmployeeID";
            // 
            // cobSalesman1
            // 
            this.cobSalesman1.DisplayMember = "EmployeeName";
            this.cobSalesman1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobSalesman1.Enabled = false;
            this.cobSalesman1.FormattingEnabled = true;
            this.cobSalesman1.Location = new System.Drawing.Point(93, 377);
            this.cobSalesman1.Name = "cobSalesman1";
            this.cobSalesman1.Size = new System.Drawing.Size(93, 20);
            this.cobSalesman1.TabIndex = 443;
            this.cobSalesman1.ValueMember = "EmployeeID";
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(93, 353);
            this.txtNote.Name = "txtNote";
            this.txtNote.ReadOnly = true;
            this.txtNote.Size = new System.Drawing.Size(413, 19);
            this.txtNote.TabIndex = 437;
            // 
            // txtContent
            // 
            this.txtContent.Location = new System.Drawing.Point(93, 307);
            this.txtContent.Name = "txtContent";
            this.txtContent.ReadOnly = true;
            this.txtContent.Size = new System.Drawing.Size(415, 19);
            this.txtContent.TabIndex = 441;
            // 
            // txtContractID
            // 
            this.txtContractID.Location = new System.Drawing.Point(408, 190);
            this.txtContractID.Name = "txtContractID";
            this.txtContractID.ReadOnly = true;
            this.txtContractID.Size = new System.Drawing.Size(100, 19);
            this.txtContractID.TabIndex = 442;
            // 
            // txtContractName
            // 
            this.txtContractName.Location = new System.Drawing.Point(93, 238);
            this.txtContractName.Name = "txtContractName";
            this.txtContractName.ReadOnly = true;
            this.txtContractName.Size = new System.Drawing.Size(415, 19);
            this.txtContractName.TabIndex = 438;
            // 
            // txtOrderNo
            // 
            this.txtOrderNo.Location = new System.Drawing.Point(93, 215);
            this.txtOrderNo.Name = "txtOrderNo";
            this.txtOrderNo.ReadOnly = true;
            this.txtOrderNo.Size = new System.Drawing.Size(247, 19);
            this.txtOrderNo.TabIndex = 440;
            // 
            // txtContractNo
            // 
            this.txtContractNo.Location = new System.Drawing.Point(93, 190);
            this.txtContractNo.Name = "txtContractNo";
            this.txtContractNo.ReadOnly = true;
            this.txtContractNo.Size = new System.Drawing.Size(247, 19);
            this.txtContractNo.TabIndex = 439;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 436;
            this.label5.Text = "注文番号";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(29, 336);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 426;
            this.label10.Text = "契約金額";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(29, 381);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 423;
            this.label13.Text = "営業担当";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(53, 289);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 421;
            this.label8.Text = "方式";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(275, 336);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 12);
            this.label24.TabIndex = 435;
            this.label24.Text = "円（税抜）";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(53, 358);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 422;
            this.label9.Text = "備考";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(53, 313);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 434;
            this.label7.Text = "内容";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(513, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 432;
            this.label3.Text = "（請負日）";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(525, 189);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 431;
            this.label15.Text = "契約日";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 264);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 430;
            this.label4.Text = "開始日";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(235, 265);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(17, 12);
            this.label22.TabIndex = 433;
            this.label22.Text = "～";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(274, 266);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(41, 12);
            this.label30.TabIndex = 429;
            this.label30.Text = "終了日";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(351, 195);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(40, 12);
            this.label25.TabIndex = 428;
            this.label25.Text = "契約ID";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(29, 244);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(53, 12);
            this.label27.TabIndex = 427;
            this.label27.Text = "契約件名";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(17, 202);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(65, 12);
            this.label28.TabIndex = 425;
            this.label28.Text = "（請負番号）";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(30, 190);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(53, 12);
            this.label31.TabIndex = 424;
            this.label31.Text = "契約番号";
            // 
            // cobCustomerID
            // 
            this.cobCustomerID.DisplayMember = "CustomerName";
            this.cobCustomerID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobCustomerID.Location = new System.Drawing.Point(65, 33);
            this.cobCustomerID.Name = "cobCustomerID";
            this.cobCustomerID.Size = new System.Drawing.Size(247, 20);
            this.cobCustomerID.TabIndex = 420;
            this.cobCustomerID.ValueMember = "CustomerID";
            this.cobCustomerID.SelectionChangeCommitted += new System.EventHandler(this.cobCustomerID_SelectionChangeCommitted);
            // 
            // dgvContractByCustomer
            // 
            this.dgvContractByCustomer.AllowUserToAddRows = false;
            this.dgvContractByCustomer.AllowUserToDeleteRows = false;
            this.dgvContractByCustomer.AllowUserToOrderColumns = true;
            this.dgvContractByCustomer.AllowUserToResizeRows = false;
            this.dgvContractByCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContractByCustomer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SaleNo,
            this.SaleID,
            this.ContractID,
            this.PaymentSite,
            this.ContractNo,
            this.ContractDate,
            this.CustomerID,
            this.OrderNo,
            this.EmployType,
            this.OrderDate,
            this.ContractName,
            this.Content,
            this.Note,
            this.StartDate,
            this.EndDate,
            this.Salesman1,
            this.Salesman2,
            this.PaymentType,
            this.PaymentDay,
            this.FinishFlag,
            this.DeleteFlg,
            this.TotalAmount,
            this.SaleDate});
            this.dgvContractByCustomer.Location = new System.Drawing.Point(19, 62);
            this.dgvContractByCustomer.MultiSelect = false;
            this.dgvContractByCustomer.Name = "dgvContractByCustomer";
            this.dgvContractByCustomer.ReadOnly = true;
            this.dgvContractByCustomer.RowHeadersVisible = false;
            this.dgvContractByCustomer.RowTemplate.Height = 23;
            this.dgvContractByCustomer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvContractByCustomer.Size = new System.Drawing.Size(761, 118);
            this.dgvContractByCustomer.TabIndex = 419;
            this.dgvContractByCustomer.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContractByCustomer_RowEnter);
            // 
            // SaleNo
            // 
            this.SaleNo.DataPropertyName = "SaleNo";
            this.SaleNo.HeaderText = "売上番号";
            this.SaleNo.Name = "SaleNo";
            this.SaleNo.ReadOnly = true;
            // 
            // SaleID
            // 
            this.SaleID.DataPropertyName = "SaleID";
            this.SaleID.HeaderText = "売上ID";
            this.SaleID.Name = "SaleID";
            this.SaleID.ReadOnly = true;
            this.SaleID.Visible = false;
            // 
            // ContractID
            // 
            this.ContractID.DataPropertyName = "ContractID";
            this.ContractID.HeaderText = "契約ID";
            this.ContractID.Name = "ContractID";
            this.ContractID.ReadOnly = true;
            this.ContractID.Visible = false;
            // 
            // PaymentSite
            // 
            this.PaymentSite.DataPropertyName = "PaymentSite";
            this.PaymentSite.HeaderText = "支払サイト";
            this.PaymentSite.Name = "PaymentSite";
            this.PaymentSite.ReadOnly = true;
            this.PaymentSite.Visible = false;
            // 
            // ContractNo
            // 
            this.ContractNo.DataPropertyName = "ContractNo";
            this.ContractNo.HeaderText = "契約番号";
            this.ContractNo.Name = "ContractNo";
            this.ContractNo.ReadOnly = true;
            // 
            // ContractDate
            // 
            this.ContractDate.DataPropertyName = "ContractDate";
            this.ContractDate.HeaderText = "契約日";
            this.ContractDate.Name = "ContractDate";
            this.ContractDate.ReadOnly = true;
            this.ContractDate.Visible = false;
            // 
            // CustomerID
            // 
            this.CustomerID.DataPropertyName = "CustomerID";
            this.CustomerID.HeaderText = "顧客ID";
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.ReadOnly = true;
            this.CustomerID.Visible = false;
            // 
            // OrderNo
            // 
            this.OrderNo.DataPropertyName = "OrderNo";
            this.OrderNo.HeaderText = "注文書番号";
            this.OrderNo.Name = "OrderNo";
            this.OrderNo.ReadOnly = true;
            this.OrderNo.Visible = false;
            // 
            // EmployType
            // 
            this.EmployType.DataPropertyName = "EmployType";
            this.EmployType.HeaderText = "方式";
            this.EmployType.Name = "EmployType";
            this.EmployType.ReadOnly = true;
            this.EmployType.Visible = false;
            // 
            // OrderDate
            // 
            this.OrderDate.DataPropertyName = "OrderDate";
            this.OrderDate.HeaderText = "注文日";
            this.OrderDate.Name = "OrderDate";
            this.OrderDate.ReadOnly = true;
            this.OrderDate.Visible = false;
            // 
            // ContractName
            // 
            this.ContractName.DataPropertyName = "ContractName";
            this.ContractName.HeaderText = "件名";
            this.ContractName.Name = "ContractName";
            this.ContractName.ReadOnly = true;
            // 
            // Content
            // 
            this.Content.DataPropertyName = "Content";
            this.Content.HeaderText = "内容";
            this.Content.Name = "Content";
            this.Content.ReadOnly = true;
            this.Content.Visible = false;
            // 
            // Note
            // 
            this.Note.DataPropertyName = "Note";
            this.Note.HeaderText = "備考";
            this.Note.Name = "Note";
            this.Note.ReadOnly = true;
            this.Note.Visible = false;
            // 
            // StartDate
            // 
            this.StartDate.DataPropertyName = "StartDate";
            this.StartDate.HeaderText = "開始日";
            this.StartDate.Name = "StartDate";
            this.StartDate.ReadOnly = true;
            // 
            // EndDate
            // 
            this.EndDate.DataPropertyName = "EndDate";
            this.EndDate.HeaderText = "終了日";
            this.EndDate.Name = "EndDate";
            this.EndDate.ReadOnly = true;
            // 
            // Salesman1
            // 
            this.Salesman1.DataPropertyName = "Salesman1";
            this.Salesman1.HeaderText = "営業担当１";
            this.Salesman1.Name = "Salesman1";
            this.Salesman1.ReadOnly = true;
            this.Salesman1.Visible = false;
            // 
            // Salesman2
            // 
            this.Salesman2.DataPropertyName = "Salesman2";
            this.Salesman2.HeaderText = "営業担当２";
            this.Salesman2.Name = "Salesman2";
            this.Salesman2.ReadOnly = true;
            this.Salesman2.Visible = false;
            // 
            // PaymentType
            // 
            this.PaymentType.DataPropertyName = "PaymentType";
            this.PaymentType.HeaderText = "支払方法";
            this.PaymentType.Name = "PaymentType";
            this.PaymentType.ReadOnly = true;
            this.PaymentType.Visible = false;
            // 
            // PaymentDay
            // 
            this.PaymentDay.DataPropertyName = "PaymentDay";
            this.PaymentDay.HeaderText = "支払日";
            this.PaymentDay.Name = "PaymentDay";
            this.PaymentDay.ReadOnly = true;
            this.PaymentDay.Visible = false;
            // 
            // FinishFlag
            // 
            this.FinishFlag.DataPropertyName = "FinishFlag";
            this.FinishFlag.FalseValue = "0";
            this.FinishFlag.HeaderText = "処理済";
            this.FinishFlag.Name = "FinishFlag";
            this.FinishFlag.ReadOnly = true;
            this.FinishFlag.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.FinishFlag.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.FinishFlag.TrueValue = "1";
            // 
            // DeleteFlg
            // 
            this.DeleteFlg.DataPropertyName = "DeleteFlg";
            this.DeleteFlg.HeaderText = "削除フラグ";
            this.DeleteFlg.Name = "DeleteFlg";
            this.DeleteFlg.ReadOnly = true;
            this.DeleteFlg.Visible = false;
            // 
            // TotalAmount
            // 
            this.TotalAmount.DataPropertyName = "TotalAmount";
            this.TotalAmount.HeaderText = "契約金額";
            this.TotalAmount.Name = "TotalAmount";
            this.TotalAmount.ReadOnly = true;
            this.TotalAmount.Visible = false;
            // 
            // SaleDate
            // 
            this.SaleDate.DataPropertyName = "SaleDate";
            this.SaleDate.HeaderText = "売上日";
            this.SaleDate.Name = "SaleDate";
            this.SaleDate.ReadOnly = true;
            this.SaleDate.Visible = false;
            // 
            // txtSaleNo
            // 
            this.txtSaleNo.Location = new System.Drawing.Point(566, 6);
            this.txtSaleNo.Name = "txtSaleNo";
            this.txtSaleNo.ReadOnly = true;
            this.txtSaleNo.Size = new System.Drawing.Size(211, 19);
            this.txtSaleNo.TabIndex = 413;
            // 
            // txtFinishFlag
            // 
            this.txtFinishFlag.Location = new System.Drawing.Point(579, 235);
            this.txtFinishFlag.Name = "txtFinishFlag";
            this.txtFinishFlag.ReadOnly = true;
            this.txtFinishFlag.Size = new System.Drawing.Size(100, 19);
            this.txtFinishFlag.TabIndex = 415;
            // 
            // txtContractDate
            // 
            this.txtContractDate.Location = new System.Drawing.Point(579, 190);
            this.txtContractDate.Name = "txtContractDate";
            this.txtContractDate.ReadOnly = true;
            this.txtContractDate.Size = new System.Drawing.Size(100, 19);
            this.txtContractDate.TabIndex = 417;
            // 
            // txtSaleDate
            // 
            this.txtSaleDate.Location = new System.Drawing.Point(391, 6);
            this.txtSaleDate.Name = "txtSaleDate";
            this.txtSaleDate.ReadOnly = true;
            this.txtSaleDate.Size = new System.Drawing.Size(100, 19);
            this.txtSaleDate.TabIndex = 416;
            // 
            // cobMonth
            // 
            this.cobMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobMonth.FormattingEnabled = true;
            this.cobMonth.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.cobMonth.Location = new System.Drawing.Point(176, 7);
            this.cobMonth.Name = "cobMonth";
            this.cobMonth.Size = new System.Drawing.Size(57, 20);
            this.cobMonth.TabIndex = 411;
            this.cobMonth.SelectionChangeCommitted += new System.EventHandler(this.cobMonth_SelectionChangeCommitted);
            // 
            // cobYear
            // 
            this.cobYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobYear.FormattingEnabled = true;
            this.cobYear.Items.AddRange(new object[] {
            "2020",
            "2019",
            "2018",
            "2017",
            "2016",
            "2015",
            "2014",
            "2013",
            "2012",
            "2011",
            "2010",
            "2009",
            "2008"});
            this.cobYear.Location = new System.Drawing.Point(65, 8);
            this.cobYear.Name = "cobYear";
            this.cobYear.Size = new System.Drawing.Size(84, 20);
            this.cobYear.TabIndex = 412;
            this.cobYear.SelectionChangeCommitted += new System.EventHandler(this.cobMonth_SelectionChangeCommitted);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(507, 11);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(53, 12);
            this.label41.TabIndex = 405;
            this.label41.Text = "売上番号";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(240, 11);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(29, 12);
            this.label38.TabIndex = 404;
            this.label38.Text = "月分";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(344, 11);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(41, 12);
            this.label40.TabIndex = 407;
            this.label40.Text = "売上日";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(21, 11);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 12);
            this.label39.TabIndex = 410;
            this.label39.Text = "売上月";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(155, 11);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(17, 12);
            this.label37.TabIndex = 409;
            this.label37.Text = "年";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(30, 36);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 12);
            this.label36.TabIndex = 408;
            this.label36.Text = "顧客";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(528, 410);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(36, 12);
            this.label23.TabIndex = 403;
            this.label23.Text = "その他";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(386, 410);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 12);
            this.label29.TabIndex = 401;
            this.label29.Text = "数量";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(308, 410);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 402;
            this.label19.Text = "作業時間";
            // 
            // btnDetailDelete
            // 
            this.btnDetailDelete.Location = new System.Drawing.Point(42, 651);
            this.btnDetailDelete.Name = "btnDetailDelete";
            this.btnDetailDelete.Size = new System.Drawing.Size(144, 23);
            this.btnDetailDelete.TabIndex = 473;
            this.btnDetailDelete.Text = "明細行の削除";
            this.btnDetailDelete.UseVisualStyleBackColor = true;
            this.btnDetailDelete.Click += new System.EventHandler(this.btnDetailDelete_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(513, 39);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(40, 12);
            this.label42.TabIndex = 406;
            this.label42.Text = "売上ID";
            // 
            // txtSaleID
            // 
            this.txtSaleID.Location = new System.Drawing.Point(566, 36);
            this.txtSaleID.Name = "txtSaleID";
            this.txtSaleID.ReadOnly = true;
            this.txtSaleID.Size = new System.Drawing.Size(100, 19);
            this.txtSaleID.TabIndex = 414;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(346, 34);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(145, 19);
            this.txtCustomerName.TabIndex = 475;
            this.txtCustomerName.TextChanged += new System.EventHandler(this.txtCustomerName_TextChanged);
            // 
            // Btn_Bill
            // 
            this.Btn_Bill.Location = new System.Drawing.Point(531, 651);
            this.Btn_Bill.Name = "Btn_Bill";
            this.Btn_Bill.Size = new System.Drawing.Size(110, 23);
            this.Btn_Bill.TabIndex = 476;
            this.Btn_Bill.Text = "請求書作成";
            this.Btn_Bill.UseVisualStyleBackColor = true;
            this.Btn_Bill.Click += new System.EventHandler(this.Btn_Bill_Click);
            // 
            // SalesModifyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(818, 705);
            this.Controls.Add(this.Btn_Bill);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.btnDetailDelete);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.txtMinHour);
            this.Controls.Add(this.txtDetailAmount);
            this.Controls.Add(this.txtPlusUnitPrice);
            this.Controls.Add(this.txtMinusUnitPrice);
            this.Controls.Add(this.txtOtherAmount);
            this.Controls.Add(this.txtMaxHour);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.txtWorkTime);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dgvContract);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.cobUnit);
            this.Controls.Add(this.cobEmployeeID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cobEmployType);
            this.Controls.Add(this.txtStartDate);
            this.Controls.Add(this.txtPaymentSite);
            this.Controls.Add(this.txtEndDate);
            this.Controls.Add(this.cobSalesman2);
            this.Controls.Add(this.cobSalesman1);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.txtContent);
            this.Controls.Add(this.txtContractID);
            this.Controls.Add(this.txtContractName);
            this.Controls.Add(this.txtOrderNo);
            this.Controls.Add(this.txtContractNo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.cobCustomerID);
            this.Controls.Add(this.dgvContractByCustomer);
            this.Controls.Add(this.txtSaleID);
            this.Controls.Add(this.txtSaleNo);
            this.Controls.Add(this.txtFinishFlag);
            this.Controls.Add(this.txtContractDate);
            this.Controls.Add(this.txtSaleDate);
            this.Controls.Add(this.cobMonth);
            this.Controls.Add(this.cobYear);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Name = "SalesModifyForm";
            this.Text = "売上修正／削除";
            this.Load += new System.EventHandler(this.SalesModifyForm_Load);
            this.Controls.SetChildIndex(this.btnUpdate, 0);
            this.Controls.SetChildIndex(this.btnDelete, 0);
            this.Controls.SetChildIndex(this.label19, 0);
            this.Controls.SetChildIndex(this.label29, 0);
            this.Controls.SetChildIndex(this.label23, 0);
            this.Controls.SetChildIndex(this.label36, 0);
            this.Controls.SetChildIndex(this.label37, 0);
            this.Controls.SetChildIndex(this.label39, 0);
            this.Controls.SetChildIndex(this.label40, 0);
            this.Controls.SetChildIndex(this.label38, 0);
            this.Controls.SetChildIndex(this.label41, 0);
            this.Controls.SetChildIndex(this.label42, 0);
            this.Controls.SetChildIndex(this.cobYear, 0);
            this.Controls.SetChildIndex(this.cobMonth, 0);
            this.Controls.SetChildIndex(this.txtSaleDate, 0);
            this.Controls.SetChildIndex(this.txtContractDate, 0);
            this.Controls.SetChildIndex(this.txtFinishFlag, 0);
            this.Controls.SetChildIndex(this.txtSaleNo, 0);
            this.Controls.SetChildIndex(this.txtSaleID, 0);
            this.Controls.SetChildIndex(this.dgvContractByCustomer, 0);
            this.Controls.SetChildIndex(this.cobCustomerID, 0);
            this.Controls.SetChildIndex(this.label31, 0);
            this.Controls.SetChildIndex(this.label28, 0);
            this.Controls.SetChildIndex(this.label27, 0);
            this.Controls.SetChildIndex(this.label25, 0);
            this.Controls.SetChildIndex(this.label30, 0);
            this.Controls.SetChildIndex(this.label22, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.label15, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label7, 0);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label24, 0);
            this.Controls.SetChildIndex(this.label8, 0);
            this.Controls.SetChildIndex(this.label13, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.label5, 0);
            this.Controls.SetChildIndex(this.txtContractNo, 0);
            this.Controls.SetChildIndex(this.txtOrderNo, 0);
            this.Controls.SetChildIndex(this.txtContractName, 0);
            this.Controls.SetChildIndex(this.txtContractID, 0);
            this.Controls.SetChildIndex(this.txtContent, 0);
            this.Controls.SetChildIndex(this.txtNote, 0);
            this.Controls.SetChildIndex(this.cobSalesman1, 0);
            this.Controls.SetChildIndex(this.cobSalesman2, 0);
            this.Controls.SetChildIndex(this.txtEndDate, 0);
            this.Controls.SetChildIndex(this.txtPaymentSite, 0);
            this.Controls.SetChildIndex(this.txtStartDate, 0);
            this.Controls.SetChildIndex(this.cobEmployType, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.cobEmployeeID, 0);
            this.Controls.SetChildIndex(this.cobUnit, 0);
            this.Controls.SetChildIndex(this.label26, 0);
            this.Controls.SetChildIndex(this.label17, 0);
            this.Controls.SetChildIndex(this.label18, 0);
            this.Controls.SetChildIndex(this.label20, 0);
            this.Controls.SetChildIndex(this.label21, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.dgvContract, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.txtPrice, 0);
            this.Controls.SetChildIndex(this.txtWorkTime, 0);
            this.Controls.SetChildIndex(this.txtRate, 0);
            this.Controls.SetChildIndex(this.txtMaxHour, 0);
            this.Controls.SetChildIndex(this.txtOtherAmount, 0);
            this.Controls.SetChildIndex(this.txtMinusUnitPrice, 0);
            this.Controls.SetChildIndex(this.txtPlusUnitPrice, 0);
            this.Controls.SetChildIndex(this.txtDetailAmount, 0);
            this.Controls.SetChildIndex(this.txtMinHour, 0);
            this.Controls.SetChildIndex(this.txtAmount, 0);
            this.Controls.SetChildIndex(this.btnDetailDelete, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.txtCustomerName, 0);
            this.Controls.SetChildIndex(this.Btn_Bill, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dgvContract)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContractByCustomer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private Common.NumericTextox txtAmount;
        private Common.NumericTextox txtMinHour;
        private Common.NumericTextox txtDetailAmount;
        private Common.NumericTextox txtPlusUnitPrice;
        private Common.NumericTextox txtMinusUnitPrice;
        private Common.NumericTextox txtOtherAmount;
        private Common.NumericTextox txtMaxHour;
        private Common.NumericTextox txtRate;
        private Common.NumericTextox txtWorkTime;
        private Common.NumericTextox txtPrice;
        private System.Windows.Forms.DataGridView dgvContract;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cobUnit;
        private System.Windows.Forms.ComboBox cobEmployeeID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cobEmployType;
        private System.Windows.Forms.DateTimePicker txtStartDate;
        private System.Windows.Forms.DateTimePicker txtPaymentSite;
        private System.Windows.Forms.DateTimePicker txtEndDate;
        private System.Windows.Forms.ComboBox cobSalesman2;
        private System.Windows.Forms.ComboBox cobSalesman1;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.TextBox txtContent;
        private System.Windows.Forms.TextBox txtContractID;
        private System.Windows.Forms.TextBox txtContractName;
        private System.Windows.Forms.TextBox txtOrderNo;
        private System.Windows.Forms.TextBox txtContractNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox cobCustomerID;
        private System.Windows.Forms.DataGridView dgvContractByCustomer;
        private System.Windows.Forms.TextBox txtSaleNo;
        private System.Windows.Forms.TextBox txtFinishFlag;
        private System.Windows.Forms.TextBox txtContractDate;
        private System.Windows.Forms.TextBox txtSaleDate;
        private System.Windows.Forms.ComboBox cobMonth;
        private System.Windows.Forms.ComboBox cobYear;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnDetailDelete;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtSaleID;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaleNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaleID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentSite;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployType;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Content;
        private System.Windows.Forms.DataGridViewTextBoxColumn Note;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Salesman1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Salesman2;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentType;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentDay;
        private System.Windows.Forms.DataGridViewCheckBoxColumn FinishFlag;
        private System.Windows.Forms.DataGridViewTextBoxColumn DeleteFlg;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaleDate;
        private System.Windows.Forms.Button Btn_Bill;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmployeeName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn WorkTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinHour;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaxHour;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinusUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn PlusUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
    }
}