﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using EB.DBAcess;
using EB.Common;
using System.Collections;
using System.Threading;

namespace EB.Sales
{
    public partial class BillSpecifyForm : DialogForm
    {
        #region 初期化
        private IF_Company entity_Company = new IF_Company();

        private string _txtSaleDate = null;
        private string _customerID = null;

        public BillSpecifyForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 
        /// </summary>
        public void setDateAndCustomer(string txtSaleDate, string customerID)
        {
            if (!string.IsNullOrEmpty(txtSaleDate) && !string.IsNullOrEmpty(customerID))
            {
                this._txtSaleDate = txtSaleDate;
                this._customerID = customerID;
                this.cobMonth.Enabled = false;
                this.cobYear.Enabled = false;
            }
        }

        /// <summary>
        /// 初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BillSpecifyForm_Load(object sender, EventArgs e)
        {
            try
            {
                cobYear.SelectedItem = System.DateTime.Now.ToString("yyyy");
                this.cobMonth.Text = System.DateTime.Now.AddMonths(-1).Month.ToString();

                //Commbox DataSourceを指定
                bindCommbox();

                //Reset画面項目
                resetAll();

                //データ取得
                loadData();

                if (!string.IsNullOrEmpty(this._txtSaleDate))
                {
                    //MessageBox.Show(this._txtSaleDate + "==" + this._customerID);
                    this.cobYear.Text = CommonHandler._GetString(this._txtSaleDate ,"(\\d{4})",1);
                    this.cobMonth.Text = CommonHandler._GetString(this._txtSaleDate, "\\d{4}\\W(\\d+)", 1);
                    this.cobMonth_SelectionChangeCommitted(null,null);

                }
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// Reset画面項目
        /// </summary>
        private void resetAll()
        {
            //cobRoundMothod.SelectedIndex = -1;
            cobRoundMothod.SelectedValue = "2";
            this.cobTaxRate.SelectedIndex = 1;
        }

        /// <summary>
        /// Commbox DataSourceを指定
        /// </summary>
        private void bindCommbox()
        {
            BL_CodeMaster bl = BL_CodeMaster.GetInstance();

            cobRoundMothod.DataSource = bl.SelectCodeMaster("CD009");//方式
            cobTaxRate.DataSource = bl.SelectCodeMaster("CD011");//税率
            //顧客
            if (string.IsNullOrEmpty(this._customerID))
            {
                this._KeyDown(this.txtCustomerName, new KeyEventArgs(Keys.Enter));
            }
            else
            {
                this.label4.Visible = false;
                this.cobCustomerID.Visible = false;
                this.txtCustomerName.Visible = false;
            }
        }
        /// <summary>
        /// データ取得
        /// </summary>
        private void loadData()
        {
            if (null == entity_Company)
            {

                ThreadPoolHelper.StartThread(this, () => {
                    return BL_Company.GetInstance().SelectCompany("1");
                },
                    (obj) =>
                    {
                        entity_Company = new IF_Company();

                        entity_Company.InitializeWithDatatable((DataTable)obj);

                        if (entity_Company.CompanyID > 0)
                        {
                            txtCompanyName.Text = entity_Company.CompanyName;
                            txtPostCode.Text = entity_Company.PostCode;
                            txtAddress.Text = entity_Company.Address;
                            txtTel.Text = entity_Company.Tel;
                        }
                    });
            }
        }
        int dgvCustomer_selectRow = 0, dgvSale_selectRow = 0;
        public void reload()
        {
            DataGridViewCellEventArgs e = new DataGridViewCellEventArgs(0, dgvCustomer_selectRow);

            this.dgvCustomer_RowEnter(null,e);

            dgvCustomer_selectRow = 0;
        }
        #endregion

        #region 画面動作
        /// <summary>
        /// 月選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobMonth_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                if (sender!=null&&(sender as ComboBox).Name == "cobCustomerID")
                {
                    this._customerID = (sender as ComboBox).SelectedValue.ToString();
                }

                if (string.IsNullOrEmpty(cobMonth.Text.Trim()))
                {
                    return;
                }
                string yy_mm = cobYear.Text + "/" + cobMonth.Text;

                ThreadPoolHelper.StartThread(this, () => { return BL_Sale.GetInstance().SelectCustomerHasSale(yy_mm, this._customerID); },
                    (obj) => {
                        dgvCustomer.DataSource = (DataTable)obj; 
                        if (((DataTable)obj).Rows.Count == 0)
                        {
                            dgvSale.DataSource = null;
                        }
                    });
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 行選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvCustomer_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int row = e.RowIndex;

                string customerID = CommonHandler.ToString(dgvCustomer.Rows[row].Cells["CustomerID"].Value);//顧客ID

                string yy_mm = cobYear.Text + "/" + cobMonth.Text;


                ThreadPoolHelper.StartThread(this, () => { return BL_Sale.GetInstance().SelectSaleForBill(customerID, yy_mm); },
                    (obj) =>
                    {
                        DataTable dt = (DataTable)obj;
                        dgvSale.DataSource = dt;
                        if (dt.Rows.Count > dgvSale_selectRow)
                        {
                            dgvSale.Rows[this.dgvSale_selectRow].Selected = true;
                            dgvSale_selectRow = 0;
                        }
                    });

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 請求書の作成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCreateBill_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (!isValidCheck()) return;
                

                BillCreateForm form = new BillCreateForm();
                dgvCustomer_selectRow = dgvCustomer.CurrentRow.Index;
                dgvSale_selectRow = dgvSale.CurrentRow.Index;

                form._para._Customer.Address1 = CommonHandler.ToString(dgvCustomer.Rows[dgvCustomer_selectRow].Cells["Address1"].Value);//住所1
                form._para._Customer.Address2 = CommonHandler.ToString(dgvCustomer.Rows[dgvCustomer_selectRow].Cells["Address2"].Value);//住所2
                form._para._Customer.CustomerID = CommonHandler.ToInt(dgvCustomer.Rows[dgvCustomer_selectRow].Cells["CustomerID"].Value);//顧客ID
                form._para._Customer.CustomerName = CommonHandler.ToString(dgvCustomer.Rows[dgvCustomer_selectRow].Cells["CustomerName"].Value);//顧客名
                form._para._Customer.PostCode = CommonHandler.ToString(dgvCustomer.Rows[dgvCustomer_selectRow].Cells["PostCode"].Value);//郵便番号
                form._para._Customer.Tel = CommonHandler.ToString(dgvCustomer.Rows[dgvCustomer_selectRow].Cells["Tel"].Value);//Tel
                /*
                 //整理中
                form._para._dgvSale = (DataTable)dgvSale.DataSource;

                if (rdoPrintAll.Checked)
                {
                    form._para._selectRow = -1;
                }
                else
                {
                    form._para._selectRow = dgvSale.CurrentRow.Index;
                }
                */

                form._para._Company = entity_Company;
                form.PARA_Method = CommonHandler.ToString(cobRoundMothod.SelectedValue);//消費税計算方法
                form.PARA_TaxRate = CommonHandler.ToDecimal(this.cobTaxRate.SelectedValue) / 100;
                //this.cobTaxRate.SelectedIndex == 1 ? 0.08m : 0.05m;//税率

                string billFlag = CommonHandler.ToString(dgvCustomer.Rows[dgvCustomer_selectRow].Cells["BillFlag"].Value);//発行状態
                string yy_mm = cobYear.Text + "/" + cobMonth.Text;//年月

                //請求書区別を一括請求と指定して、請求書の作成ボタンを押下する。
                if (rdoPrintAll.Checked)
                {
                    string saleID = string.Empty;
                    string previourBillNo = string.Empty;
                    string billNo = string.Empty;
                    string paymentSite = string.Empty;//支払日
                    for (int rowIndex = 0; rowIndex < dgvSale.Rows.Count; rowIndex++)
                    {
                        saleID = saleID + "," + CommonHandler.ToString(dgvSale.Rows[rowIndex].Cells["SaleID"].Value);//売上ID
                        billNo = CommonHandler.ToString(dgvSale.Rows[rowIndex].Cells["BillNo"].Value);//請求書番号
                        paymentSite = CommonHandler.ToString(dgvSale.Rows[rowIndex].Cells["PaymentSite"].Value);//支払日

                        //異なる請求番号が一括請求できません！
                        if (billNo != previourBillNo && rowIndex != 0)
                        {
                            MessageHelper.ShowErrorMessageByID("EB0004");
                            return;
                        }

                        previourBillNo = billNo;
                    }
                    saleID = saleID.Substring(1);//先頭,を切る

                    //指定した顧客の請求書発行状態＝発行済の場合
                    if (billFlag == "1")
                    {
                        if (MessageHelper.ShowConfirmMessage("EB2004") != DialogResult.Yes)
                        {
                            return;
                        }
                    }

                    form.PARA_BillType = "1";//請求書区分
                    form.PARA_SaleDate = yy_mm;//売上年月
                    form.PARA_BillNo = billNo;//請求書番号
                    form.PARA_SaleID = saleID;//売上ID

                    form.PARA_StartDate = yy_mm + "/01";//開始日
                    form.PARA_EndDate = CommonHandler.GetCurrentMonthLastDay(yy_mm + "/01");//終了日
                    form.PARA_OrderNo = string.Empty;//注文番号
                    form.PARA_OrderDate = string.Empty;//注文日
                    form.PARA_ContractName = string.Empty;//契約名
                    form.PARA_PaymentSite = string.Empty;//支払日
                    
                  
                    form.ShowDialog();
                }

                
                //請求書区別を注文書別と指定して、請求書の作成ボタンを押下する。
                if (rdoPrintOne.Checked)
                {
                    string saleID = CommonHandler.ToString(dgvSale.Rows[dgvSale_selectRow].Cells["SaleID"].Value);//売上ID
                    string billFinishFlag = CommonHandler.ToString(dgvSale.Rows[dgvSale_selectRow].Cells["FinishBillFlag"].Value);//売上ID
                    string billNo = CommonHandler.ToString(dgvSale.Rows[dgvSale_selectRow].Cells["BillNo"].Value);//請求書番号

                    string startDate = CommonHandler.ToString(dgvSale.Rows[dgvSale_selectRow].Cells["StartDate"].Value);//開始日
                    string endDate = CommonHandler.ToString(dgvSale.Rows[dgvSale_selectRow].Cells["EndDate"].Value);//終了日
                    string orderNo = CommonHandler.ToString(dgvSale.Rows[dgvSale_selectRow].Cells["OrderNo"].Value);//注文番号
                    string orderDate = CommonHandler.ToString(dgvSale.Rows[dgvSale_selectRow].Cells["OrderDate"].Value);//注文日
                    string contractName = CommonHandler.ToString(dgvSale.Rows[dgvSale_selectRow].Cells["ContractName"].Value);//契約名
                    string paymentSite = CommonHandler.ToString(dgvSale.Rows[dgvSale_selectRow].Cells["PaymentSite"].Value);//支払日

                    if (getBillNoCountFromList(billNo) >= 2)
                    {
                        MessageHelper.ShowErrorMessageByID("EB0008");
                        return;
                    }

                    //指定した売上の請求書発行状態＝発行済の場合
                    if (billFinishFlag == "1")
                    {
                        if (MessageHelper.ShowConfirmMessage("EB2004") != DialogResult.Yes)
                        {
                            return;
                        }
                    }
                    form.PARA_BillType = "2";//請求書区分
                    form.PARA_SaleID = saleID;//売上ID
                    form.PARA_SaleDate = yy_mm;//売上年月
                    form.PARA_BillNo = billNo;//請求書番号

                    form.PARA_StartDate = startDate;//開始日
                    form.PARA_EndDate = endDate;//終了日
                    form.PARA_OrderNo = orderNo;//注文番号
                    form.PARA_OrderDate = orderDate;//注文日
                    form.PARA_ContractName = contractName;//契約名
                    form.PARA_PaymentSite = paymentSite;//支払日
                    
                    form.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
            this.reload();
        }
        private int getBillNoCountFromList(string value)
        {
            int count = 0;

            if (string.IsNullOrEmpty(value)) return 0;

            for (int i = 0; i < dgvSale.Rows.Count; i++)
            {
                string billNo = CommonHandler.ToString(dgvSale.Rows[i].Cells["BillNo"].Value);//請求書番号
                if (billNo == value)
                {
                    count++;
                }
            }
            return count;

        }

        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheck()
        {
            if (cobRoundMothod.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "消費税の計算方法");
                return false;
            }
            //データがありません
            if (dgvSale.RowCount==0)
            {
                MessageHelper.ShowinforMessageByID("EB0007");
                return false;
            }
            return true;
        }
        /// <summary>
        /// Enter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void _KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ThreadPoolHelper.StartThread(this
                    , () =>
                    {
                        return BL_Customer.GetInstance().SelectAllCustomer(txtCustomerName.Text.Trim());//顧客ID
                    },
                    (obj) =>
                    {
                        DataTable dt = obj as DataTable;
                        DataRow dr = dt.NewRow();
                        dr[cobCustomerID.DisplayMember] = "";

                        dt.Rows.InsertAt(dr,0);

                        cobCustomerID.DataSource = dt;
                        cobCustomerID.SelectedIndex = -1;
                    });
            }

        }
        #endregion
    }
}
