﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using EB.DBAcess;
using EB.Common;
namespace EB.Sales
{
    public partial class SalesModifyForm : DialogForm
    {
        #region 初期化
        public SalesModifyForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 初期化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SalesModifyForm_Load(object sender, EventArgs e)
        {
            try
            {
                cobYear.SelectedItem = System.DateTime.Now.ToString("yyyy");

                //Commbox DataSourceを指定
                bindCommbox();

                //Reset画面項目
                resetAll();

                //Reset明細画面項目
                resetAllDetail();

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// Reset画面項目
        /// </summary>
        private void resetAll()
        {
            txtContractID.Text = string.Empty;//契約ID
            txtContractNo.Text = string.Empty;//契約番号
            txtContractDate.Text = string.Empty;//契約日

            txtOrderNo.Text = string.Empty;//注文書番号
            cobEmployType.SelectedIndex = -1;//方式

            txtContractName.Text = string.Empty;//契約件名
            txtAmount.Text = string.Empty;//契約金額
            txtContent.Text = string.Empty;//内容
            txtNote.Text = string.Empty;//備考
            txtStartDate.Text = string.Empty;//開始日
            txtEndDate.Text = string.Empty;//終了日
            cobSalesman1.SelectedIndex = -1;//営業担当１
            cobSalesman2.SelectedIndex = -1;//営業担当２
            txtFinishFlag.Text = string.Empty;
            txtPaymentSite.Text = string.Empty;//支払Site

        }

        /// <summary>
        /// Reset明細画面項目
        /// </summary>
        private void resetAllDetail()
        {
            cobEmployeeID.SelectedIndex = -1;//技術者ID
            cobUnit.SelectedIndex = -1;//単位
            txtPrice.Text = string.Empty;//単価
            txtWorkTime.Text = string.Empty;//数量
            txtRate.Text = string.Empty;
            txtOtherAmount.Text = string.Empty;
            txtMinHour.Text = string.Empty;//Min勤務
            txtMaxHour.Text = string.Empty;//Max勤務
            txtMinusUnitPrice.Text = string.Empty;//減賃金
            txtPlusUnitPrice.Text = string.Empty;//増賃金
            txtDetailAmount.Text = string.Empty;//金額

        }

        /// <summary>
        /// Commbox DataSourceを指定
        /// </summary>
        private void bindCommbox()
        {
            BL_CodeMaster bl = BL_CodeMaster.GetInstance();

            cobEmployType.DataSource = bl.SelectCodeMaster("CD007");//方式
            cobUnit.DataSource = bl.SelectCodeMaster("CD008");//単位
            cobSalesman1.DataSource = BL_Employee.GetInstance().SelectSalesEmployee();//営業担当１
            cobSalesman2.DataSource = BL_Employee.GetInstance().SelectSalesEmployee();//営業担当２
            cobEmployeeID.DataSource = BL_Employee.GetInstance().SelectTechEmployee();//技術者

        }
        #endregion

        #region 画面動作
        /// <summary>
        /// 月選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobMonth_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if ((cobMonth.SelectedIndex == -1) && (cobCustomerID.SelectedIndex == -1))
            {
                return;
            }
            //Reset明細画面項目
            resetAllDetail();

            //loadDataGridViewData();

            //Reset画面項目
            resetAll();

            if (dgvContractByCustomer.Rows.Count > 0)
            {
                DataTable dt_temp = ((DataTable)dgvContractByCustomer.DataSource).Clone();
                dgvContractByCustomer.DataSource = dt_temp;
            }
            if (dgvContract.Rows.Count > 0)
            {
                dgvContract.Rows.Clear();
            }
            

            string mm = cobMonth.Text;
            string yy_mm = cobYear.Text + "/" + cobMonth.Text;
            ThreadPoolHelper.StartThread(this, () =>
                {
                    BL_Customer bl = BL_Customer.GetInstance();
                    if (String.IsNullOrEmpty(txtCustomerName.Text.Trim()))
                        return bl.SelectCustomerByMonth(yy_mm);
                    else
                        return bl.SelectCustomerByMonth(yy_mm, txtCustomerName.Text.Trim());
                },
                (obj) =>
                {
                    cobCustomerID.DataSource = obj as DataTable;
                    cobCustomerID.SelectedIndex = -1;
                });

        }
        /// <summary>
        /// 顧客選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cobCustomerID_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                //Reset画面項目
                resetAll();

                //Reset明細画面項目
                resetAllDetail();

                dgvContract.Rows.Clear();

                ////面データを初期化
                loadDataGridViewData();

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }

        }
        /// <summary>
        /// 画面データを初期化
        /// </summary>
        private void loadDataGridViewData()
        {
            string yy_mm = cobYear.Text + "/" + cobMonth.Text;

            string customerID = CommonHandler.ToString(cobCustomerID.SelectedValue);

            int displayrowindex = dgvContractByCustomer.FirstDisplayedScrollingRowIndex;
            string saleID = txtSaleID.Text;

            ThreadPoolHelper.StartThread(this,
                    () =>
                    {
                        BL_Contract bl = BL_Contract.GetInstance();
                        return bl.SelectContractByCustomerOnSaleM(customerID, yy_mm);
                    },
                    (obj) => {
                        DataTable dt = obj as DataTable;
                        if (dt.Rows.Count > 0)
                        {
                            dgvContractByCustomer.DataSource = dt;
                            dgvContractByCustomer.Rows[0].Selected = false;
                            if (displayrowindex >= 0)
                            {
                                dgvContractByCustomer.FirstDisplayedScrollingRowIndex = displayrowindex;
                            }

                            for (int i = 0; i < dgvContractByCustomer.Rows.Count; i++)
                            {
                                if (dgvContractByCustomer.Rows[i].Cells["SaleID"].Value.ToString() == saleID)
                                {
                                    dgvContractByCustomer.Rows[i].Selected = true;
                                    this.dgvContractByCustomer_RowEnter(this.dgvContractByCustomer, new DataGridViewCellEventArgs(1, i));
                                }
                            }
                        }

                    }
                );

        }
        /// <summary>
        /// 入力予定一覧
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnInputList_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 契約一覧を選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgvContractByCustomer_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //Reset明細画面項目
                resetAllDetail();

                int row = e.RowIndex;


                txtContractID.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["ContractID"].Value);//契約ID
                txtContractNo.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["ContractNo"].Value);//契約番号
                txtContractDate.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["ContractDate"].Value);//契約日
                txtOrderNo.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["OrderNo"].Value);//注文書番号
                cobEmployType.SelectedValue = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["EmployType"].Value);//方式
                txtContractName.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["ContractName"].Value);//契約件名
                txtAmount.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["TotalAmount"].Value);//契約金額
                txtContent.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["Content"].Value);//内容
                txtNote.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["Note"].Value);//備考
                txtStartDate.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["StartDate"].Value);//開始日
                txtEndDate.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["EndDate"].Value);//終了日
                cobSalesman1.SelectedValue = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["Salesman1"].Value);//営業担当１
                cobSalesman2.SelectedValue = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["Salesman2"].Value);//営業担当２
                txtFinishFlag.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["FinishFlag"].Value);//処理済フラグ

                txtSaleID.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["SaleID"].Value);//売上ID
                txtSaleNo.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["SaleNo"].Value);//売上No
                txtSaleDate.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["SaleDate"].Value);//売上日
                txtPaymentSite.Text = CommonHandler.ToString(dgvContractByCustomer.Rows[row].Cells["PaymentSite"].Value);//支払日サイト

                string saleID = this.txtSaleID.Text;//売上ID
                BL_SaleDetail bl = BL_SaleDetail.GetInstance();
                DataTable dt = bl.SelectSaleDetail(saleID);


                dgvContract.Rows.Clear();
                foreach (DataRow dr in dt.Rows)
                {
                    row = dgvContract.Rows.Add();
                    dgvContract.Rows[row].Cells["EmployeeID"].Value = dr["EmployeeID"];//技術者ID
                    dgvContract.Rows[row].Cells["Unit"].Value = dr["Unit"];//単位ID
                    dgvContract.Rows[row].Cells["EmployeeName"].Value = dr["EmployeeName"];//技術者
                    dgvContract.Rows[row].Cells["UnitName"].Value = dr["UnitName"];//単位
                    dgvContract.Rows[row].Cells["Price"].Value = dr["Price"];//単価
                    dgvContract.Rows[row].Cells["WorkTime"].Value = dr["WorkTime"];//作業時間
                    dgvContract.Rows[row].Cells["Rate"].Value = dr["Rate"];//率
                    //dgvContract.Rows[row].Cells["Quantity"].Value = dr["Quantity"];//数量
                    dgvContract.Rows[row].Cells["MinHour"].Value = dr["MinHour"];//Min勤務
                    dgvContract.Rows[row].Cells["MaxHour"].Value = dr["MaxHour"];//Max勤務
                    dgvContract.Rows[row].Cells["OtherAmount"].Value = dr["OtherAmount"];//その他
                    dgvContract.Rows[row].Cells["MinusUnitPrice"].Value = dr["MinusUnitPrice"];//減賃金
                    dgvContract.Rows[row].Cells["PlusUnitPrice"].Value = dr["PlusUnitPrice"];//増賃金
                    dgvContract.Rows[row].Cells["Amount"].Value = dr["Amount"];//金額

                }

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 明細の更新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDetailUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvContract.SelectedRows.Count == 0) return;

                int row = dgvContract.SelectedRows[0].Index;

                cobEmployeeID.SelectedValue = CommonHandler.ToString(dgvContract.Rows[row].Cells["EmployeeID"].Value);//技術者ID
                cobUnit.SelectedValue = CommonHandler.ToString(dgvContract.Rows[row].Cells["Unit"].Value);//単位
                txtPrice.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["Price"].Value);//単価
                txtWorkTime.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["WorkTime"].Value);//数量
                txtRate.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["Rate"].Value);//率
                txtMinHour.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["MinHour"].Value);//Min勤務
                txtMaxHour.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["MaxHour"].Value);//Max勤務
                txtOtherAmount.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["OtherAmount"].Value);//その他
                txtMinusUnitPrice.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["MinusUnitPrice"].Value);//減賃金
                txtPlusUnitPrice.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["PlusUnitPrice"].Value);//増賃金
                txtDetailAmount.Text = CommonHandler.ToString(dgvContract.Rows[row].Cells["Amount"].Value);//金額

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 明細の削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDetailDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvContract.SelectedRows.Count == 0) return;

                if (MessageHelper.ShowConfirmMessage("EB2001") == DialogResult.Yes)
                {
                    int row = dgvContract.SelectedRows[0].Index;

                    dgvContract.Rows.RemoveAt(row);

                    //金額自動計算
                    caculateAmount();
                }

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 明細の修正登録
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDetailRegister_Click(object sender, EventArgs e)
        {
            try
            {
                //入力チェック
                if (!isValidCheckDetail()) return;

                //登録処理
                processDetailUpdate();

                //Reset画面項目
                resetAllDetail();

                //金額自動計算
                caculateAmount();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        private void processDetailUpdate()
        {
            if (dgvContract.SelectedRows.Count == 0) return;

            int row = dgvContract.SelectedRows[0].Index;
            if (cobEmployeeID.SelectedValue != null)
            {
                dgvContract.Rows[row].Cells["EmployeeID"].Value = cobEmployeeID.SelectedValue;//技術者ID
            }
            dgvContract.Rows[row].Cells["Unit"].Value = cobUnit.SelectedValue;//単位ID
            dgvContract.Rows[row].Cells["EmployeeName"].Value = cobEmployeeID.Text;//技術者
            dgvContract.Rows[row].Cells["UnitName"].Value = cobUnit.Text;//単位
            dgvContract.Rows[row].Cells["Price"].Value = txtPrice.Text;//単価
            dgvContract.Rows[row].Cells["WorkTime"].Value = txtWorkTime.Value;//作業時間
            dgvContract.Rows[row].Cells["Rate"].Value = txtRate.Value;//率
            dgvContract.Rows[row].Cells["MinHour"].Value = txtMinHour.Text;//Min勤務
            dgvContract.Rows[row].Cells["MaxHour"].Value = txtMaxHour.Text;//Max勤務
            dgvContract.Rows[row].Cells["OtherAmount"].Value = txtOtherAmount.Value;//その他
            dgvContract.Rows[row].Cells["MinusUnitPrice"].Value = txtMinusUnitPrice.Text;//減賃金
            dgvContract.Rows[row].Cells["PlusUnitPrice"].Value = txtPlusUnitPrice.Text;//増賃金
            dgvContract.Rows[row].Cells["Amount"].Value = txtDetailAmount.Text;//金額

        }
        private void caculateAmount()
        {
            decimal totalAmout = 0;

            for (int row = 0; row < dgvContract.Rows.Count; row++)
            {
                totalAmout = totalAmout + CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["Amount"].Value);//金額
            }

            txtAmount.Text = totalAmout.ToString();
        }
        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheckDetail()
        {

            if (string.IsNullOrEmpty(txtWorkTime.Value))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "作業時間");
                return false;
            }

            // 作業時間の入力値は一ヶ月の最大作業時間より大きい場合のエラー
            if (CommonHandler.ToDecimal(txtWorkTime.Value) > 360 )
            {
                MessageHelper.ShowConfirmMessage("EB0002", "作業時間");
                return false;
            }

            if (string.IsNullOrEmpty(txtRate.Value))
            {
                MessageHelper.ShowinforMessageByID("EB0001", "率");
                return false;
            }

            return true;
        }
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                if (string.IsNullOrEmpty(txtContractID.Text)) return;

                //入力チェック
                if (!isValidCheck()) return;

                //登録処理
                proceessUpdate();

                ////面データを初期化
                dgvContract.Rows.Clear();
                loadDataGridViewData();

                MessageHelper.ShowinforMessageByID("EB1003");

            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        /// <summary>
        /// 入力チェック
        /// </summary>
        /// <returns></returns>
        private bool isValidCheck()
        {
            //if (txtFinishFlag.Text == "1")
            //{
            //    MessageHelper.ShowinforMessageByID("EB0003");
            //    return false;
            //}

            if (cobCustomerID.SelectedIndex == -1)
            {
                MessageHelper.ShowinforMessageByID("EB0001", "顧客");
                return false;
            }
            //if (string.IsNullOrEmpty(txtOrderNo.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "注文番号");
            //    return false;
            //}
            //if (string.IsNullOrEmpty(txtContractName.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "注文日");
            //    return false;
            //}
            //if (string.IsNullOrEmpty(txtContractName.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "契約件名");
            //    return false;
            //}
            //if (string.IsNullOrEmpty(txtStartDate.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "開始日");
            //    return false;
            //}
            //if (string.IsNullOrEmpty(txtEndDate.Text))
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "終了日");
            //    return false;
            //}
            //if (cobSalesman1.SelectedIndex == -1)
            //{
            //    MessageHelper.ShowinforMessageByID("EB0001", "営業担当１");
            //    return false;
            //}
            //明細行必須
            if (dgvContract.RowCount == 0)
            {
                MessageHelper.ShowinforMessageByID("EB0006");
                return false;
            }
            return true;
        }

        /// <summary>
        /// 更新処理
        /// </summary>
        private void proceessUpdate()
        {
            IF_Sale entity = new IF_Sale();

            entity.SaleID = CommonHandler.ToInt(txtSaleID.Text);//売上ID
            entity.SaleNo = txtSaleNo.Text;//売上番号
            entity.SaleDate = txtSaleDate.Text;//売上日
            entity.CustomerID = CommonHandler.ToInt(cobCustomerID.SelectedValue);//顧客ID
            entity.ContractID = CommonHandler.ToInt(txtContractID.Text); //契約ID
            entity.StartDate = txtStartDate.Text;//開始日
            entity.EndDate = txtEndDate.Text;//終了日
            entity.SaleAmount = CommonHandler.ToDecimal(txtAmount.Text);//売上金額
            entity.Content = txtContent.Text;//内容
            entity.Note = txtNote.Text;//備考
            entity.Salesman1 = CommonHandler.ToInt(cobSalesman1.SelectedValue);//営業担当１
            entity.Salesman2 = CommonHandler.ToInt(cobSalesman2.SelectedValue);//営業担当２
            entity.PaymentSite = txtPaymentSite.Text;//支払サイト
            entity.BillFlag = "0";//請求書発行済フラグ
            entity.DeleteFlg = "0";//削除フラグ

            List<IF_SaleDetail> list = new List<IF_SaleDetail>();

            for (int row = 0; row < dgvContract.Rows.Count; row++)
            {
                IF_SaleDetail entityDetail = new IF_SaleDetail();

                entityDetail.SaleDetailID = (row + 1).ToString();
                entityDetail.EmployeeID = CommonHandler.ToInt(dgvContract.Rows[row].Cells["EmployeeID"].Value);//社員
                entityDetail.Unit = CommonHandler.ToString(dgvContract.Rows[row].Cells["Unit"].Value);//単位
                entityDetail.Price = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["Price"].Value);//単価
                entityDetail.WorkTime = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["WorkTime"].Value);//時間
                entityDetail.Rate = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["Rate"].Value);//率
                entityDetail.MinHour = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["MinHour"].Value);//Min勤務
                entityDetail.MaxHour = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["MaxHour"].Value);//Max勤務
                entityDetail.OtherAmount = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["OtherAmount"].Value);//その他
                entityDetail.MinusUnitPrice = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["MinusUnitPrice"].Value);//減賃金
                entityDetail.PlusUnitPrice = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["PlusUnitPrice"].Value);//増賃金
                entityDetail.Amount = CommonHandler.ToDecimal(dgvContract.Rows[row].Cells["Amount"].Value);//金額
                entityDetail.DeleteFlg = "0";//削除フラグ

                list.Add(entityDetail);
            }

            BL_Sale bl = BL_Sale.GetInstance();
            bl.UpdateAll(entity, list);

        }
        /// <summary>
        /// 作業時間
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtWorkTime_Leave(object sender, EventArgs e)
        {
            try
            {
                caculateDetailAmount();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 率
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtRate_Leave(object sender, EventArgs e)
        {
            try
            {
                caculateDetailAmount();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// その他
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtOtherAmount_Leave(object sender, EventArgs e)
        {
            try
            {
                caculateDetailAmount();
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        private void caculateDetailAmount()
        {

            string unit = CommonHandler.ToString(cobUnit.SelectedValue);//単位
            decimal price = CommonHandler.ToDecimal(txtPrice.Text);//単価
            decimal workTime = CommonHandler.ToDecimal(txtWorkTime.Text);//時間
            decimal rate = CommonHandler.ToDecimal(txtRate.Text);//時間
            decimal otherAmount = CommonHandler.ToDecimal(txtOtherAmount.Text);//その他
            decimal minH = CommonHandler.ToDecimal(txtMinHour.Text);//Min勤務
            decimal maxH = CommonHandler.ToDecimal(txtMaxHour.Text);//Max勤務

            decimal minusUnitPrice = CommonHandler.ToDecimal(txtMinusUnitPrice.Text);//減賃金
            decimal plusUnitPrice = CommonHandler.ToDecimal(txtPlusUnitPrice.Text);//増賃金

            decimal detailAmount = 0;

            //月
            if (unit == "1")
            {
                detailAmount = rate * price;//単価＊率
                detailAmount = detailAmount + otherAmount;//Plusその他

                if (workTime > maxH)
                {
                    detailAmount = detailAmount + (workTime - maxH) * plusUnitPrice;
                }

                if (workTime < minH)
                {
                    detailAmount = detailAmount - (minH - workTime) * minusUnitPrice;
                }
            }
            //時間
            if (unit == "2")
            {
                detailAmount = rate * price * workTime;//単価＊率＊作業時間
                detailAmount = detailAmount + otherAmount;//Plusその他

            }
            //一式
            if (unit == "3")
            {
                detailAmount = rate * price;//単価＊率
                detailAmount = detailAmount + otherAmount;//Plusその他
            }

            txtDetailAmount.Text = CommonHandler.ToInt(detailAmount).ToString();
        }
        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtContractID.Text)) return;

                if (MessageHelper.ShowDeleteConfirmMessage() != DialogResult.Yes)
                {
                    return;
                }

                proceessDelete();

                //Reset画面項目
                resetAll();

                //Reset明細画面項目
                resetAllDetail();

                ////面データを初期化
                loadDataGridViewData();

                MessageHelper.ShowinforMessageByID("EB1005");
            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }
        /// <summary>
        /// 削除処理
        /// </summary>
        private void proceessDelete()
        {
            IF_Sale entity = new IF_Sale();

            entity.SaleID = CommonHandler.ToInt(txtSaleID.Text);//契約番号

            BL_Sale bl = BL_Sale.GetInstance();
            bl.DeleteAll(entity);

        }
        #endregion

        /// <summary>
        /// 顧客検索
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCustomerName_TextChanged(object sender, EventArgs e)
        {
            if ((cobMonth.SelectedIndex == -1) && (cobCustomerID.SelectedIndex == -1))
            {
                return;
            }

            //Reset明細画面項目
            resetAllDetail();

            //Reset画面項目
            resetAll();

            string yy_mm = cobYear.Text + "/" + cobMonth.Text;

            ThreadPoolHelper.StartThread(this
                , () =>
                {
                    return BL_Customer.GetInstance().SelectCustomerByMonth(yy_mm, txtCustomerName.Text.Trim());//顧客ID
                },
                (obj) =>
                {
                    cobCustomerID.DataSource = obj as DataTable;
                    cobCustomerID.SelectedIndex = -1;
                    if (dgvContractByCustomer.Rows.Count > 0)
                    {
                        DataTable dt_temp = ((DataTable)dgvContractByCustomer.DataSource).Clone();
                        dgvContractByCustomer.DataSource = dt_temp;
                    }
                    if (dgvContract.Rows.Count > 0)
                    {
                        dgvContract.Rows.Clear();
                    }
                });
        }

        private void txtWorkTime_TextChanged(object sender, EventArgs e)
        {
            try
            {
                decimal price = CommonHandler.ToDecimal(txtPrice.Value);
                decimal quantity = CommonHandler.ToDecimal(txtWorkTime.Value);
                decimal minH = CommonHandler.ToDecimal(txtMinHour.Value);
                decimal maxH = CommonHandler.ToDecimal(txtMaxHour.Value);
                decimal plusPrice = CommonHandler.ToDecimal(txtPlusUnitPrice.Value);
                decimal minusPrice = CommonHandler.ToDecimal(txtMinusUnitPrice.Value);
                if (quantity < minH)
                {
                    if (quantity == 0)
                    {
                        txtDetailAmount.Value = CommonHandler.ToString(0);
                    }
                    else
                    {
                        txtDetailAmount.Value = CommonHandler.ToString(price - (minH - quantity) * minusPrice);
                    }
                }
                else if (quantity > maxH)
                {
                    txtDetailAmount.Value = CommonHandler.ToString(price + (quantity - maxH) * plusPrice);
                }
                else
                {
                    txtDetailAmount.Value = CommonHandler.ToString(txtPrice.Value);
                }



            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {
            try
            {
                decimal price = CommonHandler.ToDecimal(txtPrice.Value);
                decimal quantity = CommonHandler.ToDecimal(txtWorkTime.Value);
                decimal minH = CommonHandler.ToDecimal(txtMinHour.Value);
                decimal maxH = CommonHandler.ToDecimal(txtMaxHour.Value);
                decimal plusPrice = CommonHandler.ToDecimal(txtPlusUnitPrice.Value);
                decimal minusPrice = CommonHandler.ToDecimal(txtMinusUnitPrice.Value);
                if (quantity < minH)
                {
                    if (quantity == 0)
                    {
                        txtDetailAmount.Value = CommonHandler.ToString(0);
                    }
                    else
                    {
                        txtDetailAmount.Value = CommonHandler.ToString(price - (minH - quantity) * minusPrice);
                    }
                }
                else if (quantity > maxH)
                {
                    txtDetailAmount.Value = CommonHandler.ToString(price + (quantity - maxH) * plusPrice);
                }
                else
                {
                    txtDetailAmount.Value = CommonHandler.ToString(txtPrice.Value);
                }



            }
            catch (Exception ex)
            {
                CommonHandler.ProcessException(ex);
            }
        }

        private void dgvContract_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex != -1 && !dgvContract.Rows[e.RowIndex].IsNewRow)
            {
                if (e.ColumnIndex == 4 || e.ColumnIndex == 5)
                {
                    try
                    {
                        decimal price = CommonHandler.ToDecimal(this.dgvContract[4, e.RowIndex].Value);
                        decimal quantity = CommonHandler.ToDecimal(this.dgvContract[5, e.RowIndex].Value);
                        decimal minH = CommonHandler.ToDecimal(this.dgvContract[8, e.RowIndex].Value);
                        decimal maxH = CommonHandler.ToDecimal(this.dgvContract[9, e.RowIndex].Value);
                        decimal plusPrice = CommonHandler.ToDecimal(this.dgvContract[12, e.RowIndex].Value);
                        decimal minusPrice = CommonHandler.ToDecimal(this.dgvContract[11, e.RowIndex].Value);
                        if (price == 0) {
                            this.dgvContract[13, e.RowIndex].Value = CommonHandler.ToString(0);
                        }
                        else if (quantity < minH)
                        {
                            if (quantity == 0)
                            {
                                this.dgvContract[13, e.RowIndex].Value = CommonHandler.ToString(0);
                            }
                            else
                            {
                                this.dgvContract[13, e.RowIndex].Value = CommonHandler.ToString(price - (minH - quantity) * minusPrice);
                            }
                        }
                        else if (quantity > maxH)
                        {
                            this.dgvContract[13, e.RowIndex].Value = CommonHandler.ToString(price + (quantity - maxH) * plusPrice);
                        }
                        else
                        {
                            this.dgvContract[13, e.RowIndex].Value = CommonHandler.ToString(this.dgvContract[4, e.RowIndex].Value);
                        }



                    }
                    catch (Exception ex)
                    {
                        CommonHandler.ProcessException(ex);
                    }
                }
            }
        }
        private void dgvContract_CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvContract.Columns[e.ColumnIndex].Name == "Price" || dgvContract.Columns[e.ColumnIndex].Name == "Rate")
            {
                string Price = dgvContract.Rows[e.RowIndex].Cells["Price"].Value.ToString();
                string Rate = dgvContract.Rows[e.RowIndex].Cells["Rate"].Value.ToString();
                if (!string.IsNullOrEmpty(Price) && !string.IsNullOrEmpty(Rate))
                {
                    dgvContract.Rows[e.RowIndex].Cells["Amount"].Value = Convert.ToUInt32(Convert.ToDouble(Price) * Convert.ToDouble(Rate));
                }
            }
        }

        private void dgvContract_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            dgvContract.EditingControl.KeyPress -= new KeyPressEventHandler(control_KeyPress);
            dgvContract.EditingControl.KeyPress += new KeyPressEventHandler(control_KeyPress);
        }

        private void control_KeyPress(object sender, KeyPressEventArgs e)
        {
            //数字以外入力できません。
            if (((int)e.KeyChar >= 48 && (int)e.KeyChar <= 57) || e.KeyChar == 13 || e.KeyChar == 8)
            {
                e.Handled = false;
            }
            else if ((dgvContract.CurrentCell.OwningColumn.Name == "WorkTime"
                || dgvContract.CurrentCell.OwningColumn.Name == "Rate") && e.KeyChar == 46)
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
                MessageBox.Show("数字以外入力できません。");
            }
        }

        private void Btn_Bill_Click(object sender, EventArgs e)
        {
            string customerID = CommonHandler.ToString(cobCustomerID.SelectedValue);
            if (string.IsNullOrEmpty(customerID + txtSaleDate.Text))
            {
                MessageBox.Show("顧客様を選択してください!");
                return;
            }
            BillSpecifyForm bsf = new BillSpecifyForm();
            bsf.setDateAndCustomer(txtSaleDate.Text, customerID);
            bsf.ShowDialog();
        }
    }
}
