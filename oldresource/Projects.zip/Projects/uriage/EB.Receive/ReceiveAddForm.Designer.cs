﻿namespace EB.Receive
{
    partial class ReceiveAddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegister = new System.Windows.Forms.Button();
            this.rdoAll = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.cobCustomerID = new System.Windows.Forms.ComboBox();
            this.cobMonth = new System.Windows.Forms.ComboBox();
            this.cobYear = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.dgvBill = new System.Windows.Forms.DataGridView();
            this.BillNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReceiptAmountTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BillAmountTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReceiptDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReceiptAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReceiptID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBillDate = new System.Windows.Forms.TextBox();
            this.btnAmountSame = new System.Windows.Forms.Button();
            this.btnDateSame = new System.Windows.Forms.Button();
            this.txtDiffAmount = new EB.Common.NumericTextox();
            this.txtTotalReceiptAmount = new EB.Common.NumericTextox();
            this.txtTotalBillAmount = new EB.Common.NumericTextox();
            this.txtBillAmount = new EB.Common.NumericTextox();
            this.txtTotalDiffAmount = new EB.Common.NumericTextox();
            this.txtReceiptAmount = new EB.Common.NumericTextox();
            this.txtReceiptDate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBill)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(654, 414);
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(481, 414);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(83, 23);
            this.btnRegister.TabIndex = 190;
            this.btnRegister.Text = "登録";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // rdoAll
            // 
            this.rdoAll.AutoSize = true;
            this.rdoAll.Checked = true;
            this.rdoAll.Location = new System.Drawing.Point(23, 98);
            this.rdoAll.Name = "rdoAll";
            this.rdoAll.Size = new System.Drawing.Size(71, 16);
            this.rdoAll.TabIndex = 195;
            this.rdoAll.TabStop = true;
            this.rdoAll.Text = "一括入金";
            this.rdoAll.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(238, 12);
            this.label9.TabIndex = 176;
            this.label9.Text = "入金年月を指定します。年と月を指定してください";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(21, 65);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 175;
            this.label10.Text = "顧客";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(242, 12);
            this.label1.TabIndex = 176;
            this.label1.Text = "請求一覧を表示します。顧客名を指定してください";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(53, 327);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 12);
            this.label14.TabIndex = 196;
            this.label14.Text = "入金日";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(29, 303);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 196;
            this.label15.Text = "入金予定日";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(53, 354);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 12);
            this.label16.TabIndex = 196;
            this.label16.Text = "請求額";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(394, 302);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 196;
            this.label17.Text = "総請求額";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(394, 328);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 196;
            this.label2.Text = "総入金額";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(413, 377);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 196;
            this.label3.Text = "差額";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(581, 302);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 196;
            this.label18.Text = "総差額";
            // 
            // cobCustomerID
            // 
            this.cobCustomerID.DisplayMember = "CustomerName";
            this.cobCustomerID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobCustomerID.Location = new System.Drawing.Point(56, 62);
            this.cobCustomerID.Name = "cobCustomerID";
            this.cobCustomerID.Size = new System.Drawing.Size(247, 20);
            this.cobCustomerID.TabIndex = 346;
            this.cobCustomerID.ValueMember = "CustomerID";
            this.cobCustomerID.SelectedIndexChanged += new System.EventHandler(this.cobCustomerID_SelectedIndexChanged);
            this.cobCustomerID.SelectionChangeCommitted += new System.EventHandler(this.cobCustomerID_SelectionChangeCommitted);
            // 
            // cobMonth
            // 
            this.cobMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobMonth.FormattingEnabled = true;
            this.cobMonth.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.cobMonth.Location = new System.Drawing.Point(544, 12);
            this.cobMonth.Name = "cobMonth";
            this.cobMonth.Size = new System.Drawing.Size(57, 20);
            this.cobMonth.TabIndex = 345;
            this.cobMonth.SelectionChangeCommitted += new System.EventHandler(this.cobMonth_SelectionChangeCommitted);
            // 
            // cobYear
            // 
            this.cobYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobYear.FormattingEnabled = true;
            this.cobYear.Items.AddRange(new object[] {
            "2020",
            "2019",
            "2018",
            "2017",
            "2016",
            "2015",
            "2014",
            "2013",
            "2012",
            "2011",
            "2010",
            "2009",
            "2008"});
            this.cobYear.Location = new System.Drawing.Point(433, 12);
            this.cobYear.Name = "cobYear";
            this.cobYear.Size = new System.Drawing.Size(84, 20);
            this.cobYear.TabIndex = 344;
            this.cobYear.SelectionChangeCommitted += new System.EventHandler(this.cobMonth_SelectionChangeCommitted);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(608, 16);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(17, 12);
            this.label38.TabIndex = 342;
            this.label38.Text = "月";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(523, 16);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(17, 12);
            this.label37.TabIndex = 343;
            this.label37.Text = "年";
            // 
            // dgvBill
            // 
            this.dgvBill.AllowUserToAddRows = false;
            this.dgvBill.AllowUserToDeleteRows = false;
            this.dgvBill.AllowUserToOrderColumns = true;
            this.dgvBill.AllowUserToResizeRows = false;
            this.dgvBill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBill.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BillNo,
            this.ReceiptAmountTotal,
            this.CustomerID,
            this.BillDate,
            this.BillAmountTotal,
            this.ReceiptDate,
            this.ReceiptAmount,
            this.ReceiptID});
            this.dgvBill.Location = new System.Drawing.Point(12, 130);
            this.dgvBill.MultiSelect = false;
            this.dgvBill.Name = "dgvBill";
            this.dgvBill.ReadOnly = true;
            this.dgvBill.RowHeadersVisible = false;
            this.dgvBill.RowTemplate.Height = 23;
            this.dgvBill.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBill.Size = new System.Drawing.Size(717, 146);
            this.dgvBill.TabIndex = 347;
            // 
            // BillNo
            // 
            this.BillNo.DataPropertyName = "BillNo";
            this.BillNo.HeaderText = "請求書番号";
            this.BillNo.Name = "BillNo";
            this.BillNo.ReadOnly = true;
            // 
            // ReceiptAmountTotal
            // 
            this.ReceiptAmountTotal.DataPropertyName = "ReceiptAmountTotal";
            this.ReceiptAmountTotal.HeaderText = "総入金額";
            this.ReceiptAmountTotal.Name = "ReceiptAmountTotal";
            this.ReceiptAmountTotal.ReadOnly = true;
            this.ReceiptAmountTotal.Visible = false;
            // 
            // CustomerID
            // 
            this.CustomerID.DataPropertyName = "CustomerID";
            this.CustomerID.HeaderText = "顧客ID";
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.ReadOnly = true;
            this.CustomerID.Visible = false;
            // 
            // BillDate
            // 
            this.BillDate.DataPropertyName = "BillDate";
            this.BillDate.HeaderText = "入金予定日";
            this.BillDate.Name = "BillDate";
            this.BillDate.ReadOnly = true;
            // 
            // BillAmountTotal
            // 
            this.BillAmountTotal.DataPropertyName = "BillAmountTotal";
            this.BillAmountTotal.HeaderText = "請求額";
            this.BillAmountTotal.Name = "BillAmountTotal";
            this.BillAmountTotal.ReadOnly = true;
            // 
            // ReceiptDate
            // 
            this.ReceiptDate.DataPropertyName = "ReceiptDate";
            this.ReceiptDate.HeaderText = "入金日";
            this.ReceiptDate.Name = "ReceiptDate";
            this.ReceiptDate.ReadOnly = true;
            // 
            // ReceiptAmount
            // 
            this.ReceiptAmount.DataPropertyName = "ReceiptAmount";
            this.ReceiptAmount.HeaderText = "入金額";
            this.ReceiptAmount.Name = "ReceiptAmount";
            this.ReceiptAmount.ReadOnly = true;
            // 
            // ReceiptID
            // 
            this.ReceiptID.DataPropertyName = "ReceiptID";
            this.ReceiptID.HeaderText = "入金ID";
            this.ReceiptID.Name = "ReceiptID";
            this.ReceiptID.ReadOnly = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 381);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 196;
            this.label4.Text = "入金額";
            // 
            // txtBillDate
            // 
            this.txtBillDate.Location = new System.Drawing.Point(101, 298);
            this.txtBillDate.Name = "txtBillDate";
            this.txtBillDate.ReadOnly = true;
            this.txtBillDate.Size = new System.Drawing.Size(114, 19);
            this.txtBillDate.TabIndex = 197;
            // 
            // btnAmountSame
            // 
            this.btnAmountSame.Location = new System.Drawing.Point(226, 374);
            this.btnAmountSame.Name = "btnAmountSame";
            this.btnAmountSame.Size = new System.Drawing.Size(136, 23);
            this.btnAmountSame.TabIndex = 348;
            this.btnAmountSame.Text = "請求額と同一";
            this.btnAmountSame.UseVisualStyleBackColor = true;
            this.btnAmountSame.Click += new System.EventHandler(this.btnAmountSame_Click);
            // 
            // btnDateSame
            // 
            this.btnDateSame.Location = new System.Drawing.Point(226, 322);
            this.btnDateSame.Name = "btnDateSame";
            this.btnDateSame.Size = new System.Drawing.Size(136, 23);
            this.btnDateSame.TabIndex = 349;
            this.btnDateSame.Text = "入金予定日と同一";
            this.btnDateSame.UseVisualStyleBackColor = true;
            this.btnDateSame.Click += new System.EventHandler(this.btnDateSame_Click);
            // 
            // txtDiffAmount
            // 
            this.txtDiffAmount.AcceptsTab = true;
            this.txtDiffAmount.Location = new System.Drawing.Point(449, 374);
            this.txtDiffAmount.Name = "txtDiffAmount";
            this.txtDiffAmount.Precision = 0;
            this.txtDiffAmount.ReadOnly = true;
            this.txtDiffAmount.SepratedChar = ',';
            this.txtDiffAmount.Size = new System.Drawing.Size(115, 19);
            this.txtDiffAmount.TabIndex = 402;
            this.txtDiffAmount.Value = "";
            // 
            // txtTotalReceiptAmount
            // 
            this.txtTotalReceiptAmount.AcceptsTab = true;
            this.txtTotalReceiptAmount.Location = new System.Drawing.Point(449, 324);
            this.txtTotalReceiptAmount.Name = "txtTotalReceiptAmount";
            this.txtTotalReceiptAmount.Precision = 0;
            this.txtTotalReceiptAmount.ReadOnly = true;
            this.txtTotalReceiptAmount.SepratedChar = ',';
            this.txtTotalReceiptAmount.Size = new System.Drawing.Size(115, 19);
            this.txtTotalReceiptAmount.TabIndex = 403;
            this.txtTotalReceiptAmount.Value = "";
            // 
            // txtTotalBillAmount
            // 
            this.txtTotalBillAmount.AcceptsTab = true;
            this.txtTotalBillAmount.Location = new System.Drawing.Point(449, 298);
            this.txtTotalBillAmount.Name = "txtTotalBillAmount";
            this.txtTotalBillAmount.Precision = 0;
            this.txtTotalBillAmount.ReadOnly = true;
            this.txtTotalBillAmount.SepratedChar = ',';
            this.txtTotalBillAmount.Size = new System.Drawing.Size(115, 19);
            this.txtTotalBillAmount.TabIndex = 404;
            this.txtTotalBillAmount.Value = "";
            // 
            // txtBillAmount
            // 
            this.txtBillAmount.AcceptsTab = true;
            this.txtBillAmount.Location = new System.Drawing.Point(100, 351);
            this.txtBillAmount.Name = "txtBillAmount";
            this.txtBillAmount.Precision = 0;
            this.txtBillAmount.ReadOnly = true;
            this.txtBillAmount.SepratedChar = ',';
            this.txtBillAmount.Size = new System.Drawing.Size(115, 19);
            this.txtBillAmount.TabIndex = 402;
            this.txtBillAmount.Value = "";
            // 
            // txtTotalDiffAmount
            // 
            this.txtTotalDiffAmount.AcceptsTab = true;
            this.txtTotalDiffAmount.Location = new System.Drawing.Point(621, 298);
            this.txtTotalDiffAmount.Name = "txtTotalDiffAmount";
            this.txtTotalDiffAmount.Precision = 0;
            this.txtTotalDiffAmount.ReadOnly = true;
            this.txtTotalDiffAmount.SepratedChar = ',';
            this.txtTotalDiffAmount.Size = new System.Drawing.Size(108, 19);
            this.txtTotalDiffAmount.TabIndex = 405;
            this.txtTotalDiffAmount.Value = "";
            // 
            // txtReceiptAmount
            // 
            this.txtReceiptAmount.AcceptsTab = true;
            this.txtReceiptAmount.Location = new System.Drawing.Point(100, 378);
            this.txtReceiptAmount.Name = "txtReceiptAmount";
            this.txtReceiptAmount.Precision = 0;
            this.txtReceiptAmount.SepratedChar = ',';
            this.txtReceiptAmount.Size = new System.Drawing.Size(115, 19);
            this.txtReceiptAmount.TabIndex = 402;
            this.txtReceiptAmount.Value = "";
            this.txtReceiptAmount.TextChanged += new System.EventHandler(this.txtReceiptAmount_TextChanged);
            // 
            // txtReceiptDate
            // 
            this.txtReceiptDate.CustomFormat = "yyyy/MM/dd";
            this.txtReceiptDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.txtReceiptDate.Location = new System.Drawing.Point(102, 323);
            this.txtReceiptDate.Name = "txtReceiptDate";
            this.txtReceiptDate.Size = new System.Drawing.Size(116, 19);
            this.txtReceiptDate.TabIndex = 406;
            // 
            // ReceiveAddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(748, 447);
            this.Controls.Add(this.txtReceiptDate);
            this.Controls.Add(this.txtTotalDiffAmount);
            this.Controls.Add(this.txtTotalBillAmount);
            this.Controls.Add(this.txtTotalReceiptAmount);
            this.Controls.Add(this.txtReceiptAmount);
            this.Controls.Add(this.txtBillAmount);
            this.Controls.Add(this.txtDiffAmount);
            this.Controls.Add(this.btnAmountSame);
            this.Controls.Add(this.btnDateSame);
            this.Controls.Add(this.dgvBill);
            this.Controls.Add(this.cobCustomerID);
            this.Controls.Add(this.cobMonth);
            this.Controls.Add(this.cobYear);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtBillDate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.rdoAll);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label9);
            this.Name = "ReceiveAddForm";
            this.Text = "入金登録";
            this.Load += new System.EventHandler(this.ReceiveAddForm_Load);
            this.Controls.SetChildIndex(this.label9, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label10, 0);
            this.Controls.SetChildIndex(this.btnRegister, 0);
            this.Controls.SetChildIndex(this.rdoAll, 0);
            this.Controls.SetChildIndex(this.label14, 0);
            this.Controls.SetChildIndex(this.label15, 0);
            this.Controls.SetChildIndex(this.label16, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.txtBillDate, 0);
            this.Controls.SetChildIndex(this.label17, 0);
            this.Controls.SetChildIndex(this.label18, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.label37, 0);
            this.Controls.SetChildIndex(this.label38, 0);
            this.Controls.SetChildIndex(this.cobYear, 0);
            this.Controls.SetChildIndex(this.cobMonth, 0);
            this.Controls.SetChildIndex(this.cobCustomerID, 0);
            this.Controls.SetChildIndex(this.dgvBill, 0);
            this.Controls.SetChildIndex(this.btnDateSame, 0);
            this.Controls.SetChildIndex(this.btnAmountSame, 0);
            this.Controls.SetChildIndex(this.txtDiffAmount, 0);
            this.Controls.SetChildIndex(this.txtBillAmount, 0);
            this.Controls.SetChildIndex(this.txtReceiptAmount, 0);
            this.Controls.SetChildIndex(this.txtTotalReceiptAmount, 0);
            this.Controls.SetChildIndex(this.txtTotalBillAmount, 0);
            this.Controls.SetChildIndex(this.txtTotalDiffAmount, 0);
            this.Controls.SetChildIndex(this.txtReceiptDate, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBill)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.RadioButton rdoAll;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cobCustomerID;
        private System.Windows.Forms.ComboBox cobMonth;
        private System.Windows.Forms.ComboBox cobYear;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.DataGridView dgvBill;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBillDate;
        private System.Windows.Forms.Button btnAmountSame;
        private System.Windows.Forms.Button btnDateSame;
        private Common.NumericTextox txtDiffAmount;
        private Common.NumericTextox txtTotalReceiptAmount;
        private Common.NumericTextox txtTotalBillAmount;
        private Common.NumericTextox txtBillAmount;
        private Common.NumericTextox txtTotalDiffAmount;
        private Common.NumericTextox txtReceiptAmount;
        private System.Windows.Forms.DateTimePicker txtReceiptDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReceiptAmountTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn BillAmountTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReceiptDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReceiptAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReceiptID;
    }
}