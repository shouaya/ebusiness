﻿using System;
using System.Collections.Generic;

using System.Text;
using log4net;

namespace EB.Common
{
    public class LogHelper
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static void Infor(string message)
        {
            log.Info(message);
        }
        public static void Error(string message)
        {
            log.Error(message);
        }
        public static void Debug(string message)
        {
            log.Debug(message);
        }
    }
}
