﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Xml;
using System.Windows.Forms;

namespace EB.Common
{
    public class HolidayHelper
    {
        #region 祝日計算
        /// <summary>
        /// 祝日情報（戻り値）
        /// </summary>
        public struct DayInfo
        {
            public enum DAY
            {
                WEEKDAY = 0, // 平日
                HOLIDAY = 1, // 休日
                C_HOLIDAY = 2, // 振休
                SYUKUJITSU = 3, // 祝日
            };
            public DAY KindOfDay; // その日の種類
            public DayOfWeek week; // その日の曜日
            public String name; // その日に名前が付いている場合はその名前。
        };
        private static readonly DateTime SYUKUJITSU = new DateTime(1948, 7, 20); // 祝日法施行日
        private static readonly DateTime FURIKAE = new DateTime(1973, 07, 12); // 振替休日制度の開始日

        /// <summary>
        /// 期間の稼動率
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns></returns>
        public static double GetQuantityBetween(DateTime start, DateTime end)
        {
            DateTime start_month = DateTime.Parse(start.ToString("yyyy/MM"));

            DateTime end_month = DateTime.Parse(end.ToString("yyyy/MM")).AddMonths(1).AddDays(-1);

            Int32 workday = GetWorkDaysByMonth(start, end);

            Int32 workday_all = GetWorkDaysByMonth(start_month, end_month);

            return Math.Round((double)workday / (double)workday_all, 2);
        }
        /// <summary>
        /// 休日数を取得(当月)
        /// </summary>
        /// <param name="dtime"></param>
        /// <returns></returns>
        public static Int32 GetHolidaysByMonth(DateTime dtime)
        {
            DateTime dt_start = DateTime.Parse(dtime.ToString("yyyy/MM"));
            DateTime dt_end = dt_start.AddMonths(1);//.AddDays(-1);
            return GetHolidaysByMonth(dt_start,dt_end);
        }
        /// <summary>
        /// 休日数を取得(期間)
        /// </summary>
        /// <param name="dtime"></param>
        /// <returns></returns>
        public static Int32 GetHolidaysByMonth(DateTime dt_start, DateTime dt_end)
        {
            List<DayInfo> hi = new List<DayInfo>();

            while (dt_start <= dt_end)
            {
                hi.Add(GetDayInfo(dt_start));
                dt_start = dt_start.AddDays(1);
            }
            return hi.FindAll((holiday) => { return holiday.KindOfDay != DayInfo.DAY.WEEKDAY; }).Count;
        }
        /// <summary>
        /// 平日数を取得(当月)
        /// </summary>
        /// <param name="dtime"></param>
        /// <returns></returns>
        public static Int32 GetWorkDaysByMonth(DateTime dtime)
        {
            DateTime dt_start = DateTime.Parse(dtime.ToString("yyyy/MM"));
            DateTime dt_end = dt_start.AddMonths(1);//.AddDays(-1);

            return GetWorkDaysByMonth(dt_start,dt_end);
        }
        /// <summary>
        /// 平日数を取得(期間)
        /// </summary>
        /// <param name="dtime"></param>
        /// <returns></returns>
        public static Int32 GetWorkDaysByMonth(DateTime dt_start, DateTime dt_end)
        {
            List<DayInfo> hi = new List<DayInfo>();

            while (dt_start <= dt_end)
            {
                hi.Add(GetDayInfo(dt_start));
                dt_start = dt_start.AddDays(1);
            }
            return hi.FindAll((holiday) => { return holiday.KindOfDay == DayInfo.DAY.WEEKDAY; }).Count;
        }
        /// <summary>
        /// その日が何かを調べるメソッド
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        public static DayInfo GetDayInfo(DateTime t)
        {
            int yy = t.Year;
            int mm = t.Month;
            int dd = t.Day;
            DayOfWeek ww = t.DayOfWeek;

            DayInfo result = new DayInfo();
            result.week = ww;
            if (ww == DayOfWeek.Sunday || ww == DayOfWeek.Saturday)
            {
                result.KindOfDay = DayInfo.DAY.HOLIDAY;
            }
            else
            {
                result.KindOfDay = DayInfo.DAY.WEEKDAY;
            }

            // 祝日法施行以前
            if (t < SYUKUJITSU) return result;

            switch (mm)
            {
                // １月 //
                case 1:
                    if (dd == 1)
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "元日";      // 07/5/28 祝日名が '元旦' になっていたのを修正
                    }
                    else
                    {
                        if (yy >= 2000)
                        {
                            if (((int)((dd - 1) / 7) == 1) && (ww == DayOfWeek.Monday))
                            {
                                result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                                result.name = "成人の日";
                            }
                        }
                        else
                        {
                            if (dd == 15)
                            {
                                result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                                result.name = "成人の日";
                            }
                        }
                    }
                    break;
                // ２月 //
                case 2:
                    if (dd == 11)
                    {
                        if (yy >= 1967)
                        {
                            result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                            result.name = "建国記念の日";
                        }
                    }
                    else if ((yy == 1989) && (dd == 24))
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "昭和天皇の大喪の礼";
                    }
                    break;
                // ３月 //
                case 3:
                    if (dd == Syunbun(yy))
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "春分の日";
                    }
                    break;
                // ４月 //
                case 4:
                    if (dd == 29)
                    {
                        if (yy >= 2007)
                        {
                            result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                            result.name = "昭和の日";
                        }
                        else if (yy >= 1989)
                        {
                            result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                            result.name = "みどりの日";
                        }
                        else
                        {
                            result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                            result.name = "天皇誕生日";
                        }
                    }
                    else if ((yy == 1959) && (dd == 10))
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "皇太子明仁親王の結婚の儀";
                    }
                    break;
                // ５月 //
                case 5:
                    if (dd == 3)
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "憲法記念日";
                    }
                    else if (dd == 4)
                    {
                        if (yy >= 2007)
                        {
                            result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                            result.name = "みどりの日";
                        }
                        else if (yy >= 1986)
                        {
                            /* 5/4が日曜日は『只の日曜』､月曜日は『憲法記念日の振替休日』(～2006年)*/
                            if (ww > DayOfWeek.Monday)
                            {
                                result.KindOfDay = DayInfo.DAY.HOLIDAY;
                                result.name = "国民の休日";
                            }
                        }
                    }
                    else if (dd == 5)
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "こどもの日";
                    }
                    else if (dd == 6)
                    {
                        /* 07/11/21  [Wednesday or Thursday] → [Tuesday or Wednesday] に訂正 */
                        /* [5/3,5/4が日曜]ケースのみ、ここで判定 */
                        if ((yy >= 2007) && ((ww == DayOfWeek.Tuesday) || (ww == DayOfWeek.Wednesday)))
                        {
                            result.KindOfDay = DayInfo.DAY.C_HOLIDAY;
                            result.name = "振替休日";
                        }
                    }
                    break;
                // ６月 //
                case 6:
                    if ((yy == 1993) && (dd == 9))
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "皇太子徳仁親王の結婚の儀";
                    }
                    break;
                // ７月 //
                case 7:
                    if (yy >= 2003)
                    {
                        if (((int)((dd - 1) / 7) == 2) && (ww == DayOfWeek.Monday))
                        {
                            result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                            result.name = "海の日";
                        }
                    }
                    else if (yy >= 1996)
                    {
                        if (dd == 20)
                        {
                            result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                            result.name = "海の日";
                        }
                    }
                    break;
                // ８月 //
                case 8:
                    break;
                // ９月 //
                case 9:
                    if (dd == Syubun(yy))
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "秋分の日";
                    }
                    else
                    {
                        if (yy >= 2003)
                        {
                            if (((int)((dd - 1) / 7) == 2) && (ww == DayOfWeek.Monday))
                            {
                                result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                                result.name = "敬老の日";
                            }
                            else if (ww == DayOfWeek.Tuesday)
                            {
                                if (dd == Syubun(yy) - 1)
                                {
                                    result.KindOfDay = DayInfo.DAY.HOLIDAY;
                                    result.name = "国民の休日";
                                }
                            }
                        }
                        else if (yy >= 1966)
                        {
                            if (dd == 15)
                            {
                                result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                                result.name = "敬老の日";
                            }
                        }
                    }
                    break;
                // １０月 //
                case 10:
                    if (yy >= 2000)
                    {
                        if (((int)((dd - 1) / 7) == 1) && (ww == DayOfWeek.Monday))
                        {
                            result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                            result.name = "体育の日";
                        }
                    }
                    else if (yy >= 1966)
                    {
                        if (dd == 10)
                        {
                            result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                            result.name = "体育の日";
                        }
                    }
                    break;
                // １１月 //
                case 11:
                    if (dd == 3)
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "文化の日";
                    }
                    else if (dd == 23)
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "勤労感謝の日";
                    }
                    else if ((yy == 1990) && (dd == 12))
                    {
                        result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                        result.name = "即位礼正殿の儀";
                    }
                    break;
                // １２月 //
                case 12:
                    if (dd == 23)
                    {
                        if (yy >= 1989)
                        {
                            result.KindOfDay = DayInfo.DAY.SYUKUJITSU;
                            result.name = "天皇誕生日";
                        }
                    }
                    break;
                default:
                    break;
            }

            if ((result.KindOfDay == DayInfo.DAY.WEEKDAY
                 || result.KindOfDay == DayInfo.DAY.HOLIDAY) &&
                (ww == DayOfWeek.Monday))
            {
                /*月曜以外は振替休日判定不要
                  5/6(火,水)の判定は上記ステップで処理済
                  5/6(月)はここで判定する  */
                if (t >= FURIKAE)
                {
                    if (GetDayInfo(t.AddDays(-1)).KindOfDay == DayInfo.DAY.SYUKUJITSU)
                    {    /* 再帰呼出 */
                        result.KindOfDay = DayInfo.DAY.C_HOLIDAY;
                        result.name = "振替休日";
                    }
                }
            }
            return result;
        }


        /// <summary>
        /// 春分の日を返すメソッド
        /// </summary>
        /// <param name="yy"></param>
        /// <returns></returns>
        private static int Syunbun(int yy)
        {
            int dd;
            if (yy <= 1947)
            {
                dd = 99;
            }
            else if (yy <= 1979)
            {
                dd = (int)(20.8357 + (0.242194 * (yy - 1980)) - (int)((yy - 1983) / 4));
            }
            else if (yy <= 2099)
            {
                dd = (int)(20.8431 + (0.242194 * (yy - 1980)) - (int)((yy - 1980) / 4));
            }
            else if (yy <= 2150)
            {
                dd = (int)(21.851 + (0.242194 * (yy - 1980)) - (int)((yy - 1980) / 4));
            }
            else
            {
                dd = 99;
            }
            return dd;
        }
        /// <summary>
        /// 秋分の日を返すメソッド
        /// </summary>
        /// <param name="yy"></param>
        /// <returns></returns>
        private static int Syubun(int yy)
        {
            int dd;
            if (yy <= 1947)
            {
                dd = 99;
            }
            else if (yy <= 1979)
            {
                dd = (int)(23.2588 + (0.242194 * (yy - 1980)) - (int)((yy - 1983) / 4));
            }
            else if (yy <= 2099)
            {
                dd = (int)(23.2488 + (0.242194 * (yy - 1980)) - (int)((yy - 1980) / 4));
            }
            else if (yy <= 2150)
            {
                dd = (int)(24.2488 + (0.242194 * (yy - 1980)) - (int)((yy - 1980) / 4));
            }
            else
            {
                dd = 99;
            }
            return dd;
        }

        #endregion

    }
}
