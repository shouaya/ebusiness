﻿using System;
using System.Windows.Forms;
using System.Threading;
using System.Drawing;

namespace EB.Common
{
    public class ThreadPoolHelper
    {
        public delegate object ThreadingDelegate();
        public delegate void ThreadOverDelegate(object obj);

        public static void StartThread(Control mainThreadControl,ThreadingDelegate threadTodo,ThreadOverDelegate UItodo)
        {
            Label Thread_Status = Show_Thread_Status( mainThreadControl);
            
            ThreadPool.QueueUserWorkItem((o) =>
            {
                object callback = threadTodo();

                mainThreadControl.Invoke(
                   new Action<object>(
                           (obj) =>
                           {
                               UItodo(obj);
                               Thread_Status.Visible = false;
                               Thread_Status.Dispose();
                           }
                       ), callback
                );

            }, "thread_" + mainThreadControl.Name);
        }

        private static Label Show_Thread_Status(Control mainThreadControl)
        {
            int
                w = 200,
                h = 50;
            if (mainThreadControl.Cursor == Cursors.WaitCursor)
            {
                w = mainThreadControl.Width;
                h = mainThreadControl.Height;
            }
            int
                l = (mainThreadControl.Width - w) / 2,
                t = (mainThreadControl.Height - h) / 2;

            Label Thread_Status = new Label();
            Thread_Status.Text = "実行中...";
            Thread_Status.TextAlign = ContentAlignment.MiddleCenter;
            Thread_Status.Height = h;
            Thread_Status.Width = w;
            Thread_Status.Font = new Font(FontFamily.GenericSansSerif, 20);
            Thread_Status.ForeColor = Color.Red;
            Thread_Status.Left = l;
            Thread_Status.Top = t;
            Thread_Status.Parent = mainThreadControl;
            Thread_Status.BringToFront();
            Thread_Status.Visible = true;
            mainThreadControl.Refresh();

            mainThreadControl.Resize += new EventHandler((sender, e) =>
            {
                Thread_Status.Left = l;
                Thread_Status.Top = t;
            });
            return Thread_Status;
        }
    }
}
