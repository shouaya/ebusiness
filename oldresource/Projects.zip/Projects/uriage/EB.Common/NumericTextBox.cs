using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;
using System.Threading;
using System.ComponentModel;
using System.Media;

namespace EB.Common
{
    public class NumericTextox : TextBox
    {
        private char sepratedChar = ',';
        private int precision = 0;

        private void SetSepratedChar()
        {
            string text = this.Text.Replace(sepratedChar.ToString(), string.Empty);

            if (string.IsNullOrEmpty(text)) return;

            decimal value = CommonHandler.ToDecimal(text);
            if (precision == 0)
            {
                text = string.Format("{0:N0}", value);
            }
            else
            {
                text = string.Format("{0:N"+precision+"}", value);
            }

            this.Text = text;
        }

        protected override void OnLeave(EventArgs e)
        {

            SetSepratedChar();

            base.OnLeave(e);

        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {

            if (Char.IsDigit(e.KeyChar))
            {
                // Digits are OK
            }
            else if (e.KeyChar == '\b')
            {
                // Backspace key is OK

            }
            else if (e.KeyChar == '.')
            {
                string value = CommonHandler.ToString( this.Text);
                if (value.Contains("."))
                {
                    e.Handled = true;
                }

                // Backspace key is OK
            }
            else if ((ModifierKeys & (Keys.Control | Keys.Alt)) != 0)
            {
                //ModifierKeys + ( Alt & Ctrl ) are OK
            }
            else
            {
                e.Handled = true;
            }

        }

        [Description("number was entered in textBox as type of Int64")]
        [Browsable(false)]
        public string Value
        {
            get
            {
                if (this.Text.Length != 0)
                    return this.Text.Replace(sepratedChar.ToString(), string.Empty);
                else
                    return "";
            }

            set
            {
                this.Text = CommonHandler.ToString(value);
                SetSepratedChar();
            }
        }

        [Description("This character placed between number")]
        public char SepratedChar
        {
            set { sepratedChar = value; }
            get { return sepratedChar; }
        }
        [Description("Decimal places ")]
        public int Precision
        {
            set { precision = value; }
            get { return precision; }
        }
        

    }
}
