﻿using System;
using System.Collections.Generic;

using System.Text;

namespace EB.Common
{
    /// <summary>
    /// ユーザ定義Exception
    /// </summary>
    public class EBException : ApplicationException
    {
        public EBException(string message)
            : base(message)
        {
        }

        public EBException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }

}
