﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Reflection;

namespace EB.Common
{
    public class ExcelProvider
    {
        #region "Define Variable"
        private object miss = Missing.Value;
        private Microsoft.Office.Interop.Excel.Application m_objExcel = null;
        private Microsoft.Office.Interop.Excel.Workbooks m_objBooks = null;
        private Microsoft.Office.Interop.Excel.Workbook m_objBook = null;
        private Microsoft.Office.Interop.Excel.Worksheet sheet = null;
        #endregion

        #region "Property"
        public Microsoft.Office.Interop.Excel.Worksheet CurrentSheet
        {
            get{return sheet;}

            set{this.sheet = value;}
        }
        public Microsoft.Office.Interop.Excel.Workbooks CurrentWorkBooks
        {
            get{  return this.m_objBooks;}

            set{ this.m_objBooks = value; }
        }
        public Microsoft.Office.Interop.Excel.Workbook CurrentWorkBook
        {
            get{return this.m_objBook;}
            set{this.m_objBook = value;}
        }
        #endregion


        #region "Constructor"
        public ExcelProvider()
        {
            this.m_objExcel = new Microsoft.Office.Interop.Excel.Application();
        }
        public ExcelProvider(Microsoft.Office.Interop.Excel.Application objExcel)
        {

            this.m_objExcel = objExcel;
        }
        #endregion

        #region "Public Mehtod"
        public void SetRangeValue(int startRNum, int endRNum, int startCNum, int endCNum, Array arr)
        {
            Microsoft.Office.Interop.Excel.Range range = sheet.get_Range(sheet.Cells[startRNum, startCNum],

            sheet.Cells[endRNum, endCNum]);

            range.Value2 = arr;
        }
        public void MergeRangeCellH(int startRNum, int endRNum, int startCNum, int endCNum, string strText)
        {
            Microsoft.Office.Interop.Excel.Range range = sheet.get_Range(sheet.Cells[startRNum, startCNum],

            sheet.Cells[endRNum, endCNum]);
            range.Merge(true);
            range.Value2 = strText;
            range.HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlCenter;
            range.VerticalAlignment = Microsoft.Office.Interop.Excel.Constants.xlCenter;
        }
        public void MergeRangeCellV(int startRNum, int endRNum, int startCNum, int endCNum, string strText)
        {
            Microsoft.Office.Interop.Excel.Range range = sheet.get_Range(sheet.Cells[startRNum, startCNum],
            sheet.Cells[endRNum, endCNum]);
            range.Merge(Type.Missing);
            range.Value2 = strText;

            range.WrapText = true;
            range.HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlCenter;
            range.VerticalAlignment = Microsoft.Office.Interop.Excel.Constants.xlTop;
        }
        public void UserControl(bool usercontrol)
        {
            if (m_objExcel == null)
            {
                return;
            }

            m_objExcel.UserControl = usercontrol;
            m_objExcel.DisplayAlerts = usercontrol;
            m_objExcel.Visible = usercontrol;
        }
        /// <summary>
        /// Open Excel
        /// </summary>
        /// <param name="filename">Path</param>
        public void OpenExcelFile(string filename)
        {

            UserControl(false);

            m_objExcel.Workbooks.Open(filename, miss, miss, miss, miss, miss, miss, miss,
            miss, miss, miss, miss, miss, miss, miss);
            m_objBooks = (Microsoft.Office.Interop.Excel.Workbooks)m_objExcel.Workbooks;
            m_objBook = m_objExcel.ActiveWorkbook;
            sheet = (Microsoft.Office.Interop.Excel.Worksheet)m_objBook.ActiveSheet;
        }
        public string GetValue(int x, int y)
        {
            try
            {
                Microsoft.Office.Interop.Excel.Range range = (Microsoft.Office.Interop.Excel.Range)sheet.Cells[x, y];
                return (string)range.Text;
            }
            catch
            {
                return "";
            }
        }
        public int GetSheetRowCount()
        {
           return sheet.UsedRange.Rows.Count;
        }
        public void InsertColumn(int y)
        {
            ((Microsoft.Office.Interop.Excel.Range)sheet.Cells[1, y]).EntireColumn.Insert(Microsoft.Office.Interop.Excel.XlInsertShiftDirection.xlShiftToRight, Type.Missing);
            ((Microsoft.Office.Interop.Excel.Range)sheet.Cells[1, y]).EntireColumn.AutoFit();
        }
        public void CreateExceFile()
        {

            UserControl(false);

            m_objBooks = (Microsoft.Office.Interop.Excel.Workbooks)m_objExcel.Workbooks;
            m_objBook = (Microsoft.Office.Interop.Excel.Workbook)(m_objBooks.Add(miss));
            sheet = (Microsoft.Office.Interop.Excel.Worksheet)m_objBook.ActiveSheet;
        }
        public void SaveAs(string BillNo)
        {
            string excelPath = System.IO.Directory.GetCurrentDirectory() + "\\Excel\\";
            if (!System.IO.Directory.Exists(excelPath))
            {
                System.IO.Directory.CreateDirectory(excelPath);
            }

            string fullPath = excelPath + "EB請求書_" + BillNo + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".xlsx";

            m_objBook.SaveAs(fullPath, miss, miss, miss, miss, miss
                , Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlLocalSessionChanges, miss, miss, miss, miss);

            //m_objBook.Close(false, miss, miss);
        }
        public void ReleaseExcel()
        {

            m_objExcel.Quit();
            if (m_objExcel != null)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject((object)m_objExcel);
            }
            if (m_objBooks != null)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject((object)m_objBooks);
            }
            if (m_objBook != null)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject((object)m_objBook);
            }
            if (sheet != null)
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject((object)sheet);
            }

            m_objExcel = null;
            m_objBooks = null;
            m_objBook = null;

            sheet = null;

            GC.Collect();
        }
        public bool KillAllExcelApp()
        {

            try
            {

                if (m_objExcel != null)
                {
                    m_objExcel.Quit();

                    System.Runtime.InteropServices.Marshal.ReleaseComObject(m_objExcel);
                    foreach (System.Diagnostics.Process theProc in System.Diagnostics.Process.GetProcessesByName("EXCEL"))
                    {
                        if (theProc.CloseMainWindow() == false)
                        {
                            theProc.Kill();

                        }
                    }

                    m_objExcel = null;
                    return true;
                }

            }

            catch
            {
                return false;
            }

            return true;
        }
        #endregion
        private string AList = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        /// <summary>
        /// Get Fixed Area's Characters
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public string GetAix(int x, int y)
        {

            char[] AChars = AList.ToCharArray();

            if (x >= 26)
            {
                return "";

            }

            string s = "";

            s = s + AChars[x - 1].ToString();

            s = s + y.ToString();

            return s;
        }
        /// <summary>
        /// Set Cells Values
        /// </summary>
        /// <param name="x">Row Number</param>
        /// <param name="y">Column Number</param>
        /// <param name="text">Values</param>
        /// <param name="font">Font Format</param>
        /// <param name="color">Color</param>
        public void setValue(int x, int y, string text)
        {
            sheet.Cells[x, y] = text;
        }
        /// <summary>
        /// Paste Cut Content To Current Area
        /// </summary>
        public void past()
        {

            string s = "a,b,c,d,e,f,g";

            sheet.Paste(sheet.get_Range(this.GetAix(10, 10), miss), s);
        }
        /// <summary>
        /// Set Border
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="y1"></param>
        /// <param name="x2"></param>
        /// <param name="y2"></param>
        /// <param name="Width"></param>
        public void setBorder(int x1, int y1, int x2, int y2, int Width)
        {

            Microsoft.Office.Interop.Excel.Range range = sheet.get_Range(this.GetAix(x1, y1), this.GetAix(x2, y2));
            range.Borders.Weight = Width;
        }
        public void mergeCell(int x1, int y1, int x2, int y2)
        {

            Microsoft.Office.Interop.Excel.Range range = sheet.get_Range(this.GetAix(x1, y1), this.GetAix(x2, y2));
            range.Merge(true);
        }
        public Microsoft.Office.Interop.Excel.Range getRange(int x1, int y1, int x2, int y2)
        {

            Microsoft.Office.Interop.Excel.Range range = sheet.get_Range(this.GetAix(x1, y1), this.GetAix(x2, y2));
            return range;
        }
        public void GetNewWorksheet(string path)
        {

            Microsoft.Office.Interop.Excel.Workbook curWorkbook = m_objExcel.Workbooks.Add(path);
            sheet = curWorkbook.ActiveSheet as Microsoft.Office.Interop.Excel.Worksheet;
        }
        public void Print()
        {
            sheet.PrintOutEx();
        }
        public void SaveAsPdf(string BillNo)
        {
            if (!string.IsNullOrEmpty(BillNo))
            {

                string pdfPath = System.IO.Directory.GetCurrentDirectory() + "\\PDF\\";

                if (!System.IO.Directory.Exists(pdfPath))
                {
                    System.IO.Directory.CreateDirectory(pdfPath);
                }

                string fullPath = pdfPath + "EB請求書_" + BillNo + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".pdf";

                sheet.ExportAsFixedFormat(
                    Microsoft.Office.Interop.Excel.XlFixedFormatType.xlTypePDF,
                    fullPath,
                    Microsoft.Office.Interop.Excel.XlFixedFormatQuality.xlQualityStandard,
                    true, true, Type.Missing, Type.Missing, false, Type.Missing);
                //open PDF
                System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                //startInfo.FileName = Application.ExecutablePath;
                startInfo.FileName = fullPath;

                System.Diagnostics.Process process = new System.Diagnostics.Process();
                process.StartInfo = startInfo;
                process.Start();
            }
        }
        public void SetCurrentSheet(int index)
        {
            sheet = (Microsoft.Office.Interop.Excel.Worksheet)CurrentWorkBook.Worksheets.get_Item(index);
        }
    }
}
