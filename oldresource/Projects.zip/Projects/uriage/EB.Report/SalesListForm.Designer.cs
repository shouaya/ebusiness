﻿namespace EB.Report
{
    partial class SalesListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SalesList = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.cobCustomer = new System.Windows.Forms.ComboBox();
            this.cobYear = new System.Windows.Forms.ComboBox();
            this.cobMonth = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCustomer = new System.Windows.Forms.TextBox();
            this.iswithBill = new System.Windows.Forms.CheckBox();
            this.salesCount = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cobSalesMan = new System.Windows.Forms.ComboBox();
            this.isGroupbyCustomer = new System.Windows.Forms.CheckBox();
            this.cobSalesGroup1 = new System.Windows.Forms.CheckBox();
            this.btnExport = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.SalesList)).BeginInit();
            this.SuspendLayout();
            // 
            // SalesList
            // 
            this.SalesList.AllowUserToAddRows = false;
            this.SalesList.AllowUserToDeleteRows = false;
            this.SalesList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SalesList.Location = new System.Drawing.Point(10, 100);
            this.SalesList.Name = "SalesList";
            this.SalesList.ReadOnly = true;
            this.SalesList.RowTemplate.Height = 23;
            this.SalesList.Size = new System.Drawing.Size(710, 355);
            this.SalesList.TabIndex = 150;
            this.SalesList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SalesList_CellDoubleClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(226, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 136;
            this.label2.Text = "月";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(124, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 12);
            this.label1.TabIndex = 137;
            this.label1.Text = "年";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(19, 15);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(258, 12);
            this.label36.TabIndex = 138;
            this.label36.Text = "売上一覧表を表示します。年と月を指定してください。";
            // 
            // cobCustomer
            // 
            this.cobCustomer.DisplayMember = "CustomerName";
            this.cobCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobCustomer.FormattingEnabled = true;
            this.cobCustomer.Location = new System.Drawing.Point(54, 72);
            this.cobCustomer.Name = "cobCustomer";
            this.cobCustomer.Size = new System.Drawing.Size(134, 20);
            this.cobCustomer.TabIndex = 157;
            this.cobCustomer.ValueMember = "CustomerID";
            this.cobCustomer.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // cobYear
            // 
            this.cobYear.DisplayMember = "Years";
            this.cobYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobYear.FormattingEnabled = true;
            this.cobYear.Location = new System.Drawing.Point(21, 43);
            this.cobYear.Name = "cobYear";
            this.cobYear.Size = new System.Drawing.Size(97, 20);
            this.cobYear.TabIndex = 156;
            this.cobYear.ValueMember = "Years";
            this.cobYear.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // cobMonth
            // 
            this.cobMonth.DisplayMember = "Years";
            this.cobMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobMonth.FormattingEnabled = true;
            this.cobMonth.Items.AddRange(new object[] {
            "",
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12"});
            this.cobMonth.Location = new System.Drawing.Point(162, 43);
            this.cobMonth.Name = "cobMonth";
            this.cobMonth.Size = new System.Drawing.Size(58, 20);
            this.cobMonth.TabIndex = 158;
            this.cobMonth.ValueMember = "Years";
            this.cobMonth.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 159;
            this.label3.Text = "顧客";
            // 
            // txtCustomer
            // 
            this.txtCustomer.Location = new System.Drawing.Point(195, 72);
            this.txtCustomer.Name = "txtCustomer";
            this.txtCustomer.Size = new System.Drawing.Size(100, 19);
            this.txtCustomer.TabIndex = 160;
            this.txtCustomer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCustomer_KeyDown);
            // 
            // iswithBill
            // 
            this.iswithBill.AutoSize = true;
            this.iswithBill.Location = new System.Drawing.Point(271, 45);
            this.iswithBill.Name = "iswithBill";
            this.iswithBill.Size = new System.Drawing.Size(78, 16);
            this.iswithBill.TabIndex = 161;
            this.iswithBill.Text = "請求書あり";
            this.iswithBill.UseVisualStyleBackColor = true;
            this.iswithBill.CheckedChanged += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // salesCount
            // 
            this.salesCount.AutoSize = true;
            this.salesCount.Location = new System.Drawing.Point(640, 80);
            this.salesCount.Name = "salesCount";
            this.salesCount.Size = new System.Drawing.Size(41, 12);
            this.salesCount.TabIndex = 162;
            this.salesCount.Text = "件数：0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(318, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 164;
            this.label4.Text = "営業";
            // 
            // cobSalesMan
            // 
            this.cobSalesMan.DisplayMember = "EmployeeName";
            this.cobSalesMan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cobSalesMan.FormattingEnabled = true;
            this.cobSalesMan.Location = new System.Drawing.Point(353, 72);
            this.cobSalesMan.Name = "cobSalesMan";
            this.cobSalesMan.Size = new System.Drawing.Size(134, 20);
            this.cobSalesMan.TabIndex = 163;
            this.cobSalesMan.ValueMember = "EmployeeID";
            this.cobSalesMan.SelectionChangeCommitted += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // isGroupbyCustomer
            // 
            this.isGroupbyCustomer.AutoSize = true;
            this.isGroupbyCustomer.Location = new System.Drawing.Point(368, 44);
            this.isGroupbyCustomer.Name = "isGroupbyCustomer";
            this.isGroupbyCustomer.Size = new System.Drawing.Size(48, 16);
            this.isGroupbyCustomer.TabIndex = 165;
            this.isGroupbyCustomer.Text = "集計";
            this.isGroupbyCustomer.UseVisualStyleBackColor = true;
            this.isGroupbyCustomer.CheckedChanged += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // cobSalesGroup1
            // 
            this.cobSalesGroup1.AutoSize = true;
            this.cobSalesGroup1.Location = new System.Drawing.Point(482, 14);
            this.cobSalesGroup1.Name = "cobSalesGroup1";
            this.cobSalesGroup1.Size = new System.Drawing.Size(94, 16);
            this.cobSalesGroup1.TabIndex = 166;
            this.cobSalesGroup1.Text = "営業グループ１";
            this.cobSalesGroup1.UseVisualStyleBackColor = true;
            this.cobSalesGroup1.CheckedChanged += new System.EventHandler(this.cob_SelectionChangeCommitted);
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(482, 34);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(75, 23);
            this.btnExport.TabIndex = 167;
            this.btnExport.Text = "エクスポート";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // SalesListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.ClientSize = new System.Drawing.Size(748, 496);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.cobSalesGroup1);
            this.Controls.Add(this.isGroupbyCustomer);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cobSalesMan);
            this.Controls.Add(this.salesCount);
            this.Controls.Add(this.iswithBill);
            this.Controls.Add(this.txtCustomer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cobMonth);
            this.Controls.Add(this.cobCustomer);
            this.Controls.Add(this.cobYear);
            this.Controls.Add(this.SalesList);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label36);
            this.MaximizeBox = true;
            this.Name = "SalesListForm";
            this.Text = "売上一覧表";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Resize += new System.EventHandler(this.SalesListForm_Resize);
            this.Controls.SetChildIndex(this.label36, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.SalesList, 0);
            this.Controls.SetChildIndex(this.btnClose, 0);
            this.Controls.SetChildIndex(this.cobYear, 0);
            this.Controls.SetChildIndex(this.cobCustomer, 0);
            this.Controls.SetChildIndex(this.cobMonth, 0);
            this.Controls.SetChildIndex(this.label3, 0);
            this.Controls.SetChildIndex(this.txtCustomer, 0);
            this.Controls.SetChildIndex(this.iswithBill, 0);
            this.Controls.SetChildIndex(this.salesCount, 0);
            this.Controls.SetChildIndex(this.cobSalesMan, 0);
            this.Controls.SetChildIndex(this.label4, 0);
            this.Controls.SetChildIndex(this.isGroupbyCustomer, 0);
            this.Controls.SetChildIndex(this.cobSalesGroup1, 0);
            this.Controls.SetChildIndex(this.btnExport, 0);
            ((System.ComponentModel.ISupportInitialize)(this.SalesList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView SalesList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox cobCustomer;
        private System.Windows.Forms.ComboBox cobYear;
        private System.Windows.Forms.ComboBox cobMonth;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCustomer;
        private System.Windows.Forms.CheckBox iswithBill;
        private System.Windows.Forms.Label salesCount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cobSalesMan;
        private System.Windows.Forms.CheckBox isGroupbyCustomer;
        private System.Windows.Forms.CheckBox cobSalesGroup1;
        private System.Windows.Forms.Button btnExport;
    }
}