﻿using System;
using System.Collections.Generic;

using System.Text;

namespace EB.DBAcess
{
    public class IF_Employee
    {
        /// <summary>
        /// 社員ID
        /// </summary>
        public int EmployeeID
        {
            set;
            get;
        }
        /// <summary>
        /// 社員名
        /// </summary>
        public string EmployeeName
        {
            set;
            get;
        }
        /// <summary>
        /// フリカナ
        /// </summary>
        public string JapaneseSpell
        {
            set;
            get;
        }
        /// <summary>
        /// 生年月日
        /// </summary>
        public string Birthday
        {
            set;
            get;
        }
        /// <summary>
        /// 経験年数
        /// </summary>
        public string Experience
        {
            set;
            get;
        }
        /// <summary>
        /// 学歴
        /// </summary>
        public string Degree
        {
            set;
            get;
        }
        /// <summary>
        /// 資格
        /// </summary>
        public string Certificate
        {
            set;
            get;
        }
        /// <summary>
        /// 技術
        /// </summary>
        public string Skill
        {
            set;
            get;
        }
        /// <summary>
        /// 言語
        /// </summary>
        public string Language
        {
            set;
            get;
        }
        /// <summary>
        /// 〒
        /// </summary>
        public string PostCode
        {
            set;
            get;
        }
        /// <summary>
        /// 住所１
        /// </summary>
        public string Address1
        {
            set;
            get;
        }
        /// <summary>
        /// 住所２
        /// </summary>
        public string Address2
        {
            set;
            get;
        }
        /// <summary>
        /// TEL
        /// </summary>
        public string Tel
        {
            set;
            get;
        }
        /// <summary>
        /// 勤務先
        /// </summary>
        public string Company
        {
            set;
            get;
        }
        /// <summary>
        /// 評価
        /// </summary>
        public string Remark
        {
            set;
            get;
        }
        /// <summary>
        /// 備考
        /// </summary>
        public string Note
        {
            set;
            get;
        }
        /// <summary>
        /// 社員区分
        /// </summary>
        public string EmployeeType
        {
            set;
            get;
        }


        /// <summary>
        /// 仕入先
        /// </summary>
        public string SiireID
        {
            set;
            get;
        }

        /// <summary>
        /// 仕入先担当
        /// </summary>
        public string SiireSales
        {
            set;
            get;
        }
        /// <summary>
        /// 仕入先単価
        /// </summary>
        public string SiirePrice
        {
            set;
            get;
        }
        /// <summary>
        /// 交通費
        /// </summary>
        public string carfare
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }

    }
}
