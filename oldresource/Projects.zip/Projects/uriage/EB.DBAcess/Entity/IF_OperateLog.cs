﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EB.DBAcess
{
    public class IF_OperateLog
    {
        /// <summary>
        /// 操作ID
        /// </summary>
        public Int32 OperateLogID
        {
            set;
            get;
        }
        /// <summary>
        /// テーブル名
        /// </summary>
        public string TableName
        {
            set;
            get;
        }
        /// <summary>
        /// ユーザID
        /// </summary>
        public string UserID
        {
            set;
            get;
        }
        /// <summary>
        /// 操作
        /// </summary>
        public string Operate
        {
            set;
            get;
        }
        /// <summary>
        /// 時間
        /// </summary>
        public string LogTime
        {
            set;
            get;
        }

    }
}
