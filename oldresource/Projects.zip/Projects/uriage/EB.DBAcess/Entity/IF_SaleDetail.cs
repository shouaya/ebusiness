﻿using System;
using System.Collections.Generic;

using System.Text;

namespace EB.DBAcess
{
    public class IF_SaleDetail
    {
        /// <summary>
        /// 売上ID
        /// </summary>
        public int SaleID
        {
            set;
            get;
        }
        /// <summary>
        /// 売上明細ID
        /// </summary>
        public string SaleDetailID
        {
            set;
            get;
        }
        /// <summary>
        /// 技術者ID
        /// </summary>
        public int EmployeeID
        {
            set;
            get;
        }
        /// <summary>
        /// 単位
        /// </summary>
        public string Unit
        {
            set;
            get;
        }
        /// <summary>
        /// 単価
        /// </summary>
        public decimal Price
        {
            set;
            get;
        }
        /// <summary>
        /// 作業時間
        /// </summary>
        public decimal WorkTime
        {
            set;
            get;
        }
        /// <summary>
        /// 率
        /// </summary>
        public decimal Rate
        {
            set;
            get;
        }
        /// <summary>
        /// Min勤務
        /// </summary>
        public decimal MinHour
        {
            set;
            get;
        }
        /// <summary>
        /// Max勤務
        /// </summary>
        public decimal MaxHour
        {
            set;
            get;
        }
        /// <summary>
        /// 減賃金
        /// </summary>
        public decimal MinusUnitPrice
        {
            set;
            get;
        }
        /// <summary>
        /// 増賃金
        /// </summary>
        public decimal PlusUnitPrice
        {
            set;
            get;
        }
        /// <summary>
        /// 金額
        /// </summary>
        public decimal Amount
        {
            set;
            get;
        }
        /// <summary>
        /// その他
        /// </summary>
        public decimal OtherAmount
        {
            set;
            get;
        }
        /// <summary>
        /// 交通費
        /// </summary>
        public decimal purchase_carfare
        {
            set;
            get;
        }
        /// <summary>
        /// 通勤区間
        /// </summary>
        public string purchase_commuting
        {
            set;
            get;
        }
        /// <summary>
        /// 仕入単価
        /// </summary>
        public decimal purchase_price
        {
            set;
            get;
        }
        /// <summary>
        /// 備考
        /// </summary>
        public string purchase_note
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }

    }
}
