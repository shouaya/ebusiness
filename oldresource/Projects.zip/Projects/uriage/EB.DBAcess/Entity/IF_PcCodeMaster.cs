﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EB.DBAcess
{
    public class IF_PcCodeMaster
    {
        /// <summary>
        /// 端末コード
        /// </summary>
        public string PcCode
        {
            set;
            get;
        }
        /// <summary>
        /// 削除フラグ
        /// </summary>
        public string DeleteFlg
        {
            set;
            get;
        }
    }
}

