﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EB.DBAcess
{
    public class IF_BankInfo
    {
        /// <summary>
        /// 連番
        /// </summary>
        public int BankInfoId
        {
            set;
            get;
        }
        /// <summary>
        /// 会社ID
        /// </summary>
        public int CompanyID
        {
            set;
            get;
        }
        /// <summary>
        /// 銀行名
        /// </summary>
        public String BankName
        {
            set;
            get;
        }
        /// <summary>
        /// 銀行コード
        /// </summary>
        public String BankCode
        {
            set;
            get;
        }
        /// <summary>
        /// 支店名
        /// </summary>
        public String BankBranch
        {
            set;
            get;
        }
        /// <summary>
        /// 支店コード
        /// </summary>
        public String BankBranchCode
        {
            set;
            get;
        }
        /// <summary>
        /// 口座
        /// </summary>
        public String BankAccountCode
        {
            set;
            get;
        }
        /// <summary>
        /// 種別　　（普通・当座。。。。）
        /// </summary>
        public String BankAccountType
        {
            set;
            get;
        }
        /// <summary>
        /// 名義
        /// </summary>
        public String BankAccountHolderName
        {
            set;
            get;
        }
    }
}
