﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    /// <summary>
    /// DAO
    /// </summary>
    public class DBAccess
    {
        public static string ConnectString = "Server=192.168.10.155;" +
                                     "DataBase=saletest;" +
                                     "User ID=spirka;" +
                                     "Password=spirka;" +
                                     "charset=utf8;" +
                                     "Allow Zero Datetime=true";

        /// <summary>
        /// SQL文を実行する
        /// </summary>
        public static int ExecuteSQL(string sqlText, List<MySqlParameter> dbParams, MySqlConnection cn, MySqlTransaction tx)
        {
            MySqlCommand cmd = new MySqlCommand();

            if (dbParams != null)
            {
                foreach (MySqlParameter param in dbParams)
                {
                    cmd.Parameters.Add(param);
                }
            }

            cmd.Connection = cn;
            cmd.Transaction = tx;
            cmd.CommandText = sqlText;
            int result = cmd.ExecuteNonQuery();
            //成功したら、操作を記録する
            WriteLog(sqlText, dbParams, cn);

            return result;
        }
        /// <summary>
        /// SQL文を実行する
        /// </summary>
        public static long ExecuteSQLReturnID(string sqlText, List<MySqlParameter> dbParams, MySqlConnection cn, MySqlTransaction tx)
        {
            MySqlCommand cmd = new MySqlCommand();

            if (dbParams != null)
            {
                foreach (MySqlParameter param in dbParams)
                {
                    cmd.Parameters.Add(param);
                }
            }
            cmd.Connection = cn;
            cmd.Transaction = tx;
            cmd.CommandText = sqlText;
            cmd.ExecuteNonQuery();
            long id = cmd.LastInsertedId;
            //成功したら、操作を記録する
            WriteLog(sqlText, dbParams, cn);

            return id;
        }

        /// <summary>
        /// Selectを実行する
        /// </summary>
        /// <param name="selectText">SQL文</param>
        /// <param name="srcTable">取得したデータを格納する用テーブル名</param>
        /// <returns></returns>
        public static DataTable Select(string selectText, MySqlConnection cn)
        {

            DataSet ds = new DataSet();
            MySqlDataAdapter sda = new MySqlDataAdapter(selectText, cn);
            sda.Fill(ds);
            //成功したら、操作を記録する
            WriteLog(selectText, null, cn);

            return ds.Tables[0];
        }
        /// <summary>  
        /// Selectを実行する SQLインジェクション処理
        /// </summary>  
        /// <param name="SQLString">SQL文</param>  
        /// <returns>DataTable</returns>  
        public static DataTable ExecuteDataTable(string SQLString, List<MySqlParameter> dbParams, MySqlConnection cn)
        {
            MySqlCommand cmd = new MySqlCommand();    
            cmd.Connection = cn; 
            cmd.CommandText = SQLString;  
            cmd.CommandType = CommandType.Text;//cmdType;  

            if (dbParams != null)
            {
                foreach (MySqlParameter param in dbParams)
                {

                    if ((param.Direction == ParameterDirection.InputOutput || param.Direction == ParameterDirection.Input) &&
                    (param.Value == null))
                    {
                        param.Value = DBNull.Value;
                    }
                    cmd.Parameters.Add(param);
                }
            }
            using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
            {
                DataSet ds = new DataSet();
                try
                {
                    da.Fill(ds, "ds");
                    cmd.Parameters.Clear();
                    //成功したら、操作を記録する
                    WriteLog(SQLString, dbParams, cn);
                }
                catch (MySqlException ex)
                {
                    throw new Exception(ex.Message);
                }
                return ds.Tables[0];
            }
        }
        /// <summary>
        /// 操作を記録する
        /// </summary>
        /// <param name="SQLString"></param>
        /// <param name="cn"></param>
        private static void WriteLog(string SQLString, List<MySqlParameter> dbParams, MySqlConnection cn)
        {
            MySqlCommand cmd = new MySqlCommand();
            cmd = BL_OperateLog.GetInstance().GetOperateLogCommand(SQLString, dbParams);
            if (cmd != null)
            {
                cmd.Connection = cn;
                cmd.ExecuteNonQuery();
            }
        }


    }
}