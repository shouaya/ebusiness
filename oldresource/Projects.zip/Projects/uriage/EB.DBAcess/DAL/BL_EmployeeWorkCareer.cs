﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;

namespace EB.DBAcess.DAL
{
    public class BL_EmployeeWorkCareer
    {
        private static BL_EmployeeWorkCareer bl = new BL_EmployeeWorkCareer();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_EmployeeWorkCareer GetInstance()
        {
            return bl;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="yyMM"></param>
        /// <returns></returns>
        public DataTable SelectYears()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append(" DISTINCT LEFT(ContractDate,4) AS Years");//契約年
                sb.Append(" FROM (SELECT StartDate AS ContractDate FROM T_Contract ");
                sb.Append(" UNION ");
                sb.Append(" SELECT EndDate AS ContractDate FROM T_Contract) AS A ");
                sb.Append(" ORDER BY Years");

                return DBAccess.ExecuteDataTable(sb.ToString(), null, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }


        public DataTable SelectEmployeeWorkCareer(string strYear, string strEmployee)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append(" D.EmployeeName,");//社員名
                sb.Append(" C.CustomerName,");//顧客名
                sb.Append(" A.StartDate,");//開始日
                sb.Append(" A.EndDate,");//終了日
                sb.Append(" B.Unit,");//単位
                sb.Append(" B.Quantity,");//数量
                sb.Append(" B.EmployeeID,");//社員ID
                sb.Append(" A.CustomerID");//顧客ID
                sb.Append(" FROM T_Contract A ");
                sb.Append(" INNER JOIN T_ContractDetail B ON A.ContractID=B.ContractID ");
                sb.Append(" LEFT JOIN T_Customer C ON A.CustomerID=C.CustomerID ");
                sb.Append(" LEFT JOIN T_Employee D ON B.EmployeeID=D.EmployeeID ");

                if (strYear.Trim().Length != 0 && strEmployee.Trim().Length != 0) // 検索条件が年と社員名の場合
                {
                    sb.Append(" WHERE SUBSTRING(A.StartDate,1,4) >= '" + strYear + "'"); // 開始日が≧検索の年
                    sb.Append("     AND SUBSTRING(A.EndDate,1,4) <= '" + strYear + "'"); // 終了日が≦検索の年
                    sb.Append("     AND  D.EmployeeName like '%" + strEmployee + "%'");  // 社員名があいまい検索
                }
                else if (strYear.Trim().Length != 0 && strEmployee.Trim().Length == 0)
                {
                    sb.Append(" WHERE SUBSTRING(A.StartDate,1,4) >= '" + strYear + "'"); // 開始日が≧検索の年
                    sb.Append("     AND SUBSTRING(A.EndDate,1,4) <= '" + strYear + "'"); // 終了日が≦検索の年
                }

                sb.Append(" ORDER BY B.EmployeeID, A.CustomerID");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
     
}
