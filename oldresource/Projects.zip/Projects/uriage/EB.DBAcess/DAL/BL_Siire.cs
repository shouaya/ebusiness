﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_Siire
    {
        private static BL_Siire bl = new BL_Siire();

        private BL_Siire() { }

        public static BL_Siire GetInstance()
        {
            return bl;
        }

        /// <summary>
        /// Select
        /// </summary>
        /// <returns></returns>
        public DataTable SelectAllSiire()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT");
                sb.Append("     siireID");
                sb.Append("     , siireName");
                sb.Append("     , siireSales");
                sb.Append("     , PostCode");
                sb.Append("     , Address1");
                sb.Append("     , Address2");
                sb.Append("     , Tel");
                sb.Append("     , Fax");
                sb.Append("     , DeleteFlg");
                sb.Append(" FROM");
                sb.Append("     T_Siire");
                sb.Append(" WHERE");
                sb.Append("     DeleteFlg = '0'");
                sb.Append(" ORDER BY");
                sb.Append("     siireID");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 仕入先名称重複チェック
        /// </summary>
        /// <returns></returns>
        public bool SelectExsitsEmployee(string name)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("siireName");
                sb.Append(" FROM T_Siire ");
                sb.Append(" WHERE DeleteFlg = '0' AND siireName='" + name + "' ");

                DataTable dt = DBAccess.Select(sb.ToString(), cn);

                if (dt.Rows.Count > 0) return true;

                return false;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int InsertSiire(IF_Siire entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                sb.Append("INSERT INTO ");
                sb.Append("T_Siire  ");
                sb.Append("( ");
                sb.Append("siireName,");//仕入先名
                sb.Append("siireSales,");//仕入先担当
                sb.Append("PostCode	,");//郵便番号
                sb.Append("Address1,");//住所１
                sb.Append("Address2,");//住所２
                sb.Append("Tel,");//電話
                sb.Append("Fax,");//FAX

                sb.Append("DeleteFlg ");//削除フラグ
                sb.Append(") ");

                sb.Append("VALUES ");

                sb.Append("( ");
                sb.Append("@siireName,");//仕入先名
                sb.Append("@siireSales,");//仕入先担当
                sb.Append("@PostCode,");//郵便番号
                sb.Append("@Address1,");//住所１
                sb.Append("@Address2,");//住所２
                sb.Append("@Tel,");//電話
                sb.Append("@Fax,");//FAX

                sb.Append("@DeleteFlg ");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@siireName", MySqlDbType.VarChar);//仕入先名
                para.Value = entity.SiireName;//仕入先名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@siireSales", MySqlDbType.VarChar);//仕入先担当
                para.Value = entity.SiireSales;//仕入先担当
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PostCode", MySqlDbType.VarChar);//郵便番号
                para.Value = entity.PostCode;//郵便番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address1", MySqlDbType.VarChar);//住所１
                para.Value = entity.Address1;//住所１
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address2", MySqlDbType.VarChar);//住所２
                para.Value = entity.Address2;//住所２
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Tel", MySqlDbType.VarChar);//電話
                para.Value = entity.Tel;//電話
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Fax", MySqlDbType.VarChar);//FAX
                para.Value = entity.Fax;//FAX
                dbParams.Add(para);//追加

                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加


                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
