﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_BankInfo
    {
        private static BL_BankInfo bl = new BL_BankInfo();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_BankInfo GetInstance()
        {
            return bl;
        }
        /// <summary>
        /// 銀行情報を取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectAll()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("BankInfoId,");//連番
                sb.Append("CompanyID,");//会社ID
                sb.Append("BankName,");//銀行名
                sb.Append("BankCode,");//銀行コード
                sb.Append("BankBranch,");//支店名
                sb.Append("BankBranchCode,");//支店コード
                sb.Append("BankAccountCode,");//口座
                sb.Append("BankAccountType,");//種別
                sb.Append("BankAccountHolderName");//名義
                sb.Append(" FROM T_BankInfo ");
                sb.Append(" ORDER BY BankInfoId");

                return DBAccess.ExecuteDataTable(sb.ToString(), null, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
