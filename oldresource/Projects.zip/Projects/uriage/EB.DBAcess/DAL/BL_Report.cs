﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_Report
    {
        private static BL_Report bl = new BL_Report();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_Report GetInstance()
        {
            return bl;
        }
        /// <summary>
        /// 売上一覧
        /// </summary>
        /// <returns></returns>
        public DataTable SelectAll(Boolean isGroupbyCustomer, Boolean iswithBill, String month, int CustomerID,List<string> salesIDList)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(
                    @"
                        SELECT 
                        tct.`CustomerName` AS 顧客様
                        , tct.Undertaker AS 窓口
                        , tc.ContractName AS 契約件名
                        , ts.`SaleDate`     AS 売上日
                        , CASE IFNULL(TMB.`EndDate`,0) WHEN 0 THEN tc.`EndDate` ELSE TMB.`EndDate` END AS 契約終了日
                        , te.`EmployeeName` AS 社員
                        , tec.`CustomerName` AS 仕入先
                        , tec.`Undertaker` AS 仕入担当
                        , tes1.`EmployeeName` AS 営業１
                        , tes2.`EmployeeName` AS 営業２

                        , tcd.Amount AS 契約金額
                        ,tsd.Amount AS 売上
                        ,CASE IFNULL(tsd.purchase_price,0) WHEN 0 THEN te.siirePrice ELSE tsd.purchase_price END AS 仕入原価
                        ,te.siireSales AS 仕入担当
                        ,CASE IFNULL(tsd.purchase_carfare,0) WHEN 0 THEN te.carfare ELSE tsd.purchase_carfare END AS 交通費
                        ,tsd.purchase_commuting AS 通勤区間
                        ,tsd.purchase_note AS 備考
                        ,tsd.Unit AS 率
                        ,tsd.Amount-te.siirePrice*tsd.Unit AS 粗利
                        ,Round((tsd.Amount-te.siirePrice*tsd.Unit)*100/tsd.Amount,2) AS 粗利率（％）
                        -- add by liuyuqi start
                        ,te.EmployeeID AS 社員ID
                        -- add by liuyuqi end

                        ,tsd.SaleDetailID
                        , ts.`SaleID`


                        -- , tb. * 
                        FROM  `T_SaleDetail` AS tsd
                        LEFT JOIN T_Sale AS ts ON ts.`SaleID` = tsd.`SaleID` 
                        LEFT JOIN T_Contract AS tc ON tc.`ContractID` = ts.`ContractID`
                        LEFT JOIN T_ContractDetail AS tcd ON tcd.`ContractID` = ts.`ContractID` AND tcd.`EmployeeID` = tsd.`EmployeeID`
                        LEFT JOIN T_Bill AS tb ON tb.`BillNo` = ts.`BillNo` 
                        LEFT JOIN T_Employee AS te ON te.`EmployeeID` = tsd.`EmployeeID`
                        LEFT JOIN T_Customer AS tec ON tec.`CustomerID` = te.`siireID`
                        LEFT JOIN T_Employee AS tes1 ON tes1.`EmployeeID` = ts.`Salesman1`
                        LEFT JOIN T_Employee AS tes2 ON tes2.`EmployeeID` = ts.`Salesman2`
                        LEFT JOIN T_Customer AS tct ON tct.`CustomerID` = ts.`CustomerID` 
                        LEFT JOIN (
	                        SELECT * FROM (
                                SELECT `EndDate`,`CustomerID`,`EmployeeID`
                                FROM  T_ManagementBook ORDER BY `EndDate` DESC
	                        ) MB GROUP BY MB.`EmployeeID`,MB.`CustomerID`
                        ) AS TMB ON TMB.`EmployeeID` = tsd.`EmployeeID` AND TMB.`CustomerID` = ts.`CustomerID` 

                        WHERE tc.`ContractID` IS NOT NULL 
                        AND tc.DeleteFlg='0'
                        -- delete by liuyuqi start
                        -- AND tb.DeleteFlg='0'
                        -- delete by liuyuqi end
                        AND ts.DeleteFlg='0'
                    "
                );
                if (iswithBill)
                {
                    sb.Append(" AND tb.`BillNo` IS NOT NULL ");
                    //add by liuyuqi start
                    sb.Append(" AND tb.DeleteFlg='0' ");
                    //add by liuyuqi end
                }

                List<MySqlParameter> myparam = new List<MySqlParameter>();
                MySqlParameter param = null;

                if (!string.IsNullOrEmpty(month))
                {
                    sb.Append(" AND ts.`SaleDate` LIKE @SaleDate ");
                    param = new MySqlParameter("@SaleDate", MySqlDbType.VarChar, 50);
                    param.Value = month + "%";
                    myparam.Add(param);
                }
                if (CustomerID > 0)
                {
                    sb.Append(" AND ts.`CustomerID` = @CustomerID ");
                    param = new MySqlParameter("@CustomerID", MySqlDbType.VarChar, 50);
                    param.Value = CustomerID;
                    myparam.Add(param);
                }
                if (salesIDList != null && salesIDList.Count>0)
                {
                    sb.Append(" AND (FIND_IN_SET(ts.`Salesman1`, @salesManID) != 0  OR FIND_IN_SET(ts.`Salesman2`, @salesManID) != 0  )");
                    String salesuserids = string.Join(",", salesIDList.ToArray());

                    param = new MySqlParameter("@salesManID", MySqlDbType.VarChar, 50);
                    param.Value = salesuserids;
                    myparam.Add(param);
                }
                sb.Append(" ORDER BY tct.`CustomerID`,te.`EmployeeID`");

                if (isGroupbyCustomer)
                {
                    StringBuilder sbtemp = new StringBuilder();
                    sbtemp.Append(@"
                        SELECT 顧客様
                        ,SUM(契約金額) AS 契約金額SUM
                        ,SUM(売上) AS 売上SUM
                        ,SUM(仕入原価) AS 仕入原価SUM
                        ,COUNT(社員) AS 社員数

                         FROM (
                    ");
                    sbtemp.Append(sb.ToString());
                    sbtemp.Append(@"
                            ) AS temp
                        GROUP BY 顧客様
                    ");
                    sb = sbtemp;
                }

                return DBAccess.ExecuteDataTable(sb.ToString(), myparam, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        // 画面の年選択プルダウンの内容を取得
        public DataTable SelectYears()
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append(" DISTINCT LEFT(SaleDate,4) AS Years"); //契約年
                sb.Append(" FROM T_Sale ");

                sb.Append(" ORDER BY Years");

                return DBAccess.ExecuteDataTable(sb.ToString(), null, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public DataTable SelectCustomerName(string CustomerName)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append(" DISTINCT C.CustomerName"); //顧客名
                sb.Append(" ,C.CustomerID"); //顧客ID
                sb.Append(" FROM T_Sale AS TS");
                sb.Append(" LEFT JOIN T_Customer AS C ON C.CustomerID = TS.CustomerID");

                List<MySqlParameter> myparam = new List<MySqlParameter>();
                MySqlParameter param = null;

                if (!string.IsNullOrEmpty(CustomerName))
                {
                    sb.Append(" WHERE C.CustomerName LIKE @CustomerName ");
                    param = new MySqlParameter("@CustomerName", MySqlDbType.VarChar, 50);
                    param.Value = "%" + CustomerName + "%";
                    myparam.Add(param);
                }

                sb.Append(" ORDER BY C.CustomerName");

                return DBAccess.ExecuteDataTable(sb.ToString(), myparam, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
