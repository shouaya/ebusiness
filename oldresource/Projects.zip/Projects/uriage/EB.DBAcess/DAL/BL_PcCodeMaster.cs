﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_PcCodeMaster
    {
        private static BL_PcCodeMaster bl = new BL_PcCodeMaster();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_PcCodeMaster GetInstance()
        {
            return bl;
        }

        /// <summary>
        /// 端末コード
        /// </summary>
        /// <returns></returns>
        public Boolean IsHavePcCodeMaster(string machineCode)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append(" 1 ");

                sb.Append(" FROM T_PcCodeMaster ");
                sb.Append(" WHERE PcCode = '" + machineCode + "'");
                sb.Append(" AND DeleteFlg = '0'");

                DataTable dt = DBAccess.Select(sb.ToString(), cn);

                return dt.Rows.Count != 0;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
