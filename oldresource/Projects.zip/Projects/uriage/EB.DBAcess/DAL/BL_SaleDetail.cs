﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_SaleDetail
    {
        private static BL_SaleDetail bl = new BL_SaleDetail();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_SaleDetail GetInstance()
        {
            return bl;
        }
        /// <summary>
        /// 売上情報の取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectSaleDetail(string SaleID)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("A.SaleID,");//売上ID
                sb.Append("A.SaleDetailID,");//売上明細ID
                sb.Append("A.EmployeeID,");//技術者ID
                sb.Append("B.EmployeeName,");//技術者
                sb.Append("A.Unit,");//単位
                sb.Append("C.CodeName UnitName,");//単位
                sb.Append("A.Price,");//単価
                sb.Append("A.WorkTime,");//作業時間
                sb.Append("A.Rate,");//率
                sb.Append("A.MinHour,");//Min勤務
                sb.Append("A.MaxHour,");//Max勤務
                sb.Append("A.MinusUnitPrice,");//減賃金
                sb.Append("A.PlusUnitPrice,");//増賃金
                sb.Append("A.Amount,");//金額
                sb.Append("A.OtherAmount,");//その他
                sb.Append("A.DeleteFlg ");//削除フラグ

                sb.Append(" FROM T_SaleDetail A ");
                sb.Append(" LEFT JOIN T_Employee   B ON A.EmployeeID = B.EmployeeID  AND  B.DeleteFlg = '0'");
                sb.Append(" LEFT JOIN T_CodeMaster C ON A.Unit = C.CodeId AND  C.DeleteFlg = '0' AND C.CodeType = 'CD008' ");
                sb.Append(" WHERE A.DeleteFlg = '0' AND A.SaleID = @SaleID");
                sb.Append(" ORDER BY A.SaleID,A.SaleDetailID ");


                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;
                para = new MySqlParameter("@SaleID", MySqlDbType.Int32);//売上ID
                para.Value = SaleID;
                dbParams.Add(para);

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 売上詳細
        /// </summary>
        /// <returns></returns>
        public DataRow SelectSaleDetailByID(Boolean iswithBill,int saleID, string saleDetailID)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(
                    @"
                        SELECT 
                        tct.`CustomerName` AS 顧客様
                        , tct.Undertaker AS 窓口
                        , tc.ContractName AS 契約件名
                        , ts.`SaleDate`     AS 売上日
                        , te.`EmployeeName` AS 社員
                        , tes1.`EmployeeName` AS 営業１
                        , tes2.`EmployeeName` AS 営業２

                        , tcd.Amount AS 契約金額
                        ,tsd.Amount AS 売上
                        ,CASE tsd.purchase_price WHEN 0 THEN te.siirePrice ELSE tsd.purchase_price END AS 仕入原価
                        ,te.siireSales AS 仕入担当
                        ,tsd.purchase_carfare AS 交通費
                        ,tsd.purchase_commuting AS 通勤区間
                        ,tsd.purchase_note AS 備考
                        ,tsd.Unit AS 率
                        ,tsd.Amount-te.siirePrice*tsd.Unit AS 粗利
                        ,Round((tsd.Amount-te.siirePrice*tsd.Unit)*100/tsd.Amount,2) AS 粗利率（％）
                        -- add by liuyuqi start
                        ,te.EmployeeID AS 社員ID
                        -- add by liuyuqi end

                        ,tsd.SaleDetailID
                        , ts.`SaleID`


                        -- , tb. * 
                        FROM  `T_SaleDetail` AS tsd
                        LEFT JOIN T_Sale AS ts ON ts.`SaleID` = tsd.`SaleID` 
                        LEFT JOIN T_Contract AS tc ON tc.`ContractID` = ts.`ContractID`
                        LEFT JOIN T_ContractDetail AS tcd ON tcd.`ContractID` = ts.`ContractID` AND tcd.`EmployeeID` = tsd.`EmployeeID`
                        LEFT JOIN T_Bill AS tb ON tb.`BillNo` = ts.`BillNo` 
                        LEFT JOIN T_Employee AS te ON te.`EmployeeID` = tsd.`EmployeeID`
                        LEFT JOIN T_Employee AS tes1 ON tes1.`EmployeeID` = ts.`Salesman1`
                        LEFT JOIN T_Employee AS tes2 ON tes2.`EmployeeID` = ts.`Salesman2`
                        LEFT JOIN T_Customer AS tct ON tct.`CustomerID` = ts.`CustomerID` 
                        WHERE tc.`ContractID` IS NOT NULL 
                        AND tc.DeleteFlg='0'
                        AND ts.DeleteFlg='0'
                    "
                );
                if (iswithBill)
                {
                    sb.Append(" AND tb.`BillNo` IS NOT NULL ");
                    sb.Append(" AND tb.DeleteFlg='0' ");
                }

                List<MySqlParameter> myparam = new List<MySqlParameter>();
                MySqlParameter param = null;
                
                if(saleID>0){
                    sb.Append(" AND tsd.`SaleID` = @SaleID");
                    param = new MySqlParameter("@SaleID", MySqlDbType.Int32);//売上ID
                    param.Value = saleID;
                    myparam.Add(param);
                }
                if (!string.IsNullOrEmpty(saleDetailID))
                {
                    sb.Append(" AND tsd.`SaleDetailID` = @SaleDetailID");
                    param = new MySqlParameter("@SaleDetailID", MySqlDbType.VarChar);//売上詳細ID
                    param.Value = saleDetailID;
                    myparam.Add(param);
                }

                sb.Append(" ORDER BY tct.`CustomerID`,te.`EmployeeID`");

                DataTable dt = DBAccess.ExecuteDataTable(sb.ToString(), myparam, cn);
                return dt.Rows.Count>0?dt.Rows[0]:null;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int InsertSaleDetail(IF_SaleDetail entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                sb.Append("REPLACE INTO ");
                sb.Append("T_SaleDetail  ");
                sb.Append("( ");
                sb.Append("SaleID,");//売上ID
                sb.Append("SaleDetailID,");//売上明細ID
                sb.Append("EmployeeID,");//技術者ID
                sb.Append("Unit,");//単位
                sb.Append("Price,");//単価
                sb.Append("WorkTime,");//作業時間
                sb.Append("Rate,");//率
                sb.Append("MinHour,");//Min勤務
                sb.Append("MaxHour,");//Max勤務
                sb.Append("MinusUnitPrice,");//減賃金
                sb.Append("PlusUnitPrice,");//増賃金
                sb.Append("Amount,");//金額
                sb.Append("OtherAmount,");//その他
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(") ");
                sb.Append("VALUES ");
                sb.Append("( ");
                sb.Append("@SaleID,");//売上ID
                sb.Append("@SaleDetailID,");//売上明細ID
                sb.Append("@EmployeeID,");//技術者ID
                sb.Append("@Unit,");//単位
                sb.Append("@Price,");//単価
                sb.Append("@WorkTime,");//作業時間
                sb.Append("@Rate,");//率
                sb.Append("@MinHour,");//Min勤務
                sb.Append("@MaxHour,");//Max勤務
                sb.Append("@MinusUnitPrice,");//減賃金
                sb.Append("@PlusUnitPrice,");//増賃金
                sb.Append("@Amount,");//金額
                sb.Append("@OtherAmount,");//その他
                sb.Append("@DeleteFlg");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@SaleID", MySqlDbType.Int32);//売上ID
                para.Value = entity.SaleID;//売上ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@SaleDetailID", MySqlDbType.VarChar);//売上明細ID
                para.Value = entity.SaleDetailID;//売上明細ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//技術者ID
                para.Value = entity.EmployeeID;//技術者ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Unit", MySqlDbType.VarChar);//単位
                para.Value = entity.Unit;//単位
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Price", MySqlDbType.Decimal);//単価
                para.Value = entity.Price;//単価
                dbParams.Add(para);//追加
                para = new MySqlParameter("@WorkTime", MySqlDbType.Decimal);//作業時間
                para.Value = entity.WorkTime;//作業時間
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Rate", MySqlDbType.Decimal);//率
                para.Value = entity.Rate;//率
                dbParams.Add(para);//追加
                para = new MySqlParameter("@MinHour", MySqlDbType.Decimal);//Min勤務
                para.Value = entity.MinHour;//Min勤務
                dbParams.Add(para);//追加
                para = new MySqlParameter("@MaxHour", MySqlDbType.Decimal);//Max勤務
                para.Value = entity.MaxHour;//Max勤務
                dbParams.Add(para);//追加
                para = new MySqlParameter("@MinusUnitPrice", MySqlDbType.Decimal);//減賃金
                para.Value = entity.MinusUnitPrice;//減賃金
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PlusUnitPrice", MySqlDbType.Decimal);//増賃金
                para.Value = entity.PlusUnitPrice;//増賃金
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Amount", MySqlDbType.Decimal);//金額
                para.Value = entity.Amount;//金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@OtherAmount", MySqlDbType.Decimal);//その他
                para.Value = entity.OtherAmount;//その他
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.Decimal);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);
                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }


        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateSaleDetailForPurchase(IF_SaleDetail entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = new MySqlConnection(DBAccess.ConnectString);
            cn.Open();
            MySqlTransaction tx = cn.BeginTransaction();

            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                sb.Append("UPDATE ");
                sb.Append("T_SaleDetail  ");
                sb.Append("SET ");
                sb.Append("purchase_price = @purchase_price,");//仕入原価


                sb.Append("purchase_carfare = @purchase_carfare,");//交通費
                sb.Append("purchase_commuting = @purchase_commuting,");//通勤区間
                sb.Append("purchase_note = @purchase_note ");//備考

                sb.Append(" WHERE SaleID = @SaleID and SaleDetailID = @SaleDetailID");//売上ID


                para = new MySqlParameter("@SaleID", MySqlDbType.Int32);//売上ID
                para.Value = entity.SaleID;//売上ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@SaleDetailID", MySqlDbType.VarChar);//売上明細ID
                para.Value = entity.SaleDetailID;//売上明細ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@purchase_price", MySqlDbType.Decimal);//仕入原価
                para.Value = entity.purchase_price;//仕入原価
                dbParams.Add(para);//追加
                para = new MySqlParameter("@purchase_carfare", MySqlDbType.Decimal);//交通費
                para.Value = entity.purchase_carfare;//交通費
                dbParams.Add(para);//追加
                para = new MySqlParameter("@purchase_commuting", MySqlDbType.VarChar);//通勤区間
                para.Value = entity.purchase_commuting;//通勤区間
                dbParams.Add(para);//追加
                para = new MySqlParameter("@purchase_note", MySqlDbType.VarChar);//備考
                para.Value = entity.purchase_note;//備考
                dbParams.Add(para);//追加
                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();
                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }

        }
    }
}
