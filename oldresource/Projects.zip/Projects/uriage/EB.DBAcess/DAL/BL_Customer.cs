﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using Microsoft.VisualBasic;

namespace EB.DBAcess
{
    public class BL_Customer
    {
        private static BL_Customer bl = new BL_Customer();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_Customer GetInstance()
        {
            return bl;
        }

        /// <summary>
        /// 全Customer取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectAllCustomer(string keyword)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("CustomerID,");//顧客ID
                sb.Append("CustomerName,");//顧客名
                sb.Append("JapaneseSpell,");//フリカナ
                sb.Append("Representor,");//代表者名
                sb.Append("FoundDate,");//設立年月日
                sb.Append("Capital,");//資本金
                sb.Append("EmployeeCount,");//従業員数
                sb.Append("SaleAmount,");//売上高
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address1,");//住所１
                sb.Append("Address2,");//住所２
                sb.Append("Tel,");//電話番号
                sb.Append("Fax,");//ファックス
                sb.Append("Undertaker,");//担当者
                sb.Append("UndertakerMail,");//担当MAIL
                sb.Append("Remark,");//評価
                sb.Append("Note,");//備考
                sb.Append("PaymentType,");//支払方法
                sb.Append("PaymentDay,");//支払日
                sb.Append("DataOrder,");//並び順
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(" FROM T_Customer");
                sb.Append(" WHERE DeleteFlg = '0'");

                if (!string.IsNullOrEmpty(keyword))
                {
                    sb.Append(" AND (                            ");
                    sb.Append("  CustomerName     LIKE @keyword  ");
                    sb.Append(" OR JapaneseSpell  LIKE @keyword  ");
                    sb.Append(" OR Representor    LIKE @keyword  ");
                    sb.Append(" OR Undertaker     LIKE @keyword  ");
                    sb.Append(" OR UndertakerMail LIKE @keyword  ");
                    sb.Append(" OR Note           LIKE @keyword  ");

                    sb.Append(" OR CustomerName   LIKE @wkeyword ");
                    sb.Append(" OR JapaneseSpell  LIKE @wkeyword ");
                    sb.Append(" OR Representor    LIKE @wkeyword ");
                    sb.Append(" OR Undertaker     LIKE @wkeyword ");
                    sb.Append(" OR UndertakerMail LIKE @wkeyword ");
                    sb.Append(" OR Note           LIKE @wkeyword ");
                    sb.Append(" )                                ");

                    para = new MySqlParameter("@keyword", MySqlDbType.VarChar);
                    para.Value = "%" + Common.CommonHandler.StrConv(keyword, false) + "%";
                    dbParams.Add(para);
                    para = new MySqlParameter("@wkeyword", MySqlDbType.VarChar);
                    para.Value = "%" + Common.CommonHandler.StrConv(keyword, true) + "%";
                    dbParams.Add(para);
                }
                sb.Append(" ORDER BY CustomerID");

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 顧客様情報を取得
        /// </summary>
        /// <returns></returns>
        public DataRow SelectCustomerByID(Int32 customerID)
        {
            if (customerID < 1) { return null; }
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);
                para.Value = customerID;
                dbParams.Add(para);

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("CustomerID,");//顧客ID
                sb.Append("CustomerName,");//顧客名
                sb.Append("JapaneseSpell,");//フリカナ
                sb.Append("Representor,");//代表者名
                sb.Append("FoundDate,");//設立年月日
                sb.Append("Capital,");//資本金
                sb.Append("EmployeeCount,");//従業員数
                sb.Append("SaleAmount,");//売上高
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address1,");//住所１
                sb.Append("Address2,");//住所２
                sb.Append("Tel,");//電話番号
                sb.Append("Fax,");//ファックス
                sb.Append("Undertaker,");//担当者
                sb.Append("UndertakerMail,");//担当MAIL
                sb.Append("Remark,");//評価
                sb.Append("Note,");//備考
                sb.Append("PaymentType,");//支払方法
                sb.Append("PaymentDay,");//支払日
                sb.Append("DataOrder,");//並び順
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(" FROM T_Customer");
                sb.Append(" WHERE DeleteFlg = '0'");
                sb.Append(" AND CustomerID = @CustomerID ");

                DataTable dt = DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);

                return (dt.Rows.Count > 0) ? dt.Rows[0] : null;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 全Customer取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectCustomer(IF_Customer entity, bool isHaveContract, string selectedDate)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;


                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT * FROM ( ");
                sb.Append(" SELECT * FROM ( ");
                sb.Append(" SELECT ");
                sb.Append("T_Customer.CustomerID,");//顧客ID
                sb.Append("T_Customer.CustomerName,");//顧客名
                sb.Append("T_Customer.JapaneseSpell,");//フリカナ
                sb.Append("T_Customer.Representor,");//代表者名
                sb.Append("T_Customer.FoundDate,");//設立年月日
                sb.Append("T_Customer.Capital,");//資本金
                sb.Append("T_Customer.EmployeeCount,");//従業員数
                sb.Append("T_Customer.SaleAmount,");//売上高
                sb.Append("T_Customer.PostCode,");//郵便番号
                sb.Append("T_Customer.Address1,");//住所１
                sb.Append("T_Customer.Address2,");//住所２
                sb.Append("T_Customer.Tel,");//電話番号
                sb.Append("T_Customer.Fax,");//ファックス
                sb.Append("T_Customer.Undertaker,");//担当者
                sb.Append("T_Customer.UndertakerMail,");//担当MAIL
                sb.Append("T_Customer.Remark,");//評価
                sb.Append("T_Customer.Note,");//備考
                sb.Append("T_Customer.PaymentType,");//支払方法
                sb.Append("T_Customer.PaymentDay,");//支払日
                sb.Append("T_Customer.DataOrder,");//並び順
                sb.Append("T_Customer.DeleteFlg,");//削除フラグ
                sb.Append("T_Contract.StartDate,");//契約開始日
                sb.Append("T_Contract.EndDate");//契約終了日
                sb.Append(" FROM T_Customer");
                sb.Append(" LEFT JOIN T_Contract USING(CustomerID) ");

                sb.Append(" WHERE T_Customer.DeleteFlg = '0'");
                sb.Append(" AND( CustomerName LIKE @CustomerName OR CustomerName LIKE @WideCustomerName )");


                sb.Append(" ORDER BY T_Contract.EndDate DESC ,T_Customer.CustomerID");
                sb.Append(" ) AS TEMP ");


                sb.Append(" GROUP BY TEMP.CustomerID ) AS TEMP1");//


                if (!isHaveContract)
                {
                    //sb.Append(" AND T_Contract.DeleteFlg = '0'");
                    sb.Append(" WHERE TEMP1.StartDate > @T_C_StartDate");
                    sb.Append(" OR TEMP1.EndDate < @T_C_EndDate");

                    DateTime inputdate = DateTime.Parse(selectedDate);
                    DateTime inputdate_month_start = DateTime.Parse(inputdate.ToString("yyyy/MM"));
                    DateTime inputdate_month_end = inputdate_month_start.AddMonths(1).AddDays(-1);

                    para = new MySqlParameter("@T_C_StartDate", MySqlDbType.VarChar);
                    para.Value = inputdate_month_end.ToString("yyyy/MM/dd");
                    dbParams.Add(para);
                    para = new MySqlParameter("@T_C_EndDate", MySqlDbType.VarChar);
                    para.Value = inputdate_month_start.ToString("yyyy/MM/dd");
                    dbParams.Add(para);
                }

                para = new MySqlParameter("@CustomerName", MySqlDbType.VarChar);
                para.Value = "%" + Common.CommonHandler.StrConv(entity.CustomerName, false) + "%";//半角
                dbParams.Add(para);

                para = new MySqlParameter("@WideCustomerName", MySqlDbType.VarChar);
                para.Value = "%" + Common.CommonHandler.StrConv(entity.CustomerName, true) + "%";//全角
                dbParams.Add(para);

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 全Customer取得(売上画面)
        /// </summary>
        /// <returns></returns>
        public DataTable SelectCustomerByMonth(string yymm)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("CustomerID,");//顧客ID
                sb.Append("CustomerName,");//顧客名
                sb.Append("JapaneseSpell,");//フリカナ
                sb.Append("Representor,");//代表者名
                sb.Append("FoundDate,");//設立年月日
                sb.Append("Capital,");//資本金
                sb.Append("EmployeeCount,");//従業員数
                sb.Append("SaleAmount,");//売上高
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address1,");//住所１
                sb.Append("Address2,");//住所２
                sb.Append("Tel,");//電話番号
                sb.Append("Fax,");//ファックス'
                sb.Append("Undertaker,");//担当者
                sb.Append("UndertakerMail,");//担当MAIL
                sb.Append("Remark,");//評価
                sb.Append("Note,");//備考
                sb.Append("PaymentType,");//支払方法
                sb.Append("PaymentDay,");//支払日
                sb.Append("DataOrder,");//並び順
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(" FROM T_Customer");
                sb.Append(" WHERE DeleteFlg = '0'");
                sb.Append(" AND  EXISTS (SELECT ContractID FROM T_Contract WHERE T_Contract.CustomerID = T_Customer.CustomerID AND StartDate <='" + yymm + "/31' AND EndDate >= '" + yymm + "/01')");
                sb.Append(" ORDER BY CustomerID");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 全Customer取得(売上画面)
        /// </summary>
        /// <returns></returns>
        public DataTable SelectCustomerByMonth(string yymm, string CustomerName)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("CustomerID,");//顧客ID
                sb.Append("CustomerName,");//顧客名
                sb.Append("JapaneseSpell,");//フリカナ
                sb.Append("Representor,");//代表者名
                sb.Append("FoundDate,");//設立年月日
                sb.Append("Capital,");//資本金
                sb.Append("EmployeeCount,");//従業員数
                sb.Append("SaleAmount,");//売上高
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address1,");//住所１
                sb.Append("Address2,");//住所２
                sb.Append("Tel,");//電話番号
                sb.Append("Fax,");//ファックス'
                sb.Append("Undertaker,");//担当者
                sb.Append("UndertakerMail,");//担当MAIL
                sb.Append("Remark,");//評価
                sb.Append("Note,");//備考
                sb.Append("PaymentType,");//支払方法
                sb.Append("PaymentDay,");//支払日
                sb.Append("DataOrder,");//並び順
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(" FROM T_Customer");
                sb.Append(" WHERE DeleteFlg = '0'");
                sb.Append(" AND  EXISTS (SELECT ContractID FROM T_Contract WHERE T_Contract.CustomerID = T_Customer.CustomerID AND StartDate <='" + yymm + "/31' AND EndDate >= '" + yymm + "/01')");
                sb.Append(" AND( CustomerName LIKE @CustomerName OR CustomerName LIKE @WideCustomerName )");
                sb.Append(" ORDER BY CustomerID");

                para = new MySqlParameter("@CustomerName", MySqlDbType.VarChar);
                para.Value = "%" + Common.CommonHandler.StrConv(CustomerName, false) + "%";//半角
                dbParams.Add(para);

                para = new MySqlParameter("@WideCustomerName", MySqlDbType.VarChar);
                para.Value = "%" + Common.CommonHandler.StrConv(CustomerName, true) + "%";//全角
                dbParams.Add(para);

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 全Customer取得(入金画面)
        /// </summary>
        /// <returns></returns>
        public DataTable SelectCustomerByMonthOnBill(string yymm,bool isEdit)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("T_Customer.CustomerID,");//顧客ID
                sb.Append("T_Customer.CustomerName,");//顧客名
                sb.Append("T_Customer.JapaneseSpell,");//フリカナ
                sb.Append("T_Customer.Representor,");//代表者名
                sb.Append("T_Customer.FoundDate,");//設立年月日
                sb.Append("T_Customer.Capital,");//資本金
                sb.Append("T_Customer.EmployeeCount,");//従業員数
                sb.Append("T_Customer.SaleAmount,");//売上高
                sb.Append("T_Customer.PostCode,");//郵便番号
                sb.Append("T_Customer.Address1,");//住所１
                sb.Append("T_Customer.Address2,");//住所２
                sb.Append("T_Customer.Tel,");//電話番号
                sb.Append("T_Customer.Fax,");//ファックス'
                sb.Append("T_Customer.Undertaker,");//担当者
                sb.Append("T_Customer.UndertakerMail,");//担当MAIL
                sb.Append("T_Customer.Remark,");//評価
                sb.Append("T_Customer.Note,");//備考
                sb.Append("T_Customer.PaymentType,");//支払方法
                sb.Append("T_Customer.PaymentDay,");//支払日
                sb.Append("T_Customer.DataOrder,");//並び順
                sb.Append("T_Customer.DeleteFlg");//削除フラグ
                sb.Append(" FROM T_Customer");
                sb.Append(" LEFT JOIN T_Bill USING(CustomerID) ");
                sb.Append(" WHERE T_Customer.DeleteFlg = '0'");

                sb.Append("  AND BillNo IS NOT NULL AND BillDate <='" + yymm + "/31' AND BillDate >= '" + yymm + "/01' ");

                if (isEdit)
                {
                    sb.Append(" AND ReceiptID IS NOT NULL AND ReceiptID > 0");
                }
                else
                {
                    sb.Append(" AND ReceiptID IS NULL OR ReceiptID = 0");
                }

                sb.Append(" ORDER BY CustomerID");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int InsertCustomer(IF_Customer entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                sb.Append("INSERT INTO ");
                sb.Append("T_Customer  ");
                sb.Append("( ");
                sb.Append("CustomerName,");//顧客名
                sb.Append("JapaneseSpell,");//フリカナ
                sb.Append("Representor,");//代表者名
                sb.Append("FoundDate,");//設立年月日
                sb.Append("Capital,");//資本金
                sb.Append("EmployeeCount,");//従業員数
                sb.Append("SaleAmount,");//売上高
                sb.Append("PostCode,");//郵便番号
                sb.Append("Address1,");//住所１
                sb.Append("Address2,");//住所２
                sb.Append("Tel,");//電話番号
                sb.Append("Fax,");//ファックス
                sb.Append("Undertaker,");//担当者
                sb.Append("UndertakerMail,");//担当MAIL
                sb.Append("Remark,");//評価
                sb.Append("Note,");//備考
                sb.Append("PaymentType,");//支払方法
                sb.Append("PaymentDay,");//支払日
                sb.Append("DataOrder,");//並び順
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(") ");

                sb.Append("VALUES ");

                sb.Append("( ");
                sb.Append("@CustomerName,");//顧客名
                sb.Append("@JapaneseSpell,");//フリカナ
                sb.Append("@Representor,");//代表者名
                sb.Append("@FoundDate,");//設立年月日
                sb.Append("@Capital,");//資本金
                sb.Append("@EmployeeCount,");//従業員数
                sb.Append("@SaleAmount,");//売上高
                sb.Append("@PostCode,");//郵便番号
                sb.Append("@Address1,");//住所１
                sb.Append("@Address2,");//住所２
                sb.Append("@Tel,");//電話番号
                sb.Append("@Fax,");//ファックス
                sb.Append("@Undertaker,");//担当者
                sb.Append("@UndertakerMail,");//担当MAIL
                sb.Append("@Remark,");//評価
                sb.Append("@Note,");//備考
                sb.Append("@PaymentType,");//支払方法
                sb.Append("@PaymentDay,");//支払日
                sb.Append("@DataOrder,");//並び順
                sb.Append("@DeleteFlg");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                //para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                //para.Value = entity.CustomerID;//顧客ID
                //dbParams.Add(para);//追加
                para = new MySqlParameter("@CustomerName", MySqlDbType.VarChar);//顧客名
                para.Value = entity.CustomerName;//顧客名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@JapaneseSpell", MySqlDbType.VarChar);//フリカナ
                para.Value = entity.JapaneseSpell;//フリカナ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Representor", MySqlDbType.VarChar);//代表者名
                para.Value = entity.Representor;//代表者名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@FoundDate", MySqlDbType.VarChar);//設立年月日
                para.Value = entity.FoundDate;//設立年月日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Capital", MySqlDbType.VarChar);//資本金
                para.Value = entity.Capital;//資本金
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployeeCount", MySqlDbType.VarChar);//従業員数
                para.Value = entity.EmployeeCount;//従業員数
                dbParams.Add(para);//追加
                para = new MySqlParameter("@SaleAmount", MySqlDbType.VarChar);//売上高
                para.Value = entity.SaleAmount;//売上高
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PostCode", MySqlDbType.VarChar);//郵便番号
                para.Value = entity.PostCode;//郵便番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address1", MySqlDbType.VarChar);//住所１
                para.Value = entity.Address1;//住所１
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address2", MySqlDbType.VarChar);//住所２
                para.Value = entity.Address2;//住所２
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Tel", MySqlDbType.VarChar);//電話番号
                para.Value = entity.Tel;//電話番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Fax", MySqlDbType.VarChar);//ファックス
                para.Value = entity.Fax;//ファックス
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Undertaker", MySqlDbType.VarChar);//担当者
                para.Value = entity.Undertaker;//担当者
                dbParams.Add(para);//追加
                para = new MySqlParameter("@UndertakerMail", MySqlDbType.VarChar);//担当MAIL
                para.Value = entity.UndertakerMail;//担当MAIL
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Remark", MySqlDbType.VarChar);//評価
                para.Value = entity.Remark;//評価
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Note", MySqlDbType.VarChar);//備考
                para.Value = entity.Note;//備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentType", MySqlDbType.VarChar);//支払方法
                para.Value = entity.PaymentType;//支払方法
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentDay", MySqlDbType.VarChar);//支払日
                para.Value = entity.PaymentDay;//支払日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DataOrder", MySqlDbType.VarChar);//並び順
                para.Value = entity.DataOrder;//並び順
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加


                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateCustomer(IF_Customer entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                sb.Append("UPDATE ");
                sb.Append("T_Customer  ");
                sb.Append("SET ");

                sb.Append("CustomerID = @CustomerID,");//顧客ID
                sb.Append("CustomerName = @CustomerName,");//顧客名
                sb.Append("JapaneseSpell = @JapaneseSpell,");//フリカナ
                sb.Append("Representor = @Representor,");//代表者名
                sb.Append("FoundDate = @FoundDate,");//設立年月日
                sb.Append("Capital = @Capital,");//資本金
                sb.Append("EmployeeCount = @EmployeeCount,");//従業員数
                sb.Append("SaleAmount = @SaleAmount,");//売上高
                sb.Append("PostCode = @PostCode,");//郵便番号
                sb.Append("Address1 = @Address1,");//住所１
                sb.Append("Address2 = @Address2,");//住所２
                sb.Append("Tel = @Tel,");//TEL
                sb.Append("Fax = @Fax,");//FAX
                sb.Append("Undertaker = @Undertaker,");//担当者
                sb.Append("UndertakerMail = @UndertakerMail,");//担当MAIL
                sb.Append("Remark = @Remark,");//評価
                sb.Append("Note = @Note,");//備考
                sb.Append("PaymentType = @PaymentType,");//支払方法
                sb.Append("PaymentDay = @PaymentDay,");//支払日
                sb.Append("DeleteFlg = @DeleteFlg ,");//削除フラグ

                if (entity.DeleteFlg == "1")
                {
                    sb.Append("DeleteTime = @DeleteTime ");//削除時間

                    para = new MySqlParameter("@DeleteTime", MySqlDbType.DateTime);//削除時間
                    para.Value = DateTime.Now;//削除時間
                    dbParams.Add(para);//追加
                }
                else
                {
                    sb.Append("UpdateTime = @UpdateTime ");//更新時間
                    para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                    para.Value = DateTime.Now;//更新時間
                    dbParams.Add(para);//追加
                }
                sb.Append("WHERE CustomerID = @CustomerID");


                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@CustomerName", MySqlDbType.VarChar);//顧客名
                para.Value = entity.CustomerName;//顧客名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@JapaneseSpell", MySqlDbType.VarChar);//フリカナ
                para.Value = entity.JapaneseSpell;//フリカナ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Representor", MySqlDbType.VarChar);//代表者名
                para.Value = entity.Representor;//代表者名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@FoundDate", MySqlDbType.VarChar);//設立年月日
                para.Value = entity.FoundDate;//設立年月日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Capital", MySqlDbType.VarChar);//資本金
                para.Value = entity.Capital;//資本金
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployeeCount", MySqlDbType.VarChar);//従業員数
                para.Value = entity.EmployeeCount;//従業員数
                dbParams.Add(para);//追加
                para = new MySqlParameter("@SaleAmount", MySqlDbType.VarChar);//売上高
                para.Value = entity.SaleAmount;//売上高
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PostCode", MySqlDbType.VarChar);//郵便番号
                para.Value = entity.PostCode;//郵便番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address1", MySqlDbType.VarChar);//住所１
                para.Value = entity.Address1;//住所１
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Address2", MySqlDbType.VarChar);//住所２
                para.Value = entity.Address2;//住所２
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Tel", MySqlDbType.VarChar);//電話番号
                para.Value = entity.Tel;//電話番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Fax", MySqlDbType.VarChar);//ファックス
                para.Value = entity.Fax;//ファックス
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Undertaker", MySqlDbType.VarChar);//担当者
                para.Value = entity.Undertaker;//担当者
                dbParams.Add(para);//追加
                para = new MySqlParameter("@UndertakerMail", MySqlDbType.VarChar);//担当MAIL
                para.Value = entity.UndertakerMail;//担当MAIL
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Remark", MySqlDbType.VarChar);//評価
                para.Value = entity.Remark;//評価
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Note", MySqlDbType.VarChar);//備考
                para.Value = entity.Note;//備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentType", MySqlDbType.VarChar);//支払方法
                para.Value = entity.PaymentType;//支払方法
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentDay", MySqlDbType.VarChar);//支払日
                para.Value = entity.PaymentDay;//支払日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加
                
                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }   
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int DeleteCustomer(IF_Customer entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                sb.Append("UPDATE ");
                sb.Append("T_Customer  ");
                sb.Append("SET ");
                sb.Append("DeleteFlg = @DeleteFlg, ");//削除フラグ
                sb.Append("DeleteTime = @DeleteTime ");//削除時間
                sb.Append("WHERE CustomerID = @CustomerID");


                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加

                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加

                para = new MySqlParameter("@DeleteTime", MySqlDbType.DateTime);//削除時間
                para.Value = DateTime.Now;//削除時間
                dbParams.Add(para);//追加


                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                tx.Commit();

                return row;
            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
    }
}
