﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;


namespace EB.DBAcess
{
    public class BL_Contract
    {
        private static BL_Contract bl = new BL_Contract();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_Contract GetInstance()
        {
            return bl;
        }

        /// <summary>
        /// 契約番号（最大）の取得
        /// </summary>
        /// <returns></returns>
        public string SelectMaxContractNo(string yyMM)
        {
            string CONTRACT_STR = "EB-契約-";
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("MAX(ContractNo) ");//契約番号

                sb.Append(" FROM T_Contract ");
                sb.Append(" WHERE ContractNo LIKE '" + CONTRACT_STR + yyMM + "%'");

                DataTable dt = DBAccess.Select(sb.ToString(), cn);

                if (dt.Rows.Count == 0) return CONTRACT_STR + yyMM + "001";

                string contractNo = Convert.ToString(dt.Rows[0][0]);

                if (string.IsNullOrEmpty(contractNo)) return CONTRACT_STR + yyMM + "001";

                int no = Convert.ToInt32(contractNo.Substring(contractNo.Length - 3));

                string strNo = "000" + (no + 1).ToString();
                strNo = strNo.Substring(strNo.Length - 3);

                return CONTRACT_STR + yyMM + strNo;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 契約情報の取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectContractByCustomer(string customerID)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("ContractID,");//契約ID
                sb.Append("ContractNo,");//契約番号
                sb.Append("ContractDate,");//契約日
                sb.Append("CustomerID,");//顧客ID
                sb.Append("OrderNo,");//注文書番号
                sb.Append("EmployType,");//方式
                sb.Append("OrderDate,");//注文日
                sb.Append("ContractName,");//契約件名
                sb.Append("Amount AS TotalAmount,");//契約金額
                sb.Append("Content,");//内容
                sb.Append("Note,");//備考
                sb.Append("StartDate,");//開始日
                sb.Append("EndDate,");//終了日
                sb.Append("Salesman1,");//営業担当１
                sb.Append("Salesman2,");//営業担当２
                sb.Append("PaymentType,");//支払方法
                sb.Append("PaymentDay,");//支払日
                sb.Append("FinishFlag,");//処理済フラグ
                sb.Append("DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Contract ");
                sb.Append(" WHERE DeleteFlg = '0' AND CustomerID='" + customerID + "'");
                sb.Append(" ORDER BY ContractID DESC ");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 契約情報の取得（新規画面）
        /// </summary>
        /// <returns></returns>
        public DataTable SelectContractByCustomerOnSale(string customerID, string yymm)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("A.ContractID,");//契約ID
                sb.Append("A.ContractNo,");//契約番号
                sb.Append("A.ContractDate,");//契約日
                sb.Append("A.CustomerID,");//顧客ID
                sb.Append("A.OrderNo,");//注文書番号
                sb.Append("A.EmployType,");//方式
                sb.Append("A.OrderDate,");//注文日
                sb.Append("A.ContractName,");//契約件名
                sb.Append("A.Amount AS TotalAmount,");//契約金額
                sb.Append("A.Content,");//内容
                sb.Append("A.Note,");//備考
                sb.Append("A.StartDate,");//開始日
                sb.Append("A.EndDate,");//終了日
                sb.Append("A.Salesman1,");//営業担当１
                sb.Append("A.Salesman2,");//営業担当２
                sb.Append("A.PaymentType,");//支払方法
                sb.Append("A.PaymentDay,");//支払日
                sb.Append("CASE B.DeleteFlg WHEN '0' THEN '1' ELSE '0' END AS FinishFlag,");//処理済フラグ
                sb.Append("A.DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Contract A");
                sb.Append(" LEFT JOIN  T_Sale B");
                sb.Append(" ON  A.ContractID = B.ContractID ");
                sb.Append(" AND A.CustomerID = B.CustomerID ");
                sb.Append(" AND B.StartDate <='" + yymm + "/31' AND B.EndDate >= '" + yymm + "/01'");
                sb.Append(" AND B.DeleteFlg = '0' ");
                sb.Append(" WHERE A.DeleteFlg = '0' AND A.CustomerID='" + customerID + "'");
                sb.Append(" AND A.StartDate <='" + yymm + "/31' AND A.EndDate >= '" + yymm + "/01'");
                sb.Append(" ORDER BY A.ContractID");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 契約情報の取得（修正画面）
        /// </summary>
        /// <returns></returns>
        public DataTable SelectContractByCustomerOnSaleM(string customerID, string yymm)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("B.ContractID,");//契約ID
                sb.Append("B.ContractNo,");//契約番号
                sb.Append("B.ContractDate,");//契約日
                sb.Append("B.CustomerID,");//顧客ID
                sb.Append("B.OrderNo,");//注文書番号
                sb.Append("B.EmployType,");//方式
                sb.Append("B.OrderDate,");//注文日
                sb.Append("B.ContractName,");//契約件
                sb.Append("A.SaleID,");//契約ID
                sb.Append("A.SaleNo,");//契約No
                sb.Append("A.SaleDate,");//契約Date
                sb.Append("A.SaleAmount AS TotalAmount,");//契約金額
                sb.Append("A.StartDate,");//開始日
                sb.Append("A.EndDate,");//終了日
                sb.Append("A.Content,");//内容
                sb.Append("A.Note,");//備考
                sb.Append("A.Salesman1,");//営業担当１
                sb.Append("A.Salesman2,");//営業担当２
                sb.Append("A.PaymentSite,");//支払Site
                sb.Append("A.BillFlag AS FinishFlag,");//処理済フラグ
                sb.Append("A.DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Sale A");
                sb.Append(" INNER JOIN  T_Contract B");
                sb.Append(" ON  A.ContractID = B.ContractID ");
                sb.Append(" AND A.CustomerID = B.CustomerID ");
                sb.Append(" AND B.StartDate <='" + yymm + "/31' AND B.EndDate >= '" + yymm + "/01'");
                sb.Append(" AND B.DeleteFlg = '0' ");
                sb.Append(" WHERE A.DeleteFlg = '0' AND A.CustomerID='" + customerID + "'");
                sb.Append(" AND A.StartDate <='" + yymm + "/31' AND A.EndDate >= '" + yymm + "/01'");
                sb.Append(" ORDER BY A.SaleID DESC");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 契約情報の取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectContract(string contractID)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("ContractID,");//契約ID
                sb.Append("ContractNo,");//契約番号
                sb.Append("ContractDate,");//契約日
                sb.Append("CustomerID,");//顧客ID
                sb.Append("OrderNo,");//注文書番号
                sb.Append("EmployType,");//方式
                sb.Append("OrderDate,");//注文日
                sb.Append("ContractName,");//契約件名
                sb.Append("Amount,");//契約金額
                sb.Append("Content,");//内容
                sb.Append("Note,");//備考
                sb.Append("StartDate,");//開始日
                sb.Append("EndDate,");//終了日
                sb.Append("Salesman1,");//営業担当１
                sb.Append("Salesman2,");//営業担当２
                sb.Append("PaymentType,");//支払方法
                sb.Append("PaymentDay,");//支払日
                sb.Append("FinishFlag,");//処理済フラグ
                sb.Append("DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Contract ");
                sb.Append(" WHERE DeleteFlg = '0' AND ContractID = " + contractID);
                sb.Append(" ORDER BY ContractID");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 登録
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void RegisterAll(IF_Contract entity, List<IF_ContractDetail> list)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                long id = InsertContract(entity, cn, tx);

                BL_ContractDetail bl = BL_ContractDetail.GetInstance();
                foreach (IF_ContractDetail detail in list)
                {
                    detail.ContractID = Convert.ToInt32(id);
                    bl.InsertContractDetail(detail, cn, tx);
                }

                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void UpdateAll(IF_Contract entity, List<IF_ContractDetail> list)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                UpdateContract(entity, cn, tx);

                DeleteContractDetail(entity, cn, tx);

                BL_ContractDetail bl = BL_ContractDetail.GetInstance();
                foreach (IF_ContractDetail detail in list)
                {
                    detail.ContractID = entity.ContractID;
                    bl.InsertContractDetail(detail, cn, tx);
                }

                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void DeleteAll(IF_Contract entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                DeleteContractDetail(entity, cn, tx);
                DeleteContract(entity, cn, tx);


                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public long InsertContract(IF_Contract entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {

                sb.Append("INSERT INTO ");
                sb.Append("T_Contract  ");
                sb.Append("( ");
                sb.Append("ContractID,");//契約ID
                sb.Append("ContractNo,");//契約番号
                sb.Append("ContractDate,");//契約日
                sb.Append("CustomerID,");//顧客ID
                sb.Append("OrderNo,");//注文書番号
                sb.Append("EmployType,");//方式
                sb.Append("OrderDate,");//注文日
                sb.Append("ContractName,");//契約件名
                sb.Append("Amount,");//契約金額
                sb.Append("Content,");//内容
                sb.Append("Note,");//備考
                sb.Append("StartDate,");//開始日
                sb.Append("EndDate,");//終了日
                sb.Append("Salesman1,");//営業担当１
                sb.Append("Salesman2,");//営業担当２
                sb.Append("PaymentType,");//支払方法
                sb.Append("PaymentDay,");//支払日
                sb.Append("FinishFlag,");//処理済フラグ
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(") ");

                sb.Append("VALUES ");

                sb.Append("( ");
                sb.Append("@ContractID,");//契約ID
                sb.Append("@ContractNo,");//契約番号
                sb.Append("@ContractDate,");//契約日
                sb.Append("@CustomerID,");//顧客ID
                sb.Append("@OrderNo,");//注文書番号
                sb.Append("@EmployType,");//方式
                sb.Append("@OrderDate,");//注文日
                sb.Append("@ContractName,");//契約件名
                sb.Append("@Amount,");//契約金額
                sb.Append("@Content,");//内容
                sb.Append("@Note,");//備考
                sb.Append("@StartDate,");//開始日
                sb.Append("@EndDate,");//終了日
                sb.Append("@Salesman1,");//営業担当１
                sb.Append("@Salesman2,");//営業担当２
                sb.Append("@PaymentType,");//支払方法
                sb.Append("@PaymentDay,");//支払日
                sb.Append("@FinishFlag,");//処理済フラグ
                sb.Append("@DeleteFlg");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@ContractID", MySqlDbType.Int32);//契約ID
                para.Value = entity.ContractID;//契約ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractNo", MySqlDbType.VarChar);//契約番号
                para.Value = entity.ContractNo;//契約番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractDate", MySqlDbType.VarChar);//契約日
                para.Value = entity.ContractDate;//契約日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@OrderNo", MySqlDbType.VarChar);//注文書番号
                para.Value = entity.OrderNo;//注文書番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployType", MySqlDbType.VarChar);//方式
                para.Value = entity.EmployType;//方式
                dbParams.Add(para);//追加
                para = new MySqlParameter("@OrderDate", MySqlDbType.VarChar);//注文日
                para.Value = entity.OrderDate;//注文日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractName", MySqlDbType.VarChar);//契約件名
                para.Value = entity.ContractName;//契約件名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Amount", MySqlDbType.VarChar);//契約金額
                para.Value = entity.Amount;//契約金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Content", MySqlDbType.VarChar);//内容
                para.Value = entity.Content;//内容
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Note", MySqlDbType.VarChar);//備考
                para.Value = entity.Note;//備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@StartDate", MySqlDbType.VarChar);//開始日
                para.Value = entity.StartDate;//開始日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EndDate", MySqlDbType.VarChar);//終了日
                para.Value = entity.EndDate;//終了日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman1", MySqlDbType.Int32);//営業担当１
                para.Value = entity.Salesman1;//営業担当１
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman2", MySqlDbType.Int32);//営業担当２
                para.Value = entity.Salesman2;//営業担当２
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentType", MySqlDbType.VarChar);//支払方法
                para.Value = entity.PaymentType;//支払方法
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentDay", MySqlDbType.VarChar);//支払日
                para.Value = entity.PaymentDay;//支払日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@FinishFlag", MySqlDbType.VarChar);//処理済フラグ
                para.Value = entity.FinishFlag;//処理済フラグ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加


                long id = DBAccess.ExecuteSQLReturnID(sb.ToString(), dbParams, cn, tx);

                return id;
            }
            catch (Exception ex)
            {
                throw (ex);
            }

        }


        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateContract(IF_Contract entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {
                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                sb.Append("UPDATE ");
                sb.Append("T_Contract  ");
                sb.Append("SET ");
                sb.Append("ContractNo = @ContractNo,");//契約番号
                sb.Append("ContractDate = @ContractDate,");//契約日
                sb.Append("CustomerID = @CustomerID,");//顧客ID
                sb.Append("OrderNo = @OrderNo,");//注文書番号
                sb.Append("EmployType = @EmployType,");//方式
                sb.Append("OrderDate = @OrderDate,");//注文日
                sb.Append("ContractName = @ContractName,");//契約件名
                sb.Append("Amount = @Amount,");//契約金額
                sb.Append("Content = @Content,");//内容
                sb.Append("Note = @Note,");//備考
                sb.Append("StartDate = @StartDate,");//開始日
                sb.Append("EndDate = @EndDate,");//終了日
                sb.Append("Salesman1 = @Salesman1,");//営業担当１
                sb.Append("Salesman2 = @Salesman2,");//営業担当２
                sb.Append("PaymentType = @PaymentType,");//支払方法
                sb.Append("PaymentDay = @PaymentDay,");//支払日
                sb.Append("FinishFlag = @FinishFlag,");//処理済フラグ
                sb.Append("DeleteFlg = @DeleteFlg,");//削除フラグ

                if (entity.DeleteFlg == "1")
                {
                    sb.Append("DeleteTime = @DeleteTime ");//削除時間

                    para = new MySqlParameter("@DeleteTime", MySqlDbType.DateTime);//削除時間
                    para.Value = DateTime.Now;//削除時間
                    dbParams.Add(para);//追加
                }
                else
                {
                    sb.Append("UpdateTime = @UpdateTime ");//更新時間
                    para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                    para.Value = DateTime.Now;//更新時間
                    dbParams.Add(para);//追加
                }
                sb.Append(" WHERE ContractID = @ContractID");//会社ID


                para = new MySqlParameter("@ContractID", MySqlDbType.Int32);//契約ID
                para.Value = entity.ContractID;//契約ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractNo", MySqlDbType.VarChar);//契約番号
                para.Value = entity.ContractNo;//契約番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractDate", MySqlDbType.VarChar);//契約日
                para.Value = entity.ContractDate;//契約日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@OrderNo", MySqlDbType.VarChar);//注文書番号
                para.Value = entity.OrderNo;//注文書番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployType", MySqlDbType.VarChar);//方式
                para.Value = entity.EmployType;//方式
                dbParams.Add(para);//追加
                para = new MySqlParameter("@OrderDate", MySqlDbType.VarChar);//注文日
                para.Value = entity.OrderDate;//注文日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ContractName", MySqlDbType.VarChar);//契約件名
                para.Value = entity.ContractName;//契約件名
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Amount", MySqlDbType.VarChar);//契約金額
                para.Value = entity.Amount;//契約金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Content", MySqlDbType.VarChar);//内容
                para.Value = entity.Content;//内容
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Note", MySqlDbType.VarChar);//備考
                para.Value = entity.Note;//備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@StartDate", MySqlDbType.VarChar);//開始日
                para.Value = entity.StartDate;//開始日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EndDate", MySqlDbType.VarChar);//終了日
                para.Value = entity.EndDate;//終了日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman1", MySqlDbType.Int32);//営業担当１
                para.Value = entity.Salesman1;//営業担当１
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Salesman2", MySqlDbType.Int32);//営業担当２
                para.Value = entity.Salesman2;//営業担当２
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentType", MySqlDbType.VarChar);//支払方法
                para.Value = entity.PaymentType;//支払方法
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PaymentDay", MySqlDbType.VarChar);//支払日
                para.Value = entity.PaymentDay;//支払日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@FinishFlag", MySqlDbType.VarChar);//処理済フラグ
                para.Value = entity.FinishFlag;//処理済フラグ
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加



                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// 削除
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int DeleteContract(IF_Contract entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {
                sb.Append("UPDATE ");
                sb.Append("T_Contract  ");
                sb.Append("SET ");
                sb.Append("DeleteFlg = '1'");//削除フラグ
                sb.Append(" WHERE ContractID = @ContractID");//契約ID

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@ContractID", MySqlDbType.Int32);//契約ID
                para.Value = entity.ContractID;//契約ID
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int DeleteContractDetail(IF_Contract entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {

                sb.Append("UPDATE ");
                sb.Append("T_ContractDetail  ");
                sb.Append("SET ");
                sb.Append("DeleteFlg = '1'");//削除フラグ
                sb.Append(" WHERE ContractID = @ContractID");//契約ID

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@ContractID", MySqlDbType.Int32);//契約ID
                para.Value = entity.ContractID;//契約ID
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }

        }
    }
}
