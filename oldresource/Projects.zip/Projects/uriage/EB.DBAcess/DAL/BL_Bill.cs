﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_Bill
    {
        private static BL_Bill bl = new BL_Bill();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_Bill GetInstance()
        {
            return bl;
        }

        /// <summary>
        /// 請求番号（最大）の取得
        /// </summary>
        /// <returns></returns>
        public string SelectMaxBillNo(string yyMM)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {
                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("MAX(BillNo) ");//番号

                sb.Append(" FROM T_Bill ");
                sb.Append(" WHERE BillNo LIKE '" + yyMM + "%'");

                DataTable dt = DBAccess.Select(sb.ToString(), cn);

                if (dt.Rows.Count == 0) return yyMM + "001";

                string BillNo = Convert.ToString(dt.Rows[0][0]);

                if (string.IsNullOrEmpty(BillNo)) return yyMM + "001";

                int no = Convert.ToInt32(BillNo.Substring(BillNo.Length - 3));

                string strNo = "000" + (no + 1).ToString();
                strNo = strNo.Substring(strNo.Length - 3);

                return yyMM + strNo;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 請求書取得(入金画面)
        /// </summary>
        /// <returns></returns>
        public DataTable SelectBillForReceive(string customerID, string yymm)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("A.BillNo,");//請求書番号
                sb.Append("A.BankInfoId,");//振込み口座ID
                sb.Append("A.CustomerID,");//顧客ID
                sb.Append("A.BillAmountTotal,");//請求総金額
                sb.Append("A.BillDate,");//請求日
                sb.Append("A.ReceiptAmount,");//入金額
                sb.Append("A.ReceiptID,");//入金額
                sb.Append("B.ReceiptAmount AS ReceiptAmountTotal,");//入金総金額
                sb.Append("B.ReceiptDate");//入金日
                sb.Append(" FROM T_Bill A");
                sb.Append(" LEFT JOIN T_Receipt B");
                sb.Append(" ON A.ReceiptID=B.ReceiptID AND B.DeleteFlg = '0'");
                sb.Append(" WHERE A.DeleteFlg = '0'");
                sb.Append(" AND A.CustomerID = " + customerID );
                sb.Append(" AND A.BillDate Like '" + yymm + "%'");
                sb.Append(" ORDER BY A.BillNo");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 請求書取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectBill(string billNo)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("BillNo,");//請求書番号
                sb.Append("BankInfoId,");//振込み口座ID
                sb.Append("CustomerID,");//顧客ID
                sb.Append("BillAmountTotal,");//請求総金額
                sb.Append("BillDate,");//請求日
                sb.Append("DeductionItem,");//控除項目
                sb.Append("DeductionCost,");//控除額
                sb.Append("DeductionNotes,");//控除備考
                sb.Append("AdditionalItem,");//追加項目
                sb.Append("AdditionalCost,");//追加額
                sb.Append("AdditionalNotes,");//追加備考
                sb.Append("DeleteFlg ");//削除フラグ
                sb.Append(" FROM T_Bill ");
                sb.Append(" WHERE DeleteFlg = '0' AND BillNo = '" + billNo + "'");
                sb.Append(" ORDER BY BillNo");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 登録
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void RegisterAll(IF_Bill entity, string list)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                InsertBill(entity, cn, tx);

                string[] strList = list.Split(',');

                BL_Sale bl = BL_Sale.GetInstance();
                foreach (string str in strList)
                {
                    string saleID = str;

                    bl.UpdateSaleForBillStatus(saleID, entity.BillNo, cn, tx);
                }

                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public void UpdateAll(IF_Bill entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            MySqlTransaction tx = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();
                tx = cn.BeginTransaction();

                UpdateBill(entity, cn, tx);

                tx.Commit();

            }
            catch (Exception ex)
            {
                tx.Rollback();
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }

        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int InsertBill(IF_Bill entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {

                sb.Append("INSERT INTO ");
                sb.Append("T_Bill  ");
                sb.Append("( ");
                sb.Append("BillNo,");//請求書番号
                sb.Append("BankInfoId,");//振込み口座ID
                sb.Append("CustomerID,");//顧客ID
                sb.Append("BillAmountTotal,");//請求総金額
                sb.Append("BillDate,");//請求日
                sb.Append("DeductionItem,");//控除項目
                sb.Append("DeductionCost,");//控除額
                sb.Append("DeductionNotes,");//控除備考
                sb.Append("AdditionalItem,");//追加項目
                sb.Append("AdditionalCost,");//追加額
                sb.Append("AdditionalNotes,");//追加備考
                sb.Append("DeleteFlg");//削除フラグ
                sb.Append(") ");
                sb.Append("VALUES ");
                sb.Append("( ");
                sb.Append("@BillNo,");//請求書番号
                sb.Append("@BankInfoId,");//振込み口座ID
                sb.Append("@CustomerID,");//顧客ID
                sb.Append("@BillAmountTotal,");//請求総金額
                sb.Append("@BillDate,");//請求日
                sb.Append("@DeductionItem,");//控除項目
                sb.Append("@DeductionCost,");//控除額
                sb.Append("@DeductionNotes,");//控除備考
                sb.Append("@AdditionalItem,");//追加項目
                sb.Append("@AdditionalCost,");//追加額
                sb.Append("@AdditionalNotes,");//追加備考
                sb.Append("@DeleteFlg");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@BillNo", MySqlDbType.VarChar);//請求書番号
                para.Value = entity.BillNo;//請求書番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@BankInfoId", MySqlDbType.VarChar);//振込み口座ID
                para.Value = entity.BankInfoId;//振込み口座ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@BillAmountTotal", MySqlDbType.Decimal);//請求総金額
                para.Value = entity.BillAmountTotal;//請求総金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@BillDate", MySqlDbType.VarChar);//請求日
                para.Value = entity.BillDate;//請求日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeductionItem", MySqlDbType.VarChar);//控除項目
                para.Value = entity.DeductionItem;//控除項目
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeductionCost", MySqlDbType.Decimal);//控除額
                para.Value = entity.DeductionCost;//控除額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeductionNotes", MySqlDbType.VarChar);//控除備考
                para.Value = entity.DeductionNotes;//控除備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@AdditionalItem", MySqlDbType.VarChar);//追加項目
                para.Value = entity.AdditionalItem;//追加項目
                dbParams.Add(para);//追加
                para = new MySqlParameter("@AdditionalCost", MySqlDbType.Decimal);//追加額
                para.Value = entity.AdditionalCost;//追加額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@AdditionalNotes", MySqlDbType.VarChar);//追加備考
                para.Value = entity.AdditionalNotes;//追加備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }

        }

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateBill(IF_Bill entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {
                sb.Append("UPDATE ");
                sb.Append("T_Bill  ");
                sb.Append("SET ");
                sb.Append("CustomerID = @CustomerID,");//顧客ID
                sb.Append("BankInfoId = @BankInfoId,");//振込み口座ID
                sb.Append("BillAmountTotal = @BillAmountTotal,");//請求総金額
                sb.Append("BillDate = @BillDate,");//請求日
                sb.Append("DeductionItem = @DeductionItem,");//控除項目
                sb.Append("DeductionCost = @DeductionCost,");//控除額
                sb.Append("DeductionNotes = @DeductionNotes,");//控除備考
                sb.Append("AdditionalItem = @AdditionalItem,");//追加項目
                sb.Append("AdditionalCost = @AdditionalCost,");//追加額
                sb.Append("AdditionalNotes = @AdditionalNotes,");//追加備考
                sb.Append("UpdateTime = @UpdateTime ");//更新時間
                sb.Append(" WHERE BillNo = @BillNo");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@BillNo", MySqlDbType.VarChar);//請求書番号
                para.Value = entity.BillNo;//請求書番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@BankInfoId", MySqlDbType.VarChar);//振込み口座ID
                para.Value = entity.BankInfoId;//振込み口座ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@CustomerID", MySqlDbType.Int32);//顧客ID
                para.Value = entity.CustomerID;//顧客ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@BillAmountTotal", MySqlDbType.Decimal);//請求総金額
                para.Value = entity.BillAmountTotal;//請求総金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@BillDate", MySqlDbType.VarChar);//請求日
                para.Value = entity.BillDate;//請求日
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeductionItem", MySqlDbType.VarChar);//控除項目
                para.Value = entity.DeductionItem;//控除項目
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeductionCost", MySqlDbType.Decimal);//控除額
                para.Value = entity.DeductionCost;//控除額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeductionNotes", MySqlDbType.VarChar);//控除備考
                para.Value = entity.DeductionNotes;//控除備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@AdditionalItem", MySqlDbType.VarChar);//追加項目
                para.Value = entity.AdditionalItem;//追加項目
                dbParams.Add(para);//追加
                para = new MySqlParameter("@AdditionalCost", MySqlDbType.Decimal);//追加額
                para.Value = entity.AdditionalCost;//追加額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@AdditionalNotes", MySqlDbType.VarChar);//追加備考
                para.Value = entity.AdditionalNotes;//追加備考
                dbParams.Add(para);//追加
                para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                para.Value = DateTime.Now;//更新時間
                dbParams.Add(para);//追加

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int UpdateBillForReceive(IF_Bill entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {
                sb.Append("UPDATE ");
                sb.Append("T_Bill  ");
                sb.Append("SET ");
                sb.Append("ReceiptID = @ReceiptID,");//入金番号
                sb.Append("ReceiptAmount = @ReceiptAmount,");//入金額
                sb.Append("UpdateTime = @UpdateTime ");//更新時間
                sb.Append(" WHERE BillNo = @BillNo");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@BillNo", MySqlDbType.VarChar);//請求書番号
                para.Value = entity.BillNo;//請求書番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ReceiptID", MySqlDbType.Int32);//入金番号
                para.Value = entity.ReceiptID;//入金番号
                dbParams.Add(para);//追加
                para = new MySqlParameter("@ReceiptAmount", MySqlDbType.Decimal);//入金額
                para.Value = entity.ReceiptAmount;//入金額
                dbParams.Add(para);//追加    
                para = new MySqlParameter("@UpdateTime", MySqlDbType.DateTime);//更新時間
                para.Value = DateTime.Now;//更新時間
                dbParams.Add(para);//追加          

                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }
    }
}
