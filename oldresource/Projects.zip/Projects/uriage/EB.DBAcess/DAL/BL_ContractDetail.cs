﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace EB.DBAcess
{
    public class BL_ContractDetail
    {
        private static BL_ContractDetail bl = new BL_ContractDetail();//Instance初期化

        /// <summary>
        /// 初期化
        /// </summary>
        /// <returns></returns>
        public static BL_ContractDetail GetInstance()
        {
            return bl;
        }
        /// <summary>
        /// 契約明細情報の取得
        /// </summary>
        /// <returns></returns>
        public DataTable SelectContractDetail(string ContractID)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT ");
                sb.Append("ContractID,");//契約ID
                sb.Append("DetailID,");//契約明細ID
                sb.Append("T_ContractDetail.EmployeeID AS EmployeeID,");//技術者ID
                sb.Append("T_Employee.EmployeeName As EmployeeName ,");//技術者ID
                sb.Append("Unit,");//単位
                sb.Append("T_CodeMaster.CodeName AS UnitName,");//単位
                sb.Append("Price,");//単価
                sb.Append("Quantity,");//数量
                sb.Append("MinHour,");//Min勤務
                sb.Append("MaxHour,");//Max勤務
                sb.Append("MinusUnitPrice,");//減賃金
                sb.Append("PlusUnitPrice,");//増賃金
                sb.Append("Amount,");//金額
                sb.Append("T_ContractDetail.DeleteFlg");//削除フラグ
                sb.Append(" FROM T_ContractDetail ");
                sb.Append(" LEFT JOIN T_Employee ON T_Employee.EmployeeID = T_ContractDetail.EmployeeID ");
                sb.Append(" LEFT JOIN T_CodeMaster ON T_CodeMaster.CodeType = 'CD008' AND  T_CodeMaster.CodeId = T_ContractDetail.Unit");
                sb.Append(" WHERE T_ContractDetail.DeleteFlg = '0' AND ContractID = " + ContractID);
                sb.Append(" ORDER BY ContractID,DetailID");

                return DBAccess.Select(sb.ToString(), cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 技術者既に登録して契約情報があるのか
        /// </summary>
        /// <returns></returns>
        public DataTable CheckContractDetailByEmployeeID(IF_ContractDetail entity)
        {
            StringBuilder sb = new StringBuilder();
            MySqlConnection cn = null;
            try
            {

                string connectString = DBAccess.ConnectString;
                cn = new MySqlConnection(connectString);
                cn.Open();

                sb.Append(" SELECT T_Customer.CustomerName ,T_Contract.StartDate, T_Contract.EndDate");
                sb.Append(" FROM T_ContractDetail ");
                sb.Append(" LEFT JOIN T_Contract USING(ContractID) ");
                sb.Append(" LEFT JOIN T_Customer USING(CustomerID) ");
                sb.Append(" WHERE T_ContractDetail.DeleteFlg = '0' AND T_Contract.DeleteFlg = '0' ");
                sb.Append(" AND T_ContractDetail.EmployeeID = @EmployeeID");
                sb.Append(" AND T_ContractDetail.ContractID <> @ContractID");

                sb.Append(" AND (");

                sb.Append("( T_Contract.StartDate <= @StartDate AND T_Contract.EndDate > @StartDate )");
                sb.Append("OR");
                sb.Append("( T_Contract.StartDate < @EndDate AND T_Contract.EndDate >= @EndDate)");
                sb.Append("OR");
                sb.Append("( T_Contract.StartDate >= @EndDate AND T_Contract.EndDate <= @EndDate)");

                sb.Append(")");


                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@ContractID", MySqlDbType.Int32);
                para.Value = entity.ContractID;
                dbParams.Add(para);

                para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);
                para.Value = entity.EmployeeID;
                dbParams.Add(para);

                para = new MySqlParameter("@StartDate", MySqlDbType.VarChar);
                para.Value = entity.StartDate;
                dbParams.Add(para);

                para = new MySqlParameter("@EndDate", MySqlDbType.VarChar);
                para.Value = entity.EndDate;
                dbParams.Add(para);

                return DBAccess.ExecuteDataTable(sb.ToString(), dbParams, cn);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
            finally
            {
                cn.Close();
            }
        }
        /// <summary>
        /// 挿入
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public int InsertContractDetail(IF_ContractDetail entity, MySqlConnection cn, MySqlTransaction tx)
        {
            StringBuilder sb = new StringBuilder();

            try
            {

                sb.Append("REPLACE INTO ");
                sb.Append("T_ContractDetail  ");
                sb.Append("( ");
                sb.Append("ContractID,");//契約ID
                sb.Append("DetailID,");//契約明細ID
                sb.Append("EmployeeID,");//技術者ID
                sb.Append("Unit,");//単位
                sb.Append("Price,");//単価
                sb.Append("Quantity,");//数量
                sb.Append("MinHour,");//Min勤務
                sb.Append("MaxHour,");//Max勤務
                sb.Append("MinusUnitPrice,");//減賃金
                sb.Append("PlusUnitPrice,");//増賃金
                sb.Append("Amount,");//金額
                sb.Append("DeleteFlg ");//削除フラグ
                sb.Append(") ");

                sb.Append("VALUES ");

                sb.Append("( ");
                sb.Append("@ContractID,");//契約ID
                sb.Append("@DetailID,");//契約明細ID
                sb.Append("@EmployeeID,");//技術者ID
                sb.Append("@Unit,");//単位
                sb.Append("@Price,");//単価
                sb.Append("@Quantity,");//数量
                sb.Append("@MinHour,");//Min勤務
                sb.Append("@MaxHour,");//Max勤務
                sb.Append("@MinusUnitPrice,");//減賃金
                sb.Append("@PlusUnitPrice,");//増賃金
                sb.Append("@Amount,");//金額
                sb.Append("@DeleteFlg ");//削除フラグ
                sb.Append(") ");

                List<MySqlParameter> dbParams = new List<MySqlParameter>();
                MySqlParameter para = null;

                para = new MySqlParameter("@ContractID", MySqlDbType.Int32);//契約ID
                para.Value = entity.ContractID;//契約ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DetailID", MySqlDbType.VarChar);//契約明細ID
                para.Value = entity.DetailID;//契約明細ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@EmployeeID", MySqlDbType.Int32);//技術者ID
                para.Value = entity.EmployeeID;//技術者ID
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Unit", MySqlDbType.VarChar);//単位
                para.Value = entity.Unit;//単位
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Price", MySqlDbType.Decimal);//単価
                para.Value = entity.Price;//単価
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Quantity", MySqlDbType.Decimal);//数量
                para.Value = entity.Quantity;//数量
                dbParams.Add(para);//追加
                para = new MySqlParameter("@MinHour", MySqlDbType.Decimal);//Min勤務
                para.Value = entity.MinHour;//Min勤務
                dbParams.Add(para);//追加
                para = new MySqlParameter("@MaxHour", MySqlDbType.Decimal);//Max勤務
                para.Value = entity.MaxHour;//Max勤務
                dbParams.Add(para);//追加
                para = new MySqlParameter("@MinusUnitPrice", MySqlDbType.Decimal);//減賃金
                para.Value = entity.MinusUnitPrice;//減賃金
                dbParams.Add(para);//追加
                para = new MySqlParameter("@PlusUnitPrice", MySqlDbType.Decimal);//増賃金
                para.Value = entity.PlusUnitPrice;//増賃金
                dbParams.Add(para);//追加
                para = new MySqlParameter("@Amount", MySqlDbType.Decimal);//金額
                para.Value = entity.Amount;//金額
                dbParams.Add(para);//追加
                para = new MySqlParameter("@DeleteFlg", MySqlDbType.VarChar);//削除フラグ
                para.Value = entity.DeleteFlg;//削除フラグ
                dbParams.Add(para);//追加


                int row = DBAccess.ExecuteSQL(sb.ToString(), dbParams, cn, tx);

                return row;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

    }
}
