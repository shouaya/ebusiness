﻿using System;
using System.IO;
using System.Reflection;

namespace EB.Update
{
    static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {

            //System.Collections.Generic.List<string> s = new System.Collections.Generic.List<string>();
            //s.Add("EB.Common.dll");
            //s.Add("EB.DBAcess.dll");
            //Filehelper.FileEncrypt(s, "test2.ebspatch");
            string arguments = Arguments.Start;

            //arguments = Arguments.Check;
            //arguments = Arguments.Update;
            //arguments = Arguments.Setup;
            //arguments = Arguments.MakePatch;
            if (args.Length > 0)
            {
                arguments = args[0];
            }
            if (!updateself(arguments))//自体更新しない場合
            {
                if (arguments == Arguments.Update || File.Exists(arguments))
                {
                    withPath(Arguments.Update, arguments);
                }
                else
                {
                    withoutPath(arguments);
                }
            }
            


            //return;
            //MethodInfo method = typeof(Api).GetMethod(arguments, BindingFlags.Static);

            //object[] param = null;
            //if (method == null)
            //{
            //    method = typeof(Api).GetMethod(Arguments.Update, BindingFlags.Static);
            //    param = new object[] { arguments };
            //}
            //object result = method.Invoke(null, param);
        }
        /// <summary>
        /// 自体更新
        /// </summary>
        /// <returns></returns>
        static bool updateself(string arguments)
        {
            try
            {
                if (System.IO.File.Exists(Strings.updateExeTemp))
                {
                    //System.Windows.Forms.MessageBox.Show("del");
                    System.IO.File.Delete(Strings.updateExeTemp);
                }
                if (System.IO.File.Exists(Strings.updatePatch))
                {
                    //System.Windows.Forms.MessageBox.Show("move");
                    System.IO.File.Move(Strings.updateExe, Strings.updateExeTemp);
                    System.IO.File.Move(Strings.updatePatch, Strings.updateExe);
                   //System.Windows.Forms.MessageBox.Show("restart");
                    BaseHelper.processStart(arguments);

                    return true;
                }
            }
            catch //(Exception ex)
            {
                //CommonHandler.ProcessException(ex);
            }
            return false;
        }

        public delegate void DelegateApiWithPath(string s);
        public delegate void DelegateApi();

        static void withPath(string method,string path)
        {
            try
            {
                Type typeApi = typeof(Api);

                Type typeDelegate = typeof(DelegateApiWithPath);

                DelegateApiWithPath delegateMethod = (DelegateApiWithPath)Delegate.CreateDelegate(typeDelegate, typeApi, method);

                delegateMethod(path);
            }
            catch { }
        }
        static void withoutPath(string method)
        {
            try
            {
                Type typeApi = typeof(Api);

                Type typeDelegate = typeof(DelegateApi);

                DelegateApi delegateMethod = (DelegateApi)Delegate.CreateDelegate(typeDelegate, typeApi, method);

                delegateMethod();
            }
            catch { }
        }
    }

}
