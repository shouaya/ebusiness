﻿using System;
using System.Windows.Forms;

namespace EB.Update
{
    public partial class Api
    {
        private static Api self = null;

        public static Api getInstance()
        {
            if (self == null)
            {
                self = new Api();
            }
            return self;
        }
    }
}
