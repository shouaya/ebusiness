﻿using System;
using System.Windows.Forms;

namespace EB.Update
{
    public partial class Api
    {
        public static void start()
        {
            BaseHelper.processStart(Arguments.Check);
        }
    }
}
