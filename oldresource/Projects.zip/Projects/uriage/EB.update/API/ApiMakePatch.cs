﻿using System;
using System.Windows.Forms;

namespace EB.Update
{
    public partial class Api
    {
        public static void makePatch()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MakeParchForm());
        }
    }
}
