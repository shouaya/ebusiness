﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Collections.Generic;

namespace EB.Update
{
    public partial class MakeParchForm : Form
    {
        String defaultPath = Application.StartupPath + "\\patch";
        public MakeParchForm()
        {
            InitializeComponent();
            this.path_input.Text = this.path_output.Text = this.defaultPath;
        }
        /// <summary>
        /// input
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_input_Click(object sender, EventArgs e)
        {
            String path = openFolderBrowserDialog();
            if (!String.IsNullOrEmpty(path))
            {
                this.path_input.Text = this.path_output.Text = path;
                this.btn_output.Enabled = true;
            }
        }
        /// <summary>
        /// output
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_output_Click(object sender, EventArgs e)
        {
            String path = openFolderBrowserDialog();
            if (!String.IsNullOrEmpty(path))
            {
                this.path_output.Text = path;
            }
        }
        /// <summary>
        /// 出力
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void todo_Click(object sender, EventArgs e)
        {
            DirectoryInfo TheFolder = new DirectoryInfo(this.path_input.Text);
            //フォルダ
            //foreach (DirectoryInfo NextFolder in TheFolder.GetDirectories())
            //    this.listBox1.Items.Add(NextFolder.Name);
            //ファイル
            List<string> fileList = new List<string>();

            this.progressBar1.Maximum = TheFolder.GetFiles().Length;
            this.progressBar1.Visible=true;
            foreach (FileInfo NextFile in TheFolder.GetFiles())
            {
                fileList.Add(this.path_input.Text + "\\" + NextFile.Name);
                Filehelper.FileEncrypt(fileList, this.path_output.Text + "\\" + NextFile.Name + ".ebspatch");
                fileList.Clear();
                this.progressBar1.Value++;
                if (this.progressBar1.Value == this.progressBar1.Maximum)
                {
                    this.progressBar1.Value = 0;
                    this.progressBar1.Visible = false;
                    MessageBox.Show("完了");
                }
            }
            Filehelper.writeToXml(this.path_output.Text);
        }


        /// <summary>
        /// フォルダ選択
        /// </summary>
        /// <returns></returns>
        private string openFolderBrowserDialog()
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.SelectedPath = this.defaultPath;
            fbd.ShowDialog();
            return fbd.SelectedPath;
        }
    }
}
