﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using System.Windows.Forms;

namespace EB.Update
{
    class Filehelper
    {
        private static List<UpdatePatch> _xmlFiles = new List<UpdatePatch>();
        /// <summary>
        /// ファイル暗号化
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static bool FileEncrypt(List<string> fileList, string patchFilePath)
        {
            try
            {
                List<UpdatePatch> pFiles = new List<UpdatePatch>();
                //List<UpdatePatch> xmlFiles = new List<UpdatePatch>();
                fileList.ForEach(delegate(string file)
                {
                    byte[] bt = Filehelper.FileToByteArray(file);
                    UpdatePatch 
                        pFile = new UpdatePatch(), 
                        xmlpFile = new UpdatePatch();

                    xmlpFile.url = pFile.url = Path.GetFileName(patchFilePath);
                    xmlpFile.name = pFile.name = Path.GetFileName(file);
                    xmlpFile.updatetime = pFile.updatetime = File.GetLastWriteTime(file).ToString("G");

                    //xmlFiles.Add(xmlpFile);
                    _xmlFiles.Add(xmlpFile);
                    
                    ////////
                    pFile.bt = security.Encrypt(bt);
                    pFiles.Add(pFile);
                });
                ///////////////////////////////
                //System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(UpdateXml));
                //UpdateXml ei = new UpdateXml();
                //ei.patchs = xmlFiles;
                //FileStream _FileStream = new FileStream(patchFilePath+".xml", FileMode.Create, FileAccess.Write);

                //serializer.Serialize(_FileStream, ei);
                //////////////////////////////////
                if (File.Exists(patchFilePath))
                {
                    File.Delete(patchFilePath);
                }
                Filehelper.ByteArrayToFile(patchFilePath, Serialize(pFiles));
                return true;
            }
            catch(Exception e)
            {
                //error
                System.Windows.Forms.MessageBox.Show(e.Message);
            }
            return false;

        }
        public static void writeToXml(string outputPath)
        {
            System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(UpdateXml));
            UpdateXml ei = new UpdateXml();
            ei.patchs = _xmlFiles;
            FileStream _FileStream = new FileStream(outputPath+"\\patch.xml", FileMode.Create, FileAccess.Write);

            serializer.Serialize(_FileStream, ei);
        }
        /// <summary>
        /// ファイル復号化(file path)
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static bool FileDecrypt(string patchFilePath)
        {
            try
            {
                byte[] bt = Filehelper.FileToByteArray(patchFilePath);

                return FileDecrypt(bt);
            }
            catch
            {
                //error
            }
            return false;
        }
        /// <summary>
        /// ファイル復号化(byte[])
        /// </summary>
        /// <param name="bt"></param>
        /// <returns></returns>
        public static bool FileDecrypt(byte[] bt)
        {
            try
            {
                List<UpdatePatch> pfiles = (List<UpdatePatch>)Deserialize(bt);
                return FileDecrypt(pfiles);
            }
            catch
            {
                //error
            }
            return false;
        }
        /// <summary>
        /// ファイル復号化(List<PatchFile>)
        /// </summary>
        /// <param name="pfiles"></param>
        /// <returns></returns>
        public static bool FileDecrypt(List<UpdatePatch> pfiles)
        {
            try
            {
                if (pfiles.Count > 0)
                {
                    pfiles.ForEach(delegate(UpdatePatch pfile)
                    {
                        string filePath = Application.StartupPath + "\\" + pfile.name;
                        if (File.Exists(filePath))
                        {
                            File.Delete(filePath);
                        }
                        if (Filehelper.ByteArrayToFile(filePath, security.Decrypt(pfile.bt)))
                        {
                            UpdateHelper.getInstance().setCurrentUserSubkey(pfile.name,pfile.updatetime);
                        }
                    });
                    return true;
                }

            }
            catch
            {
                //error
            }
            finally
            {
            }
            return false;

        }
        /// <summary>
        /// byte to file
        /// </summary>
        /// <param name="_FileName"></param>
        /// <param name="_ByteArray"></param>
        /// <returns></returns>
        private static bool ByteArrayToFile(string _FileName, byte[] _ByteArray)
        {
            try
            {
                FileStream _FileStream =new FileStream(_FileName, FileMode.Create,FileAccess.Write);
                _FileStream.Write(_ByteArray, 0, _ByteArray.Length);
                _FileStream.Close();
                return true;
            }
            catch
            {
                // Error
            }
            return false;
        }
        /// <summary>
        /// file to byte
        /// </summary>
        /// <param name="_FileName"></param>
        /// <returns></returns>
        private static byte[] FileToByteArray(string _FileName)
        {
            if (File.Exists(_FileName))
            {
                return File.ReadAllBytes(_FileName);
            }
            return null;
        }

        /// <summary>
        /// 序列化
        /// </summary>
        /// <param name="obj">要被序列化的类</param>
        /// <returns>byte[]</returns>
        private static byte[] Serialize(object obj)
        {
            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream stream = new MemoryStream();
            bf.Serialize(stream, obj);
            byte[] datas = stream.ToArray();
            stream.Dispose();
            return datas;
        }
        /// <summary>
        /// 反序列化
        /// </summary>
        /// <param name="datas">byte[]数据</param>
        /// <param name="index">开始位置</param>
        /// <returns>object</returns>
        private static object Deserialize(byte[] datas)
        {
            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream stream = new MemoryStream(datas, 0, datas.Length);
            object obj = bf.Deserialize(stream);
            stream.Dispose();
            return obj;
        }

    }
}
