﻿using System;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Diagnostics;
using System.Net;
using System.IO;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Threading;

namespace EB.Update
{
    public class UpdateHelper
    {
        #region common
        private string _str_software_key = @"SOFTWARE\EBusiness\Sales Manager";
        private string _str_lastrun_key = "lastrun";
        private string _str_datetimeNow = null;
        private RegistryKey _obj_CurrentUser = null;
        private RegistryKey _obj_software_key = null;
        private string _str_updateurl_xml = "http://xxx.com/update.xml";
        private string _str_updateurl_path = "http://xxx.com/";


        private string _str_processesByName = "EB.Menu";
        private static UpdateHelper self = null;
        private static List<UpdatePatch> _remotePatch;

        private InvokeDelegate _invokeDelegate;

        public static UpdateHelper getInstance(){
            if (self == null)
            {
                self = new UpdateHelper();
                self._str_datetimeNow = DateTime.Now.ToString("G");
                self._obj_software_key = Registry.CurrentUser.OpenSubKey(self._str_software_key);
                self._obj_CurrentUser = Registry.CurrentUser;
            }
            return self;
        }

        /// <summary>
        /// 更新情報を取得-local
        /// </summary>
        /// <returns></returns>
        private List<UpdatePatch> getUpdatePatch()
        {
            List<UpdatePatch> remote = this.getRemoteUpdatePatch();
            if (this._obj_software_key == null) {
                return remote;
            }
            object obj = this._obj_software_key.GetValue(this._str_lastrun_key);
            if (obj == null)
            {
                return remote;
            }
            else
            {
                List<UpdatePatch> res = new List<UpdatePatch>();

                remote.ForEach(delegate(UpdatePatch patch)
                {
                    if (this.checkPatch(patch))
                    {
                        res.Add(patch);
                    }
                });
                return res;
            }
        }
        /// <summary>
        /// チェック　ファイルの更新時間
        /// </summary>
        /// <param name="patch"></param>
        /// <returns></returns>
        private bool checkPatch(UpdatePatch patch)
        {
            if (string.IsNullOrEmpty(patch.updatetime)) { return false; }
            object obj_patch = this._obj_software_key.GetValue(patch.name);

            String fileName = patch.name;
            if (fileName.Equals(Strings.updatePatch))
            {
                fileName = Strings.updateExe;
            }
            if (obj_patch == null || 
                DateTime.Parse(obj_patch.ToString()) < DateTime.Parse(patch.updatetime) ||
                !File.Exists(fileName)//
                )
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 更新情報を取得-Remote
        /// </summary>
        /// <returns></returns>
        private List<UpdatePatch> getRemoteUpdatePatch()
        {
            if (null == _remotePatch || _remotePatch.Count < 1)
            {
                try
                {
                    WebClient wc = new WebClient();
                    Stream stream = wc.OpenRead(this._str_updateurl_xml);

                    //stream.Position = 0;
                    System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(UpdateXml));
                    UpdateXml ei = (UpdateXml)serializer.Deserialize(stream);
                    stream.Close();
                    _remotePatch = ei.patchs;
                }
                catch// (Exception e)
                {
                    MessageBox.Show("エラーが発生しました。管理員に連絡してください。（ネットワーク）");
                    _remotePatch = new List<UpdatePatch>();
                }
            }
            return _remotePatch;
        }
        #endregion
        #region check for main form
        public bool checkUpdate()
        {
            int pc = this.getUpdatePatch().Count;
            return this._obj_software_key == null || pc > 0;
        }
        #endregion

        #region update setting

        /// <summary>
        /// 更新
        /// </summary>
        /// <param name="argument"></param>
        public void update(string path,InvokeDelegate invokeDelegate)
        {
            try
            {
                this._invokeDelegate = invokeDelegate;

                bool isgoon = true;
                foreach (Process proc in Process.GetProcessesByName(this._str_processesByName))
                {
                    if (MessageBox.Show("売上システムを閉じます、よろしいでしょうか？", "E-Business", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        proc.Kill();
                        isgoon = true;
                    }
                    else
                    {
                        MessageBox.Show("自動更新を取り消しました。");
                        isgoon = false;
                    }
                }
                if (isgoon)
                {
                    ThreadPoolHelper.todo(() =>
                    {
                        this.updatePatch(path);
                        //set check date
                        this.setCurrentUserSubkey(this._str_lastrun_key, this._str_datetimeNow);

                        this._invokeDelegate("売上システムを再起動します\n更新完了しました",1,1);
                        System.Threading.Thread.Sleep(3000);
                        BaseHelper.processStart(this._str_processesByName + ".exe", null);
                        Application.Exit();
                    });
                }
                else
                {
                    ThreadPoolHelper.todo(() =>
                    {
                        Application.Exit();
                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        /// <summary>
        /// update regedit 
        /// </summary>
        /// <param name="k"></param>
        /// <param name="v"></param>
        public void setCurrentUserSubkey(string k,string v)
        {
            this._obj_CurrentUser.CreateSubKey(this._str_software_key).SetValue(k, v);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="path_patch"></param>
        private void updatePatch(string path_patch)
        {
            if (Arguments.Update == path_patch)
            {
                this.checkAndUpdate();
            }
            else if (File.Exists(path_patch))
            {
                this._invokeDelegate("更新中。。。。",0,0);
                Filehelper.FileDecrypt(path_patch);
            }
        }
        /// <summary>
        /// チェック＆更新
        /// </summary>
        private void checkAndUpdate()
        {
            this._invokeDelegate("更新データを取得します",0,0);
            List<UpdatePatch> patchs = this.getUpdatePatch();

            patchs.Sort(delegate(UpdatePatch patch1, UpdatePatch patch2)
            {
                return DateTime.Parse(patch1.updatetime) > DateTime.Parse(patch2.updatetime) ? 0 : 1;
            });
            if (patchs.Count > 0)
            {
                using (WebClient wc = new WebClient())
                {
                    this._invokeDelegate("ファイルをダウンロードします",0,0);
                    List<string> downloadList = new List<string>();
                    Int32 i = 0;
                    Int32 patchCount = patchs.Count * 2;
                    patchs.ForEach(delegate(UpdatePatch patch)
                    {
                        if (string.IsNullOrEmpty(patch.url))
                        {
                            File.Delete(Application.StartupPath + "\\" + patch.name);

                        }else if (!downloadList.Contains(patch.url))
                        {
                            this._invokeDelegate(">>>[" + patch.name + "]をダウンロードします", i, patchCount);
                            byte[] dbytes = wc.DownloadData(this._str_updateurl_path + patch.url);
                            i++;
                            this._invokeDelegate(">>>[" + patch.name + "]更新します", i, patchCount);
                            Filehelper.FileDecrypt(dbytes);
                            i++;
                            downloadList.Add(patch.url);
                        }
                    });
                }
            }
        }
        #endregion
    }
}
