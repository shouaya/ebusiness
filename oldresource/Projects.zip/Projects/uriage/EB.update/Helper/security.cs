﻿using System.IO;
using System.Security.Cryptography;

namespace EB.Update
{
    public class security
    {
        private static byte[] _salt = new byte[] { 0x53, 0x74, 0x61, 0x72, 0x62, 0x6f, 0x79, 0x43, 0x68, 0x69, 0x6e, 0x61 };

        /// <summary>
        /// 暗号化
        /// </summary>
        public static byte[] Encrypt(byte[] input)
        {
            return Encrypt(Encrypt(Encrypt(input, "Hikaru"), "Ebusiness"), "SalesSystem");
        }
        /// <summary>
        /// 復号化
        /// </summary>
        public static byte[] Decrypt(byte[] input)
        {
            return Decrypt(Decrypt(Decrypt(input, "SalesSystem"), "Ebusiness"), "Hikaru");
        }
        /// <summary>
        /// 暗号化
        /// </summary>
        /// <param name="input"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        private static byte[] Encrypt(byte[] input, string Password)
        {
            MemoryStream ms = new MemoryStream();
            Rijndael alg = Rijndael.Create();


            PasswordDeriveBytes pdb = new PasswordDeriveBytes(Password, _salt);

            alg.Key = pdb.GetBytes(32);
            alg.IV = pdb.GetBytes(16);

            CryptoStream cs = new CryptoStream(ms,
               alg.CreateEncryptor(), CryptoStreamMode.Write);

            cs.Write(input, 0, input.Length);

            cs.Close();

            byte[] encryptedData = ms.ToArray();

            return encryptedData;
        }
        /// <summary>
        /// 復号化
        /// </summary>
        /// <param name="cipherData"></param>
        /// <param name="Password"></param>
        /// <returns></returns>
        private static byte[] Decrypt(byte[] cipherData, string Password)
        {
            MemoryStream ms = new MemoryStream();

            Rijndael alg = Rijndael.Create();

            PasswordDeriveBytes pdb = new PasswordDeriveBytes(Password, _salt);

            alg.Key = pdb.GetBytes(32);
            alg.IV = pdb.GetBytes(16);

            CryptoStream cs = new CryptoStream(ms,
                alg.CreateDecryptor(), CryptoStreamMode.Write);

            cs.Write(cipherData, 0, cipherData.Length);

            cs.Close();

            byte[] decryptedData = ms.ToArray();

            return decryptedData;
        }
    }
}
