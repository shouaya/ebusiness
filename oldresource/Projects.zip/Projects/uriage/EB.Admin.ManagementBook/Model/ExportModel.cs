﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EB.Admin.ManagementBook
{
    public class ExportModel 
    {


        private static List<ExcelModel> _model = null;
        public static List<ExcelModel> getModel(){
            if (_model == null)
            {
                _model = new List<ExcelModel>();
                _model.Add(new ExcelModel { key = "番号", value = "ManagementID" });
                _model.Add(new ExcelModel { key = "技術者氏名", value = "EmployeeName" });
                _model.Add(new ExcelModel { key = "営業担当1", value = "Salesman1Name" });
                _model.Add(new ExcelModel { key = "営業担当2", value = "Salesman2Name" });
                _model.Add(new ExcelModel { key = "所属部門", value = "DeptName" });
                _model.Add(new ExcelModel { key = "仕入先", value = "siireName" });
                _model.Add(new ExcelModel { key = "仕入先担当", value = "siireSales" });
                _model.Add(new ExcelModel { key = "社員区分", value = "EmployeeTypeName" });
                _model.Add(new ExcelModel { key = "顧客会社", value = "CustomerName" });
                _model.Add(new ExcelModel { key = "顧客窓口", value = "CustSalesman" });
                _model.Add(new ExcelModel { key = "プロジェクト名", value = "ContractName" });
                _model.Add(new ExcelModel { key = "作業工程", value = "ProjectName" });
                _model.Add(new ExcelModel { key = "現場", value = "WorkAddr" });
                _model.Add(new ExcelModel { key = "契約開始", value = "StartDate" });
                _model.Add(new ExcelModel { key = "契約終了", value = "EndDate" });
                _model.Add(new ExcelModel { key = "稼働月", value = "WorkMonth" });
                _model.Add(new ExcelModel { key = "売上", value = "Amount" });
                _model.Add(new ExcelModel { key = "稼働下限", value = "MinHour" });
                _model.Add(new ExcelModel { key = "控除単価", value = "MinusUnitPrice" });
                _model.Add(new ExcelModel { key = "稼働上限", value = "MaxHour" });
                _model.Add(new ExcelModel { key = "超過単価", value = "PlusUnitPrice" });
                _model.Add(new ExcelModel { key = "日割計算", value = "Quantity" });
                _model.Add(new ExcelModel { key = "支払サイト", value = "" });
                _model.Add(new ExcelModel { key = "交通費", value = "TranExpense" });
                _model.Add(new ExcelModel { key = "通勤区間", value = "" });
                _model.Add(new ExcelModel { key = "会社区分", value = "" });
                _model.Add(new ExcelModel { key = "仕入原価", value = "siirePrice" });
                _model.Add(new ExcelModel { key = "備考", value = "Memo" });
                _model.Add(new ExcelModel { key = "勤務時間", value = "" });
                _model.Add(new ExcelModel { key = "管理用確認★未確認○対応済●確認済", value = "" });
                _model.Add(new ExcelModel { key = "管理用備考（管理用確認に印付の説明）", value = "" });
                _model.Add(new ExcelModel { key = "注文書届け日", value = "OrderDate" });
                _model.Add(new ExcelModel { key = "注文書番号", value = "OrderNo" });
            }
            return _model;

        }

    }
}
