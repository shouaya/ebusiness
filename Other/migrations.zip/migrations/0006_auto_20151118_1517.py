# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0005_auto_20151116_1928'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='projectmember',
            name='expenses',
        ),
        migrations.RemoveField(
            model_name='subcontractor',
            name='created_date',
        ),
        migrations.RemoveField(
            model_name='subcontractor',
            name='updated_date',
        ),
        migrations.AddField(
            model_name='client',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='client',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='clientmember',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='clientmember',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='clientorder',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='clientorder',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='degree',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='degree',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='expensescategory',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='expensescategory',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='historyproject',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='historyproject',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='member',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='member',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='memberattendance',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='memberattendance',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='memberexpenses',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='memberexpenses',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='os',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='os',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='positionship',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='positionship',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='project',
            name='attendance_type',
            field=models.CharField(default=b'1', max_length=1, verbose_name='\u51fa\u52e4\u306e\u8a08\u7b97\u533a\u5206', choices=[(b'1', '\uff11\uff15\u5206\u3054\u3068'), (b'2', '\uff13\uff10\u5206\u3054\u3068'), (b'3', '\uff11\u6642\u9593\u3054\u3068')]),
        ),
        migrations.AddField(
            model_name='project',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='project',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='project',
            name='max_hours',
            field=models.DecimalField(default=180, help_text='\u8be5\u9879\u76ee\u4ec5\u4ec5\u662f\u4f5c\u4e3a\u9879\u76ee\u4e2d\u5404\u4eba\u5458\u65f6\u95f4\u7684\u9ed8\u8ba4\u8bbe\u7f6e\uff0c\u8ba1\u7b97\u65f6\u4e0d\u4f1a\u4f7f\u7528\u8be5\u503c\u3002', verbose_name='\u6700\u5927\u6642\u9593', max_digits=5, decimal_places=2),
        ),
        migrations.AddField(
            model_name='project',
            name='min_hours',
            field=models.DecimalField(default=160, help_text='\u8be5\u9879\u76ee\u4ec5\u4ec5\u662f\u4f5c\u4e3a\u9879\u76ee\u4e2d\u5404\u4eba\u5458\u65f6\u95f4\u7684\u9ed8\u8ba4\u8bbe\u7f6e\uff0c\u8ba1\u7b97\u65f6\u4e0d\u4f1a\u4f7f\u7528\u8be5\u503c\u3002', verbose_name='\u57fa\u6e96\u6642\u9593', max_digits=5, decimal_places=2),
        ),
        migrations.AddField(
            model_name='projectactivity',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='projectactivity',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='projectmember',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='projectmember',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='projectskill',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='projectskill',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='projectstage',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='projectstage',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='salesperson',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='salesperson',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='section',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='section',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='skill',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='skill',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='subcontractor',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='subcontractor',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AlterField(
            model_name='member',
            name='birthday',
            field=models.DateField(default=datetime.date(2015, 11, 18), null=True, verbose_name='\u751f\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 18), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 18, 15, 17, 22, 353000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='birthday',
            field=models.DateField(default=datetime.date(2015, 11, 18), null=True, verbose_name='\u751f\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 18), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
    ]
