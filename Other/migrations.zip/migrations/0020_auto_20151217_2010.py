# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0019_auto_20151217_1929'),
    ]

    operations = [
        migrations.AddField(
            model_name='project',
            name='insert_date',
            field=models.DateTimeField(auto_now_add=True, verbose_name='\u8ffd\u52a0\u65e5\u6642', null=True),
        ),
        migrations.AddField(
            model_name='project',
            name='update_date',
            field=models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65e5\u6642', null=True),
        ),
        migrations.AlterField(
            model_name='project',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u65e5\u6642', null=True, editable=False, blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 12, 17, 20, 10, 54, 889000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterUniqueTogether(
            name='clientorder',
            unique_together=set([]),
        ),
    ]
