# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0006_auto_20151118_1517'),
    ]

    operations = [
        migrations.AlterField(
            model_name='member',
            name='birthday',
            field=models.DateField(default=datetime.date(2015, 11, 19), null=True, verbose_name='\u751f\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 19), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 19, 12, 47, 3, 70000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='birthday',
            field=models.DateField(default=datetime.date(2015, 11, 19), null=True, verbose_name='\u751f\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 19), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='member_type',
            field=models.IntegerField(default=5, verbose_name='\u793e\u54e1\u533a\u5206', choices=[(0, '\u55b6\u696d\u90e8\u9577'), (5, '\u55b6\u696d\u62c5\u5f53'), (6, '\u53d6\u7de0\u5f79'), (7, '\u4ee3\u8868\u53d6\u7de0\u5f79\u793e\u9577')]),
        ),
    ]
