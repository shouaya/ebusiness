# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0007_auto_20151119_1247'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='clientorder',
            options={'ordering': ['project', 'name', 'start_date', 'end_date'], 'verbose_name': '\u304a\u5ba2\u69d8\u6ce8\u6587\u66f8', 'verbose_name_plural': '\u304a\u5ba2\u69d8\u6ce8\u6587\u66f8'},
        ),
        migrations.AddField(
            model_name='clientorder',
            name='end_date',
            field=models.DateField(default=datetime.date(2015, 11, 30), verbose_name='\u7d42\u4e86\u65e5'),
        ),
        migrations.AddField(
            model_name='clientorder',
            name='start_date',
            field=models.DateField(default=datetime.date(2015, 11, 1), verbose_name='\u958b\u59cb\u65e5'),
        ),
        migrations.AlterField(
            model_name='member',
            name='birthday',
            field=models.DateField(default=datetime.date(2015, 11, 24), null=True, verbose_name='\u751f\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 24), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='memberattendance',
            name='year',
            field=models.CharField(default=b'2015', max_length=4, verbose_name='\u5bfe\u8c61\u5e74', choices=[(b'2014', '2014\u5e74'), (b'2015', '2015\u5e74'), (b'2016', '2016\u5e74'), (b'2017', '2017\u5e74'), (b'2018', '2018\u5e74'), (b'2019', '2019\u5e74'), (b'2020', '2020\u5e74')]),
        ),
        migrations.AlterField(
            model_name='memberexpenses',
            name='year',
            field=models.CharField(default=b'2015', max_length=4, verbose_name='\u5bfe\u8c61\u5e74', choices=[(b'2014', '2014\u5e74'), (b'2015', '2015\u5e74'), (b'2016', '2016\u5e74'), (b'2017', '2017\u5e74'), (b'2018', '2018\u5e74'), (b'2019', '2019\u5e74'), (b'2020', '2020\u5e74')]),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 24, 11, 7, 31, 124000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='birthday',
            field=models.DateField(default=datetime.date(2015, 11, 24), null=True, verbose_name='\u751f\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 24), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterUniqueTogether(
            name='clientorder',
            unique_together=set([('project', 'start_date', 'end_date')]),
        ),
        migrations.AlterUniqueTogether(
            name='project',
            unique_together=set([('name', 'client')]),
        ),
        migrations.RemoveField(
            model_name='clientorder',
            name='month',
        ),
        migrations.RemoveField(
            model_name='clientorder',
            name='year',
        ),
    ]
