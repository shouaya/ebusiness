# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0011_auto_20151125_1857'),
    ]

    operations = [
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 26), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 26, 19, 11, 8, 282000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 26), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
    ]
