# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0018_auto_20151217_1846'),
    ]

    operations = [
        migrations.AddField(
            model_name='clientorder',
            name='order_date',
            field=models.DateField(null=True, verbose_name='\u6ce8\u6587\u65e5'),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 12, 17, 19, 29, 20, 454000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
    ]
