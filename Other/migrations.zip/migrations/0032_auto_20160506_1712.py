# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0031_auto_20160323_1944'),
    ]

    operations = [
        migrations.AddField(
            model_name='project',
            name='is_hourly_pay',
            field=models.BooleanField(default=False, help_text='\u9009\u4e2d\u540e\u5c06\u4f1a\u65e0\u89c6\u4eba\u5458\u7684\u5355\u4ef7\u4e0e\u589e\u51cf\u7b49\u4fe1\u606f\uff0c\u8ba1\u7b97\u8bf7\u6c42\u65f6\u4f1a\u5c06\u603b\u65f6\u95f4\u4e58\u4ee5\u65f6\u85aa\u3002', verbose_name='\u6642\u7d66'),
        ),
        migrations.AddField(
            model_name='projectmember',
            name='hourly_pay',
            field=models.IntegerField(null=True, verbose_name='\u6642\u7d66', blank=True),
        ),
        migrations.AlterField(
            model_name='clientorder',
            name='end_date',
            field=models.DateField(default=datetime.date(2016, 5, 31), verbose_name='\u7d42\u4e86\u65e5'),
        ),
        migrations.AlterField(
            model_name='clientorder',
            name='start_date',
            field=models.DateField(default=datetime.date(2016, 5, 1), verbose_name='\u958b\u59cb\u65e5'),
        ),
        migrations.AlterField(
            model_name='history',
            name='location',
            field=models.CharField(max_length=2, verbose_name='\u4f5c\u696d\u5834\u6240', choices=[(b'01', '\u6771\u5927\u5cf6'), (b'02', '\u7530\u753a'), (b'03', '\u5e9c\u4e2d'), (b'04', '\u897f\u845b\u897f')]),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 5, 6, 17, 12, 19, 868582), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='projectrequest',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True, verbose_name='\u4f5c\u6210\u65e5\u6642', null=True),
        ),
        migrations.AlterField(
            model_name='projectrequest',
            name='updated_date',
            field=models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65e5\u6642', null=True),
        ),
    ]
