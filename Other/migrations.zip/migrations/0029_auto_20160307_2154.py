# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import datetime


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('eb', '0028_auto_20160201_0019'),
    ]

    operations = [
        migrations.AddField(
            model_name='history',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='history',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='issue',
            name='deleted_date',
            field=models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='issue',
            name='is_deleted',
            field=models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False),
        ),
        migrations.AddField(
            model_name='projectrequest',
            name='client_order',
            field=models.ForeignKey(verbose_name='\u6ce8\u6587\u66f8', blank=True, to='eb.ClientOrder', null=True),
        ),
        migrations.AddField(
            model_name='projectrequest',
            name='created_user',
            field=models.ForeignKey(related_name='created_requests', editable=False, to=settings.AUTH_USER_MODEL, null=True, verbose_name='\u4f5c\u6210\u8005'),
        ),
        migrations.AddField(
            model_name='projectrequest',
            name='request_name',
            field=models.CharField(max_length=50, null=True, verbose_name='\u8acb\u6c42\u540d\u79f0', blank=True),
        ),
        migrations.AddField(
            model_name='projectrequest',
            name='updated_user',
            field=models.ForeignKey(related_name='updated_requests', editable=False, to=settings.AUTH_USER_MODEL, null=True, verbose_name='\u66f4\u65b0\u8005'),
        ),
        migrations.AddField(
            model_name='subcontractororder',
            name='created_user',
            field=models.ForeignKey(related_name='created_orders', editable=False, to=settings.AUTH_USER_MODEL, null=True, verbose_name='\u4f5c\u6210\u8005'),
        ),
        migrations.AddField(
            model_name='subcontractororder',
            name='updated_user',
            field=models.ForeignKey(related_name='updated_orders', editable=False, to=settings.AUTH_USER_MODEL, null=True, verbose_name='\u66f4\u65b0\u8005'),
        ),
        migrations.AlterField(
            model_name='clientorder',
            name='end_date',
            field=models.DateField(default=datetime.date(2016, 3, 31), verbose_name='\u7d42\u4e86\u65e5'),
        ),
        migrations.AlterField(
            model_name='clientorder',
            name='start_date',
            field=models.DateField(default=datetime.date(2016, 3, 1), verbose_name='\u958b\u59cb\u65e5'),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 3, 7, 21, 54, 55, 166000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterUniqueTogether(
            name='projectrequest',
            unique_together=set([('project', 'client_order', 'year', 'month')]),
        ),
    ]
