# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import datetime


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('eb', '0027_auto_20160131_1452'),
    ]

    operations = [
        migrations.CreateModel(
            name='Issue',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=30, verbose_name='\u30bf\u30a4\u30c8\u30eb')),
                ('content', models.TextField(verbose_name='\u5185\u5bb9')),
                ('status', models.CharField(default=1, max_length=1, verbose_name='\u30b9\u30c6\u30fc\u30bf\u30b9', choices=[(b'1', '\u63d0\u51fa\u4e2d'), (b'2', '\u5bfe\u5fdc\u4e2d'), (b'3', '\u5bfe\u5fdc\u5b8c\u4e86'), (b'4', '\u30af\u30ed\u30fc\u30ba')])),
                ('created_date', models.DateTimeField(auto_now_add=True, verbose_name='\u4f5c\u6210\u65e5\u6642')),
                ('updated_date', models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65e5\u6642')),
                ('user', models.ForeignKey(editable=False, to=settings.AUTH_USER_MODEL, verbose_name='\u4f5c\u6210\u8005')),
            ],
            options={
                'ordering': ['-created_date'],
                'verbose_name': '\u8ab2\u984c\u7ba1\u7406\u8868',
                'verbose_name_plural': '\u8ab2\u984c\u7ba1\u7406\u8868',
            },
        ),
        migrations.AlterField(
            model_name='clientorder',
            name='end_date',
            field=models.DateField(default=datetime.date(2016, 2, 29), verbose_name='\u7d42\u4e86\u65e5'),
        ),
        migrations.AlterField(
            model_name='clientorder',
            name='start_date',
            field=models.DateField(default=datetime.date(2016, 2, 1), verbose_name='\u958b\u59cb\u65e5'),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 2, 1, 0, 19, 12, 900086), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
    ]
