# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0004_auto_20151116_1503'),
    ]

    operations = [
        migrations.CreateModel(
            name='ExpensesCategory',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=50, verbose_name='\u540d\u79f0')),
            ],
            options={
                'verbose_name': '\u6e05\u7b97\u5206\u985e',
                'verbose_name_plural': '\u6e05\u7b97\u5206\u985e',
            },
        ),
        migrations.CreateModel(
            name='MemberExpenses',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('year', models.CharField(default=b'2015', max_length=4, verbose_name='\u5bfe\u8c61\u5e74', choices=[(b'2015', '2015\u5e74'), (b'2016', '2016\u5e74'), (b'2017', '2017\u5e74'), (b'2018', '2018\u5e74'), (b'2019', '2019\u5e74'), (b'2020', '2020\u5e74')])),
                ('month', models.CharField(max_length=2, verbose_name='\u5bfe\u8c61\u6708', choices=[(b'01', '1\u6708'), (b'02', '2\u6708'), (b'03', '3\u6708'), (b'04', '4\u6708'), (b'05', '5\u6708'), (b'06', '6\u6708'), (b'07', '7\u6708'), (b'08', '8\u6708'), (b'09', '9\u6708'), (b'10', '10\u6708'), (b'11', '11\u6708'), (b'12', '12\u6708')])),
                ('price', models.IntegerField(default=0, verbose_name='\u4fa1\u683c')),
                ('category', models.ForeignKey(verbose_name='\u5206\u985e', to='eb.ExpensesCategory')),
                ('project_member', models.ForeignKey(verbose_name='\u8981\u54e1', to='eb.ProjectMember')),
            ],
            options={
                'ordering': ['project_member', 'year', 'month'],
                'verbose_name': '\u6e05\u7b97\u30ea\u30b9\u30c8',
                'verbose_name_plural': '\u6e05\u7b97\u30ea\u30b9\u30c8',
            },
        ),
        migrations.AddField(
            model_name='company',
            name='branch_no',
            field=models.CharField(max_length=3, null=True, verbose_name='\u652f\u5e97\u756a\u53f7', blank=True),
        ),
        migrations.AddField(
            model_name='memberattendance',
            name='comment',
            field=models.CharField(max_length=50, null=True, verbose_name='\u5099\u8003', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 16, 19, 28, 58, 484000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
    ]
