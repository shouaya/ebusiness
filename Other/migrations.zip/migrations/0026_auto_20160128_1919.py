# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0025_auto_20160125_2023'),
    ]

    operations = [
        migrations.CreateModel(
            name='BpMemberOrderInfo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('year', models.CharField(default=b'2016', max_length=4, verbose_name='\u5bfe\u8c61\u5e74', choices=[(b'2014', '2014\u5e74'), (b'2015', '2015\u5e74'), (b'2016', '2016\u5e74'), (b'2017', '2017\u5e74'), (b'2018', '2018\u5e74'), (b'2019', '2019\u5e74'), (b'2020', '2020\u5e74')])),
                ('month', models.CharField(max_length=2, verbose_name='\u5bfe\u8c61\u6708', choices=[(b'01', '1\u6708'), (b'02', '2\u6708'), (b'03', '3\u6708'), (b'04', '4\u6708'), (b'05', '5\u6708'), (b'06', '6\u6708'), (b'07', '7\u6708'), (b'08', '8\u6708'), (b'09', '9\u6708'), (b'10', '10\u6708'), (b'11', '11\u6708'), (b'12', '12\u6708')])),
                ('min_hours', models.DecimalField(default=160, verbose_name='\u57fa\u6e96\u6642\u9593', max_digits=5, decimal_places=2)),
                ('max_hours', models.DecimalField(default=180, verbose_name='\u6700\u5927\u6642\u9593', max_digits=5, decimal_places=2)),
                ('plus_per_hour', models.IntegerField(default=0, verbose_name='\u5897\uff08\u5186\uff09')),
                ('minus_per_hour', models.IntegerField(default=0, verbose_name='\u6e1b\uff08\u5186\uff09')),
                ('comment', models.CharField(max_length=50, null=True, verbose_name='\u5099\u8003', blank=True)),
                ('is_deleted', models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False)),
                ('deleted_date', models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True)),
                ('member', models.ForeignKey(verbose_name='\u5354\u529b\u793e\u54e1', to='eb.Member')),
            ],
            options={
                'verbose_name': '\u5354\u529b\u793e\u54e1\u306e\u6ce8\u6587\u60c5\u5831',
                'verbose_name_plural': '\u5354\u529b\u793e\u54e1\u306e\u6ce8\u6587\u60c5\u5831',
            },
        ),
        migrations.CreateModel(
            name='SubcontractorOrder',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('order_no', models.CharField(unique=True, max_length=14, verbose_name='\u6ce8\u6587\u756a\u53f7')),
                ('year', models.CharField(default=b'2016', max_length=4, verbose_name='\u5bfe\u8c61\u5e74', choices=[(b'2014', '2014\u5e74'), (b'2015', '2015\u5e74'), (b'2016', '2016\u5e74'), (b'2017', '2017\u5e74'), (b'2018', '2018\u5e74'), (b'2019', '2019\u5e74'), (b'2020', '2020\u5e74')])),
                ('month', models.CharField(max_length=2, verbose_name='\u5bfe\u8c61\u6708', choices=[(b'01', '1\u6708'), (b'02', '2\u6708'), (b'03', '3\u6708'), (b'04', '4\u6708'), (b'05', '5\u6708'), (b'06', '6\u6708'), (b'07', '7\u6708'), (b'08', '8\u6708'), (b'09', '9\u6708'), (b'10', '10\u6708'), (b'11', '11\u6708'), (b'12', '12\u6708')])),
                ('created_date', models.DateTimeField(auto_now_add=True, verbose_name='\u8ffd\u52a0\u65e5\u6642')),
                ('updated_date', models.DateTimeField(auto_now=True, verbose_name='\u66f4\u65b0\u65e5\u6642')),
                ('is_deleted', models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False)),
                ('deleted_date', models.DateTimeField(verbose_name='\u524a\u9664\u65e5\u6642', null=True, editable=False, blank=True)),
                ('subcontractor', models.ForeignKey(verbose_name='\u5354\u529b\u4f1a\u793e', to='eb.Subcontractor')),
            ],
            options={
                'verbose_name': '\uff22\uff30\u8a3b\u6587\u66f8',
                'verbose_name_plural': '\uff22\uff30\u8a3b\u6587\u66f8',
            },
        ),
        migrations.AddField(
            model_name='company',
            name='order_file',
            field=models.FileField(help_text='\u5354\u529b\u4f1a\u793e\u3078\u306e\u8a3b\u6587\u66f8\u3002', upload_to=b'./eb_order', null=True, verbose_name='\u8a3b\u6587\u66f8\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 1, 28, 19, 19, 37, 568019), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterUniqueTogether(
            name='subcontractororder',
            unique_together=set([('subcontractor', 'year', 'month')]),
        ),
        migrations.AlterUniqueTogether(
            name='bpmemberorderinfo',
            unique_together=set([('member', 'year', 'month')]),
        ),
    ]
