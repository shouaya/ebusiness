# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0016_auto_20151214_2129'),
    ]

    operations = [
        migrations.AddField(
            model_name='company',
            name='request_file',
            field=models.FileField(upload_to=b'./request', null=True, verbose_name='\u8acb\u6c42\u66f8\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 12, 14, 21, 37, 27), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
    ]
