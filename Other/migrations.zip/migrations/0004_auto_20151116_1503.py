# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import eb.models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0003_auto_20151112_1809'),
    ]

    operations = [
        migrations.CreateModel(
            name='ClientOrder',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=30, verbose_name='\u6ce8\u6587\u66f8\u540d\u79f0')),
                ('year', models.CharField(default=b'2015', max_length=4, verbose_name='\u5bfe\u8c61\u5e74', choices=[(b'2015', '2015\u5e74'), (b'2016', '2016\u5e74'), (b'2017', '2017\u5e74'), (b'2018', '2018\u5e74'), (b'2019', '2019\u5e74'), (b'2020', '2020\u5e74')])),
                ('month', models.CharField(max_length=2, verbose_name='\u5bfe\u8c61\u6708', choices=[(b'01', '1\u6708'), (b'02', '2\u6708'), (b'03', '3\u6708'), (b'04', '4\u6708'), (b'05', '5\u6708'), (b'06', '6\u6708'), (b'07', '7\u6708'), (b'08', '8\u6708'), (b'09', '9\u6708'), (b'10', '10\u6708'), (b'11', '11\u6708'), (b'12', '12\u6708')])),
                ('order_no', models.CharField(max_length=20, verbose_name='\u6ce8\u6587\u756a\u53f7')),
                ('order_file', models.FileField(upload_to=eb.models.get_client_order_path, null=True, verbose_name='\u6ce8\u6587\u66f8', blank=True)),
                ('project', models.ForeignKey(verbose_name='\u6848\u4ef6', to='eb.Project')),
            ],
            options={
                'ordering': ['project', 'name', 'year', 'month'],
                'verbose_name': '\u304a\u5ba2\u69d8\u6ce8\u6587\u66f8',
                'verbose_name_plural': '\u304a\u5ba2\u69d8\u6ce8\u6587\u66f8',
            },
        ),
        migrations.RemoveField(
            model_name='client',
            name='payment_type',
        ),
        migrations.RemoveField(
            model_name='subcontractor',
            name='payment_type',
        ),
        migrations.AddField(
            model_name='company',
            name='account_holder',
            field=models.CharField(max_length=20, null=True, verbose_name='\u53e3\u5ea7\u540d\u7fa9', blank=True),
        ),
        migrations.AddField(
            model_name='member',
            name='is_retired',
            field=models.BooleanField(default=False, verbose_name='\u9000\u8077'),
        ),
        migrations.AddField(
            model_name='memberattendance',
            name='price',
            field=models.IntegerField(default=0, verbose_name='\u4fa1\u683c'),
        ),
        migrations.AddField(
            model_name='memberattendance',
            name='rate',
            field=models.DecimalField(default=1, verbose_name='\u7387', max_digits=3, decimal_places=2),
        ),
        migrations.AddField(
            model_name='salesperson',
            name='is_retired',
            field=models.BooleanField(default=False, verbose_name='\u9000\u8077'),
        ),
        migrations.AddField(
            model_name='section',
            name='is_on_sales',
            field=models.BooleanField(default=False, verbose_name='\u55b6\u696d\u5bfe\u8c61'),
        ),
        migrations.AddField(
            model_name='subcontractor',
            name='payment_month',
            field=models.CharField(default=b'1', choices=[(b'1', '\u7fcc\u6708'), (b'2', '\u7fcc\u3005\u6708'), (b'3', '\uff13\u6708'), (b'4', '\uff14\u6708'), (b'5', '\uff15\u6708'), (b'6', '\uff16\u6708')], max_length=1, blank=True, null=True, verbose_name='\u652f\u6255\u3044\u30b5\u30a4\u30c8'),
        ),
        migrations.AlterField(
            model_name='client',
            name='payment_day',
            field=models.CharField(default=b'99', choices=[(b'01', '1\u65e5'), (b'02', '2\u65e5'), (b'03', '3\u65e5'), (b'04', '4\u65e5'), (b'05', '5\u65e5'), (b'06', '6\u65e5'), (b'07', '7\u65e5'), (b'08', '8\u65e5'), (b'09', '9\u65e5'), (b'10', '10\u65e5'), (b'11', '11\u65e5'), (b'12', '12\u65e5'), (b'13', '13\u65e5'), (b'14', '14\u65e5'), (b'15', '15\u65e5'), (b'16', '16\u65e5'), (b'17', '17\u65e5'), (b'18', '18\u65e5'), (b'19', '19\u65e5'), (b'20', '20\u65e5'), (b'21', '21\u65e5'), (b'22', '22\u65e5'), (b'23', '23\u65e5'), (b'24', '24\u65e5'), (b'25', '25\u65e5'), (b'26', '26\u65e5'), (b'27', '27\u65e5'), (b'28', '28\u65e5'), (b'29', '29\u65e5'), (b'30', '30\u65e5'), (b'99', '\u6708\u672b')], max_length=2, blank=True, null=True, verbose_name='\u652f\u6255\u65e5'),
        ),
        migrations.AlterField(
            model_name='client',
            name='payment_month',
            field=models.CharField(default=b'1', choices=[(b'1', '\u7fcc\u6708'), (b'2', '\u7fcc\u3005\u6708'), (b'3', '\uff13\u6708'), (b'4', '\uff14\u6708'), (b'5', '\uff15\u6708'), (b'6', '\uff16\u6708')], max_length=1, blank=True, null=True, verbose_name='\u652f\u6255\u3044\u30b5\u30a4\u30c8'),
        ),
        migrations.AlterField(
            model_name='member',
            name='birthday',
            field=models.DateField(default=datetime.date(2015, 11, 16), verbose_name='\u751f\u5e74\u6708\u65e5'),
        ),
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 16), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 16, 15, 3, 51, 6000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='birthday',
            field=models.DateField(default=datetime.date(2015, 11, 16), verbose_name='\u751f\u5e74\u6708\u65e5'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 16), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='subcontractor',
            name='payment_day',
            field=models.CharField(default=b'99', choices=[(b'01', '1\u65e5'), (b'02', '2\u65e5'), (b'03', '3\u65e5'), (b'04', '4\u65e5'), (b'05', '5\u65e5'), (b'06', '6\u65e5'), (b'07', '7\u65e5'), (b'08', '8\u65e5'), (b'09', '9\u65e5'), (b'10', '10\u65e5'), (b'11', '11\u65e5'), (b'12', '12\u65e5'), (b'13', '13\u65e5'), (b'14', '14\u65e5'), (b'15', '15\u65e5'), (b'16', '16\u65e5'), (b'17', '17\u65e5'), (b'18', '18\u65e5'), (b'19', '19\u65e5'), (b'20', '20\u65e5'), (b'21', '21\u65e5'), (b'22', '22\u65e5'), (b'23', '23\u65e5'), (b'24', '24\u65e5'), (b'25', '25\u65e5'), (b'26', '26\u65e5'), (b'27', '27\u65e5'), (b'28', '28\u65e5'), (b'29', '29\u65e5'), (b'30', '30\u65e5'), (b'99', '\u6708\u672b')], max_length=2, blank=True, null=True, verbose_name='\u652f\u6255\u65e5'),
        ),
        migrations.AlterUniqueTogether(
            name='clientorder',
            unique_together=set([('project', 'year', 'month')]),
        ),
    ]
