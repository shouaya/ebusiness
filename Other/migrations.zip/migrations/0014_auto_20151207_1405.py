# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0013_auto_20151202_1911'),
    ]

    operations = [
        migrations.CreateModel(
            name='ProjectRequest',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('year', models.CharField(default=b'2015', max_length=4, verbose_name='\u5bfe\u8c61\u5e74', choices=[(b'2014', '2014\u5e74'), (b'2015', '2015\u5e74'), (b'2016', '2016\u5e74'), (b'2017', '2017\u5e74'), (b'2018', '2018\u5e74'), (b'2019', '2019\u5e74'), (b'2020', '2020\u5e74')])),
                ('month', models.CharField(max_length=2, verbose_name='\u5bfe\u8c61\u6708', choices=[(b'01', '1\u6708'), (b'02', '2\u6708'), (b'03', '3\u6708'), (b'04', '4\u6708'), (b'05', '5\u6708'), (b'06', '6\u6708'), (b'07', '7\u6708'), (b'08', '8\u6708'), (b'09', '9\u6708'), (b'10', '10\u6708'), (b'11', '11\u6708'), (b'12', '12\u6708')])),
                ('request_no', models.CharField(max_length=7, verbose_name='\u8acb\u6c42\u756a\u53f7')),
                ('amount', models.IntegerField(default=0, verbose_name='\u8acb\u6c42\u91d1\u984d')),
                ('project', models.ForeignKey(verbose_name='\u6848\u4ef6', to='eb.Project')),
            ],
        ),
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 12, 7), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 12, 7, 14, 5, 24, 897000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 12, 7), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
    ]
