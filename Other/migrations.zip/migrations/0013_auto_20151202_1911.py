# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0012_auto_20151126_1911'),
    ]

    operations = [
        migrations.CreateModel(
            name='BankInfo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('bank_name', models.CharField(max_length=20, verbose_name='\u9280\u884c\u540d\u79f0')),
                ('branch_no', models.CharField(max_length=3, verbose_name='\u652f\u5e97\u756a\u53f7')),
                ('branch_name', models.CharField(max_length=20, verbose_name='\u652f\u5e97\u540d\u79f0')),
                ('account_type', models.CharField(max_length=1, verbose_name='\u9810\u91d1\u7a2e\u985e', choices=[(b'1', '\u666e\u901a\u9810\u91d1'), (b'2', '\u5b9a\u671f\u9810\u91d1'), (b'3', '\u7dcf\u5408\u53e3\u5ea7'), (b'4', '\u5f53\u5ea7\u9810\u91d1'), (b'5', '\u8caf\u84c4\u9810\u91d1'), (b'6', '\u5927\u53e3\u5b9a\u671f\u9810\u91d1'), (b'7', '\u7a4d\u7acb\u5b9a\u671f\u9810\u91d1')])),
                ('account_number', models.CharField(max_length=7, verbose_name='\u53e3\u5ea7\u756a\u53f7')),
                ('account_holder', models.CharField(max_length=20, null=True, verbose_name='\u53e3\u5ea7\u540d\u7fa9', blank=True)),
                ('is_deleted', models.BooleanField(default=False, verbose_name='\u524a\u9664\u30d5\u30e9\u30b0', editable=False)),
                ('deleted_date', models.DateTimeField(verbose_name='\u524a\u9664\u5e74\u6708\u65e5', null=True, editable=False, blank=True)),
            ],
            options={
                'verbose_name': '\u9280\u884c\u53e3\u5ea7',
                'verbose_name_plural': '\u9280\u884c\u53e3\u5ea7',
            },
        ),
        migrations.RemoveField(
            model_name='company',
            name='account_holder',
        ),
        migrations.RemoveField(
            model_name='company',
            name='account_number',
        ),
        migrations.RemoveField(
            model_name='company',
            name='account_type',
        ),
        migrations.RemoveField(
            model_name='company',
            name='bank_name',
        ),
        migrations.RemoveField(
            model_name='company',
            name='branch_name',
        ),
        migrations.RemoveField(
            model_name='company',
            name='branch_no',
        ),
        migrations.AlterField(
            model_name='clientorder',
            name='end_date',
            field=models.DateField(default=datetime.date(2015, 12, 31), verbose_name='\u7d42\u4e86\u65e5'),
        ),
        migrations.AlterField(
            model_name='clientorder',
            name='start_date',
            field=models.DateField(default=datetime.date(2015, 12, 1), verbose_name='\u958b\u59cb\u65e5'),
        ),
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 12, 2), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 12, 2, 19, 11, 4, 653000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 12, 2), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AddField(
            model_name='bankinfo',
            name='company',
            field=models.ForeignKey(verbose_name='\u4f1a\u793e', to='eb.Company'),
        ),
        migrations.AddField(
            model_name='clientorder',
            name='bank_info',
            field=models.ForeignKey(verbose_name='\u632f\u8fbc\u5148\u53e3\u5ea7', to='eb.BankInfo', null=True),
        ),
        migrations.AlterUniqueTogether(
            name='bankinfo',
            unique_together=set([('branch_no', 'account_number')]),
        ),
    ]
