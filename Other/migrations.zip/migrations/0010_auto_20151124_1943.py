# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime
from decimal import Decimal


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0009_auto_20151124_1115'),
    ]

    operations = [
        migrations.AddField(
            model_name='client',
            name='decimal_type',
            field=models.CharField(default=b'0', max_length=1, verbose_name='\u5c0f\u6570\u306e\u51e6\u7406\u533a\u5206', choices=[(b'0', '\u56db\u6368\u4e94\u5165'), (b'1', '\u5207\u308a\u6368\u3066')]),
        ),
        migrations.AddField(
            model_name='client',
            name='tax_rate',
            field=models.DecimalField(default=0.08, verbose_name='\u7a0e\u7387', max_digits=3, decimal_places=2, choices=[(Decimal('0.00'), '\u7a0e\u306a\u3057'), (Decimal('0.05'), '5\uff05'), (Decimal('0.08'), '8\uff05')]),
        ),
        migrations.AddField(
            model_name='projectmember',
            name='minus_per_hour',
            field=models.IntegerField(help_text='\u8be5\u9879\u76ee\u4ec5\u4ec5\u662f\u4f5c\u4e3a\u9ed8\u8ba4\u8bbe\u7f6e\uff0c\u8ba1\u7b97\u65f6\u4e0d\u4f1a\u4f7f\u7528\u8be5\u503c\u3002', null=True, verbose_name='\u6e1b\uff08\u5186\uff09', blank=True),
        ),
        migrations.AddField(
            model_name='projectmember',
            name='plus_per_hour',
            field=models.IntegerField(help_text='\u8be5\u9879\u76ee\u4ec5\u4ec5\u662f\u4f5c\u4e3a\u9ed8\u8ba4\u8bbe\u7f6e\uff0c\u8ba1\u7b97\u65f6\u4e0d\u4f1a\u4f7f\u7528\u8be5\u503c\u3002', null=True, verbose_name='\u5897\uff08\u5186\uff09', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 24, 19, 43, 30, 878000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
    ]
