# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0029_auto_20160307_2154'),
    ]

    operations = [
        migrations.AlterField(
            model_name='clientorder',
            name='name',
            field=models.CharField(max_length=50, verbose_name='\u6ce8\u6587\u66f8\u540d\u79f0'),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 3, 23, 16, 24, 13, 418708), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
    ]
