# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='client',
            name='payment_month',
            field=models.CharField(blank=True, max_length=1, null=True, verbose_name='\u652f\u6255\u3044\u30b5\u30a4\u30c8', choices=[(b'1', '\u7fcc\u6708'), (b'2', '\u7fcc\u3005\u6708'), (b'3', '\uff13\u6708'), (b'4', '\uff14\u6708'), (b'5', '\uff15\u6708'), (b'6', '\uff16\u6708')]),
        ),
        migrations.AlterField(
            model_name='member',
            name='birthday',
            field=models.DateField(default=datetime.date(2015, 11, 12), verbose_name='\u751f\u5e74\u6708\u65e5'),
        ),
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 12), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 11, 12, 15, 33, 31, 668000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='birthday',
            field=models.DateField(default=datetime.date(2015, 11, 12), verbose_name='\u751f\u5e74\u6708\u65e5'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 11, 12), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
    ]
