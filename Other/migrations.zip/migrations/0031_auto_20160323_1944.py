# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0030_auto_20160323_1624'),
    ]

    operations = [
        migrations.AddField(
            model_name='member',
            name='is_individual_pay',
            field=models.BooleanField(default=False, verbose_name='\u500b\u5225\u7cbe\u7b97'),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 3, 23, 19, 44, 40, 99179), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
    ]
