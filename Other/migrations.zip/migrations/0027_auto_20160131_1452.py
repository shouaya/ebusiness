# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0026_auto_20160128_1919'),
    ]

    operations = [
        migrations.AddField(
            model_name='bpmemberorderinfo',
            name='cost',
            field=models.IntegerField(default=0, verbose_name='\u30b3\u30b9\u30c8'),
        ),
        migrations.AlterField(
            model_name='member',
            name='cost',
            field=models.IntegerField(default=0, verbose_name='\u30b3\u30b9\u30c8'),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 1, 31, 14, 52, 27, 943004), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
    ]
