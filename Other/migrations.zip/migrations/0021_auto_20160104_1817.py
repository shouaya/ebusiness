# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0020_auto_20151217_2010'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='clientorder',
            options={'ordering': ['name', 'start_date', 'end_date'], 'verbose_name': '\u304a\u5ba2\u69d8\u6ce8\u6587\u66f8', 'verbose_name_plural': '\u304a\u5ba2\u69d8\u6ce8\u6587\u66f8'},
        ),
        migrations.RemoveField(
            model_name='clientorder',
            name='project',
        ),
        migrations.AddField(
            model_name='clientorder',
            name='member_comma_list',
            field=models.CommaSeparatedIntegerField(verbose_name='\u30e1\u30f3\u30d0\u30fc\u4e3b\u30ad\u30fc\u306e\u30ea\u30b9\u30c8', max_length=255, null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='clientorder',
            name='projects',
            field=models.ManyToManyField(to='eb.Project', verbose_name='\u6848\u4ef6'),
        ),
        migrations.AddField(
            model_name='project',
            name='lump_comment',
            field=models.CharField(help_text='\u8be5\u9879\u76ee\u4f1a\u4f5c\u4e3a\u8bf7\u6c42\u4e66\u4e2d\u5099\u8003\u680f\u4e2d\u7684\u503c\u3002', max_length=200, null=True, verbose_name='\u4e00\u62ec\u306e\u5099\u8003', blank=True),
        ),
        migrations.AlterField(
            model_name='clientorder',
            name='end_date',
            field=models.DateField(default=datetime.date(2016, 1, 31), verbose_name='\u7d42\u4e86\u65e5'),
        ),
        migrations.AlterField(
            model_name='clientorder',
            name='start_date',
            field=models.DateField(default=datetime.date(2016, 1, 1), verbose_name='\u958b\u59cb\u65e5'),
        ),
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2016, 1, 4), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='memberattendance',
            name='year',
            field=models.CharField(default=b'2016', max_length=4, verbose_name='\u5bfe\u8c61\u5e74', choices=[(b'2014', '2014\u5e74'), (b'2015', '2015\u5e74'), (b'2016', '2016\u5e74'), (b'2017', '2017\u5e74'), (b'2018', '2018\u5e74'), (b'2019', '2019\u5e74'), (b'2020', '2020\u5e74')]),
        ),
        migrations.AlterField(
            model_name='memberexpenses',
            name='year',
            field=models.CharField(default=b'2016', max_length=4, verbose_name='\u5bfe\u8c61\u5e74', choices=[(b'2014', '2014\u5e74'), (b'2015', '2015\u5e74'), (b'2016', '2016\u5e74'), (b'2017', '2017\u5e74'), (b'2018', '2018\u5e74'), (b'2019', '2019\u5e74'), (b'2020', '2020\u5e74')]),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 1, 4, 18, 17, 21, 573000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='projectrequest',
            name='year',
            field=models.CharField(default=b'2016', max_length=4, verbose_name='\u5bfe\u8c61\u5e74', choices=[(b'2014', '2014\u5e74'), (b'2015', '2015\u5e74'), (b'2016', '2016\u5e74'), (b'2017', '2017\u5e74'), (b'2018', '2018\u5e74'), (b'2019', '2019\u5e74'), (b'2020', '2020\u5e74')]),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2016, 1, 4), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
    ]
