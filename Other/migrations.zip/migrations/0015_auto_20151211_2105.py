# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0014_auto_20151207_1405'),
    ]

    operations = [
        migrations.AddField(
            model_name='client',
            name='quotation_file',
            field=models.FileField(upload_to=b'./quotation', null=True, verbose_name='\u898b\u7a4d\u66f8\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8', blank=True),
        ),
        migrations.AddField(
            model_name='company',
            name='quotation_file',
            field=models.FileField(upload_to=b'./quotation', null=True, verbose_name='\u898b\u7a4d\u66f8\u30c6\u30f3\u30d7\u30ec\u30fc\u30c8', blank=True),
        ),
        migrations.AddField(
            model_name='member',
            name='coordinate_update_date',
            field=models.DateTimeField(verbose_name='\u5ea7\u6a19\u66f4\u65b0\u65e5\u6642', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='member',
            name='lat',
            field=models.CharField(max_length=25, null=True, verbose_name='\u7def\u5ea6', blank=True),
        ),
        migrations.AddField(
            model_name='member',
            name='lng',
            field=models.CharField(max_length=25, null=True, verbose_name='\u7d4c\u5ea6', blank=True),
        ),
        migrations.AddField(
            model_name='salesperson',
            name='coordinate_update_date',
            field=models.DateTimeField(verbose_name='\u5ea7\u6a19\u66f4\u65b0\u65e5\u6642', null=True, editable=False, blank=True),
        ),
        migrations.AddField(
            model_name='salesperson',
            name='lat',
            field=models.CharField(max_length=25, null=True, verbose_name='\u7def\u5ea6', blank=True),
        ),
        migrations.AddField(
            model_name='salesperson',
            name='lng',
            field=models.CharField(max_length=25, null=True, verbose_name='\u7d4c\u5ea6', blank=True),
        ),
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 12, 11), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 12, 11, 21, 5, 13, 430000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 12, 11), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
    ]
