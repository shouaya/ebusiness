# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0023_auto_20160119_0121'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='projectrequest',
            options={'ordering': ['-request_no'], 'verbose_name': '\u6848\u4ef6\u8acb\u6c42\u60c5\u5831', 'verbose_name_plural': '\u6848\u4ef6\u8acb\u6c42\u60c5\u5831'},
        ),
        migrations.AddField(
            model_name='memberattendance',
            name='basic_price',
            field=models.IntegerField(default=0, verbose_name='\u5358\u4fa1', editable=False),
        ),
        migrations.AddField(
            model_name='memberattendance',
            name='max_hours',
            field=models.DecimalField(default=180, verbose_name='\u6700\u5927\u6642\u9593', editable=False, max_digits=5, decimal_places=2),
        ),
        migrations.AddField(
            model_name='memberattendance',
            name='min_hours',
            field=models.DecimalField(default=160, verbose_name='\u57fa\u6e96\u6642\u9593', editable=False, max_digits=5, decimal_places=2),
        ),
        migrations.AddField(
            model_name='memberattendance',
            name='minus_per_hour',
            field=models.IntegerField(default=0, verbose_name='\u6e1b\uff08\u5186\uff09', editable=False),
        ),
        migrations.AddField(
            model_name='memberattendance',
            name='plus_per_hour',
            field=models.IntegerField(default=0, verbose_name='\u5897\uff08\u5186\uff09', editable=False),
        ),
        migrations.AddField(
            model_name='projectrequest',
            name='created_date',
            field=models.DateTimeField(auto_now_add=True, null=True),
        ),
        migrations.AddField(
            model_name='projectrequest',
            name='updated_date',
            field=models.DateTimeField(auto_now=True, null=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 1, 23, 20, 59, 50, 253016), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='projectmember',
            name='status',
            field=models.IntegerField(default=1, verbose_name='\u30b9\u30c6\u30fc\u30bf\u30b9', choices=[(1, '\u63d0\u6848\u4e2d'), (2, '\u4f5c\u696d\u78ba\u5b9a')]),
        ),
        migrations.AlterField(
            model_name='projectrequest',
            name='request_no',
            field=models.CharField(unique=True, max_length=7, verbose_name='\u8acb\u6c42\u756a\u53f7'),
        ),
        migrations.AlterUniqueTogether(
            name='projectrequest',
            unique_together=set([('project', 'year', 'month')]),
        ),
    ]
