# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0017_auto_20151214_2137'),
    ]

    operations = [
        migrations.AddField(
            model_name='project',
            name='is_lump',
            field=models.BooleanField(default=False, verbose_name='\u4e00\u62ec\u30d5\u30e9\u30b0'),
        ),
        migrations.AddField(
            model_name='project',
            name='lump_amount',
            field=models.BigIntegerField(default=0, null=True, verbose_name='\u4e00\u62ec\u91d1\u984d', blank=True),
        ),
        migrations.AlterField(
            model_name='member',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 12, 17), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2015, 12, 17, 18, 46, 4, 387000), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
        migrations.AlterField(
            model_name='salesperson',
            name='join_date',
            field=models.DateField(default=datetime.date(2015, 12, 17), null=True, verbose_name='\u5165\u793e\u5e74\u6708\u65e5', blank=True),
        ),
    ]
