# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import datetime


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('eb', '0032_auto_20160506_1712'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='memberattendance',
            options={'ordering': ['project_member', 'year', 'month'], 'verbose_name': '\u52e4\u52d9\u6642\u9593', 'verbose_name_plural': '\u52e4\u52d9\u6642\u9593', 'permissions': (('input_attendance', '\u52e4\u6020\u5165\u529b'),)},
        ),
        migrations.AlterModelOptions(
            name='projectrequest',
            options={'ordering': ['-request_no'], 'verbose_name': '\u6848\u4ef6\u8acb\u6c42\u60c5\u5831', 'verbose_name_plural': '\u6848\u4ef6\u8acb\u6c42\u60c5\u5831', 'permissions': (('generate_request', '\u8acb\u6c42\u66f8\u4f5c\u6210'),)},
        ),
        migrations.AddField(
            model_name='issue',
            name='end_date',
            field=models.DateField(null=True, verbose_name='\u4e88\u5b9a\u5b8c\u4e86\u65e5', blank=True),
        ),
        migrations.AddField(
            model_name='issue',
            name='level',
            field=models.PositiveSmallIntegerField(default=1, verbose_name='\u512a\u5148\u5ea6', choices=[(1, '\u4f4e'), (2, '\u4e2d'), (3, '\u9ad8'), (4, '\u81f3\u6025'), (5, '\u5927\u81f3\u6025')]),
        ),
        migrations.AddField(
            model_name='issue',
            name='limit_date',
            field=models.DateField(null=True, verbose_name='\u671f\u9650\u65e5', blank=True),
        ),
        migrations.AddField(
            model_name='issue',
            name='resolve_user',
            field=models.ForeignKey(related_name='resolve_issue_set', verbose_name='\u5bfe\u5fdc\u8005', blank=True, to=settings.AUTH_USER_MODEL, null=True),
        ),
        migrations.AddField(
            model_name='issue',
            name='solution',
            field=models.TextField(null=True, verbose_name='\u5bfe\u5fdc\u65b9\u6cd5', blank=True),
        ),
        migrations.AddField(
            model_name='projectrequest',
            name='filename',
            field=models.CharField(max_length=255, null=True, verbose_name='\u8acb\u6c42\u66f8\u30d5\u30a1\u30a4\u30eb\u540d', blank=True),
        ),
        migrations.AlterField(
            model_name='issue',
            name='user',
            field=models.ForeignKey(related_name='created_issue_set', editable=False, to=settings.AUTH_USER_MODEL, verbose_name='\u4f5c\u6210\u8005'),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 5, 17, 15, 8, 10, 821980), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
    ]
