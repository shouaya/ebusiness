# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('eb', '0024_auto_20160123_2059'),
    ]

    operations = [
        migrations.AddField(
            model_name='member',
            name='is_notify',
            field=models.BooleanField(default=False, verbose_name='\u30e1\u30fc\u30eb\u901a\u77e5'),
        ),
        migrations.AddField(
            model_name='member',
            name='notify_type',
            field=models.IntegerField(blank=True, null=True, verbose_name='\u901a\u77e5\u7a2e\u985e', choices=[(1, 'EB\u306e\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9'), (2, '\u500b\u4eba\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9'), (3, 'EB\u3068\u500b\u4eba\u4e21\u65b9\u306e\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9')]),
        ),
        migrations.AddField(
            model_name='salesperson',
            name='is_notify',
            field=models.BooleanField(default=False, verbose_name='\u30e1\u30fc\u30eb\u901a\u77e5'),
        ),
        migrations.AddField(
            model_name='salesperson',
            name='notify_type',
            field=models.IntegerField(blank=True, null=True, verbose_name='\u901a\u77e5\u7a2e\u985e', choices=[(1, 'EB\u306e\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9'), (2, '\u500b\u4eba\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9'), (3, 'EB\u3068\u500b\u4eba\u4e21\u65b9\u306e\u30e1\u30fc\u30eb\u30a2\u30c9\u30ec\u30b9')]),
        ),
        migrations.AlterField(
            model_name='memberattendance',
            name='max_hours',
            field=models.DecimalField(default=0, verbose_name='\u6700\u5927\u6642\u9593', editable=False, max_digits=5, decimal_places=2),
        ),
        migrations.AlterField(
            model_name='memberattendance',
            name='min_hours',
            field=models.DecimalField(default=0, verbose_name='\u57fa\u6e96\u6642\u9593', editable=False, max_digits=5, decimal_places=2),
        ),
        migrations.AlterField(
            model_name='projectactivity',
            name='open_date',
            field=models.DateTimeField(default=datetime.datetime(2016, 1, 25, 20, 23, 33, 170399), verbose_name='\u958b\u50ac\u65e5\u6642'),
        ),
    ]
